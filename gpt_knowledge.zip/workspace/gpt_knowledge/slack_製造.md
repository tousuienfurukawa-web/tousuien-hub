# Slack channel: 製造

## 2023-08-01

- [1690938007.354079] <@U0331FWGQRM>: <@U0331FWGQRM>さんがチャンネルに参加しました
- [1690938010.623299] <@U0331FZS7JT>: <@U0331FZS7JT>さんがチャンネルに参加しました
- [1690938010.768829] <@U0331FZTHEK>: <@U0331FZTHEK>さんがチャンネルに参加しました
- [1690938010.854909] <@U033G4KN4TD>: <@U033G4KN4TD>さんがチャンネルに参加しました
- [1690938010.942149] <@U03BLQ65GK0>: <@U03BLQ65GK0>さんがチャンネルに参加しました
- [1690938011.051459] <@U041RJKV5JA>: <@U041RJKV5JA>さんがチャンネルに参加しました
- [1690938011.133109] <@U05KGS6HN9H>: <@U05KGS6HN9H>さんがチャンネルに参加しました

## 2023-08-24

- [1692927228.220219] <@U0331FZS7JT>: <@U03BLQ65GK0>

今年の簡易棚（碾茶ロットKT）と
直掛け（JT）の上の
残数量を教えてください。
品種は
・やぶきた
・おくみどり

それで、その中で良さそうなパウダーを
見たいので、準備をお願いします。
- [1692929530.843039] <@U03BLQ65GK0>: <@U0331FZS7JT>
【JT】
■やぶきた
・JT1-02：194.3kg
・JT1-04：45.8kg（火香強）
・JT1-05：266.5kg（火香強）
合計：506.6kg
■おくみどり
・JT1-06：28.2kg（火香強）
・JT1-07：112.2kg
合計140.4kg

【KT】
■やぶきた
・KT-01：43.2kg
■おくみどり
・KT1-03：31.9kg

以上です。
よろしくお願いします。

## 2023-09-26

- [1695776021.149339] <@U0331FZS7JT>: <@U041RJKV5JA> <@U033G4KN4TD> <@U0331FZTHEK> <@U05KGS6HN9H>

インド展示会に向け、下記の準備をお願いします。
〈抹茶〉
碧翠園￥16,000：100g×10（ALの袋）　
〈抹茶カプチーノ〉
100g×27袋（ALの袋）
15g(スティック)×400本
〈その他〉全て有機で50g×１
ターメリックパウダー
ジンジャーパウダー
シナモンパウダー

最短で準備していつまでに準備が可能か
教えてください。
※インド宛で10月13日までに発送を予定
よろしくお願いします。
- [1695782273.814759] <@U033G4KN4TD>: <@U0331FZS7JT> 社長
CC： <@U041RJKV5JA> 部長
お疲れ様です。
出荷可能日：10月2日（月）
よろしくお願いします。

## 2023-10-02

- [1696235731.074819] <@U0331FZS7JT>: <@U041RJKV5JA> <@U033G4KN4TD><@U05KGS6HN9H>
下記、追加で発送いただきたいものを随時更新します。
・緑のプラスティックのスプーン×２（平川部長に渡し済）
・フィルターインボトル（大）×３

●ターメリックパウダー
●ジンジャーパウダー
●シナモンパウダー
⇨●の３つは今朝お渡しした振るやつにそれぞれ入れて、何が入っているかわかるように容器にラベル添付をお願いします。

〈その他〉
抹茶カプチーノのHSコードを出荷までに調べる必要があると思います。
※ミルクの問題等送る際に出荷不可などあるかどうか発送するまでに調べていただいた上で、
全てサンプルとして送ることになります（つまり、送る、という前提）。
※製品として今後送ることができるかどうかの判断材料として調べておいてください。

また情報が入り次第共有します。
よろしくお願いします。

## 2023-10-04

- [1696437512.313139] <@U0331FZS7JT>: <@U041RJKV5JA> <@U033G4KN4TD><@U05KGS6HN9H>

下記、追加で準備と他サンプルと一緒に発送をお願いします。
●タマヤ：ミニトップ缶（全色×１）
缶の中に30g,40g,50gの抹茶を入れた袋もお願いします。
どれに何g入っているかわかるようにお願いします。
抹茶はなんでもOKなので安いやつで大丈夫です。

●プルトップ缶：30g,40g,50g,100g（それぞれ抹茶を入れて下さい）
同じく抹茶はなんでもOKなので安いやつで大丈夫です。
50gと100gは１つは黒、１つは白のプラスティック蓋をお願いします。

●抹茶スティック20本
以前、魯さんが作った在庫の分でOKです。

## 2023-10-05

- [1696575579.806679] <@U0331FZS7JT>: <@U041RJKV5JA> <@U033G4KN4TD><@U05KGS6HN9H>
CC：<@U0331FWGQRM>

追加で下記準備願います。
発送ですが、資料（パンフレット）の印刷が不要になったので、
最短での発送希望をされています。
下記含めた発送日を教えてください。


●白玉粉のパック2-3つ
スーパーにある、なんめの白玉だんごの粉を３つお願いします。
HSコードの確認もお願いします。

●碧翠園￥16,000：100gを３つ追加でお願いします。
→合計100g×13となります。

●資料を入れる透明フィルム(300)A4サイズ用
→尚、印刷はインドで行うので、日本での印刷はありません。
※フィルムに資料１部とカプチーノをそれぞれ１包入れて出荷を考えていましたが、現地で封入するので、フィルムはフィルムで、カプチーノはカプチーノで梱包をお願いします。

●アルミホイル大×１


------インド送り先--------
個人宅になります。

Anitha Krora (Ms.)
＋91 799 6314 342

No 731 5th cross  8th B  Main  4th Block  Koramangala  Bangalore  560034
------------------------
よろしくお願いします。

## 2023-10-06

- [1696616195.137179] <@U0606SPN4BW>: <@U0606SPN4BW>さんがチャンネルに参加しました

## 2023-10-11

- [1697091859.627629] <@U0331FZS7JT>: <@U041RJKV5JA> <@U033G4KN4TD> <@U05KGS6HN9H> 
CC： <@U0331FWGQRM> 
本件ですが、進捗いかがでしょうか？
- [1697091982.699309] <@U041RJKV5JA>: <@U0331FZS7JT> 社長
 <@U05KGS6HN9H> さん <@U033G4KN4TD> さん CC： <@U0331FWGQRM> 執行役
進捗連絡をしておらず、申し訳ございません。
本日、出荷いたします。
出荷後、ご連絡いたします。

## 2023-10-12

- [1697096904.586839] <@U05KGS6HN9H>: <@U0331FZS7JT> 社長
CC　<@U0331FWGQRM> 執行役、<@U041RJKV5JA> 部長、<@U033G4KN4TD> さん
お疲れ様です
本日10/12UPS便で出荷いたしました。
AWB No. 1Z219Y8R0410783657

書類・画像を以下に置かせていただきます。
桃翠園（共有フォルダ_松井Google  Drive）\●海外営業\インド\インド展示会202310

宜しくお願い申し上げます。

## 2023-10-14

- [1697279118.302909] <@U0331FZS7JT>: <@U041RJKV5JA> <@U05KGS6HN9H> <@U033G4KN4TD>
CC：<@U0331FWGQRM>
本件の送り先の宛名を下記の通り変更できないか
と連絡がありました。
インボイス・パッキングリストの宛名の変更をしましたので、
日本のUPSに連絡を入れて現地通関側に対応をしてもらえるように
確認をお願い致します。
------
たいへん申し訳ないのですが、UPSへご連絡いただき、送り先の名前を
Anitha Kroraから
Anitha Alvaに変更いただけますか？こちらで事情を説明をしているのですが、全く受け入れてもらえず。荷物が受けられない状態です。
-------
よろしくお願いします。

## 2023-10-15

- [1697421257.669749] <@U05KGS6HN9H>: <@U0331FZS7JT>社長
CC　<@U0331FWGQRM> 執行役、<@U041RJKV5JA> 部長、<@U033G4KN4TD> さん
お疲れ様です。
ペガサスを通じてUPSに宛名変更の依頼をかけております。
（現状と変更方法を確認中です）取り急ぎまで一報申し上げます。
- [1697439220.411159] <@U05KGS6HN9H>: <@U0331FZS7JT> 社長
CC　<@U0331FWGQRM> 執行役、<@U041RJKV5JA> 部長、<@U033G4KN4TD> さん
お疲れ様です。
ペガサスを通じUPSへ確認致しました。日本側ではどうにもならず、
荷受人様（Krora様或いはAlva様）より、以下のアドレスに宛名変更の
依頼をお願い申し上げます。
・連絡先メールアドレス　<mailto:HASANOPR123@GMAIL.COM|HASANOPR123@GMAIL.COM>
・AWB番号（1Z219Y8R0410783657）をメールに記載
・依頼内容（荷受人Krora様からAlva様へ変更）をメールに記載

## 2023-10-16

- [1697442130.490919] <@U0331FZS7JT>: <@U05KGS6HN9H>
CC　<@U0331FWGQRM> 執行役、<@U041RJKV5JA> 部長、<@U033G4KN4TD> さん
ありがとうございます。
・連絡先メールアドレス　<mailto:HASANOPR123@GMAIL.COM|HASANOPR123@GMAIL.COM>
こちらはどなたですか？
会社名、宛名を入れるときに必要かなと思ったので！
- [1697444510.726659] <@U05KGS6HN9H>: <@U0331FZS7JT> 社長
CC　<@U0331FWGQRM> 執行役、<@U041RJKV5JA> 部長、<@U033G4KN4TD> さん
お疲れ様です。
※先方へのご連絡、*一旦STOP*をお願い致します。

ご指摘箇所を確認すべくペガサスに再度連絡致しましたが、
当初ペガサス担当者から伺った内容が間違っていたようです。
<mailto:HASANOPR123@GMAIL.COM|HASANOPR123@GMAIL.COM>は、荷受人様（Krora様或いはAlva様）
のアドレスのようです。すでに現地UPSから荷受人様にコンタクトを取り、
PUSからこのアドレスにメール送信されいるようですが、どのようにして
荷受人様のアドレスを入手するに至ったか等、念の為詳細をペガサスの
別担当者に確認中です。
- [1697445336.250229] <@U0331FZS7JT>: <@U05KGS6HN9H>
CC　<@U0331FWGQRM> 執行役、<@U041RJKV5JA> 部長、<@U033G4KN4TD> さん
了解です。
これは現地で荷受人様とUPSが連絡を取り合っているので
そこからメールでやり取りされていると思うので
聞かれなくても大丈夫だと思いますよ^^;

既にお客様とは連絡を取り合っていて
上記の旨伝えています。
ありがとうございます。

## 2023-10-17

- [1697551809.860779] <@U0331FZS7JT>: <@U041RJKV5JA> <@U05KGS6HN9H> <@U033G4KN4TD>
<@U0331FWGQRM>

お客様から、連絡があり、
下記の通り対応していただけますか？
----------

荷物の件ですが、インドの税関がかなり厳しく、名前の変更に対し、正式なレターの要請を受けております。たいへん、たいへん恐れ入りますが以下のレターを御社のカバーレターに添付し、社版とサインをしていただき、PDFでお送りいただけませんか。

To The Deputy Commissioner  of Customs
NCT and New Delhi

Dear Sir/ Madam

Sub: Request for change of consignee name from Ms Anitha Krora to  Ms Monica Mathias 
and to request you to file BOE on actual consignee name. 
The name was given inadvertently put  and we request you to note the change as requested.
We have attached the KYC – Adhar card of the consignee

Thank you 

Tousuien Co Ltd
1482 kaminaoe hikawa cho
<tel:6990624|699 0624> japan
Phone <tel:81853720039|81 853 72 0039>

また、元々の送り先だったAnithaさんがKYCという日本でいうところのマイナンバーカードの提示を断ったため、ほかに受けてくださる方の名前に変える必要があるため、INVOICEを以下の方の名前にご変更いただけませんでしょうか？

Ms. Monica Mathias

Wellington Park Apartments, Wellington Streets, Johnson Market, Richmond Town, Bangalore North, Bnagalore Museum Road, Karnataka 560025

----------

カバーレターについて
ググったら添付の様な画像が出てきたので
添付させていただきます。
よろしくお願い致します。
  - files: [{"id": "F061ARK8QK0", "created": 1697551796, "timestamp": 1697551796, "name": "IMG_0535.png", "title": "IMG_0535", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 450959, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F061ARK8QK0/img_0535.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F061ARK8QK0/download/img_0535.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8QK0-2fbb5d5e48/img_0535_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8QK0-2fbb5d5e48/img_0535_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8QK0-2fbb5d5e48/img_0535_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8QK0-2fbb5d5e48/img_0535_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 221, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8QK0-2fbb5d5e48/img_0535_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8QK0-2fbb5d5e48/img_0535_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 332, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8QK0-2fbb5d5e48/img_0535_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1734, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8QK0-2fbb5d5e48/img_0535_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 443, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8QK0-2fbb5d5e48/img_0535_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 472, "thumb_1024_h": 1024, "original_w": 1290, "original_h": 2796, "thumb_tiny": "AwAwABbR7/8A16dn600YzTqAEGM96XNIetFACUuT6UmPajb7UAHelpMYNLQAwcEjk896XcfSnH1pjOcgKA3/AALFAD+9GKahfPzLgf72adz6UAf/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F061ARK8QK0/img_0535.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F061ARK8QK0-4299d93c85", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F061ARK8TRU", "created": 1697551796, "timestamp": 1697551796, "name": "IMG_0536.png", "title": "IMG_0536", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 527217, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F061ARK8TRU/img_0536.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F061ARK8TRU/download/img_0536.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8TRU-b53a7df15f/img_0536_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8TRU-b53a7df15f/img_0536_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8TRU-b53a7df15f/img_0536_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8TRU-b53a7df15f/img_0536_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 221, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8TRU-b53a7df15f/img_0536_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8TRU-b53a7df15f/img_0536_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 332, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8TRU-b53a7df15f/img_0536_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1734, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8TRU-b53a7df15f/img_0536_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 443, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F061ARK8TRU-b53a7df15f/img_0536_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 472, "thumb_1024_h": 1024, "original_w": 1290, "original_h": 2796, "thumb_tiny": "AwAwABbR79s/WnU2nCgBOlLmkNJQAGkGfSlIzRtoAX60lLjFJQAgwuep/GnZoPrSblPANAC9TRigUtAH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F061ARK8TRU/img_0536.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F061ARK8TRU-fb1061625b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1697589382.527799] <@U05KGS6HN9H>: <@U0331FZS7JT> 社長
CC　<@U0331FWGQRM> 執行役、<@U041RJKV5JA> 部長、<@U033G4KN4TD> さん
お疲れ様です。
取り急ぎましてカバーレターと訂正のINVOICE、PLを
作成添付申し上げます。ご確認をお願い致します。
訂正インボイスの差し替えをペガサス経由でUPSに依頼する
ように致しますが、送り状の配達先も変更の必要はあります
でしょうか？
  - files: [{"id": "F061LMPMGSX", "created": 1697589331, "timestamp": 1697589331, "name": "カバーレター.pdf", "title": "カバーレター.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 154083, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F061LMPMGSX/__________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F061LMPMGSX/download/__________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F061LMPMGSX-b46491fd12/___________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F061LMPMGSX/__________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F061LMPMGSX-caa7afeda6", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F061HSVKQR3", "created": 1697589360, "timestamp": 1697589360, "name": "インド展示会用INV（訂正20231018）.pdf", "title": "インド展示会用INV（訂正20231018）.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 360083, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F061HSVKQR3/_____________________inv_________20231018___.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F061HSVKQR3/download/_____________________inv_________20231018___.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F061HSVKQR3-4757827d47/_____________________inv_________20231018____thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1357, "thumb_pdf_h": 1920, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F061HSVKQR3/_____________________inv_________20231018___.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F061HSVKQR3-dd2ea4b614", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F061P8ACX6G", "created": 1697589364, "timestamp": 1697589364, "name": "インド展示会用PL（訂正20231018）.pdf", "title": "インド展示会用PL（訂正20231018）.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 328405, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F061P8ACX6G/_____________________pl_________20231018___.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F061P8ACX6G/download/_____________________pl_________20231018___.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F061P8ACX6G-4efaf67ce1/_____________________pl_________20231018____thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1263, "thumb_pdf_h": 1786, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F061P8ACX6G/_____________________pl_________20231018___.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F061P8ACX6G-e9d9e2ae0c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-10-18

- [1697616513.338279] <@U05KGS6HN9H>: <@U0331FZS7JT> 社長
CC　<@U0331FWGQRM> 執行役、<@U041RJKV5JA> 部長、<@U033G4KN4TD> さん
お疲れ様です。ペガサス経由で修正INVOICEはUPSに提出しております。
ペガサスより以下のメールを受信いたしました。
※現地UPSからの連絡
We will required below documents for taking permission from customs of name change . Please inform c/nee to share with us requested documents.

 1.   Duly signed and stamped request letter from actual consignee addressed to deputy commissioner of customs, NCT, and New Delhi mentioning the reason for consignee name change and requesting customs to file BOE on actual consignee name.
 2.   Signed copy of the revised invoice.
 3.   Please share any one KYC
 4.   Amendment fees is INR 1880 + 18% IGST.

ほぼカバーレターに記載されておりますが
1.税関へのレター他(BOE等)は、荷受人様からご手配が必要なようです。
2. 桃翠園から署名入り修正Invoiceをペガサス経由でUPS-Japanへ送付済み。
3. KYC書類は荷受人様がご存知と思います。
4. 変更費用としてINR 1880 + 18% IGST発生するとのことです。

## 2023-10-24

- [1698138391.693629] <@U05KGS6HN9H>: <@U0331FZS7JT> 社長
CC　<@U0331FWGQRM> 執行役、<@U041RJKV5JA> 部長、<@U033G4KN4TD> さん
お疲れ様です。
インド展示会出荷分、2回目配達で不在となっているようです。
念の為まで連絡申し上げます。
file:///C:/Users/tousu/OneDrive/%E3%83%87%E3%82%B9%E3%82%AF%E3%83%88%E3%83%83%E3%83%97/%E8%B2%A8%E7%89%A9%E8%BF%BD%E8%B7%A1%20_%20UPS%20-%20%E6%97%A5%E6%9C%AC.html?loc=ja_JP&amp;requester=ST/

## 2023-10-25

- [1698230008.572759] <@U0331FZS7JT>: <@U041RJKV5JA>
<@U05KGS6HN9H> <@U033G4KN4TD><@U0331FWGQRM>

本件で、<@U041RJKV5JA>から送っていただいた添付のポスター画像ですが、
こちらもっと解像度が高い（データ容量が大きい）ものって
ありましたっけ？
お客様がA1ポスターにしたいらしく、そのデータがあるかの連絡がありました。
ご確認、よろしくお願いいたします。
  - files: [{"id": "F0629R70QF9", "created": 1698229883, "timestamp": 1698229883, "name": "出雲抹茶ポスター画像2.jpg", "title": "出雲抹茶ポスター画像2.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 1400149, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0629R70QF9/_________________________________2.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0629R70QF9/download/_________________________________2.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0629R70QF9/_________________________________2.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0629R70QF9-c57d6c0322", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1698289191.909109] <@U041RJKV5JA>: <@U0331FZS7JT> 社長
 <@U0331FWGQRM> 執行役<@U05KGS6HN9H> さん <@U033G4KN4TD> さん
タマヤよりデータをいただけることになりました。
入手しましたらご連絡いたします。
- [1698302545.460999] <@U0331FZS7JT>: <@U041RJKV5JA> 
ありがとうございます。
いつ頃になりそうです？
- [1698303278.729799] <@U041RJKV5JA>: <@U0331FZS7JT>
本日中にお送りいただけます。
届き次第ご連絡いたします。

## 2023-10-26

- [1698309633.950899] <@U041RJKV5JA>: <@U0331FZS7JT>
データが届きましたが、容量が大きい為下記よりダウンロードをお願いいたします。
DL期限は7日間です。
<https://firestorage.jp/download/3393f7ef258a527b4f0258eae0ef11e7b62bacc3>
よろしくお願いいたします。

## 2023-11-21

- [1700559311.591119] <@U066P20UQH1>: <@U066P20UQH1>さんがチャンネルに参加しました

## 2024-01-30

- [1706638770.656229] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0331FZS7JT>
参考
袋シーラー　脱気＋窒素ガス充填
<https://www.youtube.com/watch?v=_eLwFsICEcs>
<https://www.youtube.com/watch?v=vx3ZjPB3B84>
  - attachments: [{"from_url": "https://www.youtube.com/watch?v=_eLwFsICEcs", "service_icon": "https://a.slack-edge.com/80588/img/unfurl_icons/youtube.png", "thumb_url": "https://i.ytimg.com/vi/_eLwFsICEcs/hqdefault.jpg", "thumb_width": 480, "thumb_height": 360, "video_html": "<iframe width=\"400\" height=\"225\" src=\"https://www.youtube.com/embed/_eLwFsICEcs?feature=oembed&autoplay=1&iv_load_policy=3\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen title=\"ユニバックの真空ガス充填自動シーラー「ＦＧシリーズ」　ヒライ商事株式会社\"></iframe>", "video_html_width": 400, "video_html_height": 225, "id": 1, "original_url": "https://www.youtube.com/watch?v=_eLwFsICEcs", "fallback": "YouTube Video: ユニバックの真空ガス充填自動シーラー「ＦＧシリーズ」　ヒライ商事株式会社", "title": "ユニバックの真空ガス充填自動シーラー「ＦＧシリーズ」　ヒライ商事株式会社", "title_link": "https://www.youtube.com/watch?v=_eLwFsICEcs", "author_name": "ヒライ商事株式会社", "author_link": "https://www.youtube.com/@user-mx7it4oo6h", "service_name": "YouTube", "service_url": "https://www.youtube.com/"}, {"from_url": "https://www.youtube.com/watch?v=vx3ZjPB3B84", "service_icon": "https://a.slack-edge.com/80588/img/unfurl_icons/youtube.png", "thumb_url": "https://i.ytimg.com/vi/vx3ZjPB3B84/hqdefault.jpg", "thumb_width": 480, "thumb_height": 360, "video_html": "<iframe width=\"400\" height=\"225\" src=\"https://www.youtube.com/embed/vx3ZjPB3B84?feature=oembed&autoplay=1&iv_load_policy=3\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen title=\"ガス置換シール機\"></iframe>", "video_html_width": 400, "video_html_height": 225, "id": 2, "original_url": "https://www.youtube.com/watch?v=vx3ZjPB3B84", "fallback": "YouTube Video: ガス置換シール機", "title": "ガス置換シール機", "title_link": "https://www.youtube.com/watch?v=vx3ZjPB3B84", "author_name": "株式会社共和", "author_link": "https://www.youtube.com/@user-yh3oz3dg9q", "service_name": "YouTube", "service_url": "https://www.youtube.com/"}]

## 2024-02-05

- [1707182782.887289] <@U03BLQ65GK0>: <!channel>
Dipo印字機の印字テスト動画です
  - files: [{"id": "F06HBQDSZAN", "created": 1707182708, "timestamp": 1707182708, "name": "桃翠園様動画.mp4", "title": "桃翠園様動画.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 11231806, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "complete", "locale": "ja-JP", "preview": {"content": "じゃあえ、台座なしバージョンになります。字をこのように貼り付けていただいて、ちょっとハの字にしていただきまして、ここにこのものがはまるように", "has_more": true}}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F06HBQDSZAN-bc6ec1a9b1/__________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F06HBQDSZAN-bc6ec1a9b1/__________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06HBQDSZAN/download/__________________.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "vtt": "https://files.slack.com/files-tmb/T033D70RR6H-F06HBQDSZAN-bc6ec1a9b1/file.vtt?_xcb=8fba3&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F06HBQDSZAN-bc6ec1a9b1/file.m3u8?_xcb=8fba3&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTI4NTYzNyxBVkVSQUdFLUJBTkRXSURUSD0xMjA4MzY1LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTYwOHgxMDgwLEZSQU1FLVJBVEU9MjkuOTcwLFNVQlRJVExFUz0ic3VicyIKZGF0YTphcHBsaWNhdGlvbi92bmQuYXBwbGUubXBlZ3VybDtiYXNlNjQsSTBWWVZFMHpWUW9qUlZoVUxWZ3RWa1ZTVTBsUFRqb3pDaU5GV0ZRdFdDMVVRVkpIUlZSRVZWSkJWRWxQVGpvM0NpTkZXRlF0V0MxTlJVUkpRUzFUUlZGVlJVNURSVG94Q2lORldGUXRXQzFRVEVGWlRFbFRWQzFVV1ZCRk9sWlBSQW9qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEyU0VKUlJGTmFRVTR0WW1NMlpXTXhZVGxpTVM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBMlNFSlJSRk5hUVU0dFltTTJaV014WVRsaU1TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TWk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTJTRUpSUkZOYVFVNHRZbU0yWldNeFlUbGlNUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd015NTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEyU0VKUlJGTmFRVTR0WW1NMlpXTXhZVGxpTVM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOQzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBMlNFSlJSRk5hUVU0dFltTTJaV014WVRsaU1TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TlM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTJTRUpSUkZOYVFVNHRZbU0yWldNeFlUbGlNUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd05pNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEyU0VKUlJGTmFRVTR0WW1NMlpXTXhZVGxpTVM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOeTUwY3dvalJWaFVTVTVHT2pBdU5qWTNMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBMlNFSlJSRk5hUVU0dFltTTJaV014WVRsaU1TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3T0M1MGN3b2pSVmhVTFZndFJVNUVURWxUVkFvPQojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9NzY5MDI4LEFWRVJBR0UtQkFORFdJRFRIPTczMDkyOSxDT0RFQ1M9ImF2YzEuNjQwMDFlLG1wNGEuNDAuNSIsUkVTT0xVVElPTj00MDZ4NzIwLEZSQU1FLVJBVEU9MjkuOTcwLFNVQlRJVExFUz0ic3VicyIKaHR0cHM6Ly9maWxlcy5zbGFjay5jb20vZmlsZXMtdG1iL1QwMzNENzBSUjZILUYwNkhCUURTWkFOLWJjNmVjMWE5YjEvZmlsZV9IXzI2NF8xMjgweDcyMF8zNTAwS0JQU183UVZCUi5tM3U4CiNFWFQtWC1NRURJQTpUWVBFPVNVQlRJVExFUyxHUk9VUC1JRD0ic3VicyIsTkFNRT0iRW5nbGlzaCIsREVGQVVMVD1ZRVMsQVVUT1NFTEVDVD1ZRVMsRk9SQ0VEPU5PLExBTkdVQUdFPSJlbmciLFVSST0iZGF0YTphcHBsaWNhdGlvbi92bmQuYXBwbGUubXBlZ3VybDtiYXNlNjQsSTBWWVZFMHpWUW9qUlZoVUxWZ3RWa1ZTVTBsUFRqb3pDaU5GV0ZRdFdDMVVRVkpIUlZSRVZWSkJWRWxQVGpvMk1EQUtJMFZZVkMxWUxVMUZSRWxCTFZORlVWVkZUa05GT2pFS0kwVllWQzFZTFZCTVFWbE1TVk5VTFZSWlVFVTZWazlFQ2lORldGUkpUa1k2TkRJdU56QTVMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBMlNFSlJSRk5hUVU0dFltTTJaV014WVRsaU1TOW1hV3hsTG5aMGRBb2pSVmhVTFZndFJVNUVURWxUVkE9PSIK", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F06HBQDSZAN-bc6ec1a9b1/___________________trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 42709, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F06HBQDSZAN-bc6ec1a9b1/___________________thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06HBQDSZAN/__________________.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F06HBQDSZAN-c70197bfed", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1707183143.301679] <@U0331FWGQRM>: <@U03BLQ65GK0>
有難うございます。
綺麗に印字できていて完璧です。
あとは、足で押すスイッチを購入願います。
インクの使用期限が1年とのことでしたので、
トラブルがあった時に、注文して何日で届くのか
念の為に確認願います。

<@U0331FZS7JT>
これでとりあえず１台発注かけますが、
いいですか？上記動画と合わせて、確認願います。
- [1707183277.796869] <@U0331FZS7JT>: <@U0331FWGQRM> 
印字、めっちゃ綺麗ですやん！
発注、よろしくお願いします:blush:
- [1707183940.443249] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U033G4KN4TD> cc <@U0331FZS7JT>
余談ですが、
印字する対象として、
もしかすると、今後は缶だけでなく、袋など様々なものに使用する可能性があると思います。
（現状の印字機の印字位置の変更などの“設定“が面倒すぎて、この機械を多用する可能性もある）

なので、本体にジグを貼り付けるのは、
おそらく他の商品を印字するときの邪魔になると思うので、
Amazonとかで台座（2000円くらい？）を複数台購入し、その台座に印をつけるなどするのがbetterかもしれないので、その案も検討願います。
台座の位置は本体にマジック等で書き込めば良いと思います。

<@U033G4KN4TD>
印字を消す薬品としては、先日使用した、
アセトン100%の溶液が良い結果だったと思うのですが、どうでしょうか？
ベンジンと比較してどうでしたか？？

あと、保管は事務所でお願いします。
（FSSCのルール上、茶詰場に保管はNGもしくは、ややこしいルールがあったような気がするので）

## 2024-02-06

- [1707210886.736469] <@U033G4KN4TD>: <@U0331FWGQRM>
印字を消す薬品ですが、ベンジン・アルコールよりもアセトン100％のほうがすぐ消えました。
カナダGenuine Tea様の印字直しの際もアセトン使用させていただきました。
(外で作業しました）
作業効率はベンジン・アルコールに比べるとかなり上がると思われます。

保管の件承知しました。
作業自体も匂いがかなりきつい為、外もしくは通気性の良い場所で
作業するようにします。

## 2024-02-12

- [1707746318.312689] <@U0331FWGQRM>: <@U0331FZS7JT> <@U03BLQ65GK0>
窒素充填、脱酸素剤、の桃翠園のスタンスとして、
固めたいのですが、

・全ての抹茶・煎茶には窒素ガス充填する。
・玄米茶、ほうじ茶には窒素ガス充填しない。

を基本として、それ以外の例外で、
脱酸素剤を入れるという形にするのはどうでしょうか？

現状、1kg袋の窒素ガス充填が微妙？とか、
シーラーがどうとか、色々課題等あると思いますが。また相談させてください！
- [1707778029.257449] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0331FZS7JT>
ハラル認証書（pdf）はいつ入手できるんでしたっけ？
- [1707797995.841779] <@U03BLQ65GK0>: <@U0331FWGQRM> <@U0331FZS7JT>
本日中に送ってもらえるとのことです。
届き次第共有+共有フォルダに格納しますので宜しくお願いします。
- [1707799578.572719] <@U0331FWGQRM>: <@U03BLQ65GK0> cc <@U0331FZS7JT>
はや！！！！w
了解ですw

## 2024-02-13

- [1707813404.892649] <@U03BLQ65GK0>: <!channel>
HALALの認証書とマークが届きましたので共有します。
これらは以下に格納しています。
「共有フォルダ」 → 「認証関係（FSSC・ISO・有機・HALAL）」→ 「HALAL」

マークの使用方法やルール、何ができて何ができないなどをまとめていますので出来次第また共有します。
宜しくお願いします。
  - files: [{"id": "F06J2QZAT0X", "created": 1707813102, "timestamp": 1707813102, "name": "【桃翠園】HALAL認証書.pdf", "title": "【桃翠園】HALAL認証書.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 1142812, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06J2QZAT0X/_______________halal_________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06J2QZAT0X/download/_______________halal_________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F06J2QZAT0X-04d21621ed/_______________halal__________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 908, "thumb_pdf_h": 1283, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06J2QZAT0X/_______________halal_________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F06J2QZAT0X-414284ce93", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F06JKRHMLTW", "created": 1707813105, "timestamp": 1707813105, "name": "Halal_Logo_JIT_Modified.jpg", "title": "Halal_Logo_JIT_Modified.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 1000644, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06JKRHMLTW/halal_logo_jit_modified.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06JKRHMLTW/download/halal_logo_jit_modified.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F06JKRHMLTW-b4cce2407e/halal_logo_jit_modified_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F06JKRHMLTW-b4cce2407e/halal_logo_jit_modified_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F06JKRHMLTW-b4cce2407e/halal_logo_jit_modified_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 357, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F06JKRHMLTW-b4cce2407e/halal_logo_jit_modified_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 476, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F06JKRHMLTW-b4cce2407e/halal_logo_jit_modified_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F06JKRHMLTW-b4cce2407e/halal_logo_jit_modified_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 714, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F06JKRHMLTW-b4cce2407e/halal_logo_jit_modified_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 794, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F06JKRHMLTW-b4cce2407e/halal_logo_jit_modified_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 952, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F06JKRHMLTW-b4cce2407e/halal_logo_jit_modified_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 1016, "original_w": 6310, "original_h": 6259, "thumb_tiny": "AwAvADDTJAGTwKrtOzfc+Veu4jn/AOt+NE7bn2ZAUdc9z/nmiGION7jIPIB/mff+VAEZ+bO0ySDsecf0FLuCAZMsfuc4/XIq2CCSARx1ooAgWYpjzCCv94dvr/jU9V5I/K+dOE/iHp7j+tOhba3l87eq57eooAgYb8Z6O2D+Jx/IVbd1jXcxwPU1WOQrgKSY2z+uf5GppJQARtDLt3fWgCNtjkyJIflOcpzk46e9IHmVdiIfMznLD5eeetSGQJuVVA2jIxwPentIFdV9f0oAVdxTEgXPcDpVaPgR+qtt/UirCyDyt7cADJqugfMasMZO4/zoAlmXa3mAZGMMP5GolIj4ZQyEdudo9PpVuoWgxnyzjPVT0/8ArUAOURSL8u1h7UN5UandtUH171C6fMWeEfhgj+lCxnny4QuejcDH86AEfDc7NkQPPY/U+1SwK333znGBnsKVYstukO4+g6CpaAP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06JKRHMLTW/halal_logo_jit_modified.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F06JKRHMLTW-ee790cebb7", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-02-14

- [1707981579.618699] <@U0331FWGQRM>: <@U03BLQ65GK0>
  - files: [{"id": "F06K02BU30C", "created": 1707981575, "timestamp": 1707981575, "name": "COA_編集中_Ralphフォーマットのコピー.xlsx", "title": "COA_編集中_Ralphフォーマットのコピー.xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 21733, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06K02BU30C/coa___________ralph_________________________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06K02BU30C/download/coa___________ralph_________________________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F06K02BU30C-6fa76cf1f6/coa___________ralph__________________________________converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F06K02BU30C-6fa76cf1f6/coa___________ralph__________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06K02BU30C/coa___________ralph_________________________________.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F06K02BU30C-24155dd714", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-02-28

- [1709173280.774369] <@U033G4KN4TD>: <!channel>
Dipo印字機についてご参考まで
2/27よりイギリスOSSU TEA様の再印字にて使用開始しております。
ガイド(タマヤ/40ｇ缶用)を作成し、缶の真ん中へ印字できるようにしてます。
作業時間について、1缶あたり大体10秒程度です。
台座についてですが、カナダGenuine様の缶(タマヤ/ミニトップ缶(黒)）は、キズが付きやすく、台座の使用よりガイドを作成し、作業した方が早い。
と、感じました。
※台座は袋の印字等があったら使用する予定です。
  - files: [{"id": "F06LRNF534P", "created": 1709172482, "timestamp": 1709172482, "name": "730865020.987850.mp4", "title": "730865020.987850.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 3755826, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F06LRNF534P-dcfd675794/730865020.987850.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F06LRNF534P-dcfd675794/730865020.987850.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06LRNF534P/download/730865020.987850.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F06LRNF534P-dcfd675794/file.m3u8?_xcb=636c5&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTA3MzAzMyxBVkVSQUdFLUJBTkRXSURUSD0xMDQ5MjQ0LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTYwOHgxMDgwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBMlRGSk9SalV6TkZBdFpHTm1aRFkzTlRjNU5DOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TVM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTJURkpPUmpVek5GQXRaR05tWkRZM05UYzVOQzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01pNTBjd29qUlZoVVNVNUdPakl1TVRZNUxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEyVEZKT1JqVXpORkF0WkdObVpEWTNOVGM1TkM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNeTUwY3dvalJWaFVMVmd0UlU1RVRFbFRWQW89CiNFWFQtWC1TVFJFQU0tSU5GOkJBTkRXSURUSD03MDc2NzYsQVZFUkFHRS1CQU5EV0lEVEg9Njk4NDEwLENPREVDUz0iYXZjMS42NDAwMWUsbXA0YS40MC41IixSRVNPTFVUSU9OPTQwNng3MjAsRlJBTUUtUkFURT0yOS45NzAKaHR0cHM6Ly9maWxlcy5zbGFjay5jb20vZmlsZXMtdG1iL1QwMzNENzBSUjZILUYwNkxSTkY1MzRQLWRjZmQ2NzU3OTQvZmlsZV9IXzI2NF8xMjgweDcyMF8zNTAwS0JQU183UVZCUi5tM3U4Cg==", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F06LRNF534P-dcfd675794/730865020.987850_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 14180, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F06LRNF534P-dcfd675794/730865020.987850_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06LRNF534P/730865020.987850.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F06LRNF534P-c79c7c97df", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F06M69KE1DG", "created": 1709172488, "timestamp": 1709172488, "name": "S__181911560_0.jpg", "title": "S__181911560_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 329174, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06M69KE1DG/s__181911560_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06M69KE1DG/download/s__181911560_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KE1DG-9dc4707cd7/s__181911560_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KE1DG-9dc4707cd7/s__181911560_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KE1DG-9dc4707cd7/s__181911560_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KE1DG-9dc4707cd7/s__181911560_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KE1DG-9dc4707cd7/s__181911560_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KE1DG-9dc4707cd7/s__181911560_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KE1DG-9dc4707cd7/s__181911560_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KE1DG-9dc4707cd7/s__181911560_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KE1DG-9dc4707cd7/s__181911560_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACSLFSxv2NMAp6puOKgosouetDJioJGYZCsePQ0xbmRlIBBxxkjpVkk2KMU0RSMoLSEE+lL5L/8APVqAIFqeIZNVxVmAc59ahFsiaLc7sWx3qCJw6kgY56VJI7BWB4B496LaIE4XovJ96oksKCFAJbOPWl59W/OnNknqB+FJz6/pQBWjdTwR+NThttUlNWGOYaQ2TRGNpMlBj6UTInmExkKw9Kh8wQxlz26VXikKqzHLM56f1qkSy15pHDLzSecP7poyfY/WjcfQUAf/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06M69KE1DG/s__181911560_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F06M69KE1DG-ddb393be47", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F06M69KJ2JE", "created": 1709172491, "timestamp": 1709172491, "name": "S__181911562_0.jpg", "title": "S__181911562_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 386730, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06M69KJ2JE/s__181911562_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06M69KJ2JE/download/s__181911562_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KJ2JE-6b5e1f4315/s__181911562_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KJ2JE-6b5e1f4315/s__181911562_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KJ2JE-6b5e1f4315/s__181911562_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KJ2JE-6b5e1f4315/s__181911562_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KJ2JE-6b5e1f4315/s__181911562_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KJ2JE-6b5e1f4315/s__181911562_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KJ2JE-6b5e1f4315/s__181911562_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KJ2JE-6b5e1f4315/s__181911562_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F06M69KJ2JE-6b5e1f4315/s__181911562_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADASHMTODyO1IDjrSxylYymM5qF33DgHINIZaQhulPFUS7rgx4z3zVhZjgErz3zQA+TLYCjcScYFSeWFGMVVAGW6juMelPF1HGgU54445zQA7ykHU/rQYfR8fhQbgBeMn6etMScbSep9KAIXjw5GasRoB8xO70GOlRDLOf1pymTziACU2/lQLYlmw6hvwqugKNuQgN3z0NSx4YlTKoBzgd6jNAFYsSc5pY/uu2TkYpvc06P/AFcn4fzoAuRqAufUVKkakc5z65pi/c/CpY+hpgMa3jflhmq4XaCMng45q6OlUz/F/vGhiP/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06M69KJ2JE/s__181911562_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F06M69KJ2JE-181d402003", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F06M8PW1VB6", "created": 1709173130, "timestamp": 1709173130, "name": "S__181911567.jpg", "title": "S__181911567.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 257363, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06M8PW1VB6/s__181911567.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06M8PW1VB6/download/s__181911567.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F06M8PW1VB6-3ff93ff4f4/s__181911567_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F06M8PW1VB6-3ff93ff4f4/s__181911567_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F06M8PW1VB6-3ff93ff4f4/s__181911567_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 203, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F06M8PW1VB6-3ff93ff4f4/s__181911567_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 270, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F06M8PW1VB6-3ff93ff4f4/s__181911567_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F06M8PW1VB6-3ff93ff4f4/s__181911567_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 405, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F06M8PW1VB6-3ff93ff4f4/s__181911567_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1422, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F06M8PW1VB6-3ff93ff4f4/s__181911567_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 540, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F06M8PW1VB6-3ff93ff4f4/s__181911567_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 576, "thumb_1024_h": 1024, "original_w": 960, "original_h": 1706, "thumb_tiny": "AwAwABufyWJzwKY/y9wfpStIx+83HpUZG7pSGGc0uaYQVPPT1o3UhjnIxQrqByaa8ZG0yZ+Y4Cr/AI0wdSOQfQdfzpiLAYyZCpwOu6l+zp6mm2z5O08cce9WKBEV0paA46jkfWqzXUa/OigswByex78VdBDxgjoRmqK2qiQ55GaYERnkdwcHcTkGtAM2BleaiQKr7SMEdPepj1oA/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06M8PW1VB6/s__181911567.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F06M8PW1VB6-7bc92528bd", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F06MK0ELCGH", "created": 1709173136, "timestamp": 1709173136, "name": "S__181911568.jpg", "title": "S__181911568.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 291628, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06MK0ELCGH/s__181911568.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06MK0ELCGH/download/s__181911568.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F06MK0ELCGH-dd97255313/s__181911568_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F06MK0ELCGH-dd97255313/s__181911568_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F06MK0ELCGH-dd97255313/s__181911568_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 203, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F06MK0ELCGH-dd97255313/s__181911568_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 270, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F06MK0ELCGH-dd97255313/s__181911568_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F06MK0ELCGH-dd97255313/s__181911568_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 405, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F06MK0ELCGH-dd97255313/s__181911568_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1422, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F06MK0ELCGH-dd97255313/s__181911568_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 540, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F06MK0ELCGH-dd97255313/s__181911568_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 576, "thumb_1024_h": 1024, "original_w": 960, "original_h": 1706, "thumb_tiny": "AwAwABuuI1bgA5+tXYogq8gUsaDqaezqvUgfjSQ2I6hhjHFVzAufu/rVnPFJTEVb2ZowsaHGRkkVSZi33iT9TV69iDgMPvLWfyOooAntZWSQDJKHqK08Vn2kZZunAOTmr9AEMnINVjGxbgZq4y0gGKAEhj8tecZNTZqLdTt3vigD/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06MK0ELCGH/s__181911568.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F06MK0ELCGH-4c8bbba74c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1709176303.398419] <@U0331FWGQRM>: <@U033G4KN4TD>
ありがとうございます！！
さっき見てきました！マジでいいですね！！
品質最高です:+1:
- [1709176854.100979] <@U0331FZS7JT>: <@U033G4KN4TD>
ありがとうございます！
Genuine様の件、作業性と品質どちらもガイド作成の方が良いという結果であれば、そちらが良いと思います！

よろしくお願いします！

## 2024-02-29

- [1709263030.233859] <@U03BLQ65GK0>: <!channel>
現在使用しているスプレッドシートの在庫管理表ですが、
一つのシートの中で大きな容量のページが2つ入っていることから、
スプレッドシート自体がとても重くなり、入力から反映までかなり時間がかかっていました。
そのため、これまで一つのシート内で管理していた入庫と出庫を
それぞれ別のスプレッドシートに分けることにしました。
使用方法はこれまでと同様ですので問題なく使用できるかと思います。
よろしくお願いします。
※本ページ上部にある管理表も変更しています

入庫
<https://docs.google.com/spreadsheets/d/1NoCr4WktPL0rrBLP9vz1CuxTusgwOL-AUyuZLURCiVA/edit#gid=943485998&fvid=568541386>

出庫
<https://docs.google.com/spreadsheets/d/1Ruq2E71cHJb9olInsOBIUS2DvUnQI0DPeOErxFEO_pw/edit#gid=1765478480&fvid=364633887>

在庫状況
<https://docs.google.com/spreadsheets/d/1FsTgUFNB0LRZA-zX1djNrdPRC2edH2inEYux2OxqDZ4/edit#gid=45730170>

## 2024-03-05

- [1709657305.954029] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U033G4KN4TD> cc<@U0331FZS7JT>
セミオートの粉末充填機械の見積もりを入手しました。
確認願います。

メーカー：ZHEJIANG CAPSULCN MACHINERY CO.,LTD
URL :
<https://www.alibaba.com/product-detail/CN-HZFB-Semi-Automatic-Milk-Powder_50043889021.html>
<https://cnshanfan.en.alibaba.com/index.html?spm=a2700.shop_plgr.88.13>
  - attachments: [{"from_url": "https://www.alibaba.com/product-detail/CN-HZFB-Semi-Automatic-Milk-Powder_50043889021.html", "service_icon": "https://www.alibaba.com/favicon.ico", "id": 1, "original_url": "https://www.alibaba.com/product-detail/CN-HZFB-Semi-Automatic-Milk-Powder_50043889021.html", "fallback": "Cn-hzfb Semi-automatic Milk Powder Starch Premixes Additives Filler Auger Screw Dry Powder Filling Machine - Buy Powder Filling Machine,Auger Screw Dry Powder Filling Machine,Dry Powder Filling Machine Product on Alibaba.com", "text": "Cn-hzfb Semi-automatic Milk Powder Starch Premixes Additives Filler Auger Screw Dry Powder Filling Machine - Buy Powder Filling Machine,Auger Screw Dry Powder Filling Machine,Dry Powder Filling Machine Product on <http://Alibaba.com|Alibaba.com>", "title": "Cn-hzfb Semi-automatic Milk Powder Starch Premixes Additives Filler Auger Screw Dry Powder Filling Machine - Buy Powder Filling Machine,Auger Screw Dry Powder Filling Machine,Dry Powder Filling Machine Product on Alibaba.com", "title_link": "https://www.alibaba.com/product-detail/CN-HZFB-Semi-Automatic-Milk-Powder_50043889021.html", "service_name": "alibaba.com"}, {"from_url": "https://cnshanfan.en.alibaba.com/index.html?spm=a2700.shop_plgr.88.13", "service_icon": "http://is.alicdn.com/simg/single/icon/favicon.ico", "thumb_url": "https://sc04.alicdn.com/kf/H65acb292f0354659bfaa887138a0803dr.jpg", "thumb_width": 200, "thumb_height": 200, "id": 2, "original_url": "https://cnshanfan.en.alibaba.com/index.html?spm=a2700.shop_plgr.88.13", "fallback": "Alibaba.com: ZHEJIANG CAPSULCN MACHINERY CO.,LTD - Tablet Capsule Counting Machine,  Blister Packaging Machine", "text": "ZHEJIANG CAPSULCN MACHINERY CO.,LTD, Experts in Manufacturing and Exporting Tablet Capsule Counting Machine, Blister Packaging Machine and 0 more Products.", "title": "ZHEJIANG CAPSULCN MACHINERY CO.,LTD - Tablet Capsule Counting Machine,  Blister Packaging Machine", "title_link": "https://cnshanfan.en.alibaba.com/index.html?spm=a2700.shop_plgr.88.13", "service_name": "Alibaba.com"}]
  - files: [{"id": "F06MU6H9V3Q", "created": 1709657186, "timestamp": 1709657186, "name": "Quotation_Semi-automatic powder filling machine⚫︎_ZHEJIANG CAPSULCN MACHINERY CO.,LTD.pdf", "title": "Quotation_Semi-automatic powder filling machine⚫︎_ZHEJIANG CAPSULCN MACHINERY CO.,LTD.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 1013989, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06MU6H9V3Q/quotation_semi-automatic_powder_filling_machine_______zhejiang_capsulcn_machinery_co._ltd.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06MU6H9V3Q/download/quotation_semi-automatic_powder_filling_machine_______zhejiang_capsulcn_machinery_co._ltd.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F06MU6H9V3Q-ad6113a58b/quotation_semi-automatic_powder_filling_machine_______zhejiang_capsulcn_machinery_co._ltd_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06MU6H9V3Q/quotation_semi-automatic_powder_filling_machine_______zhejiang_capsulcn_machinery_co._ltd.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F06MU6H9V3Q-8586ec1888", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1709692175.591929] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U033G4KN4TD> cc <@U0331FZS7JT>
JONAの認証取得予定日っていつでしたでしょうか？:sweat_drops:
- [1709692685.323339] <@U03BLQ65GK0>: <@U0331FWGQRM>
2/8に申請は出しているので、5月頭頃になるはずですが音沙汰無いので確認します！
- [1709692941.770779] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0331FZS7JT>
ありがとうございます。
有機認証取得した場合、有機同等性証明（COI）の取得や、
ラベルの確認などで頻繁に連絡を取ることになると思います。

その際のフローや有機同等性取得までのリードタイムなども確認したいので、
レクチャーやwebMTGなどの機会があれば、関係者皆が参加した方がいいと思うので、情報共有願います。
- [1709693178.294749] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0331FZS7JT>
追記
オプションのspiral loader powder feederの価格は $2,200
  - files: [{"id": "F06MX8ZV230", "created": 1709693173, "timestamp": 1709693173, "name": "スクリーンショット 2024-03-06 0.54.59.png", "title": "スクリーンショット 2024-03-06 0.54.59.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 23117, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06MX8ZV230/____________________________2024-03-06_0.54.59.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06MX8ZV230/download/____________________________2024-03-06_0.54.59.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F06MX8ZV230-b48fd20bc0/____________________________2024-03-06_0.54.59_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F06MX8ZV230-b48fd20bc0/____________________________2024-03-06_0.54.59_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F06MX8ZV230-b48fd20bc0/____________________________2024-03-06_0.54.59_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 319, "thumb_360_h": 204, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F06MX8ZV230-b48fd20bc0/____________________________2024-03-06_0.54.59_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 319, "original_h": 204, "thumb_tiny": "AwAeADDSpCCehxThRQA3a39/9KNrf3/0p1MyXOB93ufWgBVBxy2aWhVCqAOgpTQACobliFXaxGT2qXNIwDEE54oAqxCRnBZztzj61cAwMCm4X0NLmgBaDSZozQB//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06MX8ZV230/____________________________2024-03-06_0.54.59.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F06MX8ZV230-ba4aa559b9", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1709694526.536469] <@U0331FWGQRM>: <https://youtu.be/AMphj-8wJcM>
  - attachments: [{"from_url": "https://youtu.be/AMphj-8wJcM", "service_icon": "https://a.slack-edge.com/80588/img/unfurl_icons/youtube.png", "thumb_url": "https://i.ytimg.com/vi/AMphj-8wJcM/hqdefault.jpg", "thumb_width": 480, "thumb_height": 360, "video_html": "<iframe width=\"400\" height=\"225\" src=\"https://www.youtube.com/embed/AMphj-8wJcM?feature=oembed&autoplay=1&iv_load_policy=3\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen title=\"Operation---Semi-auto capsule filling machine HZF B\"></iframe>", "video_html_width": 400, "video_html_height": 225, "id": 1, "original_url": "https://youtu.be/AMphj-8wJcM", "fallback": "YouTube Video: Operation---Semi-auto capsule filling machine HZF B", "title": "Operation---Semi-auto capsule filling machine HZF B", "title_link": "https://youtu.be/AMphj-8wJcM", "author_name": "Manda Lee", "author_link": "https://www.youtube.com/@mandalee2972", "service_name": "YouTube", "service_url": "https://www.youtube.com/"}]
- [1709704941.674759] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0331FZS7JT> <@U041RJKV5JA> <@U05KGS6HN9H> <@U033G4KN4TD>
この機械のテストを中国側で行ってもらいたいので、
下記内容をサンプルで発送願います。

・5kg　抹茶粉末（安いやつ、もしくは廃棄予定のものでOK）

・各10袋のテスト用袋
　　∟清和10275
　　∟清和50011
　　∟清和10329
　　∟清和50112
　　∟清和260（30gのガゼット）
　　∟？？？（1kgのガゼット）
　　∟30g pulltop缶
その他テストしたい包材。

・EMSで出荷
（Purechimpのサンプル発送時にEMSで届いたので）
・送り先
Atten : CapsulCN International CO.,LTD.
Name : Manda Li
Address : 51# Kaifayilu Economy Development Zone, Rui’an, Zhejiang, 325200, China
Mobile: 86-18858877155
- [1709706496.344199] <@U0331FWGQRM>: <@U041RJKV5JA> <@U05KGS6HN9H> <@U033G4KN4TD>
念の為に、袋と抹茶を分けて発送願います。
抹茶はEMS・会社名なし。（サンプルと記載すること）
袋はEMS・会社名あり。（サンプルと記載すること）

宜しくお願いします。

## 2024-03-17

- [1710729266.040979] <@U03BLQ65GK0>: <!channel>
【HALAL認証運用と認証マーク】
HALAL認証運用について現時点で確認したいことについてクリアになりましたのでまとめました。
その中で特に重要な箇所を以下記載します
■認証マークについて
　2種類あり、
　①マークのみバージョン
　②マーク+認証番号バージョン　とあります。
　この2つの使用ルールですが
　・①を使用→任意のタイミングで②に変更＝OK（①を使い続けるのも、もちろんOK)
　・②を使用→任意のタイミングで①に変更＝NG
　・①を使用→任意のタイミングで②に変更→再び①に戻す＝NG
　・顧客Aには①、顧客Bには②を使用＝NG（使用するマークを統一する）
となります。
無難なのは最初から②で運用する方ですが、お客様のご要望というところもあるかと思いますので、
その時に判断をお願いします。

■出荷手続き
基本的に何か作業や書類が必要ということはありません。
但し、輸出国がサウジアラビアの時に限り「貨物証明」という書類が必要になるので、
その都度認証団体に依頼して発行して貰う必要があります。
（依頼から発行までは2〜3営業日、原本より先にPDFデータでもらうことも可能）

重要な箇所は以上です。
その他のことについては添付Wordを参照下さい。
また、認証マークについて
・マークのみ
・マーク+認証番号
のai形式のデータを添付します。

これらのデータは
共有フォルダ　→　認証関係（FSSC・ISO・有機・HALAL）→　HALAL　内に格納しています。
よろしくお願いします。
  - files: [{"id": "F06PJES6LB1", "created": 1710729004, "timestamp": 1710729004, "name": "halal logo 1.ai", "title": "halal logo 1.ai", "mimetype": "application/illustrator", "filetype": "ai", "pretty_type": "Illustrator File", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 12568053, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06PJES6LB1/halal_logo_1.ai?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06PJES6LB1/download/halal_logo_1.ai?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06PJES6LB1/halal_logo_1.ai", "permalink_public": "https://slack-files.com/T033D70RR6H-F06PJES6LB1-0f2edf4312", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F06PYU0QZJ7", "created": 1710729017, "timestamp": 1710729017, "name": "halal logo CIV-0195.ai", "title": "halal logo CIV-0195.ai", "mimetype": "application/illustrator", "filetype": "ai", "pretty_type": "Illustrator File", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 12867726, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06PYU0QZJ7/halal_logo_civ-0195.ai?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06PYU0QZJ7/download/halal_logo_civ-0195.ai?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F06PYU0QZJ7-853c53f68f/halal_logo_civ-0195_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1376, "thumb_pdf_h": 1400, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06PYU0QZJ7/halal_logo_civ-0195.ai", "permalink_public": "https://slack-files.com/T033D70RR6H-F06PYU0QZJ7-531443d756", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F06PW495QQ5", "created": 1710729024, "timestamp": 1710729024, "name": "HALAL認証運用について.docx", "title": "HALAL認証運用について.docx", "mimetype": "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "filetype": "docx", "pretty_type": "Word Document", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 14937, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06PW495QQ5/halal________________________.docx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06PW495QQ5/download/halal________________________.docx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F06PW495QQ5-b1aee85420/halal_________________________converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F06PW495QQ5-b1aee85420/halal_________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06PW495QQ5/halal________________________.docx", "permalink_public": "https://slack-files.com/T033D70RR6H-F06PW495QQ5-20128f9962", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-03-27

- [1711601744.252189] <@U05KGS6HN9H>: <@U0331FWGQRM>
<@U03BLQ65GK0> <@U041RJKV5JA> <@U033G4KN4TD>
遅くなりましたが、本日のEMSでテスト材料関係を中国メーカーに
発送いたしました。以下2件で社名有り無しを分けております。
抹茶サンプル　EMS AWB No EN311383953JP
包材サンプル　EMS AWB No EN310278551JP
画像等は以下に置きます。
共有〉●工場〉機械仕様書・見積書〉「自動茶詰め設備」
抹茶は廃棄予定分から5Kg、包材は風袋12種と缶2種を発送しています。
宜しくお願い致します。
  - files: [{"id": "F06RABX93UP", "created": 1711601638, "timestamp": 1711601638, "name": "自動茶詰め設備テスト用材料明細.pdf", "title": "自動茶詰め設備テスト用材料明細.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 290204, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06RABX93UP/_____________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06RABX93UP/download/_____________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F06RABX93UP-618ad84097/______________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1286, "thumb_pdf_h": 910, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06RABX93UP/_____________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F06RABX93UP-1ba9adc3b8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-03-30

- [1711817155.238949] <@U0331FWGQRM>: <@U05KGS6HN9H> <@U033G4KN4TD> <@U041RJKV5JA>
出荷する前に、内容が決まった時に何を出荷するか、
事前に確認してくれると助かります。
約１ヶ月ぶりにいきなり、出荷しました。と連絡されても困ります。
今回の件とりあえずOKです。。
これらデータ、情報はどこに保管していますか？

## 2024-03-31

- [1711925418.261039] <@U05KGS6HN9H>: <@U0331FWGQRM>
突然の連絡となり、すみません。
情報は
共有〉●工場〉機械仕様書・見積書〉「自動茶詰め設備」
に入れております。

## 2024-05-14

- [1715731012.862999] <@U0331FWGQRM>: <!channel>
＜情報共有＞
Teangle様の商品を購入されたお客様から、
クレームがあったそうです。

（画像１）：チャイ / TSE015-24かTSE016-23
（画像２）：Matcha49 / TSE009-24かTSE042-23
（画像3）：どちらかの近接画像？

こういったことが起こる可能性の原因と、
その対策を求められています。

関連部署には後ほど連絡しますので、
一緒に原因と対策を検討しましょう。

また現在進行中のTSE019のレモンの原料も同じなので、
これについても同様のクレームが起こり得ないか検討したいです。
宜しくお願いします。

取り急ぎ情報共有。
  - files: [{"id": "F0739BKANCE", "created": 1715730811, "timestamp": 1715730811, "name": "クレーム１.png", "title": "クレーム１.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 479731, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0739BKANCE/_______________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0739BKANCE/download/_______________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0739BKANCE-86d78316ad/________________64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0739BKANCE-86d78316ad/________________80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0739BKANCE-86d78316ad/________________360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 306, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0739BKANCE-86d78316ad/________________480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 408, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0739BKANCE-86d78316ad/________________160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 478, "original_h": 562, "thumb_tiny": "AwAwACisXz0BpUY571P5K9TxSgopzj8TSuNjVyGBJ609CVcE9BUqsp7D8qftVu35UCIomxnNSbx60x4ivK8io+adxjXbJqNl3rgninMMNQKgAGV6VPHJnr1qIYNNzg0AXg1G5fSoIpM9ak3Cncka8XmjI4YfrVd1ZOCCKtA4p2SevNPcoog0pq0yr/dFM2knA4pWAiiUqct+VS7v9mnDMZyVBFO85f7n609AP//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0739BKANCE/_______________.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F0739BKANCE-c311bf0ccf", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0744PYPAP2", "created": 1715730814, "timestamp": 1715730814, "name": "クレーム３.png", "title": "クレーム３.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 670023, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0744PYPAP2/_______________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0744PYPAP2/download/_______________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0744PYPAP2-60d68bfc24/________________64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0744PYPAP2-60d68bfc24/________________80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0744PYPAP2-60d68bfc24/________________360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 345, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0744PYPAP2-60d68bfc24/________________480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 460, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0744PYPAP2-60d68bfc24/________________160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 638, "original_h": 666, "thumb_tiny": "AwAwAC1enA6+vpUUj5yq/iaV3z8idO59aaFxQAzAFIQKeaQKzMFUZNACLuZgoPeiTcrkN1qeKMxliCpb25xSNK+eTn8Km5aiIAAKQ9CT0HU08rj7v5UxuVKkkZqiEI6sv3gcU2NiGxng9T6VLHvRBhiRTl2SMFdFye4GKm5fLbVEbDZ8ynIPcUMGVv74PeryxxeXtCjFCqE4ApDvfcrgU1lBFOzSdaszIsEDmpRIohx/F3pCKbt43DnHakykxY5yDzVtXyM1VhhWV2/uCnhthZAc4OKkZ//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0744PYPAP2/_______________.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F0744PYPAP2-07bd66354b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0744PYSSAC", "created": 1715730816, "timestamp": 1715730816, "name": "クレーム２.png", "title": "クレーム２.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 573539, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0744PYSSAC/_______________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0744PYSSAC/download/_______________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0744PYSSAC-d20061cd6a/________________64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0744PYSSAC-d20061cd6a/________________80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0744PYSSAC-d20061cd6a/________________360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 313, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0744PYSSAC-d20061cd6a/________________480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 418, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0744PYSSAC-d20061cd6a/________________160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 568, "original_h": 653, "thumb_tiny": "AwAwAClzDg0yiOGXG52Kg+ppO+KQCP8AdpWyeTg/UUj/AHac3SmBIirLGMkrj04o+zJ/eP51CshjYcnGam+0j+6aAJZyDb7uwqmW+VT65q3EQYCufpUAXccEAAdqQDFw/wB4cU6QBMBTxTtoCHb260zqCx7cUrgMOCxGRRj6VHjJye9O2UwJbeQruUcc8e1MjLEDPUVGrYc+5p6sFJ649amRRKC2elNcYT3Jo85R0OfapUAIJf8A/VUq4FYcHmnbh60xmySaTIrQR//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0744PYSSAC/_______________.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F0744PYSSAC-1559aba059", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1715733231.215449] <@U0331FZS7JT>: <@U0331FWGQRM> <@U05KGS6HN9H> <@U041RJKV5JA> <@U03BLQ65GK0>
<https://us02web.zoom.us/j/84899423075?pwd=NkhPb0x0WWtZYW1DSFNXc3RFUXl3UT09>
- [1715735008.350669] <@U0331FZS7JT>: <@U0331FWGQRM> <@U03BLQ65GK0> <@U05KGS6HN9H> <@U041RJKV5JA>
  - files: [{"id": "F0739HJM2CE", "created": 1715734994, "timestamp": 1715734994, "name": "【まるゑい】製品規格書【有機抹茶1C 2023.7.2.pdf", "title": "【まるゑい】製品規格書【有機抹茶1C 2023.7.2.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 167496, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0739HJM2CE/________________________________________________1c_2023.7.2.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0739HJM2CE/download/________________________________________________1c_2023.7.2.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0739HJM2CE-73b1315637/________________________________________________1c_2023.7.2_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0739HJM2CE/________________________________________________1c_2023.7.2.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F0739HJM2CE-b7f5e24f29", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1715738250.490119] <@U0331FWGQRM>: 分級＝篩　40メッシュ
- [1715739841.667699] <@U0331FZS7JT>: <@U0331FWGQRM> <@U03BLQ65GK0> <@U05KGS6HN9H> <@U041RJKV5JA>
大石茶園：有機抹茶25号
篩工程あり
メッシュサイズ~確認中。~：100メッシュ
ビーズ・ミル→篩はラインに組み込まれているため必ず篩を通してパッキングする。
  - files: [{"id": "F073JSV81RS", "created": 1715739692, "timestamp": 1715739692, "name": "有機抹茶25規格書 大石茶園.pdf", "title": "有機抹茶25規格書 大石茶園.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 145208, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F073JSV81RS/____________25______________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F073JSV81RS/download/____________25______________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F073JSV81RS-ebe0edb735/____________25_______________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1819, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F073JSV81RS/____________25______________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F073JSV81RS-9b05685da6", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-06-02

- [1717388764.219509] <@U0331FWGQRM>: <!channel>
粉末充填機械の現場確認についてですが、
・補助金の取得タイミング（最低２ヶ月はかかりそう？）
・フルオートの機械が高額
と言うこともあり、
購入を段階的に行うことにしました。
まずは、セミオート充填機を購入し、運用して状況を確認してから、
フルオートの機械を購入したいと思います。

また、入国についての手続きのノウハウも分かっておりませんので、
視察として、まずは、セミオート機械の購入のために、
<@U05KGS6HN9H> <@U0331FZS7JT> <@U0331FWGQRM>　の3人がまず行こうと思います。

その知見をもとに、必要に応じて、
第二回目の出張に他の方も行くのがいいのかなと思いました。

進捗報告です。
ご確認宜しくお願いします。

<@U05KGS6HN9H>
DMで足立さんのパスポートのスキャンデータをもらえますか？
宜しくお願いします。

## 2024-06-03

- [1717423032.753089] <@U0331FWGQRM>: &lt;&lt;Top Y Machinery Co., Ltd.&gt;&gt;
Alice Chan
301-302, 3# Building, Qide Huiye Industrial Park, Beijiao Town, Shunde District,
 FoShan City 528311, Guangdong,China
  - files: [{"id": "F076NTBD2JD", "created": 1717422833, "timestamp": 1717422833, "name": "MDP+auger filler3.mp4", "title": "MDP+auger filler3.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 34892917, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F076NTBD2JD-58fef5c4b7/mdp_auger_filler3.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F076NTBD2JD-58fef5c4b7/mdp_auger_filler3.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F076NTBD2JD/download/mdp_auger_filler3.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F076NTBD2JD-58fef5c4b7/file.m3u8?_xcb=954da&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MzQwMDE1MSxBVkVSQUdFLUJBTkRXSURUSD0yNzQ4MzE4LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTEyODB4NzIwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM05rNVVRa1F5U2tRdE5UaG1aV1kxWXpSaU55OW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREF4TG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EYzJUbFJDUkRKS1JDMDFPR1psWmpWak5HSTNMMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TURJdWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdOelpPVkVKRU1rcEVMVFU0Wm1WbU5XTTBZamN2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd015NTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzTms1VVFrUXlTa1F0TlRobVpXWTFZelJpTnk5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01EQTBMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURjMlRsUkNSREpLUkMwMU9HWmxaalZqTkdJM0wyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNRFV1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd056Wk9WRUpFTWtwRUxUVTRabVZtTldNMFlqY3ZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3Tmk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNOazVVUWtReVNrUXROVGhtWldZMVl6UmlOeTltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURBM0xuUnpDaU5GV0ZSSlRrWTZOaTR3TURZc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGMyVGxSQ1JESktSQzAxT0dabFpqVmpOR0kzTDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01EZ3VkSE1LSTBWWVZFbE9Sam8yTGpBd05pd0thSFIwY0hNNkx5OW1hV3hsY3k1emJHRmpheTVqYjIwdlptbHNaWE10ZEcxaUwxUXdNek5FTnpCU1VqWklMVVl3TnpaT1ZFSkVNa3BFTFRVNFptVm1OV00wWWpjdlptbHNaVjlJWHpJMk5GOHhNamd3ZURjeU1GOHpOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdPUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM05rNVVRa1F5U2tRdE5UaG1aV1kxWXpSaU55OW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREV3TG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EYzJUbFJDUkRKS1JDMDFPR1psWmpWak5HSTNMMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TVRFdWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdOelpPVkVKRU1rcEVMVFU0Wm1WbU5XTTBZamN2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE1pNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzTms1VVFrUXlTa1F0TlRobVpXWTFZelJpTnk5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01ERXpMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURjMlRsUkNSREpLUkMwMU9HWmxaalZqTkdJM0wyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNVFF1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd056Wk9WRUpFTWtwRUxUVTRabVZtTldNMFlqY3ZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF4TlM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNOazVVUWtReVNrUXROVGhtWldZMVl6UmlOeTltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURFMkxuUnpDaU5GV0ZSSlRrWTZOaTR3TURZc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGMyVGxSQ1JESktSQzAxT0dabFpqVmpOR0kzTDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01UY3VkSE1LSTBWWVZFbE9Sam8yTGpBd05pd0thSFIwY0hNNkx5OW1hV3hsY3k1emJHRmpheTVqYjIwdlptbHNaWE10ZEcxaUwxUXdNek5FTnpCU1VqWklMVVl3TnpaT1ZFSkVNa3BFTFRVNFptVm1OV00wWWpjdlptbHNaVjlJWHpJMk5GOHhNamd3ZURjeU1GOHpOVEF3UzBKUVUxODNVVlpDVWw4d01EQXhPQzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM05rNVVRa1F5U2tRdE5UaG1aV1kxWXpSaU55OW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREU1TG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EYzJUbFJDUkRKS1JDMDFPR1psWmpWak5HSTNMMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TWpBdWRITUtJMFZZVkVsT1Jqb3hMak16TlN3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdOelpPVkVKRU1rcEVMVFU0Wm1WbU5XTTBZamN2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeU1TNTBjd29qUlZoVUxWZ3RSVTVFVEVsVFZBbz0K", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F076NTBD2JD-58fef5c4b7/mdp_auger_filler3_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 121454, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F076NTBD2JD-58fef5c4b7/mdp_auger_filler3_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 1280, "thumb_video_h": 720, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F076NTBD2JD/mdp_auger_filler3.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F076NTBD2JD-502bdb49fd", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F075VLSC9FH", "created": 1717422861, "timestamp": 1717422861, "name": "MDP3+auger filler-金品.mp4", "title": "MDP3+auger filler-金品.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 5197122, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F075VLSC9FH-bb82d76c5d/mdp3_auger_filler-______.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F075VLSC9FH-bb82d76c5d/mdp3_auger_filler-______.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F075VLSC9FH/download/mdp3_auger_filler-______.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F075VLSC9FH-bb82d76c5d/file.m3u8?_xcb=a9cab&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTQ4MTQ2MixBVkVSQUdFLUJBTkRXSURUSD0xMTUzNTk2LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTEyODB4NzIwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM05WWk1VME01UmtndFltSTRNbVEzTm1NMVpDOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREF4TG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EYzFWa3hUUXpsR1NDMWlZamd5WkRjMll6VmtMMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TURJdWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdOelZXVEZORE9VWklMV0ppT0RKa056WmpOV1F2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd015NTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzTlZaTVUwTTVSa2d0WW1JNE1tUTNObU0xWkM5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01EQTBMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURjMVZreFRRemxHU0MxaVlqZ3laRGMyWXpWa0wyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNRFV1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd056VldURk5ET1VaSUxXSmlPREprTnpaak5XUXZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3Tmk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNOVlpNVTBNNVJrZ3RZbUk0TW1RM05tTTFaQzltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURBM0xuUnpDaU5GV0ZSSlRrWTZNaTQ1TnpBc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGMxVmt4VFF6bEdTQzFpWWpneVpEYzJZelZrTDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01EZ3VkSE1LSTBWWVZDMVlMVVZPUkV4SlUxUUsK", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F075VLSC9FH-bb82d76c5d/mdp3_auger_filler-_______trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 45011, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F075VLSC9FH-bb82d76c5d/mdp3_auger_filler-_______thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 1280, "thumb_video_h": 720, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F075VLSC9FH/mdp3_auger_filler-______.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F075VLSC9FH-8973381f7c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F075VLT4LH5", "created": 1717422868, "timestamp": 1717422868, "name": "Quotation of MDP1 mini doypack machine with auger filler-TOP Y Machinery.pdf", "title": "Quotation of MDP1 mini doypack machine with auger filler-TOP Y Machinery.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 1924098, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F075VLT4LH5/quotation_of_mdp1_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F075VLT4LH5/download/quotation_of_mdp1_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F075VLT4LH5-98c700cf0c/quotation_of_mdp1_mini_doypack_machine_with_auger_filler-top_y_machinery_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F075VLT4LH5/quotation_of_mdp1_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F075VLT4LH5-b9afbada7e", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-06-05

- [1717597580.817619] <@U0331FWGQRM>: <@U05KGS6HN9H> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
追加で10kgのテスト用抹茶が必要らしいです。
どんな抹茶でもいいので発送お願いできますか？

## 2024-06-07

- [1717745265.174999] <@U05KGS6HN9H>: <@U0331FWGQRM>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
テスト用抹茶の追加10Kgを本日6/7のEMSで発送しました。
AWB No EN324493572JP
※前回に準じて会社名は記載せず発送しております。
宜しくお願い致します。

## 2024-06-09

- [1717980489.963359] <@U03BLQ65GK0>: 《補助金について》（メモ）

【使用する（できる）補助金】
ものづくり生産プロセス変革支援補助金
※この他には使えそうな補助金が今のところない

【概要】
補助限度額：下限50万〜上限1000万
補助率：2/3
公募開始：6/3
公募締切：7/5
補助金交付予定：8月に全ての書類が揃って申請した場合9月下旬〜10月中旬頃の予定
備考：事前着手OK（4月購入の物から対象）
　　　海外からの直接仕入も可能（商社噛ませる必要なし）

【取得までの流れ】
①事前着手の申請を斐川町商工会より県へ提出
　　→6/10か11に提出

②機器類購入と必要書類準備→提出

③公募締切の7/5後審査会(プレゼンあり)が7月下旬に開催(予定)され、その後採択

④採択：8月〜9月上旬

⑤補助金交付：9月下旬〜10月中旬

【注意事項】
・海外からの直接取引に於いて見積書などの証憑類がウォンや＄などの外貨表記の場合、
　申請時や実績報告時に見積時点や支払時の為替レートを示す書類が必要になり、
　交付決定後の為替変動による物価高騰は勘案されない。
　（例）
　　採択時 一万ドル＝150万円←この金額に対して補助金が決定。
　　実績報告時 1万ドル＝160万円　だった場合、
　　補助金決定額は変わらないので、変動分10万円は手出しとなる。

・購入する機器類の価格が100万円を超える場合は相見積もりが必要

【必要書類】
添付資料参照
  - files: [{"id": "F076VBPSG2K", "created": 1717980086, "timestamp": 1717980086, "name": "【補助金】生産プロセス＿必要書類リスト.pdf", "title": "【補助金】生産プロセス＿必要書類リスト.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 637132, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F076VBPSG2K/____________________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F076VBPSG2K/download/____________________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F076VBPSG2K-718612a9c1/_____________________________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F076VBPSG2K/____________________________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F076VBPSG2K-1de1cd3828", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1717981603.211979] <@U0331FWGQRM>: <@U03BLQ65GK0> cc <@U0331FZS7JT>
Max 1500万円まで購入可能（1000万円の補助）だと思います。
5については、交付ではなく、おそらく交付決定（採択）のことだと思います。
実際に振込されるタイミングは事業完了後以降だと思いますが、
ざっくりいつ頃でしょうか？

また、桃翠園として
設備購入の予算（支払っていいキャッシュ）は
何円まででしたでしょうか？
再度確認お願いします。

※この補助金でフルに活用（購入）する必要もないので、
　順番にやっていけたらと思います。　

＜メモ＞
購入したいもの優先順位高い順番
ーーー
セミオート粉末充填機（複数台？）
フルオート粉末充填機
ーーー
スティック粉末充填機
プレハブ
篩
ブレンダー
- [1717982972.964919] <@U03BLQ65GK0>: <@U0331FWGQRM> cc  <@U0331FZS7JT>
&gt; Max 1500万円まで購入可能（1000万円の補助）だと思います。
→そうです、補助限度額の上限が1000万円で購入対象金額が1500万円です（2/3で1000万円）

&gt; 5については、交付ではなく、おそらく交付決定（採択）のことだと思います。
→いえ、交付の日付です。
　この事業は年2回まで公募されるので、1回目の事業期間が採択されるまでとなります。
　（細かく言うと採択完了後、補助金交付申請を県に対して行い、受理後9月末〜10月中旬ごろに交付となります）

&gt; 桃翠園として
&gt; 設備購入の予算（支払っていいキャッシュ）は
&gt; 何円まででしたでしょうか？
→500万円までです。

以上確認願います。

## 2024-06-25

- [1719306367.357479] <@U03BLQ65GK0>: <!channel>
【補助金について】
本日商工会より補助金について現状を踏まえた上で、
どのように進めるべきかを相談し回答を頂いているので共有します。

■現状
申請に必須な見積書が申請期限の7/5に間に合わないかもしれない

■対策案
友和産業の同じ機能の機械の見積もりを取り一旦申請だけはしておいて、後ほど対象を中国のものに変更して購入する

■問題点
事前申請したものと違うものを購入するのはNG
→事前申請せずに購入し、変更届を提出することで対応は可能であるが、
　採択後の購入となるので購入可能時期（発注可能時期）は8月末〜9月頭となる。
　加えて、
　・あまりに申請時と金額が違いすぎると受理されない可能性がある
　・全く同じ機械が別の所（販売者）が安く出しているから買うというのはOKだが、違う機械となると難しいかもしれない
　→つまり何が何でも申請時に出した機械買えと言われる可能性がある

■今後の進め方
①上記踏まえた上でこのまま進める
②この補助金の2次公募で改めて申請する
この２つとなります。
《②のメリット》
・1次公募と同様に今年の4/1から購入したものが事前着手として認められる
　（①のように8月末〜9月頭まで待つ必要がない）
・申請に必要な資料が余裕を持って準備できる
・購入機器について（購入先含めて）今一度検討する時間が作れる

《②のデメリット》
・2次公募がいつから始まるかは1次公募が終わるか、それに近づかないと分からない
　（今のところ9月頃からではないかと言われている）
・2次公募があるという確約はない
　→ただ、現在の商工会や県への相談件数や申請数からして本事業予算が3億であることに対して到達する可能性はかなり低く、
　　これまで同様の2〜3次公募がある補助金の実績から見ても、2次公募がある可能性は非常に高い
・①より補助金の交付が遅くなる（早く買えば買うほど資金負担の期間が長くなる）
　→交付は恐らく12月〜1月になるのではないかという商工会の見立て。
　　ただこの点に関しては資金繰り計画上、問題ないと見ています。

以上が本日確認できた内容です。
個人的には②で良いと思っています。
ご確認よろしくお願いします！
- [1719307678.992039] <@U0331FZS7JT>: <@U03BLQ65GK0>
CC：<@U0331FWGQRM>

・質問
補助金って１次も２次も両方申請可能ですか？
１次で今の見積もりを出して、１台テストして、２次で追加（または別の機械）購入する、といった方法が取れるかなと思いましたので確認です。
- [1719308609.435849] <@U03BLQ65GK0>: <@U0331FZS7JT>
結論は不可です。
一次・二次と公募のタイミングが違っても、同一年度内に各企業がその補助金が使用できるのは1回だけです。（全く別の補助金であれば問題ありません）

## 2024-06-27

- [1719552980.362839] <@U0331FWGQRM>: <@U05KGS6HN9H> <@U03BLQ65GK0> cc<@U0331FZS7JT>
機械購入・補助金取得において、
機械費用だけでなく、下記なども申請できる様です。
（会長から架電にて確認）

・機械の輸送費用★（Top yー桃翠園）
・設置費用（人件費：USD700 (100/day)）
・渡航費
　∟現地移動費用：約USD100　とのこと
　∟航空券★
　∟日本移動費用★（関空ー伊丹ー出雲空港）
・滞在費用（約3, 4日でいいとのことだが7日予定）

（約3, 4日でいいとのことですが、
往復2日あるので、7日予定しておきます。）

Top Yからの見積もりは、EXWなので、
上記は含んでおりません。

補助金申請するから見積もりをくれと言ったのですが、
うまく伝わっているかどうかわからないので、
こちらからこの内容で見積もりを作成してくれ、
とお願いしようと思います。

なので、すみませんが、
<@U05KGS6HN9H> <@U03BLQ65GK0>
★マークの見積り（高くてOK）を取ってもらえますか？
宜しくお願いします。
- [1719556229.132989] <@U05KGS6HN9H>: <@U0331FWGQRM>
TOP YのAliceさんから伺ったwechatコードで、Aliceさんを
見つけ出し、こちらから新しい友人での承認（相手側が承認後に
チャットでやり取り可能）を待っておりますが反応がありません。
すみませんが、Aliceさんへ一声かけていただけませんでしょうか？
  - files: [{"id": "F07AK6APQKB", "created": 1719556220, "timestamp": 1719556220, "name": "4511.jpg", "title": "4511.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 36617, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07AK6APQKB/4511.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07AK6APQKB/download/4511.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07AK6APQKB-14829320fe/4511_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07AK6APQKB-14829320fe/4511_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07AK6APQKB-14829320fe/4511_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 173, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07AK6APQKB-14829320fe/4511_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 231, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07AK6APQKB-14829320fe/4511_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07AK6APQKB-14829320fe/4511_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 347, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07AK6APQKB-14829320fe/4511_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 385, "thumb_800_h": 800, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07AK6APQKB-14829320fe/4511_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 462, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07AK6APQKB-14829320fe/4511_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 493, "thumb_1024_h": 1024, "original_w": 720, "original_h": 1496, "thumb_tiny": "AwAwABfRyvPcj2pd3sfypOmSFFOoARcHoCPqKWiigBMdelHftSZozQA6im5ozQAlFFFABRRmigD/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07AK6APQKB/4511.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07AK6APQKB-390c81ff49", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-06-28

- [1719560639.139169] <@U0331FWGQRM>: <@U05KGS6HN9H> 
情報共有
  - files: [{"id": "F07A6MXHGHH", "created": 1719560632, "timestamp": 1719560632, "name": "IMG_5180.png", "title": "IMG_5180", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 559026, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07A6MXHGHH/img_5180.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07A6MXHGHH/download/img_5180.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07A6MXHGHH-a4e63b017e/img_5180_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07A6MXHGHH-a4e63b017e/img_5180_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07A6MXHGHH-a4e63b017e/img_5180_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07A6MXHGHH-a4e63b017e/img_5180_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 221, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07A6MXHGHH-a4e63b017e/img_5180_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07A6MXHGHH-a4e63b017e/img_5180_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 332, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07A6MXHGHH-a4e63b017e/img_5180_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1734, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07A6MXHGHH-a4e63b017e/img_5180_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 443, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07A6MXHGHH-a4e63b017e/img_5180_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 472, "thumb_1024_h": 1024, "original_w": 1290, "original_h": 2796, "thumb_tiny": "AwAwABa/755pefb9aQnHcfjRv/2h+dAC4xRRuX+8KMj1FADWCsMnH403Z7JTncJjIzmm+cPSpdhOwu08cLRtP91aUOWwQpIpdx/ummhh17ilwPUflSgDHNAKZ4IpgJRSnOelJz6UAf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07A6MXHGHH/img_5180.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07A6MXHGHH-2085769939", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07A3U5DEPP", "created": 1719560632, "timestamp": 1719560632, "name": "IMG_5181.png", "title": "IMG_5181", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 343449, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07A3U5DEPP/img_5181.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07A3U5DEPP/download/img_5181.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07A3U5DEPP-c389dabef3/img_5181_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07A3U5DEPP-c389dabef3/img_5181_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07A3U5DEPP-c389dabef3/img_5181_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07A3U5DEPP-c389dabef3/img_5181_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 221, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07A3U5DEPP-c389dabef3/img_5181_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07A3U5DEPP-c389dabef3/img_5181_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 332, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07A3U5DEPP-c389dabef3/img_5181_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1734, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07A3U5DEPP-c389dabef3/img_5181_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 443, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07A3U5DEPP-c389dabef3/img_5181_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 472, "thumb_1024_h": 1024, "original_w": 1290, "original_h": 2796, "thumb_tiny": "AwAwABa/785o5PTFL+Jo/E0AGMUUhcZ6H8qTePQ/lQA7n2o59qKCMjHP4UALRTNnu350uz3P50ALRS4454pMr/eFABRS856UnPpQB//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07A3U5DEPP/img_5181.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07A3U5DEPP-eb3fa1f61f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-06-30

- [1719810174.121159] <@U05KGS6HN9H>: <@U03BLQ65GK0>
フルオート茶詰め機購入に関係する資料を以下に保存しております。
桃翠園共有フォルダ〉●工場〉機械仕様書・見積書〉自動茶詰め設備〉フルオート茶詰め設備
エクセルファイル「フルオート茶詰め機購入費用概要」に、諸費用をまとめる予定です。
（渡航費、移動費、宿泊費、食費等は主任へ確認しました）
・現在、輸入費用（中国メーカー工場引取り～桃翠園搬入）を福山通運Gに依頼中です。
・機械組み上げ時に、例えばAuger filler（N/W180kg）のような重量物もある為、茶詰め場内に
　個々部分を入れた後、どのようにして持ち上げるか等、事前シミュレーションが必要です。
（必要工具等の外部レンタル等も検討？）
  - files: [{"id": "F07A0V1GN23", "created": 1719810162, "timestamp": 1719810162, "name": "例_Auger filler.jpg", "title": "例_Auger filler.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 57060, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07A0V1GN23/____auger_filler.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07A0V1GN23/download/____auger_filler.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07A0V1GN23-863d665976/____auger_filler_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07A0V1GN23-863d665976/____auger_filler_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07A0V1GN23-863d665976/____auger_filler_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 90, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07A0V1GN23-863d665976/____auger_filler_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 120, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07A0V1GN23-863d665976/____auger_filler_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07A0V1GN23-863d665976/____auger_filler_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 179, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07A0V1GN23-863d665976/____auger_filler_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 199, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07A0V1GN23-863d665976/____auger_filler_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 239, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07A0V1GN23-863d665976/____auger_filler_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 255, "original_w": 1067, "original_h": 266, "thumb_tiny": "AwALADC/8uc5FJgf3hUmBRigCMgY+VgPenceop2KMCgBAwA60u5fWjaKNo9KAP/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07A0V1GN23/____auger_filler.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07A0V1GN23-858e786c0a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-07-03

- [1720060725.625539] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U05KGS6HN9H> cc <@U0331FZS7JT>
他の会社ですが、この機械も追加したいです。
仕様について詰めたいのですが、
巻じめを行う缶のサイズをリストアップして、
それで再度見積もりとり直そうと思います。

今依頼している缶のサイズはこれ。
60x60Hmm
60x68Hmm
60x85Hmm
60x100Hmm

日東の缶：66x102
タマヤの白い缶（Momatchaで検討中）：70x100

その他、今後必要になりそうな缶サイズもあれば。
  - files: [{"id": "F07BJFJGB2L", "created": 1720005025, "timestamp": 1720005025, "name": "Xtime-Semi-1台_automatic_vacuum_nitrogen_filling_can_sealing_machine-231116.pdf", "title": "Xtime-Semi-1台_automatic_vacuum_nitrogen_filling_can_sealing_machine-231116.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 1365262, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07BJFJGB2L/xtime-semi-1____automatic_vacuum_nitrogen_filling_can_sealing_machine-231116.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07BJFJGB2L/download/xtime-semi-1____automatic_vacuum_nitrogen_filling_can_sealing_machine-231116.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07BJFJGB2L-d01662643c/xtime-semi-1____automatic_vacuum_nitrogen_filling_can_sealing_machine-231116_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07BJFJGB2L/xtime-semi-1____automatic_vacuum_nitrogen_filling_can_sealing_machine-231116.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07BJFJGB2L-b184a5d7fd", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-07-20

- [1721464409.549999] <@U05KGS6HN9H>: <@U0331FZS7JT> <@U0331FWGQRM>
<@U03BLQ65GK0>
TOP Yフルオート自動茶詰め機の経過報告となります。
（昨日7/19に前金50％の送金が完了しTOP Yでも入金が確認できております）
会長、金山工場長、熱田さん、福井さんとも協議し、当初の内容から
機械仕様2点を修正変更しております。全体金額は、補助金申請で見込んでいる
当初金額より若干安くなります。
〈変更点1〉コンプレッサー
機械油を使用するタイプ（7.5kw）でしたが、SFFC的にアウトの為、オイルフリー
タイプ（油を使用しない）に変更。機械を正常稼働させる必要パワー5kwに対し、
6kwのオイルフリーコンプレッサーとなります。金額は安くなり（＄3445→＄1500）
〈変更点2〉原料供給筒
原料フィーダーから原料を汲み上げる筒（中にスクリューが入っている円筒）
ですが、1本3.6ｍある為、機械清掃時に筒奥が見えない問題がありました。
※添付動画は1本物の円筒（従来の供給筒）の取り外し画像です。
清掃の利便性とスクリュー出し入れ時の擦れ防止を視野に、これをU字型開閉蓋付の
仕様に変更。食品接触面にシリコンパッキンが使用されますが、SGSで対応は可能の
ようです。オプションとしての追加の為、金額プラス＄710となります。
◆変更点を加味した最終のProforma Invoiceが届いております。
これからメーカーで機械製造に入ります。
  - files: [{"id": "F07CW7L8PPH", "created": 1721464258, "timestamp": 1721464258, "name": "【20240720取得最新】4th Proforma invoice of MDP2 mini doypack machine with auger filler-TOP Y Machinery.pdf", "title": "【20240720取得最新】4th Proforma invoice of MDP2 mini doypack machine with auger filler-TOP Y Machinery.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 47619, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07CW7L8PPH/___20240720_______________4th_proforma_invoice_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07CW7L8PPH/download/___20240720_______________4th_proforma_invoice_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07CW7L8PPH-564bc85624/___20240720_______________4th_proforma_invoice_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07CW7L8PPH/___20240720_______________4th_proforma_invoice_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07CW7L8PPH-4522ba1dcc", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07DALQ9XL3", "created": 1721464270, "timestamp": 1721464270, "name": "原料フィーダー（Round tube)取り外し動画.mp4", "title": "原料フィーダー（Round tube)取り外し動画.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 33099523, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F07DALQ9XL3-1e99ee3e1a/________________________round_tube___________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F07DALQ9XL3-1e99ee3e1a/________________________round_tube___________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07DALQ9XL3/download/________________________round_tube___________________.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F07DALQ9XL3-1e99ee3e1a/file.m3u8?_xcb=50181&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MzQ1Mzc0MSxBVkVSQUdFLUJBTkRXSURUSD0yNDQ2NjAwLENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTEyNzJ4NzIwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1JFRk1VVGxZVERNdE1XVTVPV1ZsTTJVeFlTOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREF4TG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EZEVRVXhST1ZoTU15MHhaVGs1WldVelpURmhMMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TURJdWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdOMFJCVEZFNVdFd3pMVEZsT1RsbFpUTmxNV0V2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd015NTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzUkVGTVVUbFlURE10TVdVNU9XVmxNMlV4WVM5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01EQTBMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURkRVFVeFJPVmhNTXkweFpUazVaV1V6WlRGaEwyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNRFV1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd04wUkJURkU1V0V3ekxURmxPVGxsWlRObE1XRXZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3Tmk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNSRUZNVVRsWVRETXRNV1U1T1dWbE0yVXhZUzltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURBM0xuUnpDaU5GV0ZSSlRrWTZOaTR3TURZc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGRFUVV4Uk9WaE1NeTB4WlRrNVpXVXpaVEZoTDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01EZ3VkSE1LSTBWWVZFbE9Sam8yTGpBd05pd0thSFIwY0hNNkx5OW1hV3hsY3k1emJHRmpheTVqYjIwdlptbHNaWE10ZEcxaUwxUXdNek5FTnpCU1VqWklMVVl3TjBSQlRGRTVXRXd6TFRGbE9UbGxaVE5sTVdFdlptbHNaVjlJWHpJMk5GOHhNamd3ZURjeU1GOHpOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdPUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1JFRk1VVGxZVERNdE1XVTVPV1ZsTTJVeFlTOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREV3TG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EZEVRVXhST1ZoTU15MHhaVGs1WldVelpURmhMMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TVRFdWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdOMFJCVEZFNVdFd3pMVEZsT1RsbFpUTmxNV0V2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE1pNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzUkVGTVVUbFlURE10TVdVNU9XVmxNMlV4WVM5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01ERXpMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURkRVFVeFJPVmhNTXkweFpUazVaV1V6WlRGaEwyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNVFF1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd04wUkJURkU1V0V3ekxURmxPVGxsWlRObE1XRXZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF4TlM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNSRUZNVVRsWVRETXRNV1U1T1dWbE0yVXhZUzltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURFMkxuUnpDaU5GV0ZSSlRrWTZOaTR3TURZc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGRFUVV4Uk9WaE1NeTB4WlRrNVpXVXpaVEZoTDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01UY3VkSE1LSTBWWVZFbE9Sam8yTGpBd05pd0thSFIwY0hNNkx5OW1hV3hsY3k1emJHRmpheTVqYjIwdlptbHNaWE10ZEcxaUwxUXdNek5FTnpCU1VqWklMVVl3TjBSQlRGRTVXRXd6TFRGbE9UbGxaVE5sTVdFdlptbHNaVjlJWHpJMk5GOHhNamd3ZURjeU1GOHpOVEF3UzBKUVUxODNVVlpDVWw4d01EQXhPQzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1JFRk1VVGxZVERNdE1XVTVPV1ZsTTJVeFlTOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREU1TG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EZEVRVXhST1ZoTU15MHhaVGs1WldVelpURmhMMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TWpBdWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdOMFJCVEZFNVdFd3pMVEZsT1RsbFpUTmxNV0V2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeU1TNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzUkVGTVVUbFlURE10TVdVNU9XVmxNMlV4WVM5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01ESXlMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURkRVFVeFJPVmhNTXkweFpUazVaV1V6WlRGaEwyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNak11ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd04wUkJURkU1V0V3ekxURmxPVGxsWlRObE1XRXZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF5TkM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNSRUZNVVRsWVRETXRNV1U1T1dWbE0yVXhZUzltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURJMUxuUnpDaU5GV0ZSSlRrWTZOaTR3TURZc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGRFUVV4Uk9WaE1NeTB4WlRrNVpXVXpaVEZoTDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01qWXVkSE1LSTBWWVZFbE9Sam8yTGpBd05pd0thSFIwY0hNNkx5OW1hV3hsY3k1emJHRmpheTVqYjIwdlptbHNaWE10ZEcxaUwxUXdNek5FTnpCU1VqWklMVVl3TjBSQlRGRTVXRXd6TFRGbE9UbGxaVE5sTVdFdlptbHNaVjlJWHpJMk5GOHhNamd3ZURjeU1GOHpOVEF3UzBKUVUxODNVVlpDVWw4d01EQXlOeTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1JFRk1VVGxZVERNdE1XVTVPV1ZsTTJVeFlTOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREk0TG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EZEVRVXhST1ZoTU15MHhaVGs1WldVelpURmhMMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TWprdWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdOMFJCVEZFNVdFd3pMVEZsT1RsbFpUTmxNV0V2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBek1DNTBjd29qUlZoVVNVNUdPakF1TXpZM0xBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzUkVGTVVUbFlURE10TVdVNU9XVmxNMlV4WVM5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01ETXhMblJ6Q2lORldGUXRXQzFGVGtSTVNWTlVDZz09Cg==", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F07DALQ9XL3-1e99ee3e1a/________________________round_tube____________________trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 180547, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F07DALQ9XL3-1e99ee3e1a/________________________round_tube____________________thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 960, "thumb_video_h": 544, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07DALQ9XL3/________________________round_tube___________________.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F07DALQ9XL3-27fa40ebfa", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07DD8TV0TE", "created": 1721464296, "timestamp": 1721464296, "name": "原料供給筒（U字開閉蓋付）.jpg", "title": "原料供給筒（U字開閉蓋付）.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 256550, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07DD8TV0TE/__________________u__________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07DD8TV0TE/download/__________________u__________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07DD8TV0TE-d0492f58c8/__________________u___________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07DD8TV0TE-d0492f58c8/__________________u___________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07DD8TV0TE-d0492f58c8/__________________u___________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 244, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07DD8TV0TE-d0492f58c8/__________________u___________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 326, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07DD8TV0TE-d0492f58c8/__________________u___________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07DD8TV0TE-d0492f58c8/__________________u___________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 489, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07DD8TV0TE-d0492f58c8/__________________u___________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1179, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07DD8TV0TE-d0492f58c8/__________________u___________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 652, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07DD8TV0TE-d0492f58c8/__________________u___________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 695, "thumb_1024_h": 1024, "original_w": 942, "original_h": 1388, "thumb_tiny": "AwAwACA8zC7NwDEZGf5UnmO9vISuF2jn8RVbGW55NWIctA6D+7/WgCBQH+6fzpfLww4PWrDQq6/dGfpTBGoYAjBz68GgAe1kjQF9qjpktSwsse4s68rjg+9XNQXdbgHpuFZcSluAPpQBej/ek+VhiPepDA56qPzpmnoVeTIx2q9QBV1Dm3AHdhWd5m1gFAA6c1o6gCbfAzyw6Csso+c7G/KgDQ09izv9BV6qGnA73yrDgdRV+gD/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07DD8TV0TE/__________________u__________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07DD8TV0TE-dfc730d95a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07DPE66YAV", "created": 1721464304, "timestamp": 1721464304, "name": "シリコンパッキンSGS.pdf", "title": "シリコンパッキンSGS.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 370535, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07DPE66YAV/________________________sgs.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07DPE66YAV/download/________________________sgs.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07DPE66YAV-20ff12f49e/________________________sgs_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07DPE66YAV/________________________sgs.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07DPE66YAV-51d0f4e245", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1721490525.584219] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U03BLQ65GK0> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
納品して、設置、稼働までを考慮して、
いつから本格稼働可能（そう）ですか？？

セバスチャンが間も無く来そうです:sweat_drops:
やばいです。初回おそらく32000袋。。。

メーカーに、こまめに進捗を確認し、
1週間でも10日でも早く届くように、
コミュニケーションをとってください。
早くしろ、というだけでなく、
ミスが起きないように入念に連絡をとってください。

もちろん、これが稼働できないことも視野に入れて、他の方法もこちらで検討します。
これは事務、製造、営業全てのコミュニケーションが重要ですので、宜しくお願いします。
またMTGさせてください。
宜しくお願い致します。

## 2024-07-22

- [1721671264.599029] <@U0331FWGQRM>: <@U05KGS6HN9H>
ちなみにこのスティックを製造する機械はいくらくらいするんでしたっけ？？
確認してもらえますか？:sweat_drops:
  - files: [{"id": "F07E6SMAA0G", "created": 1721671208, "timestamp": 1721671208, "name": "Catalogue of DXD-50F Powder Sachet Packing Machine-TOP Y Machinery.pdf", "title": "Catalogue of DXD-50F Powder Sachet Packing Machine-TOP Y Machinery.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 183887, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07E6SMAA0G/catalogue_of_dxd-50f_powder_sachet_packing_machine-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07E6SMAA0G/download/catalogue_of_dxd-50f_powder_sachet_packing_machine-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07E6SMAA0G-7531c8dd7a/catalogue_of_dxd-50f_powder_sachet_packing_machine-top_y_machinery_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07E6SMAA0G/catalogue_of_dxd-50f_powder_sachet_packing_machine-top_y_machinery.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07E6SMAA0G-40e69fec3e", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07E6STE21W", "created": 1721671243, "timestamp": 1721671243, "name": "4f486af1519731ec8c755960c1695695.mp4", "title": "4f486af1519731ec8c755960c1695695.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 15797528, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F07E6STE21W-e6e445d4c3/4f486af1519731ec8c755960c1695695.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F07E6STE21W-e6e445d4c3/4f486af1519731ec8c755960c1695695.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07E6STE21W/download/4f486af1519731ec8c755960c1695695.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F07E6STE21W-e6e445d4c3/file.m3u8?_xcb=79c5d&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MjMzNzM4NSxBVkVSQUdFLUJBTkRXSURUSD0yMDY2OTkzLENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTYwOHgxMDgwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1JUWlRWRVV5TVZjdFpUWmxORFExWkRSak15OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TVM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNSVFpUVkVVeU1WY3RaVFpsTkRRMVpEUmpNeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01pNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzUlRaVFZFVXlNVmN0WlRabE5EUTFaRFJqTXk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNeTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1JUWlRWRVV5TVZjdFpUWmxORFExWkRSak15OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TkM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNSVFpUVkVVeU1WY3RaVFpsTkRRMVpEUmpNeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd05TNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzUlRaVFZFVXlNVmN0WlRabE5EUTFaRFJqTXk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOaTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1JUWlRWRVV5TVZjdFpUWmxORFExWkRSak15OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3Tnk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNSVFpUVkVVeU1WY3RaVFpsTkRRMVpEUmpNeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd09DNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzUlRaVFZFVXlNVmN0WlRabE5EUTFaRFJqTXk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdPUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1JUWlRWRVV5TVZjdFpUWmxORFExWkRSak15OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF4TUM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNSVFpUVkVVeU1WY3RaVFpsTkRRMVpEUmpNeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE1TNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzUlRaVFZFVXlNVmN0WlRabE5EUTFaRFJqTXk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXhNaTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1JUWlRWRVV5TVZjdFpUWmxORFExWkRSak15OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF4TXk1MGN3b2pSVmhVU1U1R09qQXVOVFkzTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNSVFpUVkVVeU1WY3RaVFpsTkRRMVpEUmpNeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE5DNTBjd29qUlZoVUxWZ3RSVTVFVEVsVFZBbz0KI0VYVC1YLVNUUkVBTS1JTkY6QkFORFdJRFRIPTEzNTY1MDQsQVZFUkFHRS1CQU5EV0lEVEg9MTI1MTY3NixDT0RFQ1M9ImF2YzEuNjQwMDFlLG1wNGEuNDAuNSIsUkVTT0xVVElPTj00MDZ4NzIwLEZSQU1FLVJBVEU9MjkuOTcwCmh0dHBzOi8vZmlsZXMuc2xhY2suY29tL2ZpbGVzLXRtYi9UMDMzRDcwUlI2SC1GMDdFNlNURTIxVy1lNmU0NDVkNGMzL2ZpbGVfSF8yNjRfMTI4MHg3MjBfMzUwMEtCUFNfN1FWQlIubTN1OAo=", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F07E6STE21W-e6e445d4c3/4f486af1519731ec8c755960c1695695_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 78645, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F07E6STE21W-e6e445d4c3/4f486af1519731ec8c755960c1695695_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07E6STE21W/4f486af1519731ec8c755960c1695695.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F07E6STE21W-62fec29270", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-07-23

- [1721804362.748259] <@U03BLQ65GK0>: <@U0331FWGQRM> <@U033G4KN4TD>
大樹 岡 さんがあなたをスケジュール済みの Zoom ミーティングに招待しています。

トピック: 大樹 岡のパーソナルミーティングルーム

参加 Zoom ミーティング
<https://us05web.zoom.us/j/9361417572?pwd=S2hVR1huY216YUhxa05ZclhxQnlQUT09>

ミーティング ID: <tel:9361417572|936 141 7572>
パスコード: 6up9SH

## 2024-07-24

- [1721804579.679109] <@U0331FWGQRM>: <@U066P20UQH1>
SebastyanのMTG　URL
- [1721806857.840929] <@U0331FWGQRM>: <@U066P20UQH1> <@U0331FZS7JT> <@U03BLQ65GK0> <@U033G4KN4TD>
<https://meet.google.com/xpq-wxgo-kkg>
  - attachments: [{"from_url": "https://meet.google.com/xpq-wxgo-kkg", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "id": 1, "original_url": "https://meet.google.com/xpq-wxgo-kkg", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/xpq-wxgo-kkg", "service_name": "meet.google.com"}]
- [1721808586.618019] <@U0331FWGQRM>: <@U03BLQ65GK0>
<https://www.houwa.net/category/container/>
  - attachments: [{"from_url": "https://www.houwa.net/category/container/", "service_icon": "https://www.houwa.net/wp-content/uploads/2017/03/cropped-favicon-houwa1703-1-180x180.png", "id": 1, "original_url": "https://www.houwa.net/category/container/", "fallback": "ホウワ: ホウワコンテナショップ | トップページ", "text": "新品・中古海上コンテナの製造、改造、販売、レンタルを手がけるホウワコンテナショップのトップページです。", "title": "ホウワコンテナショップ | トップページ", "title_link": "https://www.houwa.net/category/container/", "service_name": "ホウワ"}]
- [1721808631.818599] <@U05KGS6HN9H>: <@U0331FWGQRM>
金額確認したところ、TOP-Y担当より質問があります。
・熱転写印字+バックシール製袋タイプでよろしいですか？
・ステック袋のサイズとパウダー量を教えてください。
- [1721808959.611759] <@U0331FWGQRM>: <@U05KGS6HN9H>
> ・熱転写印字+バックシール製袋タイプでよろしいですか？
→インクジェット可能であれば。

> ・ステック袋のサイズとパウダー量を教えてください。
→2g-15g入ればOK。メインは3-5g。
幅3-10cmできればOK。メインは3-5cm。

一列でなくて、２列になれば値段はどの程度高くなりますか？

## 2024-07-26

- [1721988034.359339] <@U05KGS6HN9H>: <@U0331FWGQRM>
担当者へ電話も試みましたが繋がらず、Cahtで断続的にやり取りを
行っていますが、ご家庭の事情で休まれているそうです。
細かい仕様部分は別として、カタログの標準機械金額だけでも分からないか
問い合わせていますが、返信がありません。
来週月曜か火曜より出社するようですので、引き続きプッシュ致します。

## 2024-07-30

- [1722398426.946789] <@U05KGS6HN9H>: <@U03BLQ65GK0>
先ほど図面が届きました。茶詰め機本体電源1本は画像の位置から3Mの長さ
で出ているそうです。コンプレッサとドライヤの電源2本も確認しましたが、
コンセント近くの壁際付近に設置すれば問題無いとの回答（サイズ感を知る上で
図面を要求しましたが、購入機器の為図面は無いとのことです）
先方からは、電源コード位置及び設備全体が茶詰め場に問題なくレイアウト
できるか最終確認の要請です。
納期の件、何度となく確認していますが（まず現状7/22起算で45日以内出荷→
9/11が45日目に対して、機械完成及び動作確認可能が何時になるか→納期短縮
が可能か）、未だ具体的な生産日程の回答が得られません。
  - files: [{"id": "F07EMBHPN86", "created": 1722398319, "timestamp": 1722398319, "name": "図面_MDPX2 开拉链+气动振斗+ 双层防尘封刀+单拍+喷码+圆斗+充气(MDP2024049订单).PDF", "title": "図面_MDPX2 开拉链+气动振斗+ 双层防尘封刀+单拍+喷码+圆斗+充气(MDP2024049订单).PDF", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 785760, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07EMBHPN86/_______mdpx2________________________________________________________________________mdp2024049_______.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07EMBHPN86/download/_______mdpx2________________________________________________________________________mdp2024049_______.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07EMBHPN86-cca98f6587/_______mdpx2________________________________________________________________________mdp2024049________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1819, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07EMBHPN86/_______mdpx2________________________________________________________________________mdp2024049_______.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07EMBHPN86-3a7fc25aa0", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07EWEWBDV2", "created": 1722398324, "timestamp": 1722398324, "name": "茶詰め機電源コード.jpg", "title": "茶詰め機電源コード.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 840998, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07EWEWBDV2/___________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07EWEWBDV2/download/___________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07EWEWBDV2-ff7d92adfb/____________________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07EWEWBDV2-ff7d92adfb/____________________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07EWEWBDV2-ff7d92adfb/____________________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07EWEWBDV2-ff7d92adfb/____________________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 222, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07EWEWBDV2-ff7d92adfb/____________________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07EWEWBDV2-ff7d92adfb/____________________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 332, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07EWEWBDV2-ff7d92adfb/____________________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1733, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07EWEWBDV2-ff7d92adfb/____________________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 443, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07EWEWBDV2-ff7d92adfb/____________________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 473, "thumb_1024_h": 1024, "original_w": 1080, "original_h": 2340, "thumb_tiny": "AwAwABawblNxAJIHcDrTknV2C5Iz0yKglKqSEUbBjAIqNXijlBX5jgYGeAe9AGkFxRiqJucoBIpJPIpvnJ/cNAEYKmL95k+hB5FV0jaTcQPu9TnpVqSPy8p1APWkgSXO+Ie2ccUDREqMvbPHbrTvm/uP+dTtG7MWdlQg47Ck8r/psv50AXpFRwNwz9RSjavC9uvFKQfWk2nOcmkAKqqzMByxyTinZHv+VGKNo9KYj//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07EWEWBDV2/___________________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07EWEWBDV2-9457b5640b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1722401914.810359] <@U03BLQ65GK0>: <@U05KGS6HN9H>
ありがとうございます！
図面についてですが、お願いしていたのは茶詰め場のどこに200Vの電源を設置する必要があるのかが分かる図面です。
つまり、ベースは現在設置場所の検討に使用している図面で、その中のどこに電源を設置するのかを明記していただきたいということです。
上記図面内に記載された機械のどの部分から電源（コンセント）が出ているのかを記載してもらうだけでも良いのでお願いします。

## 2024-07-31

- [1722420370.867079] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
巻締機（真空不可）の購入のために、
中国メーカーに下記缶を各10缶送ってくれますか？

72 x 100 mm（←タマヤのMomatcha様に提案していたやつ）
60 x 60 mm（中国製でOK）スクリュープルトップ
60 x 100 mm（中国製でOK）スクリュープルトップ
62 x 102 mm（日東のプラスチック蓋のやつ）
~65 x 85 mm　（おそらく間も無くサウジのFayから届くと思います）~

ーーー
Company Name: Guangdong Xtime Packaging Equiment Co., Ltd.
Address: 17-She Industrial Park Hecun, Chengjiao Street, Conghua District, Guangzhou, Guangdong, China.
Post code: 510900
Attn: Ray Huang
Tel: <tel:+8613726829643|+86-137 2682 9643>

## 2024-08-01

- [1722555795.626879] <@U05KGS6HN9H>: <@U0331FWGQRM>
添付が担当者が昨夜在宅で送信してくれた見積となりますが、印字が熱転写で
見積もられております。（依頼はインクジェット、現在引き続き確認中）
取り急ぎおおよその金額として、ご確認お願い致します。
（EXWで USD8920 ≒ 140万円）
  - files: [{"id": "F07F661KJ1G", "created": 1722555791, "timestamp": 1722555791, "name": "20240801_DXD-50F_ステック茶詰め機見積_熱転写印字.pdf", "title": "20240801_DXD-50F_ステック茶詰め機見積_熱転写印字.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 890006, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07F661KJ1G/20240801_dxd-50f_______________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07F661KJ1G/download/20240801_dxd-50f_______________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07F661KJ1G-98d68c3fb2/20240801_dxd-50f________________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07F661KJ1G/20240801_dxd-50f_______________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07F661KJ1G-f5d1c8529a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1722558496.115359] <@U0331FWGQRM>: <@U05KGS6HN9H>
有難うございます。
自動粉末充填機のinkjetの価格はUSD 1710なので、
それをベースに考えると、プリンターだけ高すぎません？？:sweat_drops:
  - files: [{"id": "F07F8Q4NZ7E", "created": 1722558478, "timestamp": 1722558478, "name": "4th Quotation of MDP2 mini doypack machine with auger filler-TOP Y Machinery.pdf", "title": "4th Quotation of MDP2 mini doypack machine with auger filler-TOP Y Machinery.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 1968921, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07F8Q4NZ7E/4th_quotation_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07F8Q4NZ7E/download/4th_quotation_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07F8Q4NZ7E-ba5db44ea6/4th_quotation_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07F8Q4NZ7E/4th_quotation_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07F8Q4NZ7E-6ee92ec22a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1722571761.483329] <@U05KGS6HN9H>: <@U0331FWGQRM>
インクジェット印字での見積を取得しました。
自動粉末充填機と同タイプのプリンター採用可能とのことで、
価格的にはUSD2135下がり、EXWでUSD6785≒105万円の
見積となっております。合わせて参考動画が届きました。
印字につき、先方からは補足として、DXD機でのインクジェットは
インクの乾きが遅く擦れ汚れが生じる可能性があるとのことです。
※参考動画内の印字はインクジェット式とのことです。
  - files: [{"id": "F07F9CGMRQU", "created": 1722571647, "timestamp": 1722571647, "name": "20240801_DXD-50Fステック茶詰め機見積_インクジェット印字.pdf", "title": "20240801_DXD-50Fステック茶詰め機見積_インクジェット印字.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 886340, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07F9CGMRQU/20240801_dxd-50f__________________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07F9CGMRQU/download/20240801_dxd-50f__________________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07F9CGMRQU-352259ed91/20240801_dxd-50f___________________________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07F9CGMRQU/20240801_dxd-50f__________________________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07F9CGMRQU-8740c78318", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07ESBDHL0P", "created": 1722571655, "timestamp": 1722571655, "name": "4dd55814ae63eb25a46efa1ac0f2cb9a.mp4", "title": "4dd55814ae63eb25a46efa1ac0f2cb9a.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 8285169, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F07ESBDHL0P-f9b7c72ca1/4dd55814ae63eb25a46efa1ac0f2cb9a.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F07ESBDHL0P-f9b7c72ca1/4dd55814ae63eb25a46efa1ac0f2cb9a.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07ESBDHL0P/download/4dd55814ae63eb25a46efa1ac0f2cb9a.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F07ESBDHL0P-f9b7c72ca1/file.m3u8?_xcb=1d1dd&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9Mzc1MzQ4OSxBVkVSQUdFLUJBTkRXSURUSD0zMDE5OTc4LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTEyODB4NzE4LEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1JWTkNSRWhNTUZBdFpqbGlOMk0zTW1OaE1TOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREF4TG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EZEZVMEpFU0V3d1VDMW1PV0kzWXpjeVkyRXhMMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TURJdWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdOMFZUUWtSSVREQlFMV1k1WWpkak56SmpZVEV2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd015NTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzUlZOQ1JFaE1NRkF0WmpsaU4yTTNNbU5oTVM5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01EQTBMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURkRlUwSkVTRXd3VUMxbU9XSTNZemN5WTJFeEwyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNRFV1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd04wVlRRa1JJVERCUUxXWTVZamRqTnpKallURXZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3Tmk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNSVk5DUkVoTU1GQXRaamxpTjJNM01tTmhNUzltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURBM0xuUnpDaU5GV0ZSSlRrWTZOaTR3TURZc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGRGVTBKRVNFd3dVQzFtT1dJM1l6Y3lZMkV4TDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01EZ3VkSE1LSTBWWVZFbE9Sam8yTGpBd05pd0thSFIwY0hNNkx5OW1hV3hsY3k1emJHRmpheTVqYjIwdlptbHNaWE10ZEcxaUwxUXdNek5FTnpCU1VqWklMVVl3TjBWVFFrUklUREJRTFdZNVlqZGpOekpqWVRFdlptbHNaVjlJWHpJMk5GOHhNamd3ZURjeU1GOHpOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdPUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1JWTkNSRWhNTUZBdFpqbGlOMk0zTW1OaE1TOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREV3TG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EZEZVMEpFU0V3d1VDMW1PV0kzWXpjeVkyRXhMMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TVRFdWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdOMFZUUWtSSVREQlFMV1k1WWpkak56SmpZVEV2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE1pNTBjd29qUlZoVVNVNUdPalF1T1RBMUxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzUlZOQ1JFaE1NRkF0WmpsaU4yTTNNbU5oTVM5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01ERXpMblJ6Q2lORldGUXRXQzFGVGtSTVNWTlVDZz09Cg==", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F07ESBDHL0P-f9b7c72ca1/4dd55814ae63eb25a46efa1ac0f2cb9a_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 76976, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F07ESBDHL0P-f9b7c72ca1/4dd55814ae63eb25a46efa1ac0f2cb9a_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 856, "thumb_video_h": 480, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07ESBDHL0P/4dd55814ae63eb25a46efa1ac0f2cb9a.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F07ESBDHL0P-00b0878914", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-08-02

- [1722584567.836549] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
65 x 85 mm
（おそらく間も無くサウジのFayから届くと思います）
→これは後回しになりました。
　とりあえずこれは無しで、
　送ってもらえますか？
　宜しくお願いします！:sweat_drops:
- [1722586094.179459] <@U0331FWGQRM>: <@U05KGS6HN9H>
悩みどころですね:sweat_drops:
それにしても、元の印字機、値段高すぎません？？？

## 2024-08-05

- [1722905999.585449] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本件、いつ頃発送できそうですか？
（タマヤ待ちですか？タマヤからいつ頃入りそうです？？？）
- [1722910149.812029] <@U05KGS6HN9H>: <@U0331FWGQRM>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
タマヤ待ちで、入荷予定が8/8（木）です。
入荷当日8/8のDHL発送で予定致します。

## 2024-08-07

- [1723099648.899929] <@U05KGS6HN9H>: <@U03BLQ65GK0>
資料関係を以下に保存してゆきます。
桃翠園共有〉●工場〉機械仕様書・見積書〉ステック茶詰め機DXD-50F
これからメーカー側に発注を前提として、インクジェット印字をベースに、
カット刃形状の金型詳細等を盛り込んだ見積依頼を行います。

## 2024-08-08

- [1723111829.644119] <@U05KGS6HN9H>: <@U0331FWGQRM>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本日8/8のDHLで缶4種を発送しました。
AWB No 9154330813
資料、画像関係は以下に保存しております。
桃翠園共有〉●工場〉機械仕様書・見積書〉巻締め機（中国）〉20240808巻締め機テスト缶
宜しくお願い致します。
- [1723181539.923519] <@U05KGS6HN9H>: <@U03BLQ65GK0>
<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
メーカー側に希望する袋形状4種（添付A～D）を伝え、各ブレード費用を盛り込んだ見積書を
依頼したところ、A（ギザ刃）とB（フラット）はブレード交換し機械1台で共有できるが、
C（角丸）とD（変形カット）は機構的に複雑な交換調整が必要のようで、1台で交換共有は
推奨できず、万一調整が上手くいかなかった場合には、機械破損に繋がるようです。
見積はAとB共用前提で進めたいと思いますが、宜しいでしょうか。
  - files: [{"id": "F07G4K19EPP", "created": 1723181484, "timestamp": 1723181484, "name": "ステック茶詰め機_確認資料.pdf", "title": "ステック茶詰め機_確認資料.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 186670, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07G4K19EPP/_____________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07G4K19EPP/download/_____________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07G4K19EPP-cd4eaf78e7/______________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07G4K19EPP/_____________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07G4K19EPP-a87e3f5254", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07G0SL75NJ", "created": 1723181500, "timestamp": 1723181500, "name": "メーカー見解.jpg", "title": "メーカー見解.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 35079, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07G0SL75NJ/__________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07G0SL75NJ/download/__________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07G0SL75NJ-826808a274/___________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07G0SL75NJ-826808a274/___________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07G0SL75NJ-826808a274/___________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 124, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07G0SL75NJ-826808a274/___________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 165, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07G0SL75NJ-826808a274/___________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 690, "original_h": 237, "thumb_tiny": "AwAQADDR53Y4xRz7UYGc96Z5fvQA87uwH50c98UmxfejYPU0ALilpvlr706gD//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07G0SL75NJ/__________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07G0SL75NJ-8bfc7d4dc3", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1723183325.584679] <@U03BLQ65GK0>: <@U05KGS6HN9H>
ありがとうございます。
CとDは使用しないということですか？
もし使用する場合はC用に1台、D用に1台が必要になるという認識で合ってますか？

## 2024-08-09

- [1723186901.750769] <@U05KGS6HN9H>: <@U03BLQ65GK0> <@U0331FWGQRM>
メーカーに確認しましたが、1台で兼用可能はAとB。C或いはDは、それぞれ1台ずつ専用機
で必要（つまりC用に1台、D用に1台が必要）との回答です。以下で見積取りましょうか？
パターン①　A/B兼用
パターン②　C専用（参考）
パターン③　D専用（参考）
- [1723188623.384039] <@U03BLQ65GK0>: <@U05KGS6HN9H>
②と③取っても良いのですが（邪魔にはならないという意味で）、本当は①だけで良いということで良いです？
（桃翠園としては①で製造を進めていくということで良いですか？）
- [1723190096.758749] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U05KGS6HN9H> cc <@U0331FZS7JT>
返信遅くなりすみません。
1台で全てできるのであれば、
全種類のアタッチメントが欲しい（見積もりだけでも）と思ったのですが、
上記の状況を考慮すると、
購入は今のところ、パターン①　A/B兼用　だけで良さそうですね。

その上で、
&gt; 機構的に複雑な交換調整が必要のようで、1台で交換共有は
&gt; 推奨できず、万一調整が上手くいかなかった場合には、機械破損に繋がる
これについて詳しく理解することができれば、
（いやいや、全然自分達で交換できますやん。ってなれば）
アタッチメントの交換を自分達で行い、１台で交換共有できるかもしれませんね。
なぜ、“万一調整が上手くいかなかった場合“の様なことが起こりうるのか、
今でなくても良いですが、知りたいなと思いました。

## 2024-08-10

- [1723285285.393259] <@U05KGS6HN9H>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
TOP-Yよりステック機（DXD-50F）の見積を入手致しました。
220V/3相/60Hz、インクジェット印字、A（ギザ刃）/B（フラット）兼用です。
見積が「３rd」「4th」ありますが、添付「要回答_見積確認事項」の
②V Shape有無の違いです。メーカーには8/15まで盆休みの為、8/16回答と
なる旨を連絡しております。

<@U0331FZS7JT> <@U0331FWGQRM>
◆見積確認事項の①②につき、ご検討ご指示をお願い致します。

<@U03BLQ65GK0>
既に発注済みの茶詰め機（MDP）と同時出荷で可能との回答はありました。
9/10に機械梱包完了予定です。別途フォワーダー経由で、具体的な船便の
スケジュール等を詰める必要があります。MDP機につきましてはメーカーの
生産計画表をご参考ください。
  - files: [{"id": "F07GRQXQAQ1", "created": 1723285253, "timestamp": 1723285253, "name": "20240810_3rd Quotation of DXD-50F Sachet Packing Machine for Powder-TOP Y Machinery.pdf", "title": "20240810_3rd Quotation of DXD-50F Sachet Packing Machine for Powder-TOP Y Machinery.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 868696, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07GRQXQAQ1/20240810_3rd_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07GRQXQAQ1/download/20240810_3rd_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07GRQXQAQ1-cc32190f0b/20240810_3rd_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07GRQXQAQ1/20240810_3rd_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07GRQXQAQ1-94f14f6594", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07FYJKHNHM", "created": 1723285259, "timestamp": 1723285259, "name": "20240810_4th Quotation of DXD-50F Sachet Packing Machine for Powder-TOP Y Machinery.pdf", "title": "20240810_4th Quotation of DXD-50F Sachet Packing Machine for Powder-TOP Y Machinery.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 868117, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07FYJKHNHM/20240810_4th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07FYJKHNHM/download/20240810_4th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07FYJKHNHM-45d7f0d924/20240810_4th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07FYJKHNHM/20240810_4th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07FYJKHNHM-9f234acf16", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07GA8KTD8D", "created": 1723285265, "timestamp": 1723285265, "name": "要回答_見積確認事項.pdf", "title": "要回答_見積確認事項.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 667974, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07GA8KTD8D/____________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07GA8KTD8D/download/____________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07GA8KTD8D-a177372b55/_____________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1444, "thumb_pdf_h": 2042, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07GA8KTD8D/____________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07GA8KTD8D-8f5210f6fb", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07GFKPMTK6", "created": 1723285270, "timestamp": 1723285270, "name": "生産計画表20240810_MDP2024049订单生产计划排产表.xlsx", "title": "生産計画表20240810_MDP2024049订单生产计划排产表.xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 17448, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07GFKPMTK6/_______________20240810_mdp2024049___________________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07GFKPMTK6/download/_______________20240810_mdp2024049___________________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07GFKPMTK6-45c09c67f7/_______________20240810_mdp2024049____________________________converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07GFKPMTK6-45c09c67f7/_______________20240810_mdp2024049____________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07GFKPMTK6/_______________20240810_mdp2024049___________________________.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F07GFKPMTK6-23f15b2db2", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-08-17

- [1723885228.666349] <@U05KGS6HN9H>: <@U0331FZS7JT> <@U0331FWGQRM> <@U03BLQ65GK0>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
《共有》
本日の打ち合わせで決まったステック袋幅（25㎜/30㎜/35㎜/40㎜/50㎜/60㎜）
をメーカーに伝えたところ、今更のように背面ピロー幅の標準は8㎜との情報が
入り、社長とも相談して静パックに準じて「ピロー幅は5㎜、袋仕上りで上記幅
6規格」をメーカーに改めて要求しております。
  - files: [{"id": "F07H547CLP8", "created": 1723885210, "timestamp": 1723885210, "name": "袋子要求.pdf", "title": "袋子要求.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 57310, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07H547CLP8/____________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07H547CLP8/download/____________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07H547CLP8-ab8450f69d/_____________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07H547CLP8/____________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07H547CLP8-7af68a833a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1723900415.174599] <@U0331FWGQRM>: <@U05KGS6HN9H>
&gt; 静パックに準じて「ピロー幅は5㎜
と言うのは、実測で5mmなのですか？
それとも静パックに確認して、
“5mm”と言う回答をもらっているのですか？

質問の意図は、
その幅自体が、どの機械でも固定の幅なのかな？と気になった為です。
つまり、静パックは調整できるのだけど、今手元にあるスティックが偶然5mm、って言う可能性はないのかな？
時になっただけなのですが。。。

## 2024-08-18

- [1724036338.472509] <@U05KGS6HN9H>: <@U0331FWGQRM>
<@U0331FZS7JT> <@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
&gt; 静パックに準じて「ピロー幅は5㎜]
は実測です。
中国機械（DXD-50F）はforming tubeを作成した時点でピロー幅が固定
となる（標準で8㎜）との連絡が入り、ピロー部分が8㎜もあると印字等で
邪魔になることを懸念し、5㎜幅に設定した次第です。
こちらからの要求（ピロー幅5㎜で、袋仕上幅が25㎜/30㎜/35㎜/40㎜/
50㎜/60㎜）に対して対応は可能であり、以下のロールフィルム幅となる
連絡がきております。
　仕上幅25㎜←フィルム幅60㎜（ピロー部分重なり5㎜×2+袋25㎜×2）
　仕上幅30㎜←フィルム幅70㎜（ピロー部分重なり5㎜×2+袋30㎜×2）
　仕上幅35㎜←フィルム幅80㎜（ピロー部分重なり5㎜×2+袋35㎜×2）
　仕上幅40㎜←フィルム幅90㎜（ピロー部分重なり5㎜×2+袋40㎜×2）
　仕上幅50㎜←フィルム幅110㎜（ピロー部分重なり5㎜×2+袋50㎜×2）
　仕上幅60㎜←フィルム幅130㎜（ピロー部分重なり5㎜×2+袋60㎜×2）
<@U03BLQ65GK0>
forming tube追加分での見積（5th)を取得いたしました。
ご確認をお願い致します。
  - files: [{"id": "F07HEQCD8HH", "created": 1724036244, "timestamp": 1724036244, "name": "20240819_5th Quotation of DXD-50F Sachet Packing Machine for Powder-TOP Y Machinery.pdf", "title": "20240819_5th Quotation of DXD-50F Sachet Packing Machine for Powder-TOP Y Machinery.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 868126, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07HEQCD8HH/20240819_5th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07HEQCD8HH/download/20240819_5th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07HEQCD8HH-e5f5db1e4e/20240819_5th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07HEQCD8HH/20240819_5th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07HEQCD8HH-576f59c948", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07HEQELDDZ", "created": 1724036302, "timestamp": 1724036302, "name": "フィルム幅.jpg", "title": "フィルム幅.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 70659, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07HEQELDDZ/_______________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07HEQELDDZ/download/_______________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07HEQELDDZ-8833fc22c3/________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07HEQELDDZ-8833fc22c3/________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07HEQELDDZ-8833fc22c3/________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 173, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07HEQELDDZ-8833fc22c3/________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 231, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07HEQELDDZ-8833fc22c3/________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07HEQELDDZ-8833fc22c3/________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 347, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07HEQELDDZ-8833fc22c3/________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 385, "thumb_800_h": 800, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07HEQELDDZ-8833fc22c3/________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 462, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07HEQELDDZ-8833fc22c3/________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 493, "thumb_1024_h": 1024, "original_w": 720, "original_h": 1496, "thumb_tiny": "AwAwABe/ijn+9+lLx64pQV9RQAgFFAzjlgT7UtADHTfjPameSPWpBkdu/rS/hSshWERdop1FJTGHPpmlA9RQPel4oAaMkcjHtRS8k+1GDQB//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07HEQELDDZ/_______________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07HEQELDDZ-893e7ecf66", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-08-19

- [1724120013.329749] <@U05KGS6HN9H>: <@U0331FZS7JT> <@U0331FWGQRM>
中国メーカーよりステック機のインクジェット用インクにつき
確認が入っております。
《訳》
DXD-50Fのインクジェットプリンターには、標準備品として
黒インキが2箱付きます（5th見積金額内）。それ以外に白インキも
必要でしょうか？白はUSD180/箱（5th見積に含まれず）です。
何箱必要かご確認ご連絡をお願いします。
- [1724121716.821399] <@U0331FWGQRM>: <@U05KGS6HN9H>
白インクは必要ないのですが、
提案可否検討用として、
サンプルで一個つけてもらうか、
最小数量購入がいいかと思います~が、~
~どうでしょうか? <@U0331FZS7JT>~ 

## 2024-08-20

- [1724141263.202559] <@U0331FWGQRM>: <@U05KGS6HN9H>
上記確認でストップしてしまってますか？
OKなので、上記内容（下記）でそのまま進めてください。
&gt; 白インクは必要ないのですが、
&gt; 提案可否検討用として、
&gt; サンプルで一個つけてもらうか、
&gt; 最小数量購入がいいかと思います
- [1724149202.366929] <@U05KGS6HN9H>: <@U0331FWGQRM> <@U0331FZS7JT>
現在サンプルで白インキ1箱をもらえないか、担当から確認してもらって
おります。
- [1724207897.715279] <@U05KGS6HN9H>: <@U0331FZS7JT> <@U0331FWGQRM>
担当者から会社側にサンプル提供を打診してもらいましたが、
無償提供は不可とのことですので、1箱優待価格USD100で
購入させていただきます。
- [1724208411.156159] <@U0331FWGQRM>: <@U05KGS6HN9H>
ありがとうございます。OKです。

事前に確認していただきたい（すぐでなくてもいい）のですが、
フィルムのダイラインは提供いただけるのでしょうか？
この機械がどの様なフィルムのデザインが必要なのかなどの情報を確認いただきたいです。
（静パックで言うところの添付の様なものです）

※雑談で聞いて頂きたいのですが、
若干気になったのが、
forming tubeが高い？と少しだけ引っかかったので、一応共有しておきます。（全体に対しては小さい額なのでいいんですけど、。）
  - files: [{"id": "F07J61TCXQ9", "created": 1724208385, "timestamp": 1724208385, "name": "スティック充填用レイアウト図サイズ35㎜×110P(2連用).pdf", "title": "スティック充填用レイアウト図サイズ35㎜×110P(2連用).pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 75365, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07J61TCXQ9/______________________________________________________35_____110p_2_______.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07J61TCXQ9/download/______________________________________________________35_____110p_2_______.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07J61TCXQ9-446b2b7515/______________________________________________________35_____110p_2________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07J61TCXQ9/______________________________________________________35_____110p_2_______.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07J61TCXQ9-57b9d824e0", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1724211752.422609] <@U05KGS6HN9H>: <@U0331FZS7JT> <@U0331FWGQRM> <@U03BLQ65GK0>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
茶詰め機MDPとステック機DXDの同時出荷（一括で搬入し中国技術者設置）
について、先に完成予定のMDP（9/10）に対し、DXDとはそれほど大きな
開きはないのではないかというメーカー見解ですが、先ずは手付金50％の
支払いが必要です。添付最終スペックご確認をお願い致します。
<@U03BLQ65GK0>
白インク1箱を入れた6th見積です。Proforma invoiceにて送金の御手配を
お願い致します。また補助金取得に必要な一般基本契約は、汎用的なものが無く、
こちらの意図を伝え一度草稿をもらうように依頼しております。
輸入費用は梱包後の物量情報をメーカーに要請しております。
  - files: [{"id": "F07HQK70RPX", "created": 1724211730, "timestamp": 1724211730, "name": "最終スペック.png", "title": "最終スペック.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 177876, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07HQK70RPX/__________________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07HQK70RPX/download/__________________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07HQK70RPX-7f609eaf15/___________________64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07HQK70RPX-7f609eaf15/___________________80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07HQK70RPX-7f609eaf15/___________________360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 294, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07HQK70RPX-7f609eaf15/___________________480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 392, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07HQK70RPX-7f609eaf15/___________________160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07HQK70RPX-7f609eaf15/___________________720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 588, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07HQK70RPX-7f609eaf15/___________________800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 654, "original_w": 892, "original_h": 729, "thumb_tiny": "AwAnADDQlbbGxBwccUyBnYHcD9TUN39/HsKktTlelAEpY7sDFKCe5H5UhByaUA9xQAv4ijvR+FA60ARtEjtuZSD609UVPujFI33hyaVPuigB1FFFABRRRQAx87xgdqWPhBmg9aUdKAFooooAKKKKAP/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07HQK70RPX/__________________.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07HQK70RPX-1e1eab23a5", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07HW0RLH6G", "created": 1724211735, "timestamp": 1724211735, "name": "20240821_6th Quotation of DXD-50F Sachet Packing Machine for Powder-TOP Y Machinery.pdf", "title": "20240821_6th Quotation of DXD-50F Sachet Packing Machine for Powder-TOP Y Machinery.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 869276, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07HW0RLH6G/20240821_6th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07HW0RLH6G/download/20240821_6th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07HW0RLH6G-f8ec147662/20240821_6th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07HW0RLH6G/20240821_6th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07HW0RLH6G-9e8576c71b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07HCUW6ZRD", "created": 1724211739, "timestamp": 1724211739, "name": "Proforma invoice of DXD-50F sachet packing machine-TOP Y Machinery.pdf", "title": "Proforma invoice of DXD-50F sachet packing machine-TOP Y Machinery.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 41454, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07HCUW6ZRD/proforma_invoice_of_dxd-50f_sachet_packing_machine-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07HCUW6ZRD/download/proforma_invoice_of_dxd-50f_sachet_packing_machine-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07HCUW6ZRD-8026b0c3ce/proforma_invoice_of_dxd-50f_sachet_packing_machine-top_y_machinery_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07HCUW6ZRD/proforma_invoice_of_dxd-50f_sachet_packing_machine-top_y_machinery.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07HCUW6ZRD-5544f7655f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-08-23

- [1724403468.638539] <@U066P20UQH1>: <@U03BLQ65GK0>
<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
halalの認証マークについて質問です。
&gt; ・顧客Aには①、顧客Bには②を使用＝NG（使用するマークを統一する）
&gt; となります。
とありますが、これはどういう意味なのでしょうか？
「①を使用しても②に変更ができる」と「無難なのは最初から②で運用する方ですが、お客様のご要望というところもあるかと思いますので、
その時に判断をお願いします。」が引用部分と矛盾しているような気がして気になりました:sweat_drops:

それからHALAL認証マーク利用規約1.10に関してお客様から、これは認証番号等がないとマークが使用できないのでは？
と質問があり、確かに、どういう意味なのだろう。。と思ったのですが、、
もし、会長の方ですぐに回答が難しければ、
上記の件と合わせて私からJITに直接確認してよければ、確認しますので、連絡先を教えていただけますか？

お忙しいところすみませんが、ご確認の程よろしくお願いします。
  - files: [{"id": "F07JA17URS8", "created": 1724403447, "timestamp": 1724403447, "name": "111459", "title": "111459", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 38658, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07JA17URS8/111459?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07JA17URS8/download/111459?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07JA17URS8-1d0d3fa9a6/111459_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07JA17URS8-1d0d3fa9a6/111459_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07JA17URS8-1d0d3fa9a6/111459_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 125, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07JA17URS8-1d0d3fa9a6/111459_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 167, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07JA17URS8-1d0d3fa9a6/111459_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 570, "original_h": 198, "thumb_tiny": "AwAQADDRwSAdxFNBI6liPU4qSoyOAMcD/ZoAMkHqx/Kgk57j8RS7Qw5A/FaCmT/Dj0xQAAkZ+Yn24pVzjnP1NGz6flSgYFAH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07JA17URS8/111459", "permalink_public": "https://slack-files.com/T033D70RR6H-F07JA17URS8-80a2702eaa", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07J0T7252S", "created": 1724403453, "timestamp": 1724403453, "name": "HALAL認証マーク利用規約.pdf", "title": "HALAL認証マーク利用規約.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 284974, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07J0T7252S/halal___________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07J0T7252S/download/halal___________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07J0T7252S-1ef7f1b1fc/halal____________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07J0T7252S/halal___________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07J0T7252S-7678227e17", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1724416008.707479] <@U0606SPN4BW>: <@U03BLQ65GK0>  cc <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
私も自分の解釈に確信が持てないので、併せて認識合わせをお願いします！＾＾；

▼HALAL認証運用について.docx によると…
```"認証番号を入れたマークを使用した場合、その後認証マークを取外した、マークのみのタイプは使用できなくなる。"```
とのことなので、最初から「認証番号あり」のみで提案・運用する方が無難でシンプル。と認識しています。
↑ちなみに「認証番号なし」の場合、認証団体側は製品の出所をどうやって特定するんだろう？と、ふと疑問に思いました。(販売会社に聞くしかない？)


■認証番号は有無どちらでも進められるので仮に「認証番号あり」で進める場合。
---
前提条件：

①今回お問い合わせのマレーシア・Jasper Faiさんは、JAKIM(マレーシア・イスラム開発局)とJHA（ハラール局・Jabatan Halal Malaysia） に登録されている。とのこと。
  （マレーシアでハラル認証を持っている。）


②マレーシア現地で小分け・リパックして販売予定。
↓小分けにあたり関連する記述としては下記があります。
----
```【不可】
・当社からハラール認証を持っておられないお客様に原料を提供し、
お客様の方で小分け作業などをされた場合にHALAL認証マークを付けて販売することは出来ない```
上記を言い換えますと、
「先方がハラール認証を持っている場合。原料を提供し、お客様の方で小分け作業した製品もHALAL認証マークを付けて販売可能。」
先方はマレーシアでHALAL認証を受けていますので(JAKIM, JHA)、「現地で小分け可能」になるとの理解をしています。

また、"輸出時についても特に同等性などの手続きも不要。"との記述があります。
加えて「日本イスラーム文化センター」と「JAKIM, JHA」は相互認証されているとのこと。(webサイトにて確認)、

つまり今回のケースでは「先方はハラル認証されているので、現地で小分けも問題なさそう？」と見ておりますが。。
もし、どこか認識に齟齬があればご教授お願いします！
  - files: [{"id": "F07J1PEG7JA", "created": 1724415923, "timestamp": 1724415923, "name": "image.png", "title": "image.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0606SPN4BW", "user_team": "T033D70RR6H", "editable": false, "size": 27978, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07J1PEG7JA/image.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07J1PEG7JA/download/image.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1PEG7JA-59e652da08/image_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1PEG7JA-59e652da08/image_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1PEG7JA-59e652da08/image_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 213, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1PEG7JA-59e652da08/image_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 444, "original_h": 263, "thumb_tiny": "AwAcADDS/wA9KTn1P5UtN2n0FABn3P5Uufr+VIEx0Ao2n0FADsj3/KgU3afSnAEUAFMAIGMU+igBuD6UbDjjFOooAbtOO1KqkdcfhS5ozQB//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07J1PEG7JA/image.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07J1PEG7JA-daecaeabdb", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07J8CK1Q9Y", "created": 1724415938, "timestamp": 1724415938, "name": "image.png", "title": "image.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0606SPN4BW", "user_team": "T033D70RR6H", "editable": false, "size": 10951, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07J8CK1Q9Y/image.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07J8CK1Q9Y/download/image.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07J8CK1Q9Y-1dfbd4f967/image_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07J8CK1Q9Y-1dfbd4f967/image_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07J8CK1Q9Y-1dfbd4f967/image_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 143, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07J8CK1Q9Y-1dfbd4f967/image_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 404, "original_h": 160, "thumb_tiny": "AwATADDS68YNJg+h/Olo/OgBoHs350oyOx/Ol79TRjPc0AGT6GilAx3oNACUUUUAFFFFABRRRQB//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07J8CK1Q9Y/image.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07J8CK1Q9Y-497bd2e6e3", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07JASYPSDA", "created": 1724415965, "timestamp": 1724415965, "name": "image.png", "title": "image.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0606SPN4BW", "user_team": "T033D70RR6H", "editable": false, "size": 578621, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07JASYPSDA/image.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07JASYPSDA/download/image.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07JASYPSDA-486285b931/image_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07JASYPSDA-486285b931/image_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07JASYPSDA-486285b931/image_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07JASYPSDA-486285b931/image_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07JASYPSDA-486285b931/image_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07JASYPSDA-486285b931/image_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 719, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07JASYPSDA-486285b931/image_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 799, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07JASYPSDA-486285b931/image_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 959, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07JASYPSDA-486285b931/image_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 1023, "original_w": 1327, "original_h": 1326, "thumb_tiny": "AwAvADA/tCTHCJ+tH9pS/wBxP1qv5bf3T+VIYn/un8jQK6LQv5mGRGuPxo/tCfvEPyNVdjqMbW/AGk2P/cb8jTC5aGoy5+4n60G/kPVE/Wqu1/7jfkaNr/3G/I0WGbjdKbnnr+tK7bRnBP0GaQNkZ6fUUgF59aX/AD3pMn1o3cUALQKjEj/88/8Ax4U5GYnlcfjmnYCqmoeY21IST/vUh1DBIMLAg4PNQpY3KNuUqCO4akNhcHOSpz70CJ/7RH/PE/nR/aI/55H86g/s+f8A2fzpP7PuP9j86NAJ/wC01/55H86P7TX/AJ5H86i/s+bA5Ge/NJ/Z9x/s/wDfVGgH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07JASYPSDA/image.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07JASYPSDA-a788dec8d4", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1724416111.429289] <@U03BLQ65GK0>: <@U066P20UQH1> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
私の方で確実に回答が出来るのは1つ目の方ですのでまずそちらに回答します。
「①を使用しても②に変更ができる」というのは、ご理解いただいているかと思いますが、番号を入れないのであれば入れなくても良いし、その後に入れたバージョンで運用も出来ますよ ということです。ただし入れるんであればその後は番号入れた物しか使えませんよ、というルールがありあます。
その上で、お客様のご要望上番号入れて欲しいと言われることがあった場合、例えばそこまで番号無しで運用していたのに、そのお客様のご要望にお応えたことで今まで番号なしで行っていたお客様にも番号ありバージョンに変更しなくてはならなくなるということがあるので、運用スタート時点で番号有り無しどちらのバージョンで行くかは判断して下さいという意味でした。
これだけ聞くと初めから番号入れておくのが無難と思いますが、過去に有機の認証マークで、当社の番号を入れないでほしいというお客様のご要望があったので、一時期番号なしの認証マークの運用をしていた背景が有りましたので、HALAL認証の運用スタート時点でその部分を営業サイドで判断してほしいということで言っていました。

1.10については、私も改めて読んでみて不可解に思ったのが、記載されていることの裏を返せばこちら側の判断でJITの許可があれば他の団体、企業に認証マークを割り当てられることができると取れるのですが、こんなことができるのであれば桃翠園が認定機関ということになりますがそんなわけは無いですし。。（ここについては私から確認取ってみます）
それはそれとしてこの1.10から認証番号がないと運用が出来ないということは私はちょっと読み取れないのですが、どの辺りがそういった意味合いとして取られているのでしょうか？
- [1724416768.912339] <@U03BLQ65GK0>: <@U0606SPN4BW> cc <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
ありがとうございます！
以下回答いたします。
&gt; ちなみに「認証番号なし」の場合、認証団体側は製品の出所をどうやって特定するんだろう？と、ふと疑問に思いました。(販売会社に聞くしかない？)
→これは仰るとおり販売会社に聞いてたどっていくしか無いと思います。認証団体によってはしっかり管理されていて、回答できるパターンもあるかと思いますが、当社が認定を受けている団体の手法は基本的に販売会社（桃翠園）管理で、どこに何をどれだけ出したなどの他の認証では有る年間実績報告の義務がないことから、認証団体によるトレサビはほぼ不可能であると認識しています。

&gt; 今回のケースでは「先方はハラル認証されているので、現地で小分けも問題なさそう？」
→仰るとおりこの点については先方が当社のHALAL認証と同等性を持つHALAL認証を取得されているのであれば、当社がHALAL認証マークを貼付したバルク製品を荷受け・小分けされた後、「先方のHALAL認証マーク」を商品に貼付して販売することは問題ございません。

以上です。
ご確認のほどよろしくお願いします！
- [1724422060.017659] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0606SPN4BW> <@U066P20UQH1>
&gt; そのお客様のご要望にお応えたことで今まで番号なしで行っていたお客様にも番号ありバージョンに変更しなくてはならなくなるということがあるので、運用スタート時点で番号有り無しどちらのバージョンで行くかは判断して下さいという意味でした。
→そのお客様個別での話ではなく、他のお客様にも影響するんですね！:sweat_drops:
　この点についてだけ、改めて正確に把握したいです。
（確認したいこと）
　番号をつけるつけないの選択及びその後の変更について、
　客先ごとの話なのか、全てのお客様に関係・影響することなのか。

また、1.10について要約すると、
“HALAL認証マークを使用する権利は、JIT HCBの許可なく譲渡NGです。”
&gt; The right to use the certification mark by the organization cannot be assigned to or acquired by any other person, entity, or corporation (including through a change of ownership of the organization) without JIT HCB’s prior written consent.
という意味なので、会長の言われる通り、
“認証番号がないと運用が出来ないということは私はちょっと読み取れない“というのは、その通りだと思います。（全く番号について言及していない）

それ以外については、今の所、特に引っかかるところはありません。
- [1724422440.072249] <@U0606SPN4BW>: <@U03BLQ65GK0> cc <@U0331FWGQRM> <@U066P20UQH1>
その後、先方から「ブランドはまだ立ち上げ段階で現地ハラル認証は未取得」であることが判明しました:sweat_drops:

よって「ハラル認証運用.doc」に従い、現地小分けは不可。
でもOEMで桃翠園で商品の茶詰め・マレーシアにお届けであればハラル認証未取得でも現地販売可であることをお伝えしました！
- [1724458025.628139] <@U03BLQ65GK0>: <@U0331FWGQRM> cc <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
&gt; 番号をつけるつけないの選択及びその後の変更について、
&gt; 客先ごとの話なのか、全てのお客様に関係・影響することなのか。
→こちらについてのルールは
【運用スタート時点で選択できること】
番号の有無のどちらで運用を開始するか

【スタート後の番号有無verの変更】
番号なしでスタートした後、番号ありに変更することは可能だが、
一度番号ありにすると番号なしには戻れない。
※番号有りでスタートした場合も同様に番号無しに変更はできない
また、番号有り無しの両方が存在することは出来ない

【ルールの適用範囲】
あくまで桃翠園の運用ルールなので番号有り無しのどちらかの認証マークを使用するか決め、
そのマークで桃翠園が運用するということになります。
そのルールの中でお客様への対応をするとなるので、全ての客先に対して影響が出ます。
よって前述した「番号無しで既に行っていた先に、番号有りで運用を始めた場合はその先に対しても番号有りに変更しなくてはならない」というのは、桃翠園として出荷するもの全てに同じ内容のマークを出さなくてはならない為です。（番号有無ver混在運用不可の為）
- [1724458108.856789] <@U03BLQ65GK0>: <@U0606SPN4BW> cc <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
そうだったんですね:sweat_drops:
先方にお伝えいただいた内容で問題ございませんので、引き続きよろしくお願いします！

## 2024-08-27

- [1724808555.062189] <@U03BLQ65GK0>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
HALAL認証マーク利用規約1.10の認証マークを他社に対して当社が付与できるのか？という件についてJIT HCに確認をいたしました。
【結論】
不可

【理由】
和訳冒頭の「組織による」の「組織」は当社であれば桃翠園のことを指しているのではなく、
世に存在する全ての組織（＝団体・企業）を指しており、全ての組織はJIT HCの許可なく認証マークを使用することは出来ません という至極当然のことが記載されていました。

以上共有いたします！
  - files: [{"id": "F07JM427VQW", "created": 1724808490, "timestamp": 1724808490, "name": "スクリーンショット 2024-08-26 11.49.09.png", "title": "スクリーンショット 2024-08-26 11.49.09.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 52338, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07JM427VQW/____________________________2024-08-26_11.49.09.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07JM427VQW/download/____________________________2024-08-26_11.49.09.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07JM427VQW-19f1b90b8a/____________________________2024-08-26_11.49.09_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07JM427VQW-19f1b90b8a/____________________________2024-08-26_11.49.09_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07JM427VQW-19f1b90b8a/____________________________2024-08-26_11.49.09_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 55, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07JM427VQW-19f1b90b8a/____________________________2024-08-26_11.49.09_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 74, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07JM427VQW-19f1b90b8a/____________________________2024-08-26_11.49.09_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07JM427VQW-19f1b90b8a/____________________________2024-08-26_11.49.09_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 111, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07JM427VQW-19f1b90b8a/____________________________2024-08-26_11.49.09_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 123, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07JM427VQW-19f1b90b8a/____________________________2024-08-26_11.49.09_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 147, "original_w": 1022, "original_h": 157, "thumb_tiny": "AwAHADDSYEjjrTNr+v61JRQAza396lYYxTqa1ACbT+FOAI60o6UUAf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07JM427VQW/____________________________2024-08-26_11.49.09.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07JM427VQW-82e277d4c8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-08-29

- [1724922063.334459] <@U066P20UQH1>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
2点質問＆相談があります。
注文確定してる案件じゃないので、お手隙で回答いただければ助かります:sweat_drops:

①先日マレーシアのJasper Fai様というお客様とオンラインMTGをした際に、HALALマークをつけれるかどうかが最も重要なポイントだということで色々ご質問をいただいた中で、1点どっちだろう？という内容があるので
皆様に相談。。。かつもし聞いた方が良さそうであれば、<@U03BLQ65GK0> 会長にご確認いただきたいのですが、
例えば30gの抹茶を桃翠園でアルミ蒸着の風袋に詰めて、それをマレーシアに送ったものを、現地で缶に詰めた場合、HALALマークは缶につけられるのでしょうか・・？
HALAL認証運用についてという書類を見ると、
```【不可】
	・当社からハラール認証を持っておられないお客様に原料を提供し、
	お客様の方で小分け作業などをされた場合にHALAL認証マークを付けて
	販売することは出来ない```
とあるのですが、私だと可か不可かの判断がわからず。。
すみませんが皆様の意見もお聞かせいただきつつ必要に応じて認証団体に確認ができればと思います。

②もう1点、HALALマークの下に認証番号をつけるか否かですが、
結論、番号をつけておくというルールに決めておくのが良いかと思いますがどう思いますか？
仮に番号なしでいくつか出荷したとして、どこかで番号ありになった際に、過去に番号なしで出荷したものを、番号がついてないまま出荷してしまうおそれがあったり、お客様にラベルデータの変更を行なっていただかないといけなかったりと、手間やミスが増えそうだと思ったので、初めからつけておけば迷うこともないかなと思いましたがいかがでしょうか。
- [1724927094.264629] <@U0331FWGQRM>: <@U03BLQ65GK0> 
cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
最後に一点確認させてください。
もし、番号あり、なし、混合で運用しても、
みつかりようがないですよね？？笑
この認識であってます？？？

そして罰則は何もないですよね？


これらがイエス、なのであれば、

とりあえず、桃翠園のルール上は番号ありで運用しましょうか！

そして、事前にわかる分は改正して、
もし漏れがあり、万が一リピート客で番号なしで出荷しそうになったら、その都度、各々が指摘し合い、改正しましょうか。
- [1724975522.466189] <@U03BLQ65GK0>: <@U066P20UQH1> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
①についてですが、結論は可能です。
【理由】
当社がHALAL認証下で担保しなくてはならないのは製品がHALALの規定に従って製造されたものであるということです。
つまり、HACCPを基準に衛生管理されていることに加え、HALAL特有のアルコール、肉（特に豚）が製品に使用されていないことを担保しなくてはなりません。
当社で製造・小分けした製品については当然HALALに従った内容で製造していますので、
当社で小分けし、製品が直接外気に触れないような状態であれば上記は担保された状態でマレーシアのお客様の手元へ届きます。
その為、製品を小袋に詰めたままの状態で更に缶に入れて販売する場合は当社のHALAL性が担保されたまま販売されるので缶にHALALマークがついていることに問題はありません。
ただし、缶に表記されるHALALマークは当社が使用許可を得ているマーク（このスレッドの最初に私が共有したマーク）です。
以上よろしくお願いします！
- [1724975898.493469] <@U03BLQ65GK0>: <@U0331FWGQRM> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
&gt; もし、番号あり、なし、混合で運用しても、
&gt; みつかりようがないですよね？？笑
はい笑
絶対見つからないと思います笑
罰則もないです。せいぜい注意が来るぐらいだと思います。

なので、言われるように番号あり運用で、問題あれば都度修正ぐらいの温度感で全く問題ないと思います！
よろしくお願いします！

## 2024-08-30

- [1725014310.489199] <@U0331FWGQRM>: <@U05KGS6HN9H> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
スティック充填機械DXDの納期はわかりますか？
スケジュール前倒しなど、情報更新があれば共有願います。

またダイラインの取得はできましたか？
※以前送ったPDFは２連のもので、今回注文している機械は１連だと言うことは認識しております

※今回急いでいる理由は、静パックの製造スケジュールが遅すぎて、10月頭出荷希望のsebastyanの商品の製造が10月末になりそうだからです。
機械だけ先に届いてもいいので、出荷を早められるかどうか確認願います。必ずしも一緒に出荷、作業者と一緒に出荷、、でなければならない訳ではないので。
宜しくお願いします。
- [1725058668.630109] <@U05KGS6HN9H>: <@U0331FWGQRM>
<@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
・一昨日8/29にステック充填機DXDの前金50％送金が完了（メーカー側でも
入金が確認済み）し、現在納期連絡を依頼中です。

・ダイライン情報の件、静パックのレイアウトに模した図と印刷版下イメージ等を
メーカー側に伝えて確認しました。レイアウト図は数値穴埋めで返信があったものを
日本語に翻訳しています。印刷版下イメージは、印刷有効幅・光電管マークの位置・
サイズ等の情報をもらいたかったのですが、メーカーには既存の具体的な版下データ
（印刷アタリ等のレイアウト）は無いようで、以下の情報までしか取得できませんでした。
『通常フィルムメーカーなら、標準となる印刷レイアウトは全て承知されているはずなので、
フィルムメーカー標準のレイアウトに準じて手配していただきたい』
『光電管センサーは左右に移動調整が可能で、光電管マーク色は、「印刷ベース色が薄ければ、
マークは濃い色（黒等濃い色）」「印刷ベース色が濃ければ、マークは薄い色（白等薄い色）」
のように、センサーに感知されるマーク色とベース印刷色の濃淡が明確であれば良い』
  - files: [{"id": "F07KQURMDEV", "created": 1725058634, "timestamp": 1725058634, "name": "袋子設計確認（袋レイアウト確認）.pdf", "title": "袋子設計確認（袋レイアウト確認）.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 260984, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07KQURMDEV/________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07KQURMDEV/download/________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07KQURMDEV-6d8972572e/_________________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1513, "thumb_pdf_h": 2140, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07KQURMDEV/________________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07KQURMDEV-7b296836b9", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07KEPE177E", "created": 1725058639, "timestamp": 1725058639, "name": "袋子版面設計確認（印刷版下イメージ）.pdf", "title": "袋子版面設計確認（印刷版下イメージ）.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 33795, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07KEPE177E/______________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07KEPE177E/download/______________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07KEPE177E-298a951268/_______________________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07KEPE177E/______________________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07KEPE177E-525e9d8728", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-09-01

- [1725259421.884489] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <@U03BLQ65GK0>
相場の情報共有として、、、、

*スティック自動充填放送機*
メーカー：三光機械株式会社
型式：FC80（2連）
本体：800-900万
オーガ：＋1000万（マスト）
プリンター：＋200万x2個

合計：2200万。。。
- [1725259491.641899] <@U0331FWGQRM>: 
  - files: [{"id": "F07L5NT7F9N", "created": 1725259485, "timestamp": 1725259485, "name": "stick-general-catalog.pdf", "title": "stick-general-catalog.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 5523897, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07L5NT7F9N/stick-general-catalog.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07L5NT7F9N/download/stick-general-catalog.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07L5NT7F9N-91437cfcb1/stick-general-catalog_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 888, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07L5NT7F9N/stick-general-catalog.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07L5NT7F9N-2aba941d64", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-09-02

- [1725327119.175789] <@U05KGS6HN9H>: <@U0331FWGQRM>
V Shape（切れ込み）はUSD230です。
（8/10：見積「３rd」「4th」の違いが、このV Shapeの有り無しです）

## 2024-09-03

- [1725365173.484319] <@U05KGS6HN9H>: <@U0331FWGQRM> <@U03BLQ65GK0>
<@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
メーカー（TOP-Y）より、フルオート茶詰め機MDPの風袋シールエンボス形状につき
確認依頼が入りました。
A：横線エンボス
B：網目エンボス
・見積にはいずれか1型分の費用は含まれています。
・もしAとBの両方が必要であれば、もう1型分の費用（USD230）追加で
　両方手配可能（付け替え可能）とのことです。

→社長へ相談させていただき、A/B両方で手配を進めさせていただきたく考えております。
  - files: [{"id": "F07KL9QUGF7", "created": 1725365127, "timestamp": 1725365127, "name": "シールエンボス形状確認.pdf", "title": "シールエンボス形状確認.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 298474, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07KL9QUGF7/_________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07KL9QUGF7/download/_________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07KL9QUGF7-20d20c3de3/__________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 968, "thumb_pdf_h": 1368, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07KL9QUGF7/_________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07KL9QUGF7-fa2ac9a390", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1725366440.058329] <@U05KGS6HN9H>: <@U03BLQ65GK0>
フルオート茶詰め機MDPの進捗ですが、機械本体の組み上げまで進んでいるようです。
明日、タッチパネルの文言（中文→日文翻訳必要）を提供してもらえるようです。

仮に9/10輸出梱包完成の場合での、桃翠園着予定シミュレーションですが、
概要は以下のような感じです。（①は疑問点あり確認中）

9/11　中国現地機械引取り（おそらく事前或いは同時に通関申告？）

①深圳出港9/12（木）→神戸入港9/17（火）→桃翠園9/20（金）
或いは
②深圳出港9/14（土）→神戸入港9/19（木）→桃翠園9/25（水）

※引取～桃翠園搬入まで、福山通運G手配です。
※税関検査や天候等による不可抗力を加味していない日程です。
  - files: [{"id": "F07KLCPQ88M", "created": 1725366388, "timestamp": 1725366388, "name": "20240903_組み上げ画像.jpg", "title": "20240903_組み上げ画像.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 6329969, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07KLCPQ88M/20240903___________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07KLCPQ88M/download/20240903___________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLCPQ88M-211d882f8b/20240903____________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLCPQ88M-211d882f8b/20240903____________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLCPQ88M-211d882f8b/20240903____________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLCPQ88M-211d882f8b/20240903____________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLCPQ88M-211d882f8b/20240903____________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLCPQ88M-211d882f8b/20240903____________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLCPQ88M-211d882f8b/20240903____________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLCPQ88M-211d882f8b/20240903____________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLCPQ88M-211d882f8b/20240903____________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 5120, "original_h": 3840, "thumb_tiny": "AwAkADC4VJ6U0qfQU93RZPnYD68Up2gDOKAKUzspyj4H8qYSWgJJyd3epXjKyyEtuXsM1G2VATcNrEbWPOKAIfyowe5Az61KYxyAxyDik2KGH3Rn8aAJ5LZy3zkOcCmnJTO4Zqa7V3K7Px5qoucnIHagBWZxgk96ZuVgwbGT3pzsApOVU5yKrBssKAJvNCRn+Js8H2pI5WZ03Z2rknntTCQetAOAcD72KANNzVOT5TxVt6qzdaBED80zFPbpTaBhgYoo7UUAf//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07KLCPQ88M/20240903___________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07KLCPQ88M-bb358c7cf1", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-09-04

- [1725442873.742079] <@U05KGS6HN9H>: <@U03BLQ65GK0>
<@U0331FZS7JT> <@U0331FWGQRM>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
（こちらのスレッドに記載して良いか迷いましたが…）
ステック茶詰め機DXD-50Fの納期交渉を続けておりましたが、
輸出梱包完成予定が9/16との連絡をメーカーより貰えました。
・フルオート茶詰め機MDP（輸出梱包完成予定9/10）
・ステック茶詰め機DXD（輸出梱包完成予定9/16）

仮ですが9/16（9/17引取り？）まで待って、この2台を20Fコンテナに積んだ場合
最短で桃翠園着が何時になるかを、現在福通Gさんへ確認しております。
途中経過となりますが共有致します。

## 2024-09-06

- [1725611404.556039] <@U0331FWGQRM>: <@U05KGS6HN9H>
下記２点、確認して欲しいのですが、
・切れ込みの形について、V以外にもありますか？
　例えばただの切り込み線のみとか。
・サンプルフィルムを送ったら、そのフィルムでテスト製造することは可能ですか？
- [1725617881.404509] <@U05KGS6HN9H>: <@U0331FWGQRM>
メーカーに確認してみました。
・切れ込みの形について、V以外にもありますか？
　例えばただの切り込み線のみとか。
→マジックカットでないフィルムを想定した確認と思いますが、今回無しとした
V Shape形状以外では、今回の製袋形状A/Bに入れられる切込みは無いそうです。
形状BでV Shape型というパターンのみですが、機械構造上後付けは不可で、今からでは
V Shape装置の取り付けは出来ないとの回答です。また只の切れ込みは、形状Dに
対してだけしか出来ないとのことです。

・サンプルフィルムを送ったら、そのフィルムでテスト製造することは可能ですか？
→もしフィルムを送付いただいてテストする場合には、納期の関係上、来週木曜までに
メーカーに到着するよう送付が必要とのことです。もし提供されるフィルムが無い場合、
メーカーの手持ち任意フィルムで稼働確認を行うとのことです。
  - files: [{"id": "F07LMB8CM89", "created": 1725617875, "timestamp": 1725617875, "name": "切れ込み.png", "title": "切れ込み.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 73099, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07LMB8CM89/____________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07LMB8CM89/download/____________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07LMB8CM89-a9a5efd468/_____________64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07LMB8CM89-a9a5efd468/_____________80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07LMB8CM89-a9a5efd468/_____________360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 347, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07LMB8CM89-a9a5efd468/_____________480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 463, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07LMB8CM89-a9a5efd468/_____________160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 505, "original_h": 524, "thumb_tiny": "AwAwAC6wltH5KEkhsDPzkVJ9mixnLY/3zQFVo0LAE7R1pyqvlkYGM9KdxWRH9miIIJJz23npTDYWu77ox/vGplVQ4wAKGVeTtFICI6fagfcx/wACNC6fakfcye+GNWCAVXIHSkiADNgYoGNX/VJ/uinL9w/WmD/Vp/uinL/qz9aAEH3xQ1Iv3xQ/egCQ/dX6UkXU0N91fpRF1agCMf6tP90U5P8AVH61X85diANjCgHinLOgiK7uc+lOwrokX/WfgaHPWolmRWyW7elRteQEn97x/umkBcb7i/SiH7zVWe+tyqgSdPVTRFfW6ZzJnPopoGf/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07LMB8CM89/____________.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07LMB8CM89-e8db3b7508", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1725685759.784849] <@U05KGS6HN9H>: <@U03BLQ65GK0>
<@U0331FZS7JT> <@U0331FWGQRM> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
MDPフルオート機のタッチパネル日本語表示の件、ようやくメーカーから表示文言
のデータが届きましたが、英文/中文の単語羅列のみだった為、不明箇所（同じ英単語
が2つの中文単語に訳されている、英文と中文が内容リンクしていない…等）も多く、
メーカー技術者を呼び出して、表示内容が何を意味するか、1項目ずつ確認
しながら日文に翻訳しました。何度か反復確認しておりますが、もしかしたら
表示された際に違和感のある日本語となるかもしれません。
（実際の操作で、動きとリンクできるように表現翻訳したつもりですが…）

・添付でメーカーにデータ入力を依頼します。OS環境で文字化けの懸念がありますので、
PDFで提供します。
・別途ステックDXD機の文言を催促しております。
  - files: [{"id": "F07LCUFG44T", "created": 1725685577, "timestamp": 1725685577, "name": "MDP翻訳.pdf", "title": "MDP翻訳.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 170205, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07LCUFG44T/mdp______.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07LCUFG44T/download/mdp______.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07LCUFG44T-edbe585128/mdp_______thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07LCUFG44T/mdp______.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07LCUFG44T-30ba5e9394", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1725689200.314359] <@U05KGS6HN9H>: <@U03BLQ65GK0>
<@U0331FZS7JT> <@U0331FWGQRM>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
福通Gさんに、フルオートMDPとステックDXDを1コンテナに積み合わせした場合で、
桃翠園着最短シミュレーションを模索確認しておりましたが、当初9/20と9/25桃翠園着
となる予定船が、台風影響や、既に積載スペース飽和で押さえられず、現状以下の
最短スケジュールとなっております。

◆深圳出港9/23（月）→ 神戸入港9/28→ 10/3（木）桃翠園着
※天候等による不可抗力遅延は含みません。
※初回輸入の為、税関検査の可能性があるようです。検査に当たった場合に1日程度で
　検査がクリアできた場合での想定のようです。

・追加確認事項として、輸入にあたり食品衛生法に関係する場合の手続き有無確認があります。
　→9/9広島検疫所に確認予定
・中国技術者1回来日で2台据付～調整→現在メーカー側でビザ取得に必要な書類関係を手配中
　→当社で招聘状等発行の協力が必要
　L技術者来日にあたって、日当等の事前振込手配必要
　→機械2台据付の具体的な必要日数（支払い必要な具体的金額）をメーカーに確認中
　L最終残金支払いは「工場出荷前の動作確認後」のタイミングとなります。
　フルオートMDP 総額USD31395　前金支払済みUSD16200　残金USD15195
　（風袋シール圧着型を横線/網目エンボスで確定→ 添付：最終7th Quotation）
　ステックDXD    総額USD7025　　前金支払済みUSD3512.5　残金USD3512.5
　（白インキ1個追加→添付：最終6th Quotation）
　●残金合計USD18707.5
・輸入時に発生する輸入消費税引落口座（リアルタイム口座）の開設
　→主任経由で開設申請を依頼済み（上記輸入予定であれば、間に合う見込み）

現状を共有申し上げます。
  - files: [{"id": "F07KYG21T4P", "created": 1725686992, "timestamp": 1725686992, "name": "残金支払い.png", "title": "残金支払い.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 40696, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07KYG21T4P/_______________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07KYG21T4P/download/_______________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07KYG21T4P-a7b4db9161/________________64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07KYG21T4P-a7b4db9161/________________80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07KYG21T4P-a7b4db9161/________________360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 158, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07KYG21T4P-a7b4db9161/________________480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 211, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07KYG21T4P-a7b4db9161/________________160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07KYG21T4P-a7b4db9161/________________720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 316, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07KYG21T4P-a7b4db9161/________________800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 351, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07KYG21T4P-a7b4db9161/________________960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 422, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07KYG21T4P-a7b4db9161/________________1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 450, "original_w": 1077, "original_h": 473, "thumb_tiny": "AwAVADDRwaBRS0AISB1pNy+o/OhlDDmmiJPSlqLUfuX+8Pzo3D1FN8pPSlCKDkCjUNRRmjn2oFFMYUtFFABRRRQB/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07KYG21T4P/_______________.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07KYG21T4P-403e9973c9", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07LD11GC5R", "created": 1725689015, "timestamp": 1725689015, "name": "7th Quotation of MDP2 mini doypack machine with auger filler-TOP Y Machinery.pdf", "title": "7th Quotation of MDP2 mini doypack machine with auger filler-TOP Y Machinery.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 1941469, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07LD11GC5R/7th_quotation_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07LD11GC5R/download/7th_quotation_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07LD11GC5R-732a6b7250/7th_quotation_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07LD11GC5R/7th_quotation_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07LD11GC5R-8e3f922b08", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07KYH9RTPH", "created": 1725689090, "timestamp": 1725689090, "name": "20240821_6th Quotation of DXD-50F Sachet Packing Machine for Powder-TOP Y Machinery.pdf", "title": "20240821_6th Quotation of DXD-50F Sachet Packing Machine for Powder-TOP Y Machinery.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 869276, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07KYH9RTPH/20240821_6th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07KYH9RTPH/download/20240821_6th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07KYH9RTPH-4a1808b7a8/20240821_6th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07KYH9RTPH/20240821_6th_quotation_of_dxd-50f_sachet_packing_machine_for_powder-top_y_machinery.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07KYH9RTPH-1d54553aa0", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-09-09

- [1725871474.392819] <@U0331FWGQRM>: <@U05KGS6HN9H>
返信遅くなりすみません。

・切れ込みについて、了解です。
　今回は無しでOKです。

・サンプルフィルムについて、
上記の状況を先方に伝えて、
サンプルを今依頼中ですが、
おそらく間に合わないので、桃翠園でのテストになるかと思います。
- [1725872333.602429] <@U0331FWGQRM>: <@U041RJKV5JA> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
吉村に、フィルムの見積依頼をお願いします。

Sebastyanの2.0g抹茶用に使用しているアルミフィルム（健祥で充填してるやつ。マジックカット）

桃翠園に導入する機械は1連なので、
おそらく幅は下記になります。

25mm幅スティック：フィルム幅60mm
30mm幅スティック：フィルム幅70mm
35mm幅スティック：フィルム幅80mm

MOQと価格の確認をお願いします。
  - files: [{"id": "F07LWG2AG2V", "mode": "tombstone"}]
- [1725872813.227879] <@U0331FWGQRM>: 参考
  - files: [{"id": "F07LLBUL2H2", "created": 1725872658, "timestamp": 1725872658, "name": "スクリーンショット 2024-09-09 18.04.15.png", "title": "スクリーンショット 2024-09-09 18.04.15.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 248647, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07LLBUL2H2/____________________________2024-09-09_18.04.15.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07LLBUL2H2/download/____________________________2024-09-09_18.04.15.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07LLBUL2H2-e9ecf5fab0/____________________________2024-09-09_18.04.15_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07LLBUL2H2-e9ecf5fab0/____________________________2024-09-09_18.04.15_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07LLBUL2H2-e9ecf5fab0/____________________________2024-09-09_18.04.15_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 324, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07LLBUL2H2-e9ecf5fab0/____________________________2024-09-09_18.04.15_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 432, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07LLBUL2H2-e9ecf5fab0/____________________________2024-09-09_18.04.15_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 642, "original_h": 713, "thumb_tiny": "AwAwACvSJpCwB6N+VIyjdmkOe4GPrQA4Nk4pT0qK2YyQhj1NE7GNU245YLQBMOlFRtu/vbacM45OaAA96QkYPBpW700sDuFADLb5IFXrjuvPelnG8R9sODzSWZ/0ZP8APei6I/df9dBQBK3J+lLUbdef88VJQA1j83T9abu+Xt/31UjZIwKh8s54U0ACZRQqhQo96VsMRlAcHI+bvSqHz3AqTPsaAGMN4GUz+NPUYUDGPalooA//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07LLBUL2H2/____________________________2024-09-09_18.04.15.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07LLBUL2H2-13a9ff355e", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-09-10

- [1725955992.718279] <@U05KGS6HN9H>: <@U0331FWGQRM> <@U03BLQ65GK0>
<@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
最短予定で機械輸入を目指す上で食衛法の問題がある為、神戸検疫所（担当：田原様）へ確認致しました。
・機械を国内販売品の製造に使用する場合は検疫所へ届出必要
　→海外向け製品の製造に特化した機械であれば届け不要（誓約書を提出）
・ステンレス材質は届け不要だが、その他材質が食品接触箇所に
　使用されている場合には、届出が必要（場合によっては分析等の対応必要→費用時間等を多分に要する見込み）
　→フルオート茶詰め機ではアクリル窓が該当。
　　メーカーへ現状予定変更無しでアクリル窓をステンレスにで修正が出来ないか確認しましたが、
　　工場出荷予定及び以降の予定に遅れが生じます。また今更ですがアクリル以外にも、一部パッキンに
　　シリコンが使用されていたとの情報訂正がありました。
《結論》
これ以上の予定遅延を回避する為、メーカーからは現状のまま（アクリル窓等はそのまま）で出荷し、
フルオートMDPは海外顧客向け製品の製造用として誓約書を提出（届出無し）の方向で進めたいと
思います。（ステック機は全てステンレス）
補足：国内向けでは使用しない前提で、参考として、もし国内向けで使用する場合（可能かどうかも含め）には
　　どのような対応（例；食品接触部分を日本製に改造する等）となるか検疫所へ確認します。
- [1725965041.046629] <@U0606SPN4BW>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U03BLQ65GK0> <@U0331FZTHEK>
&lt; オランダ倉庫 パネル式冷蔵庫 見積り &gt;

*表題の件のついて、以下こちらのチャンネルでも共有させていただきます！

-------------------------------
■パネル式の冷蔵庫の見積が出ましたのでお知らせします。
・概要は添付のPDFをご確認をお願いします。


&lt; ポイント &gt;
・VAT込み 約330万円 (冷却機の設置場所のオプションや工賃で多少前後)
・現実味のある範囲で、設置可能な限り大きなサイズで調整。
・PDFの図面の縮尺はざっくりですが、大きくは違わないハズ。。
・現場の下見に来るのは可能。


&lt; 只今、確認中事項 &gt;
・注文してから納期はどれくらいか？
・決済方法のオプションは？
・"脱霜水は冷蔵庫外の床面上まで排出" と、あるが参考写真はあるか？
　（直接、床が濡れることを回避したいと考えている。）
・移転時の分解、移動、再設置の対応は可能か？
-------------------------------
  - files: [{"id": "F07LTFFSJ12", "created": 1725964959, "timestamp": 1725964959, "name": "20240909_パネル式冷蔵庫_W_Vink.pdf", "title": "20240909_パネル式冷蔵庫_W_Vink.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0606SPN4BW", "user_team": "T033D70RR6H", "editable": false, "size": 450607, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07LTFFSJ12/20240909_______________________w_vink.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07LTFFSJ12/download/20240909_______________________w_vink.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07LTFFSJ12-03518dc1cc/20240909_______________________w_vink_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1288, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07LTFFSJ12/20240909_______________________w_vink.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07LTFFSJ12-d3ece84efc", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07LN4RHXDK", "created": 1725964967, "timestamp": 1725964967, "name": "Polysystems-folder-koelen-vriezen-isoleren.pdf", "title": "Polysystems-folder-koelen-vriezen-isoleren.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0606SPN4BW", "user_team": "T033D70RR6H", "editable": false, "size": 2890414, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07LN4RHXDK/polysystems-folder-koelen-vriezen-isoleren.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07LN4RHXDK/download/polysystems-folder-koelen-vriezen-isoleren.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07LN4RHXDK-985d14166d/polysystems-folder-koelen-vriezen-isoleren_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 2723, "thumb_pdf_h": 1290, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07LN4RHXDK/polysystems-folder-koelen-vriezen-isoleren.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07LN4RHXDK-5f183206e5", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1725972540.582729] <@U0331FZS7JT>: <@U0606SPN4BW>
ありがとうございます！
庫内温度4℃はかなり良いですね！
決済方法のオプションで、分割払いができるとめちゃめちゃ良いです！w

<@U03BLQ65GK0>
補助金の対象となる（該当する補助金ってある）でしょうか？
桃翠園が契約していない建物内に設置という条件ですが、使用するのは桃翠園という状況です。
確認をお願いします。
- [1726034108.241669] <@U033G4KN4TD>: <@U0331FWGQRM> <@U03BLQ65GK0> <@U0331FZS7JT>
 <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
中国から缶の巻締機が届きました。
作業場所の選定や電源(コンセントの形)確認などが出来次第
テストしてみようと思います。
(来週17日(火)にタマヤより100ｇ缶入荷予定(約300缶))
取り急ぎ、到着の連絡でした。

よろしくお願いします。
  - files: [{"id": "F07LW8F9WNP", "created": 1726033871, "timestamp": 1726033871, "name": "S__221904921_0.jpg", "title": "S__221904921_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 487709, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07LW8F9WNP/s__221904921_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07LW8F9WNP/download/s__221904921_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07LW8F9WNP-c9f79874e0/s__221904921_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07LW8F9WNP-c9f79874e0/s__221904921_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07LW8F9WNP-c9f79874e0/s__221904921_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07LW8F9WNP-c9f79874e0/s__221904921_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07LW8F9WNP-c9f79874e0/s__221904921_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07LW8F9WNP-c9f79874e0/s__221904921_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07LW8F9WNP-c9f79874e0/s__221904921_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07LW8F9WNP-c9f79874e0/s__221904921_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07LW8F9WNP-c9f79874e0/s__221904921_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1478, "original_h": 1108, "thumb_tiny": "AwAjADBAKdtpqurcqeMdhUqYccZJHtUFDCtMI5qcrhSSDioC6Z6mgYZozgelIWHZT9arylg/zcrTQmTIMLuzhvrjP1qxbERphupOSaqhW8tQSp7nLCm7CDnco/GmIvvOmMcn3qq20uctjv0qPI7uv602Rl3Z3/pQBMpyCCc0113rjuOlRLIAT836Uqyc5LZ/CgB/alhUNJhhkYpO1Og/1v4UCK79TUYqR+pqIUwHUtJS0Af/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07LW8F9WNP/s__221904921_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07LW8F9WNP-4c9b957c1f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07LWBGU3DY", "created": 1726033874, "timestamp": 1726033874, "name": "S__221904919_0.jpg", "title": "S__221904919_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 444132, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07LWBGU3DY/s__221904919_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07LWBGU3DY/download/s__221904919_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWBGU3DY-ed549fcf90/s__221904919_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWBGU3DY-ed549fcf90/s__221904919_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWBGU3DY-ed549fcf90/s__221904919_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWBGU3DY-ed549fcf90/s__221904919_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWBGU3DY-ed549fcf90/s__221904919_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWBGU3DY-ed549fcf90/s__221904919_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWBGU3DY-ed549fcf90/s__221904919_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWBGU3DY-ed549fcf90/s__221904919_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWBGU3DY-ed549fcf90/s__221904919_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1478, "original_h": 1108, "thumb_tiny": "AwAjADCBBvkChsZ/SpDaOOjA/jUVtxOtaFJjSK4hZeRk0MjGIryGznp+lWR0pRSuFjMJZX3HIPrirUcqzABuGFXAapXcOw+ag4/iA7e9AFWA/v0+taVZUZxIh96stdnJx0psEXF60pbjsKzWuSe/61H5pJ5JpWGawcHoc0buGJ+73z0qhHO+AscYOPXmnu8hfEnX0p2JKRpvWnHpTRTAKntUV5cMMjFQ1Ys/9d+FJgWSArsoGADwBSTfcQ9+lK3+sf60Tf6tPqalFH//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07LWBGU3DY/s__221904919_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07LWBGU3DY-404822cf64", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07LYRV9XPE", "created": 1726033878, "timestamp": 1726033878, "name": "S__221904922_0.jpg", "title": "S__221904922_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 326087, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07LYRV9XPE/s__221904922_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07LYRV9XPE/download/s__221904922_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07LYRV9XPE-81a3c8efe2/s__221904922_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07LYRV9XPE-81a3c8efe2/s__221904922_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07LYRV9XPE-81a3c8efe2/s__221904922_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 203, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07LYRV9XPE-81a3c8efe2/s__221904922_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 270, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07LYRV9XPE-81a3c8efe2/s__221904922_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07LYRV9XPE-81a3c8efe2/s__221904922_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 405, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07LYRV9XPE-81a3c8efe2/s__221904922_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 450, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07LYRV9XPE-81a3c8efe2/s__221904922_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 540, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07LYRV9XPE-81a3c8efe2/s__221904922_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 576, "original_w": 1706, "original_h": 960, "thumb_tiny": "AwAbADBSmMEcUgYlwuRSsGUe1MHLZ79qW49ULI2xiHYjcCMHsahMYCAqM+9WnxLHtbg0yNPLTA5yeaLBchjJRtw7dqfKA2XTnPWnNGG9jSwoyhs+hxSGWCRjBqs8e07kJB9M1O/TNR5OR9KSY7EbMxOTjNMMrK3sakk6Uzt+FO4rEiNnk08uMYFVSxLEZ4pyk7evegD/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07LYRV9XPE/s__221904922_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07LYRV9XPE-4ba88aef81", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-09-11

- [1726040081.888429] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
プラグが入っているらしいので、
同梱物を細かく確認願います。
  - files: [{"id": "F07LWQBFXNE", "created": 1726040078, "timestamp": 1726040078, "name": "322baab45f8da1a894d3687bbbe53ecc.jpg", "title": "322baab45f8da1a894d3687bbbe53ecc.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 298219, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07LWQBFXNE/322baab45f8da1a894d3687bbbe53ecc.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07LWQBFXNE/download/322baab45f8da1a894d3687bbbe53ecc.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWQBFXNE-74fffa4068/322baab45f8da1a894d3687bbbe53ecc_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWQBFXNE-74fffa4068/322baab45f8da1a894d3687bbbe53ecc_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWQBFXNE-74fffa4068/322baab45f8da1a894d3687bbbe53ecc_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 203, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWQBFXNE-74fffa4068/322baab45f8da1a894d3687bbbe53ecc_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 270, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWQBFXNE-74fffa4068/322baab45f8da1a894d3687bbbe53ecc_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWQBFXNE-74fffa4068/322baab45f8da1a894d3687bbbe53ecc_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 405, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWQBFXNE-74fffa4068/322baab45f8da1a894d3687bbbe53ecc_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 450, "thumb_800_h": 800, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWQBFXNE-74fffa4068/322baab45f8da1a894d3687bbbe53ecc_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 540, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07LWQBFXNE-74fffa4068/322baab45f8da1a894d3687bbbe53ecc_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 576, "thumb_1024_h": 1024, "original_w": 720, "original_h": 1280, "thumb_tiny": "AwAwABuWRn/1bkGq0DbZNqjC56CrEqEgFRx6UCPBoAGOWX5sYNS5FVJgQx4NAZsck0AWWfdIFXgVIUCr6nNUklKuWYCpjKSMnNIY5xj7oznv2qPYPQ/gacCsnBGal8k+opiM4tnpmnhnxyePSoTKEyFGaaJm4wcUkNsn3MGyCfxqwLk45Q/nVRZNw5p2aYj/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07LWQBFXNE/322baab45f8da1a894d3687bbbe53ecc.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07LWQBFXNE-a4cf874b5a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-09-12

- [1726138337.297969] <@U05KGS6HN9H>: <@U0331FZS7JT> <@U0331FWGQRM>
CC　<@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
フルオート茶詰め機MDPに関し、TOP-Yより送付した風袋サンプルを使用し
実機での確認を行っているとの連絡が入りました。添付動画はAL-8でのテスト
を撮影したものです。

◆動画中で風袋に差し込まれている充填ノズルに関し、メーカーからの確認依頼です。
以下「充填ノズル極小」の必要可否をが確認お願い致します。
《経緯/確認内容》
実機には充填ノズル大中小の3規格が付いて来ますが、メーカーから「AL-8の場合、
小ノズルでも風袋に対して大きい為、更に小さいノズル（極小）を別途手配しますか？」
との連絡があります。
画像：充填ノズル、防塵ブレード参照ください
（ノズルUSD15と防塵ブレードUSD185が1セット＝追加費用USD200）
↓　
動画ではキツくても袋に差し込まれて充填出来ているように見えるので、
より小さいノズルは何故必要か？どのような不具合があり得るか？
と提案の意図を確認。
↓
TOP-Y見解として「もし袋が十分に開いていない状態だった場合、
ノズルが完全に袋へ挿入されない可能性があり、充填でパウダーが
こぼれるかもしれない」「AL-8以外の風袋は、従来付属の大中小ノズルで
充填は可能」

・但し実機MDPで充填可能なサイズとしては、AL-8が最小
（＝更に小さいノズルを作成しても、ほぼAL-8専用となる可能性あり）
・今後の風袋でAL-8サイズの受注がどれくらい見込まれるか等？

参考：今回仮に不要判断とし、もし今後必要であれば、或いは今回の
　便に間に合わない場合には、別途作成してメーカーからエアー便で
　送ることは可能。
  - files: [{"id": "F07M49YCEAX", "created": 1726138169, "timestamp": 1726138169, "name": "テスト運転20240912.mp4", "title": "テスト運転20240912.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 19673048, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F07M49YCEAX-049a95f32f/_______________20240912.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F07M49YCEAX-049a95f32f/_______________20240912.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07M49YCEAX/download/_______________20240912.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F07M49YCEAX-049a95f32f/file.m3u8?_xcb=d05e7&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MzQwMzE1NixBVkVSQUdFLUJBTkRXSURUSD0yNTQ3NzY2LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTEyNzJ4NzIwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1RUUTVXVU5GUVZndE1EUTVZVGsxWmpNeVppOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREF4TG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EZE5ORGxaUTBWQldDMHdORGxoT1RWbU16Sm1MMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TURJdWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdOMDAwT1ZsRFJVRllMVEEwT1dFNU5XWXpNbVl2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd015NTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzVFRRNVdVTkZRVmd0TURRNVlUazFaak15Wmk5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01EQTBMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURkTk5EbFpRMFZCV0Mwd05EbGhPVFZtTXpKbUwyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNRFV1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd04wMDBPVmxEUlVGWUxUQTBPV0U1TldZek1tWXZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3Tmk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNUVFE1V1VORlFWZ3RNRFE1WVRrMVpqTXlaaTltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURBM0xuUnpDaU5GV0ZSSlRrWTZOaTR3TURZc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGROTkRsWlEwVkJXQzB3TkRsaE9UVm1NekptTDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01EZ3VkSE1LSTBWWVZFbE9Sam8yTGpBd05pd0thSFIwY0hNNkx5OW1hV3hsY3k1emJHRmpheTVqYjIwdlptbHNaWE10ZEcxaUwxUXdNek5FTnpCU1VqWklMVVl3TjAwME9WbERSVUZZTFRBME9XRTVOV1l6TW1ZdlptbHNaVjlJWHpJMk5GOHhNamd3ZURjeU1GOHpOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdPUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1RUUTVXVU5GUVZndE1EUTVZVGsxWmpNeVppOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREV3TG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EZE5ORGxaUTBWQldDMHdORGxoT1RWbU16Sm1MMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TVRFdWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdOMDAwT1ZsRFJVRllMVEEwT1dFNU5XWXpNbVl2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE1pNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzVFRRNVdVTkZRVmd0TURRNVlUazFaak15Wmk5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01ERXpMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURkTk5EbFpRMFZCV0Mwd05EbGhPVFZtTXpKbUwyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNVFF1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd04wMDBPVmxEUlVGWUxUQTBPV0U1TldZek1tWXZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF4TlM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNUVFE1V1VORlFWZ3RNRFE1WVRrMVpqTXlaaTltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURFMkxuUnpDaU5GV0ZSSlRrWTZNQzQyTURFc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGROTkRsWlEwVkJXQzB3TkRsaE9UVm1NekptTDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01UY3VkSE1LSTBWWVZDMVlMVVZPUkV4SlUxUUsK", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F07M49YCEAX-049a95f32f/_______________20240912_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 96696, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F07M49YCEAX-049a95f32f/_______________20240912_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 960, "thumb_video_h": 544, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07M49YCEAX/_______________20240912.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F07M49YCEAX-fa31379450", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07MH3CE9PT", "created": 1726138177, "timestamp": 1726138177, "name": "充填ノズル_参考画像.png", "title": "充填ノズル_参考画像.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 948565, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07MH3CE9PT/____________________________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07MH3CE9PT/download/____________________________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07MH3CE9PT-41b1f12577/_____________________________64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07MH3CE9PT-41b1f12577/_____________________________80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07MH3CE9PT-41b1f12577/_____________________________360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 271, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07MH3CE9PT-41b1f12577/_____________________________480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 361, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07MH3CE9PT-41b1f12577/_____________________________160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 535, "original_h": 711, "thumb_tiny": "AwAwACSNYzbzcncpHP0pmd68djT2dmAJHK81LMVVVcKACMnApDI1iVovMAIOcYpWIAGOSPanxDdbOB65qLGT1NOwrkytFtG4c45wKXdD6fpT47XKAuzAnsKf9kX++1Kw7mezEYAUnNSsC1qBzwcVA7YA/KrFmP3hGTTEOhISNgXAJ6UzcN+QOM5ANOuE2vuHQ1EKpIVy0LpsUfam9Kr0VVhEQA29flb17Gn274lzUb4GFBzjv705NvGeCKiwzQmwIyTg1SIxT3kAAAYsPQ9qYzZ6dKauAUUmaM1Qj//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07MH3CE9PT/____________________________.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07MH3CE9PT-f86f6870b1", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07LPS6F9UP", "created": 1726138179, "timestamp": 1726138179, "name": "防塵ブレード_参考画像.jpg", "title": "防塵ブレード_参考画像.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 6592532, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07LPS6F9UP/_______________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07LPS6F9UP/download/_______________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07LPS6F9UP-aceebcc2ba/________________________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07LPS6F9UP-aceebcc2ba/________________________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07LPS6F9UP-aceebcc2ba/________________________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07LPS6F9UP-aceebcc2ba/________________________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07LPS6F9UP-aceebcc2ba/________________________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07LPS6F9UP-aceebcc2ba/________________________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07LPS6F9UP-aceebcc2ba/________________________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07LPS6F9UP-aceebcc2ba/________________________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07LPS6F9UP-aceebcc2ba/________________________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3840, "original_h": 5120, "thumb_tiny": "AwAwACSHGOKMU+pZYSIvNJyMDjFAEAPFIc96VV3OqnjJxT5k2JGuc4B5P1oAixSYpeaOaAJB0qzOQLTBPUKB79KpNuBz1qzON1sHOQUAI/SgCAEK6EnABqa55WMj3qqh3uqnucVauVAjjA7HFAFfmjn2pM0ZoAc3SrFxIPsxTPO0VUzxQ7bnLH0AoARRiRT6MKt3DBoxg5w1UzQrhYyvqQaAHdKM1GW5pN1AH//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07LPS6F9UP/_______________________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07LPS6F9UP-c3e086c75e", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1726144332.368389] <@U0331FWGQRM>: <@U05KGS6HN9H> cc <@U0331FZS7JT>
納期が変わらないんであれば購入してもいいと思いますがどうでしょうか？

※サウジのFay様の袋も結構小さいうえに、口が開きにくかったと思いますし。
- [1726146833.336149] <@U0331FWGQRM>: <@U05KGS6HN9H> cc <@U0331FZS7JT>
色々と進めてくださってありがとうございます。

私や社長からの返答待ち等あれば、
教えてくださいね。
（その返答待ちのせいで進められない。などあれば、遠慮なく教えてください。忘れている可能性があります:sweat_drops:）
- [1726147708.643359] <@U0606SPN4BW>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U03BLQ65GK0> <@U0331FZTHEK>
---&lt; 確認事項 回答 &gt;---

Q1: 注文してから納期はどれくらいか？

*・ご注文後、配送・設置までに約6週間かかります。*


Q2: 決済方法のオプションは？

*・申し訳ございませんが、分割払いはできません。*


Q3: "脱霜水は冷蔵庫外の床面上まで排出" と、あるが参考写真はあるか？
（直接、床が濡れることを回避したいと考えている。）

・*32 mmのパイプを作ります。部屋の排水溝まで延長できます。*排水ポイントがそれほど遠くない場合は、霜取り水の排水を排水ポイントまで延長することができます。

↑既存の排水パイプに繋ぎ込めるみたいです。


Q4: 移転時の分解、移動、再設置の対応は可能か？

*・はい、必要に応じて新しい場所に移動できます。*

-------------------



<@U0331FZS7JT> 残念ながら分割払いはできないとのことです！＾＾；
- [1726148187.111829] <@U0331FZS7JT>: <@U0331FWGQRM> <@U05KGS6HN9H>
同じく納期変わらないのであれば、購入する、で進めて下さい。
※オーストラリアのJarrod様も30gのデカフェ抹茶が今後増える見込みです。
よろしくお願いします。

## 2024-09-13

- [1726218769.485329] <@U05KGS6HN9H>: <@U0331FZS7JT> <@U0331FWGQRM>
<@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
機械の出荷予定を変更せず、極小ノズル手配が可能とのことですので追加し
船便に積載していただきます。追加費用USD200で更新された8th Quotationと
6th P/Iを添付致します。
  - files: [{"id": "F07MCSYDGFN", "created": 1726218726, "timestamp": 1726218726, "name": "8th Quotation of MDP2 mini doypack machine with auger filler-TOP Y Machinery.pdf", "title": "8th Quotation of MDP2 mini doypack machine with auger filler-TOP Y Machinery.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 1943158, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07MCSYDGFN/8th_quotation_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07MCSYDGFN/download/8th_quotation_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07MCSYDGFN-d088bec81c/8th_quotation_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07MCSYDGFN/8th_quotation_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07MCSYDGFN-15843fc3e0", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07MP2YH9RP", "created": 1726218732, "timestamp": 1726218732, "name": "6th Proforma invoice of MDP2 mini doypack machine with auger filler-TOP Y Machinery.pdf", "title": "6th Proforma invoice of MDP2 mini doypack machine with auger filler-TOP Y Machinery.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 48907, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07MP2YH9RP/6th_proforma_invoice_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07MP2YH9RP/download/6th_proforma_invoice_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07MP2YH9RP-8b9e202de3/6th_proforma_invoice_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07MP2YH9RP/6th_proforma_invoice_of_mdp2_mini_doypack_machine_with_auger_filler-top_y_machinery.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07MP2YH9RP-269448f876", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1726288547.604689] <@U05KGS6HN9H>: <@U0331FZS7JT> <@U0331FWGQRM>
<@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
食衛法届け資料の関係もあり、メーカーをプッシュしていましたが、
ようやくステック機DXDの図面が入手できましたので共有申し上げます。
  - files: [{"id": "F07M0BDSB8F", "created": 1726288542, "timestamp": 1726288542, "name": "ステック機DXD図面.png", "title": "ステック機DXD図面.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 85797, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07M0BDSB8F/_______________dxd______.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07M0BDSB8F/download/_______________dxd______.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07M0BDSB8F-d85e479691/_______________dxd_______64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07M0BDSB8F-d85e479691/_______________dxd_______80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07M0BDSB8F-d85e479691/_______________dxd_______360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 285, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07M0BDSB8F-d85e479691/_______________dxd_______480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 380, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07M0BDSB8F-d85e479691/_______________dxd_______160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07M0BDSB8F-d85e479691/_______________dxd_______720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 569, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07M0BDSB8F-d85e479691/_______________dxd_______800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 633, "original_w": 927, "original_h": 733, "thumb_tiny": "AwAlADDTpmTng96cODSf3aAHVHGWLHcacR8p5pFXaRwBxigBxOATSLIrHAPNBHGDzTI12tnuetAEtN2Dj2OacTgVG0hXseuOaAHkAjBqJmxLgLzjg1KDkZqNsEn2oAkADKM0gUDk8n1pV749aWgApCucZ7UtFABQQDjI6UUUAFFFFAH/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07M0BDSB8F/_______________dxd______.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07M0BDSB8F-79d366182a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-09-15

- [1726448337.156659] <@U05KGS6HN9H>: <@U03BLQ65GK0> <@U0331FZS7JT> <@U0331FWGQRM> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
支払に関し残金のP/Iがメーカーより入りましたので共有いたします。

<@U03BLQ65GK0>
添付の3，Terms of payment:に残金が表示されております。
ご確認と主任へ送金のご指示をお願い致します。
◆フルオート機MDP　残金USD15935
　（総額USD31595、送金済みUSD16200）
　Ｌ最終AL-8サイズに適した充填ノズル（極小）を追加が総額です
◆ステック機ＤＸＤ　残金USD3512.5
　（総額USD7025、送金済みUSD3512.5）
  - files: [{"id": "F07MLER942G", "created": 1726448326, "timestamp": 1726448326, "name": "20240916_フルオート機_支払い残金Left Balance Proforma invoice of MDP2.pdf", "title": "20240916_フルオート機_支払い残金Left Balance Proforma invoice of MDP2.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 48892, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07MLER942G/20240916___________________________________left_balance_proforma_invoice_of_mdp2.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07MLER942G/download/20240916___________________________________left_balance_proforma_invoice_of_mdp2.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07MLER942G-27f88a631d/20240916___________________________________left_balance_proforma_invoice_of_mdp2_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07MLER942G/20240916___________________________________left_balance_proforma_invoice_of_mdp2.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07MLER942G-4db801263d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07MWL4KLJD", "created": 1726448329, "timestamp": 1726448329, "name": "20240916_ステック機支払い残金_Left Balance Proforma invoice of DXD-50F sachet.pdf", "title": "20240916_ステック機支払い残金_Left Balance Proforma invoice of DXD-50F sachet.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 41443, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07MWL4KLJD/20240916________________________________left_balance_proforma_invoice_of_dxd-50f_sachet.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07MWL4KLJD/download/20240916________________________________left_balance_proforma_invoice_of_dxd-50f_sachet.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07MWL4KLJD-43ce53d1c3/20240916________________________________left_balance_proforma_invoice_of_dxd-50f_sachet_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07MWL4KLJD/20240916________________________________left_balance_proforma_invoice_of_dxd-50f_sachet.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07MWL4KLJD-d9fff1b26f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-09-16

- [1726541823.520959] <@U05KGS6HN9H>: <@U0331FZS7JT> <@U0331FWGQRM> <@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
ステック機DXDが完成し動作確認の動画が届きましたので
取り急ぎ共有致します。
◆先日共有の動作動画フルオートMDPと合わせまして、
機械出荷前の実機検収となるそうです。

<@U0331FZS7JT> <@U0331FWGQRM>
再度2機の動画を添付させていただきます。
OKであれば早急に残金支払いを進めたく、ご確認のほどお願い申し上げます。
  - files: [{"id": "F07MM0A1CVB", "created": 1726541787, "timestamp": 1726541787, "name": "20240917ステック機DXD動作.mp4", "title": "20240917ステック機DXD動作.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 11539856, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F07MM0A1CVB-f2c16c0db2/20240917_______________dxd______.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F07MM0A1CVB-f2c16c0db2/20240917_______________dxd______.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07MM0A1CVB/download/20240917_______________dxd______.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F07MM0A1CVB-f2c16c0db2/file.m3u8?_xcb=58c21&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MzE0OTk4NixBVkVSQUdFLUJBTkRXSURUSD0yNDU2Njk0LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTEyNzJ4NzIwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1RVMHdRVEZEVmtJdFpqSmpNVFpqTUdSaU1pOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREF4TG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EZE5UVEJCTVVOV1FpMW1NbU14Tm1Nd1pHSXlMMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TURJdWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdOMDFOTUVFeFExWkNMV1l5WXpFMll6QmtZakl2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd015NTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzVFUwd1FURkRWa0l0WmpKak1UWmpNR1JpTWk5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01EQTBMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURkTlRUQkJNVU5XUWkxbU1tTXhObU13WkdJeUwyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNRFV1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd04wMU5NRUV4UTFaQ0xXWXlZekUyWXpCa1lqSXZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3Tmk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNUVTB3UVRGRFZrSXRaakpqTVRaak1HUmlNaTltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURBM0xuUnpDaU5GV0ZSSlRrWTZOaTR3TURZc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGROVFRCQk1VTldRaTFtTW1NeE5tTXdaR0l5TDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01EZ3VkSE1LSTBWWVZFbE9Sam8yTGpBd05pd0thSFIwY0hNNkx5OW1hV3hsY3k1emJHRmpheTVqYjIwdlptbHNaWE10ZEcxaUwxUXdNek5FTnpCU1VqWklMVVl3TjAxTk1FRXhRMVpDTFdZeVl6RTJZekJrWWpJdlptbHNaVjlJWHpJMk5GOHhNamd3ZURjeU1GOHpOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdPUzUwY3dvalJWaFVTVTVHT2pJdU1EWTVMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1RVMHdRVEZEVmtJdFpqSmpNVFpqTUdSaU1pOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREV3TG5SekNpTkZXRlF0V0MxRlRrUk1TVk5VQ2c9PQo=", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F07MM0A1CVB-f2c16c0db2/20240917_______________dxd_______trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 56122, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F07MM0A1CVB-f2c16c0db2/20240917_______________dxd_______thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 960, "thumb_video_h": 544, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07MM0A1CVB/20240917_______________dxd______.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F07MM0A1CVB-494a0c28d3", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07MPS06T6W", "created": 1726541809, "timestamp": 1726541809, "name": "テスト運転20240912.mp4", "title": "テスト運転20240912.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 19673048, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F07MPS06T6W-d182664f1e/_______________20240912.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F07MPS06T6W-d182664f1e/_______________20240912.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07MPS06T6W/download/_______________20240912.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F07MPS06T6W-d182664f1e/file.m3u8?_xcb=06514&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MzQwMzE1NixBVkVSQUdFLUJBTkRXSURUSD0yNTQ3NzY2LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTEyNzJ4NzIwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1RWQlRNRFpVTmxjdFpERTRNalkyTkdZeFpTOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREF4TG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EZE5VRk13TmxRMlZ5MWtNVGd5TmpZMFpqRmxMMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TURJdWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdOMDFRVXpBMlZEWlhMV1F4T0RJMk5qUm1NV1V2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd015NTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzVFZCVE1EWlVObGN0WkRFNE1qWTJOR1l4WlM5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01EQTBMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURkTlVGTXdObFEyVnkxa01UZ3lOalkwWmpGbEwyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNRFV1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd04wMVFVekEyVkRaWExXUXhPREkyTmpSbU1XVXZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3Tmk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNUVkJUTURaVU5sY3RaREU0TWpZMk5HWXhaUzltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURBM0xuUnpDaU5GV0ZSSlRrWTZOaTR3TURZc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGROVUZNd05sUTJWeTFrTVRneU5qWTBaakZsTDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01EZ3VkSE1LSTBWWVZFbE9Sam8yTGpBd05pd0thSFIwY0hNNkx5OW1hV3hsY3k1emJHRmpheTVqYjIwdlptbHNaWE10ZEcxaUwxUXdNek5FTnpCU1VqWklMVVl3TjAxUVV6QTJWRFpYTFdReE9ESTJOalJtTVdVdlptbHNaVjlJWHpJMk5GOHhNamd3ZURjeU1GOHpOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdPUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1RWQlRNRFpVTmxjdFpERTRNalkyTkdZeFpTOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREV3TG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EZE5VRk13TmxRMlZ5MWtNVGd5TmpZMFpqRmxMMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TVRFdWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdOMDFRVXpBMlZEWlhMV1F4T0RJMk5qUm1NV1V2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE1pNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzVFZCVE1EWlVObGN0WkRFNE1qWTJOR1l4WlM5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01ERXpMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURkTlVGTXdObFEyVnkxa01UZ3lOalkwWmpGbEwyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNVFF1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd04wMVFVekEyVkRaWExXUXhPREkyTmpSbU1XVXZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF4TlM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNUVkJUTURaVU5sY3RaREU0TWpZMk5HWXhaUzltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURFMkxuUnpDaU5GV0ZSSlRrWTZNQzQyTURFc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGROVUZNd05sUTJWeTFrTVRneU5qWTBaakZsTDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01UY3VkSE1LSTBWWVZDMVlMVVZPUkV4SlUxUUsK", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F07MPS06T6W-d182664f1e/_______________20240912_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 96696, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F07MPS06T6W-d182664f1e/_______________20240912_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 960, "thumb_video_h": 544, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07MPS06T6W/_______________20240912.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F07MPS06T6W-e35f2240af", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-09-19

- [1726736500.773379] <@U05KGS6HN9H>: <@U0331FZS7JT> <@U0331FWGQRM> <@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本日9/19午後、TOP-Yから福山通運Gで集荷が完了した旨、
メーカーより連絡が入りましたので共有致します。
・食衛法届出：神戸検疫所担当官には必要書類草案を事前確認していただき、
　ほぼOKをもらいました。正式届出作成を早急に進めます。
・添付INVOICEとPacking Listで福通Gと輸入手続きを進めます。
<@U03BLQ65GK0>
　9/17福通G/後藤氏メールで、船遅延の情報（10/5が最短桃翠園着の可能性高い）
　が入っておりますが、9/23出港予定以降の本船動静追跡を引き続き依頼します。
　搬入据付の動きもありますので、別途相談させてください。
・据付時のメーカー技術者招聘
　ピンポイントで来日してもらう必要がありますので、メーカー側とビザ取得等を
　詰めてゆきます。
  - files: [{"id": "F07MP3FP5N3", "created": 1726733817, "timestamp": 1726733817, "name": "Commercial invoice.pdf", "title": "Commercial invoice.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 10422, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07MP3FP5N3/commercial_invoice.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07MP3FP5N3/download/commercial_invoice.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07MP3FP5N3-109ee6fd7f/commercial_invoice_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07MP3FP5N3/commercial_invoice.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07MP3FP5N3-e288c03653", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07MX16NY86", "created": 1726733822, "timestamp": 1726733822, "name": "Packing list.pdf", "title": "Packing list.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 19219, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07MX16NY86/packing_list.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07MX16NY86/download/packing_list.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07MX16NY86-7ac8fff60e/packing_list_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07MX16NY86/packing_list.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07MX16NY86-6ee9df950d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07NGA4GVCH", "created": 1726733826, "timestamp": 1726733826, "name": "Image_20240919170308.jpg", "title": "Image_20240919170308.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 444461, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07NGA4GVCH/image_20240919170308.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07NGA4GVCH/download/image_20240919170308.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4GVCH-fc9243f270/image_20240919170308_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4GVCH-fc9243f270/image_20240919170308_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4GVCH-fc9243f270/image_20240919170308_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 203, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4GVCH-fc9243f270/image_20240919170308_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 270, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4GVCH-fc9243f270/image_20240919170308_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4GVCH-fc9243f270/image_20240919170308_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 405, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4GVCH-fc9243f270/image_20240919170308_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1422, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4GVCH-fc9243f270/image_20240919170308_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 540, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4GVCH-fc9243f270/image_20240919170308_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 576, "thumb_1024_h": 1024, "original_w": 1080, "original_h": 1920, "thumb_tiny": "AwAwABtMhgEk4J6Gpk/eAq3Dd/8AGoZQhX5+OeDTUmZRzyR0aktipbkhB69xwauJJ8oqmj72JK4+lTjoKZKKrDcp+tNjiL87sDOKeSAMseKbHMig5Pf0pLYp7ksabGIznIqZR8oqusqGTOeMU5ZPlHNMRFMq4wrHd6moRE3fpUqshb548fhSSlcEICAPWkgY0j5cDNW44XKKcgcdMVBZgvKNw4HNaVDEf//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07NGA4GVCH/image_20240919170308.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07NGA4GVCH-6fc6e18466", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07NGA4TJD7", "created": 1726733830, "timestamp": 1726733830, "name": "Image_20240919170322.jpg", "title": "Image_20240919170322.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 490987, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07NGA4TJD7/image_20240919170322.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07NGA4TJD7/download/image_20240919170322.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4TJD7-5f7aea50c3/image_20240919170322_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4TJD7-5f7aea50c3/image_20240919170322_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4TJD7-5f7aea50c3/image_20240919170322_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 203, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4TJD7-5f7aea50c3/image_20240919170322_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 270, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4TJD7-5f7aea50c3/image_20240919170322_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4TJD7-5f7aea50c3/image_20240919170322_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 405, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4TJD7-5f7aea50c3/image_20240919170322_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1422, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4TJD7-5f7aea50c3/image_20240919170322_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 540, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07NGA4TJD7-5f7aea50c3/image_20240919170322_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 576, "thumb_1024_h": 1024, "original_w": 1080, "original_h": 1920, "thumb_tiny": "AwAwABsPBAkwD2YU9CwkO9uG/U1HJyuJCCBTEZgCv3l7ZpLUclZlphtx/dam8jg549KRJMoFfn3p5DKcDpTEV3PyN9KjBDYycY44p7/cbOOlQgilHYqe5OnIFSgnFV1YBRmnCTjqaokWQbl2ovB7jmoTAR94sPrSr94blAbuR396cyktxk596kb1EUfKQTu7A1NHFKEHy/rS29qysGZuPSrwPFAH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07NGA4TJD7/image_20240919170322.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07NGA4TJD7-7c452ac25d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07N0PFE37F", "created": 1726733834, "timestamp": 1726733834, "name": "Image_20240919170335.jpg", "title": "Image_20240919170335.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 369108, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07N0PFE37F/image_20240919170335.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07N0PFE37F/download/image_20240919170335.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07N0PFE37F-65e0fcc515/image_20240919170335_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07N0PFE37F-65e0fcc515/image_20240919170335_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07N0PFE37F-65e0fcc515/image_20240919170335_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 203, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07N0PFE37F-65e0fcc515/image_20240919170335_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 270, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07N0PFE37F-65e0fcc515/image_20240919170335_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07N0PFE37F-65e0fcc515/image_20240919170335_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 405, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07N0PFE37F-65e0fcc515/image_20240919170335_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1422, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07N0PFE37F-65e0fcc515/image_20240919170335_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 540, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07N0PFE37F-65e0fcc515/image_20240919170335_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 576, "thumb_1024_h": 1024, "original_w": 1080, "original_h": 1920, "thumb_tiny": "AwAwABuSZA0JAYdOM1TRzgVYBBG9sbAMcVEI0ydoG3/aOaaAPMx1NHmj1oO3+ECkquUm4sTxpHtk55NNCxM3ExAPYiomIJ7/AJVJabTcKCM+xFSMMIDiMkr6mlzRMQszg8c03ev94VaaE0XHiB7UwW/cHFL5zqcHB+tAuSPvLWOpoOW2XHzDJ96Dbpn7ooW6Rj3B+lO89P71LUD/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07N0PFE37F/image_20240919170335.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07N0PFE37F-74e0f9bb13", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-09-20

- [1726890510.035019] <@U041RJKV5JA>: <@U0331FZS7JT> <@U0331FWGQRM>
吉村よりスティックロールの見積もりが届きました。
巾30㎜用、長さ4,100メートルで81,180円（税込み）となっております。
よろしければ発注いたします。
ご確認お願いいたします。
  - files: [{"id": "F07NEL0Q9SP", "created": 1726890478, "timestamp": 1726890478, "name": "【御見積書】無地スティックロール　７０ｍｍ幅【エスプリ】ﾏｯﾄﾆｽ無し.pdf", "title": "【御見積書】無地スティックロール　７０ｍｍ幅【エスプリ】ﾏｯﾄﾆｽ無し.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 83485, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07NEL0Q9SP/_________________________________________________________________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07NEL0Q9SP/download/_________________________________________________________________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07NEL0Q9SP-149893b415/__________________________________________________________________________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07NEL0Q9SP/_________________________________________________________________________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07NEL0Q9SP-5b7badffb9", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-09-24

- [1727235774.550759] <@U0331FWGQRM>: <@U041RJKV5JA>
念の為にロールの巻き長さを確認願います。
１ロール1000m以下でお願いします！
- [1727244853.978199] <@U041RJKV5JA>: <@U0331FWGQRM>
1ロールの納品サイズは、70mm×1000m巻きとなります。
よろしくお願いします。

## 2024-10-08

- [1728391895.191269] <@U05KGS6HN9H>: <@U0331FZS7JT> <@U0331FWGQRM>
<@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
フルオート茶詰め機とステック機の桃翠園搬入につきまして、
途中経過となりますが、取り急ぎの情報共有をさせていただきます。
・機械は最短で10/15（火）AM9:00着となります。
　※4ｔウイング×1車で搬入予定
・設置の中国技術者
来日ビザ発給が遅れており最短での来日予定をプッシュしております。
先に機械を搬入する動きとなりますが、来日予定分かり次第に
情報共有させていただきます。
　※2名来日予定：1名据付、1名アフターメンテ等担当（1名経費は先方負担）

<@U03BLQ65GK0> <@U033G4KN4TD>
・フルオート機は8梱包、ステック機は1梱包で合板木箱に入ってきます。
・箱内の機械には透明フィルム（袋？）が被せてあるそうです。
・開梱時にインパクトやくぎ抜き、バール等が必要です。それなりに木材ゴミが
　でると思われます。
・機械はフォーク爪の通る下駄板の上に乗っていますが、箱の長手方向からしか
　フォーク爪は挿せないようですので、あればコロ台車の載せて搬入が良いと
　思われます。
※添付PackingListご参考下さい（1~8 がフルオート機、9がステック機）
※auger filler据付では、固定ベルト（画像参照）の準備をお願い致します。
確認事項ありましたらメーカーに問合せ致します。
  - files: [{"id": "F07QWLW3PS7", "created": 1728391338, "timestamp": 1728391338, "name": "Packing list.pdf", "title": "Packing list.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 19219, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07QWLW3PS7/packing_list.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07QWLW3PS7/download/packing_list.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07QWLW3PS7-82818bcb2d/packing_list_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07QWLW3PS7/packing_list.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07QWLW3PS7-1d979acd0d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07RKHLPKFA", "created": 1728391378, "timestamp": 1728391378, "name": "固定ベルト（当社準備）.jpg", "title": "固定ベルト（当社準備）.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 4884515, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07RKHLPKFA/_________________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07RKHLPKFA/download/_________________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07RKHLPKFA-49a3d9b51d/__________________________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07RKHLPKFA-49a3d9b51d/__________________________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07RKHLPKFA-49a3d9b51d/__________________________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07RKHLPKFA-49a3d9b51d/__________________________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07RKHLPKFA-49a3d9b51d/__________________________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07RKHLPKFA-49a3d9b51d/__________________________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07RKHLPKFA-49a3d9b51d/__________________________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07RKHLPKFA-49a3d9b51d/__________________________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07RKHLPKFA-49a3d9b51d/__________________________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3840, "original_h": 5120, "thumb_tiny": "AwAwACS5upjc03dRnmmAjAGkI44wM0ueaSkAm2k207OKN30oAKQ1IyAKT0xUZ4oCwA02Ryq5AzijNIeaAG+arcjdj6UeYPf8qjkVt529KZtk9aAJEklkcGQ/KO2KmLZqAGnZ4oAfnimlsUBgwyDTHoYyTOQDRzUQcgUu81JR/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07RKHLPKFA/_________________________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07RKHLPKFA-807b89e2de", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1728405475.907869] <@U0331FZS7JT>: <@U05KGS6HN9H> <@U03BLQ65GK0> <@U033G4KN4TD>
コロ台車は出雲精茶にあります。
固定ベルトも出雲精茶にありますし、桃翠園のダンプに入っていると思います。
ご確認、よろしくお願いします。
※重たい部品というか機械の部分を上に挙げて設置すると思いますが、それはいる人だけの力で上がるものですか？
難しそうであれば、対応するための方法を考えるのと事前の準備が必要だと思うので、先方に確認をお願いします。
- [1728427785.929829] <@U05KGS6HN9H>: <@U0331FZS7JT>
<@U03BLQ65GK0> <@U033G4KN4TD>
一部情報が不十分でした。失礼しました。
重量物の持ち上げにつき補足致します。
小冷蔵庫で使用している昇降リフトを吊り上げに使用予定です。
メーカー側には添付でリフト規格を確認しており、これで作業OKと
伺っております。
  - files: [{"id": "F07QXEQFD1B", "created": 1728427745, "timestamp": 1728427745, "name": "昇降叉车.pdf", "title": "昇降叉车.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 549780, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07QXEQFD1B/____________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07QXEQFD1B/download/____________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07QXEQFD1B-7832a8c255/_____________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07QXEQFD1B/____________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07QXEQFD1B-d3258bd577", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1728438501.788699] <@U0331FZS7JT>: <@U03BLQ65GK0>
CC：<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>

相良製作所の相良社長から連絡があり、
ボールミル45kg機（出雲精茶のでかい方と同じもの）を
２台無料で送ってくださる、という連絡をいただきました。

製造メーカーの宮村には既にボールミルの製造依頼をしているそうで
納期は未定です。

届いたらすぐに使えるようにしたいです。
三相用の工事が必要となるので、
今回桃翠園の茶詰め場で工事を依頼したところが
相見積もりの上、安かったと聞いたので再度見積もり依頼をお願いします。
（40数万円）

取り敢えず、冷蔵庫内という環境で、
そんなに今後機械を搬入する場所ではないので
２口で良いと思います。

よろしくお願いします。

## 2024-10-10

- [1728614677.857139] <@U05KGS6HN9H>: <@U0331FZS7JT> <@U0331FWGQRM> <@U03BLQ65GK0>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
途中経過となり申し訳ありませんが、現状の情報を共有致します。
&gt; ・設置の中国技術者
&gt; 来日ビザ発給が遅れており最短での来日予定をプッシュしております。
&gt; 先に機械を搬入する動きとなりますが、来日予定分かり次第に
&gt; 情報共有させていただきます。
先般中国で発生した事件（子供が亡くなった事案）の影響で、
日本大使館側のビザ発給における来日者チェックが厳格化されており、
発給に時間を要しているようです。
◆未確定ですがビザ発給が10/25頃の見込み（翌日フライトに搭乗来日）
との情報までとなります。引き続き現地側でも取得状況やフライト空き等
確認を要請しております。

## 2024-10-15

- [1728981212.552719] <@U05KGS6HN9H>: <@U0331FZS7JT> <@U0331FWGQRM> <@U03BLQ65GK0>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本日10/15先に設備が桃翠園に入荷しましたが、組み上げに際して
来日する中国技術者の日程が決まりましたので共有致します。
実質的には、当社に10/23、24、25、26滞在して、据付や調整指導等
を行ってもらう予定となります。
  - files: [{"id": "F07S91NKPPB", "created": 1728981199, "timestamp": 1728981199, "name": "機械据付スケジュール概要.pdf", "title": "機械据付スケジュール概要.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 296794, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07S91NKPPB/____________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07S91NKPPB/download/____________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07S91NKPPB-7df088e070/_____________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1286, "thumb_pdf_h": 910, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07S91NKPPB/____________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07S91NKPPB-955000518d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-11-16

- [1731819875.262249] <@U05KGS6HN9H>: <@U0331FZS7JT> <@U0331FWGQRM>
<@U03BLQ65GK0> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U0331FZTHEK>
ケース梱包時に箱と製品の隙間を埋めるエアクッションを、従来は空気が入ったクッション形状で
外部業者から仕入れておりましたが、今後エアクッションメーカー（機械）を使用し場内で内製化
させていただきます。
《概要》
・コスト削減
従来クッション仕入4,478円/1000粒/袋（4.478円/粒）
　L現状5袋5,000粒（22,390円）を1か月で消費
→内製フィルム仕入3,225円/3333粒/ロール（0.967円/粒）
　L最少フィルムLot数6ロール＝19,998粒（19,350円）+機械代18,750円＝38,100円
・クッションの保管スペース削減
・機械にフィルムをかけておけば自動製造が可能

梱包時は製品の上に従来通りプチプチ緩衝材を敷き、その上にクッションを入れますので、直接
製品と接触することはなく、また海外向け出荷は基本Wカートンを使用しており、クッションは
箱内で製品が踊らない為の隙間埋めという点から、耐荷重への影響等は少ないと考えます。
ご承知おき頂きたく、宜しくお願い申し上げます。

《参考》
<https://aswill-tech.co.jp/acm-2/?doing_wp_cron=1731816166.8582439422607421875000>
  - attachments: [{"from_url": "https://aswill-tech.co.jp/acm-2/?doing_wp_cron=1731816166.8582439422607421875000", "ts": 1631781675, "thumb_url": "https://aswill-tech.co.jp/wp-content/uploads/2021/07/cropped-aswill-logo-dgrn.png", "thumb_width": 667, "thumb_height": 177, "service_icon": "https://aswill-tech.co.jp/wp-content/uploads/2021/09/cropped-aswill-logo2-2-180x180.png", "id": 1, "original_url": "https://aswill-tech.co.jp/acm-2/?doing_wp_cron=1731816166.8582439422607421875000", "fallback": "アスウィル - エアークッションメーカーを販売する、株式会社アスウィルの公式HP: エアークッションメーカー【自分で作る緩衝材】 - アスウィル", "text": "緩衝材を自分で作れるエアークッションメーカー！必要な分だけ作れるから省スペース＆経済的で作れば作るほどコストカットに！緩衝材はかさばるから送料が...自分で作れるからそんな問題も解決しちゃいます。3種類のエアクッションメーカーから用途にあったものをお選びいただけます。", "title": "エアークッションメーカー【自分で作る緩衝材】 - アスウィル", "title_link": "https://aswill-tech.co.jp/acm-2/?doing_wp_cron=1731816166.8582439422607421875000", "service_name": "アスウィル - エアークッションメーカーを販売する、株式会社アスウィルの公式HP"}]
  - files: [{"id": "F08145J0C2H", "created": 1731819680, "timestamp": 1731819680, "name": "エアクッションメーカー.jpg", "title": "エアクッションメーカー.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 118537, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08145J0C2H/_________________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08145J0C2H/download/_________________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08145J0C2H-43d8317add/__________________________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08145J0C2H-43d8317add/__________________________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08145J0C2H-43d8317add/__________________________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 203, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08145J0C2H-43d8317add/__________________________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 270, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08145J0C2H-43d8317add/__________________________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08145J0C2H-43d8317add/__________________________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 405, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08145J0C2H-43d8317add/__________________________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 450, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08145J0C2H-43d8317add/__________________________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 540, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08145J0C2H-43d8317add/__________________________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 576, "original_w": 1706, "original_h": 960, "thumb_tiny": "AwAbADBxNHkrIhDZBB6iog+cCpISfMbrg0XCwrwRrGPlzg9TSLGoAwAMHNPkJETN1xzUbSN5bMoHynFAIkwAM96QhSckdPSoYpGc4Iz3JHapc8UmUQx9yQMn17U8PtYHrio/8aMc0h2L4HGTjFMyi5IIAz9KYSfIz3ApsYBAY8n1NO5Fh+8FSqrgH0GKjZSB7VJS9qVytj//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08145J0C2H/_________________________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08145J0C2H-da6c9b4fcd", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F081VQJ2Z16", "created": 1731819683, "timestamp": 1731819683, "name": "上_新規、下_従来.jpg", "title": "上_新規、下_従来.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 81131, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F081VQJ2Z16/_______________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F081VQJ2Z16/download/_______________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ2Z16-3533f2511a/________________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ2Z16-3533f2511a/________________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ2Z16-3533f2511a/________________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 203, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ2Z16-3533f2511a/________________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 270, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ2Z16-3533f2511a/________________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ2Z16-3533f2511a/________________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 405, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ2Z16-3533f2511a/________________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1422, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ2Z16-3533f2511a/________________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 540, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ2Z16-3533f2511a/________________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 576, "thumb_1024_h": 1024, "original_w": 960, "original_h": 1706, "thumb_tiny": "AwAwABuzvT1pN6+v6VFmgGpuOxKHX1/SnjBHWoM9akU/KKYWIFI4qQAY60xMYHAzTxj0qRiZGakT7ophHsKevSmhMqAkAYqVG9arF8c5IpVlIXeS2AcUimW8k8UtQ/aOB97kZHFKJJcdaYj/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F081VQJ2Z16/_______________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F081VQJ2Z16-d17026db90", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0810CBAJVC", "created": 1731819687, "timestamp": 1731819687, "name": "イメージ.jpg", "title": "イメージ.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 95979, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0810CBAJVC/____________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0810CBAJVC/download/____________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0810CBAJVC-1f097b39ef/_____________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0810CBAJVC-1f097b39ef/_____________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0810CBAJVC-1f097b39ef/_____________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 203, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0810CBAJVC-1f097b39ef/_____________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 270, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0810CBAJVC-1f097b39ef/_____________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0810CBAJVC-1f097b39ef/_____________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 405, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0810CBAJVC-1f097b39ef/_____________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 450, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0810CBAJVC-1f097b39ef/_____________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 540, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0810CBAJVC-1f097b39ef/_____________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 576, "original_w": 1706, "original_h": 960, "thumb_tiny": "AwAbADCb7vXpTxj1qFjyKdnI49alIdyQgetN70p5Bxim4yeKdhXI5ZdnQZqDc0h+Y1LMKhSpaKRMWBNG7pSBF9KXavpRcLC7zg0hc5PNG0ego2r6CncLDHYnqc0wGpvLT+6KPKT+7QB//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0810CBAJVC/____________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0810CBAJVC-863db395ee", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F081VQJ7M5E", "created": 1731819691, "timestamp": 1731819691, "name": "フィルム印刷内容.jpg", "title": "フィルム印刷内容.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 81109, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F081VQJ7M5E/________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F081VQJ7M5E/download/________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ7M5E-d9909896b7/_________________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ7M5E-d9909896b7/_________________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ7M5E-d9909896b7/_________________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 203, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ7M5E-d9909896b7/_________________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 270, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ7M5E-d9909896b7/_________________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ7M5E-d9909896b7/_________________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 405, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ7M5E-d9909896b7/_________________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 450, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ7M5E-d9909896b7/_________________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 540, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F081VQJ7M5E-d9909896b7/_________________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 576, "original_w": 1706, "original_h": 960, "thumb_tiny": "AwAbADCwxxjmkAJzg4oPahm4wKQgLc4BH5Uh3Z7UDNBIHuaBjDTad17UUAPZjxxSD73SkpRQA7ikppopgKaYaU000gP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F081VQJ7M5E/________________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F081VQJ7M5E-5d5d9c6aee", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1731823701.559599] <@U0331FWGQRM>: <@U05KGS6HN9H> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
連絡ありがとうございます。
省スペース化とコスト削減はいいと思うのですが、
この機械の選定過程が気になる（他に候補があったのかどうか）ことと、
この件の決定までの過程（誰が判断して誰が決定したか）が不明（記載されていない）ので、
どうレスポンスしていいのか困ります。

（というのも、以前こういう機械を提案したことがあったような気がしますが、その際は流れた記憶があり、そのような経緯もあります。）

それと、
> 製品と直接触れることはなく
というのが気になりましたが、直接触れたらダメなのですか?

宜しくお願いします

## 2024-12-01

- [1733104651.246699] <@U082RF7UF1V>: <@U082RF7UF1V>さんがチャンネルに参加しました

## 2024-12-05

- [1733442214.995819] <@U0331FZS7JT>: <@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
CC：<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
八女抹茶（星野製茶）の一部代替品について、こちら進捗いかがでしょうか？
- [1733442638.269639] <@U03BLQ65GK0>: <@U0331FZS7JT>
八女抹茶のNo.120と同品DRのブレンド（品名：八女抹茶No.120DRブレンド　としました）は45kg本日挽き上がります。
後のものについては水宗園からの原料入荷待ちですが、<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> こちらはどうなっていますか？
- [1733446748.694449] <@U041RJKV5JA>: <@U03BLQ65GK0>
水宗園　一茶八女産碾茶　焙煎Bは、
大冷蔵庫に175kg保管してあります。
- [1733446972.686109] <@U0331FZS7JT>: <@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
CC：<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
それであれば、早速製造（粉砕）をお願いします。
製造後、五月雨式でも良いので、共有をお願いします。
共有とともに管理フォルダにある
「八女抹茶・宇治抹茶在庫情報他」に反映もお願いします。
よろしくお願いします。
- [1733466177.461549] <@U03BLQ65GK0>: <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
各八女抹茶（星野製茶）代替品の品名を添付表に追記しました。（黄色で網掛け部分です）
※先ほどご連絡した「八女抹茶No.120DRブレンド」も変更します。
こちらの状態で原本も保存しています。
  - files: [{"id": "F083VDANR1B", "created": 1733466022, "timestamp": 1733466022, "name": "八女抹茶・宇治抹茶在庫情報他＿代替品名追記.xlsx", "title": "八女抹茶・宇治抹茶在庫情報他＿代替品名追記.xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 13120, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F083VDANR1B/_______________________________________________________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F083VDANR1B/download/_______________________________________________________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F083VDANR1B-9ccfc3c636/________________________________________________________________converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F083VDANR1B-9ccfc3c636/________________________________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F083VDANR1B/_______________________________________________________________.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F083VDANR1B-54472c2628", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1733466524.486289] <@U0331FZS7JT>: <@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
八女抹茶A（八女の露）については、現在注文が入っていますので、
優先的に製造を行ってください。
<https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1733413091540239>
※「八女の露」が12月13日に3kg桃翠園着(From 星野製茶)
      注文数量は4kg
よろしくお願いします。
  - attachments: [{"from_url": "https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1733413091540239", "ts": "1733413091.540239", "author_id": "U0331FWGQRM", "channel_id": "C03C62NBSDP", "channel_team": "T033D70RR6H", "is_msg_unfurl": true, "is_thread_root_unfurl": true, "message_blocks": [{"team": "T033D70RR6H", "channel": "C03C62NBSDP", "ts": "1733413091.540239", "message": {"blocks": [{"type": "rich_text", "block_id": "xahhk", "elements": [{"type": "rich_text_section", "elements": [{"type": "usergroup", "usergroup_id": "S073HEMKWV7"}, {"type": "text", "text": "\n"}, {"type": "emoji", "name": "flag-th", "unicode": "1f1f9-1f1ed"}, {"type": "text", "text": "タイのtachu houseより注文がありました。\nTSE-TAC-043-24"}]}]}]}}], "id": 1, "original_url": "https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1733413091540239", "fallback": "[December 5th, 2024 7:38 AM] tousuien.matsui: <!subteam^S073HEMKWV7>\n:flag-th:タイのtachu houseより注文がありました。\nTSE-TAC-043-24", "text": "<!subteam^S073HEMKWV7>\n:flag-th:タイのtachu houseより注文がありました。\nTSE-TAC-043-24", "author_name": "matsui", "author_link": "https://grp-ssm9297.slack.com/team/U0331FWGQRM", "author_icon": "https://secure.gravatar.com/avatar/f9d05f2cae161f657bb1248fc85b5235.jpg?s=48&d=https%3A%2F%2Fa.slack-edge.com%2Fdf10d%2Fimg%2Favatars%2Fava_0008-48.png", "author_subname": "matsui", "mrkdwn_in": ["text"], "footer": "Slack の会話内のスレッド"}]
- [1733469344.413209] <@U0840UVFVA8>: <@U0840UVFVA8>さんがチャンネルに参加しました

## 2024-12-06

- [1733480044.202939] <@U0606SPN4BW>: 
  - files: [{"id": "F083Z3ESJJF", "created": 1733480033, "timestamp": 1733480033, "name": "241204 FurukawaSatoshi-S-GRAVENHAGE-K-Vkoelcel (1).pdf", "title": "241204 FurukawaSatoshi-S-GRAVENHAGE-K-Vkoelcel (1).pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0606SPN4BW", "user_team": "T033D70RR6H", "editable": false, "size": 382444, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F083Z3ESJJF/241204_furukawasatoshi-s-gravenhage-k-vkoelcel__1_.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F083Z3ESJJF/download/241204_furukawasatoshi-s-gravenhage-k-vkoelcel__1_.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F083Z3ESJJF-371d349dff/241204_furukawasatoshi-s-gravenhage-k-vkoelcel__1__thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F083Z3ESJJF/241204_furukawasatoshi-s-gravenhage-k-vkoelcel__1_.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F083Z3ESJJF-6619914464", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F083Z3F26M9", "created": 1733480036, "timestamp": 1733480036, "name": "241204 FurukawaSatoshi-S-GRAVENHAGE-K-Vkoelcel.pdf", "title": "241204 FurukawaSatoshi-S-GRAVENHAGE-K-Vkoelcel.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0606SPN4BW", "user_team": "T033D70RR6H", "editable": false, "size": 296679, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F083Z3F26M9/241204_furukawasatoshi-s-gravenhage-k-vkoelcel.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F083Z3F26M9/download/241204_furukawasatoshi-s-gravenhage-k-vkoelcel.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F083Z3F26M9-2af6a469f1/241204_furukawasatoshi-s-gravenhage-k-vkoelcel_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F083Z3F26M9/241204_furukawasatoshi-s-gravenhage-k-vkoelcel.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F083Z3F26M9-4c262b25db", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1733480259.558259] <@U0331FWGQRM>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <@U03BLQ65GK0>
古川さんより、
見積書兼契約書を入手されたようです。

＜内容要約＞
金額：17350ユーロ
※5%の値上げ
※納期が6週間から10週間に伸びている？
※注文時に50%、納品直前に残り50%

支払い方法は銀行口座が各ページの下に記載あり。
オランダ語の方の書類のサイン箇所にサインしてこちらに貼り付けてもらえますか？

そして、支払いも良いタイミングでお願いします。

## 2024-12-08

- [1733700215.427199] <@U03BLQ65GK0>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U0840UVFVA8>
土曜日に中国から缶が50c/s入っています。
こちらは新生の倉庫に移動・保管しています。
よろしくお願いします。
- [1733703408.856979] <@U03BLQ65GK0>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
契約書にサイン記入しました。
よろしくお願いします。
  - files: [{"id": "F0843LJRBC5", "created": 1733703404, "timestamp": 1733703404, "name": "契約書＿サイン済み.pdf", "title": "契約書＿サイン済み.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 301133, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0843LJRBC5/___________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0843LJRBC5/download/___________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0843LJRBC5-3f9e93668b/____________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0843LJRBC5/___________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F0843LJRBC5-e77c830f80", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1733709213.007019] <@U03BLQ65GK0>: <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
八女抹茶Aの製造状況です。
10kgを本日粉砕開始し、明日完成です。

## 2024-12-12

- [1734012235.951579] <@U0606SPN4BW>: <@U03BLQ65GK0> <@U0331FZS7JT> <@U0331FWGQRM> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
先方から初回50%の請求書を受け取りました。
お支払い完了後、お知らせをよろしくお願いいたします！
  - files: [{"id": "F084RPVJBPF", "created": 1734012086, "timestamp": 1734012086, "name": "20241212_初回50%請求書_20151812 FurukawaSatoshi-S-GRAVENHAGE-K-V.pdf", "title": "20241212_初回50%請求書_20151812 FurukawaSatoshi-S-GRAVENHAGE-K-V.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0606SPN4BW", "user_team": "T033D70RR6H", "editable": false, "size": 651245, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F084RPVJBPF/20241212_______50___________20151812_furukawasatoshi-s-gravenhage-k-v.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F084RPVJBPF/download/20241212_______50___________20151812_furukawasatoshi-s-gravenhage-k-v.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F084RPVJBPF-c5721a80a5/20241212_______50___________20151812_furukawasatoshi-s-gravenhage-k-v_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F084RPVJBPF/20241212_______50___________20151812_furukawasatoshi-s-gravenhage-k-v.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F084RPVJBPF-6eb98451cf", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-12-16

- [1734394859.522019] <@U03BLQ65GK0>: <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
八女抹茶の状況です。
【製造状況】
八女抹茶C：103kg　完了
八女抹茶D：84kg　完了

【製造予定】
八女抹茶E：94kg　12/18粉砕完了予定
八女抹茶F：100kg　12/18合組（製造）予定

## 2024-12-18

- [1734509539.208669] <@U0331FZS7JT>: <@U0606SPN4BW>
<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <@U03BLQ65GK0>
本件、本日送金（事前50%）をしました。
※WISE
12月18日中に着金するとのことです。
よろしくお願いします:man-bowing:！
- [1734577056.426289] <@U03BLQ65GK0>: <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
八女抹茶の状況です。
【製造状況】
八女抹茶E：94kg　完了
八女抹茶F：100kg　完了
以上で一旦八女抹茶各代替品の製造が完了しています。
以降は
吉田園「八女碾茶150号」+「八女碾茶150号DR」+ 水宗園「一茶八女産碾茶 焙煎B」を
各グレードに応じて比率を変えてブレンドしていく。
※八女碾茶150号DRの更にロースト強めの物を作ってブレンドするかもしれない

## 2024-12-19

- [1734631825.822289] <@U0606SPN4BW>: <@U0331FZS7JT> <@U03BLQ65GK0> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
先方から着金を確認した旨、連絡がありましたのでお知らせします。
納期的に少し先になるかと思いますが何か進捗があり次第、追って共有します。
よろしくお願いします！

## 2024-12-25

- [1735181735.988059] <@U033G4KN4TD>: <!channel>
中国のスティック機械テスト行いましたのでご報告です。
テストは中国から送られてきたスイスSebastyanのフィルムでテストしました。
結果として、静パックでは圧着不良となるとの事でしたが、桃翠園の機械では綺麗に圧着することが出来ました。
(シール温度125°～130°)
空気漏れもなさそうでした。
印字も問題なさそうです。

*今後、スティックを桃翠園で製造する場合のリードタイム目安として*
原料にもよりますが、*10～15本/min＝600～900本/h=4500～6600本程度/日*(7.5時間稼働での計算)となります。
ただ、機械の設定～充填テストに約4～5時間必要となります。
まだ、手探りの状態ですのでテストを重ねていけば稼働までの時間は短縮できると思います。
  - files: [{"id": "F086H5FKVA6", "created": 1735181627, "timestamp": 1735181627, "name": "S__235577349_0.jpg", "title": "S__235577349_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 327583, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F086H5FKVA6/s__235577349_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F086H5FKVA6/download/s__235577349_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5FKVA6-d339ff67bb/s__235577349_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5FKVA6-d339ff67bb/s__235577349_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5FKVA6-d339ff67bb/s__235577349_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5FKVA6-d339ff67bb/s__235577349_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5FKVA6-d339ff67bb/s__235577349_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5FKVA6-d339ff67bb/s__235577349_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5FKVA6-d339ff67bb/s__235577349_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5FKVA6-d339ff67bb/s__235577349_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5FKVA6-d339ff67bb/s__235577349_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACSIVJGc5FMEbEZ6VNHEUOA4z9KnYYhWm4AqUDcM7gPwqNxtbGc00xBxRxRmiqAlIzTJJSpBCnOakFMYZxWcikELApyO9MmBMn4CiJsDb6U4kk56cdKEtRCBDijYakHTsKOPUfnWgiYRgDJNVjIv99fzqfz1MYJ6kciqsjIT8qj8qhq4xquik5cVJJL8m6PB7E56VUJIbJNTeZ5jZIAC9FoSAM55PJoyPSjHqcUYHrQM/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F086H5FKVA6/s__235577349_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F086H5FKVA6-cbacfddf04", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F086H5GE03C", "created": 1735181654, "timestamp": 1735181654, "name": "756798384.276994.mp4", "title": "756798384.276994.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 16436338, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5GE03C-9d2ecf626f/756798384.276994.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5GE03C-9d2ecf626f/756798384.276994.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F086H5GE03C/download/756798384.276994.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5GE03C-9d2ecf626f/file.m3u8?_xcb=d23e1&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MjI4OTU1NSxBVkVSQUdFLUJBTkRXSURUSD0xNDQyNDcyLENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTYwOHgxMDgwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE5rZzFSMFV3TTBNdE9XUXlaV05tTmpJMlppOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TVM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTROa2cxUjBVd00wTXRPV1F5WldObU5qSTJaaTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01pNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0TmtnMVIwVXdNME10T1dReVpXTm1OakkyWmk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNeTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE5rZzFSMFV3TTBNdE9XUXlaV05tTmpJMlppOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TkM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTROa2cxUjBVd00wTXRPV1F5WldObU5qSTJaaTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd05TNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0TmtnMVIwVXdNME10T1dReVpXTm1OakkyWmk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOaTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE5rZzFSMFV3TTBNdE9XUXlaV05tTmpJMlppOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3Tnk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTROa2cxUjBVd00wTXRPV1F5WldObU5qSTJaaTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd09DNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0TmtnMVIwVXdNME10T1dReVpXTm1OakkyWmk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdPUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE5rZzFSMFV3TTBNdE9XUXlaV05tTmpJMlppOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF4TUM1MGN3b2pSVmhVU1U1R09qSXVNVE0xTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTROa2cxUjBVd00wTXRPV1F5WldObU5qSTJaaTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE1TNTBjd29qUlZoVUxWZ3RSVTVFVEVsVFZBbz0K", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5GE03C-9d2ecf626f/756798384.276994_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 62195, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5GE03C-9d2ecf626f/756798384.276994_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F086H5GE03C/756798384.276994.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F086H5GE03C-64feb71a78", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0862KD8N07", "created": 1735181665, "timestamp": 1735181665, "name": "印字.mp4", "title": "印字.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 16442961, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "complete", "locale": "en-US", "preview": {"content": "ね。", "has_more": false}}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F0862KD8N07-10755465ca/______.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F0862KD8N07-10755465ca/______.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0862KD8N07/download/______.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "vtt": "https://files.slack.com/files-tmb/T033D70RR6H-F0862KD8N07-10755465ca/file.vtt?_xcb=93ec4&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F0862KD8N07-10755465ca/file.m3u8?_xcb=93ec4&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MjIyMTk0MyxBVkVSQUdFLUJBTkRXSURUSD0xNjIwODk0LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTYwOHgxMDgwLEZSQU1FLVJBVEU9MjkuOTcwLFNVQlRJVExFUz0ic3VicyIKZGF0YTphcHBsaWNhdGlvbi92bmQuYXBwbGUubXBlZ3VybDtiYXNlNjQsSTBWWVZFMHpWUW9qUlZoVUxWZ3RWa1ZTVTBsUFRqb3pDaU5GV0ZRdFdDMVVRVkpIUlZSRVZWSkJWRWxQVGpvM0NpTkZXRlF0V0MxTlJVUkpRUzFUUlZGVlJVNURSVG94Q2lORldGUXRXQzFRVEVGWlRFbFRWQzFVV1ZCRk9sWlBSQW9qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0TmpKTFJEaE9NRGN0TVRBM05UVTBOalZqWVM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE5qSkxSRGhPTURjdE1UQTNOVFUwTmpWallTOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TWk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTROakpMUkRoT01EY3RNVEEzTlRVME5qVmpZUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd015NTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0TmpKTFJEaE9NRGN0TVRBM05UVTBOalZqWVM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOQzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE5qSkxSRGhPTURjdE1UQTNOVFUwTmpWallTOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TlM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTROakpMUkRoT01EY3RNVEEzTlRVME5qVmpZUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd05pNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0TmpKTFJEaE9NRGN0TVRBM05UVTBOalZqWVM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOeTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE5qSkxSRGhPTURjdE1UQTNOVFUwTmpWallTOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3T0M1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTROakpMUkRoT01EY3RNVEEzTlRVME5qVmpZUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd09TNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0TmpKTFJEaE9NRGN0TVRBM05UVTBOalZqWVM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXhNQzUwY3dvalJWaFVTVTVHT2pJdU5EQXlMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE5qSkxSRGhPTURjdE1UQTNOVFUwTmpWallTOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF4TVM1MGN3b2pSVmhVTFZndFJVNUVURWxUVkFvPQojRVhULVgtTUVESUE6VFlQRT1TVUJUSVRMRVMsR1JPVVAtSUQ9InN1YnMiLE5BTUU9IkVuZ2xpc2giLERFRkFVTFQ9WUVTLEFVVE9TRUxFQ1Q9WUVTLEZPUkNFRD1OTyxMQU5HVUFHRT0iZW5nIixVUkk9ImRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzJNREFLSTBWWVZDMVlMVTFGUkVsQkxWTkZVVlZGVGtORk9qRUtJMFZZVkMxWUxWQk1RVmxNU1ZOVUxWUlpVRVU2Vms5RUNpTkZXRlJKVGtZNk5qSXVORFl5TEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTROakpMUkRoT01EY3RNVEEzTlRVME5qVmpZUzltYVd4bExuWjBkQW9qUlZoVUxWZ3RSVTVFVEVsVFZBPT0iCg==", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F0862KD8N07-10755465ca/_______trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 62462, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F0862KD8N07-10755465ca/_______thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0862KD8N07/______.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F0862KD8N07-81cd70f899", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F086H5HH7B4", "created": 1735181693, "timestamp": 1735181693, "name": "756873915.191394.mp4", "title": "756873915.191394.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 3703134, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5HH7B4-22fa33ad0c/756873915.191394.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5HH7B4-22fa33ad0c/756873915.191394.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F086H5HH7B4/download/756873915.191394.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5HH7B4-22fa33ad0c/file.m3u8?_xcb=bef54&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTU1MTU3OSxBVkVSQUdFLUJBTkRXSURUSD0xNDcyNDQ3LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTYwOHgxMDgwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE5rZzFTRWczUWpRdE1qSm1ZVE16WVdRd1l5OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TVM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTROa2cxU0VnM1FqUXRNakptWVRNellXUXdZeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01pNTBjd29qUlZoVVNVNUdPakl1TURNMUxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0TmtnMVNFZzNRalF0TWpKbVlUTXpZV1F3WXk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNeTUwY3dvalJWaFVMVmd0UlU1RVRFbFRWQW89Cg==", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5HH7B4-22fa33ad0c/756873915.191394_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 14047, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F086H5HH7B4-22fa33ad0c/756873915.191394_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F086H5HH7B4/756873915.191394.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F086H5HH7B4-87128833c0", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F086H2XQUUB", "created": 1735181696, "timestamp": 1735181696, "name": "充填量確認.mp4", "title": "充填量確認.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 10527195, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F086H2XQUUB-3ead205af7/_______________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F086H2XQUUB-3ead205af7/_______________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F086H2XQUUB/download/_______________.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F086H2XQUUB-3ead205af7/file.m3u8?_xcb=eb351&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTYxMzE4MSxBVkVSQUdFLUJBTkRXSURUSD0xNDQ3MzIyLENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTYwOHgxMDgwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE5rZ3lXRkZWVlVJdE0yVmhaREl3TldGbU55OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TVM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTROa2d5V0ZGVlZVSXRNMlZoWkRJd05XRm1OeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01pNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0TmtneVdGRlZWVUl0TTJWaFpESXdOV0ZtTnk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNeTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE5rZ3lXRkZWVlVJdE0yVmhaREl3TldGbU55OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TkM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTROa2d5V0ZGVlZVSXRNMlZoWkRJd05XRm1OeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd05TNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0TmtneVdGRlZWVUl0TTJWaFpESXdOV0ZtTnk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOaTUwY3dvalJWaFVTVTVHT2pNdU9UTTNMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE5rZ3lXRkZWVlVJdE0yVmhaREl3TldGbU55OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3Tnk1MGN3b2pSVmhVTFZndFJVNUVURWxUVkFvPQo=", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F086H2XQUUB-3ead205af7/________________trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 39973, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F086H2XQUUB-3ead205af7/________________thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F086H2XQUUB/_______________.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F086H2XQUUB-cb741a1bf5", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0876049M0Q", "created": 1735181702, "timestamp": 1735181702, "name": "空気漏れ確認.mp4", "title": "空気漏れ確認.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 5079889, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F0876049M0Q-f3d57cdfb8/__________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F0876049M0Q-f3d57cdfb8/__________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0876049M0Q/download/__________________.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F0876049M0Q-f3d57cdfb8/file.m3u8?_xcb=5ffe9&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MjA4OTIyMixBVkVSQUdFLUJBTkRXSURUSD0xOTk3NTcwLENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTYwOHgxMDgwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE56WXdORGxOTUZFdFpqTmtOVGRqWkdaaU9DOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TVM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTROell3TkRsTk1GRXRaak5rTlRkalpHWmlPQzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01pNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0TnpZd05EbE5NRkV0WmpOa05UZGpaR1ppT0M5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNeTUwY3dvalJWaFVTVTVHT2pFdU5UQXlMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE56WXdORGxOTUZFdFpqTmtOVGRqWkdaaU9DOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TkM1MGN3b2pSVmhVTFZndFJVNUVURWxUVkFvPQo=", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F0876049M0Q-f3d57cdfb8/___________________trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 19519, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F0876049M0Q-f3d57cdfb8/___________________thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0876049M0Q/__________________.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F0876049M0Q-8e423ca700", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F087604DRA4", "created": 1735181706, "timestamp": 1735181706, "name": "Sebastyanスティックテスト.jpg", "title": "Sebastyanスティックテスト.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 414341, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F087604DRA4/sebastyan________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F087604DRA4/download/sebastyan________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F087604DRA4-d1ba79c71d/sebastyan_________________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F087604DRA4-d1ba79c71d/sebastyan_________________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F087604DRA4-d1ba79c71d/sebastyan_________________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F087604DRA4-d1ba79c71d/sebastyan_________________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F087604DRA4-d1ba79c71d/sebastyan_________________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F087604DRA4-d1ba79c71d/sebastyan_________________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F087604DRA4-d1ba79c71d/sebastyan_________________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F087604DRA4-d1ba79c71d/sebastyan_________________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F087604DRA4-d1ba79c71d/sebastyan_________________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADBIhyKtuAYxVOM4NW2KbgMLyfSpbsOxSkHNRnmr+IzIRtXhfT3poEfzkquN39BS5gsyjsPpSFDWigj44AyM1DKF7U07gQqavOPmjPv/AENUVHNWmfbDvZuR0pSVwuKMC4bpjZ/WkZQI5PxIqobqQOWGM4x0pGu5CCDjB9qnlY7lhziHPcACoWJqE3DuNpxj6UvmE44q4qwiRaSZ2IwTxSimS0wI6a3SnU1ulAxq9akFRr1qQUCP/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F087604DRA4/sebastyan________________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F087604DRA4-04f634a734", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F086H2YBF43", "created": 1735181713, "timestamp": 1735181713, "name": "S__235675654_0.jpg", "title": "S__235675654_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 541487, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F086H2YBF43/s__235675654_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F086H2YBF43/download/s__235675654_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F086H2YBF43-346fbc6c52/s__235675654_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F086H2YBF43-346fbc6c52/s__235675654_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F086H2YBF43-346fbc6c52/s__235675654_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F086H2YBF43-346fbc6c52/s__235675654_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F086H2YBF43-346fbc6c52/s__235675654_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F086H2YBF43-346fbc6c52/s__235675654_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F086H2YBF43-346fbc6c52/s__235675654_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F086H2YBF43-346fbc6c52/s__235675654_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F086H2YBF43-346fbc6c52/s__235675654_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADCCCJJFJZtuDU4hjUEh84GaZY/dfnHIq1nIPzDoe1S3qMga3jOMswzTPs0eVwzYOatK2EXkjimE8r82eSOntSuwIxBGP4zUcyBScdKtZOPvg/hUFx1PNNMBlkSA+CB061Z3ccyKciqEExhzhQc+tWo5ml42L0oa1AkSQeWhLY4FMZgWTDZIelXeEUB1HHcf/XphZwy5Kn5u1ICYtjI3L0qtdPyvOcipm3eidPeqt1nzR7r2oQEI61ds/vVSHWrtn96rQFS6P75qhyamuf8AXNUNABk+tPQ/OKZT4/vigD//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F086H2YBF43/s__235675654_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F086H2YBF43-2f1cdce70c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-01-09

- [1736423121.904749] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
相談です。
Sebastyanのスティック製造を桃翠園で行ってもいいのかどうか検討したいです。Sebastyanの製品の製造を桃翠園で行うのは、現時点では可能性は限りなく低いと考えていますが、
今後のことを考えると懸念点を払拭していく必要があります。

懸念点は３点、
・安定した製造が可能かどうか
・ラテを充填した時、砂糖に偏りがで無いかどうか
・手切性の無いフィルムのため、ギザギザカットがマスト。手で切れるかどうか。

上記についてどうでしょうか？
他にもあればコメントください。
- [1736465916.234819] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
・フレーバーの匂いが他製品に影響しないか
・フレーバー抹茶切替の際に次の製品に影響がないか
以上も確認事項としてあったらよいかなと。
よろしくお願いします。

## 2025-01-10

- [1736577945.529959] <@U0331FWGQRM>: <@U0840UVFVA8> <@U03BLQ65GK0> <@U0331FZS7JT> <@U05KGS6HN9H>
<https://meet.google.com/obj-twdu-xbu>
  - attachments: [{"from_url": "https://meet.google.com/obj-twdu-xbu", "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "id": 1, "original_url": "https://meet.google.com/obj-twdu-xbu", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/obj-twdu-xbu", "service_name": "meet.google.com"}]

## 2025-01-29

- [1738220344.758819] <@U0331FZS7JT>: <!channel>
【情報共有】小分け業務委託会社
〈株式会社大伸シプレ〉
<https://www.taishin-spl.co.jp/company>

お茶に特化した小分け受託会社＠静岡
香岳園も小分けを委託している先

<!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0>
よかったら確認してみてください。
よろしくお願いします。
  - attachments: [{"from_url": "https://www.taishin-spl.co.jp/company", "id": 1, "original_url": "https://www.taishin-spl.co.jp/company", "fallback": "株式会社 大伸シプレ: トータルパッケージングの株式会社大伸シプレ｜会社概要", "text": "トータルパッケージングサービスとして、梱包資材の卸およびお茶の受託加工をおこなっている株式会社大伸シプレ（静岡）の会社概要ページです。会社概要・住所・事業内容・沿革・アクセスマップにて大伸シプレの概要をご紹介しています。", "title": "トータルパッケージングの株式会社大伸シプレ｜会社概要", "title_link": "https://www.taishin-spl.co.jp/company", "service_name": "株式会社 大伸シプレ"}]
- [1738223875.265609] <@U033G4KN4TD>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
株式会社　宝パック
*食品の包装委託加工、各種包装資材の販売を行う会社です。*
<http://takarapack.com/>

缶やスティックも行えそうです。
情報収集してみます。
  - attachments: [{"from_url": "http://takarapack.com/", "id": 1, "original_url": "http://takarapack.com/", "fallback": "株式会社 宝パック", "text": "（株）宝パック", "title": "株式会社 宝パック", "title_link": "http://takarapack.com/", "service_name": "takarapack.com"}]

## 2025-01-30

- [1738284806.796619] <@U03BLQ65GK0>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> cc<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
【問い合わせした結果共有】
〈株式会社大伸シプレ〉
・現在受注量過多にて新規の受注は受けられない
　→4月に充填機を1台増設するので受け入れることができる「かも」しれない（再度問い合わせ）
・缶への充填について
　→巻締機2台所有でこちらは少々余裕あり（真空窒素充填は不可）
　　4月以降で充填機に空きがあれば受入可能かもしれない
　→缶の形状が多少違う場合でも、これまで巻締部分のの型を何パターンか作ってきているので対応は可能
　　新しく型を作ることも可能だが、
　　明らかに当社以外でも使用が可能な型でない（汎用性がない）場合は料金発生の可能性あり（数十万単位）
　　↳一旦、現在所有している型で当社にある缶が巻締可能かどうかテストをしていただく
　　　→本日サンプル発送
　　　　→受託可能であれば見積もりいただく

## 2025-01-31

- [1738393740.183009] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U0331FZS7JT>
2/18に東洋機械製作所へ行こうと思いますが、
みなさまスケジュールどうでしょうか？
- [1738394799.458309] <@U0331FZS7JT>: <@U0331FWGQRM> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
スケジュール大丈夫です！
よろしくお願いします！

## 2025-02-02

- [1738535919.834199] <@U033G4KN4TD>: <@U0331FWGQRM> <@U0331FZS7JT> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
大丈夫です。
よろしくお願いします。
- [1738554283.201389] <@U033G4KN4TD>: <@U03BLQ65GK0> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
CC <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
本日、株式会社大伸シプレ様へ下記9種類の缶を発送いたします。
よろしくお願いします。
テスト①　中国　30ｇエンボス（出荷場）
テスト②　中国　40ｇエンボス　(出荷場)　20240321入荷
テスト③　中国　80ｇエンボス　(茶詰場2Ｆ)　20240321入荷
テスト④　中国　30ｇプリント　(茶詰場2Ｆ)　20240719入荷
テスト⑤　中国　40ｇプリント　(茶詰場2Ｆ)　20241207入荷
テスト⑥　中国　60ｇプリント　(茶詰場2Ｆ)　20241207入荷
テスト⑦　中国　80ｇプリント　(茶詰場2Ｆ)　20241207入荷
テスト⑧　奥村製缶　30ｇ
テスト⑨　静岡製缶　40ｇ

佐川送り状番号：4917-6819-1655
  - files: [{"id": "F08C38SLA0Y", "created": 1738554012, "timestamp": 1738554012, "name": "缶テスト1.pdf", "title": "缶テスト1.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 760593, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08C38SLA0Y/____________1.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08C38SLA0Y/download/____________1.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08C38SLA0Y-adb21e301e/____________1_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1286, "thumb_pdf_h": 910, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08C38SLA0Y/____________1.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08C38SLA0Y-78b378fb57", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-02-03

- [1738587745.933229] <@U0840UVFVA8>: すみません遅くなりました
大丈夫です！

## 2025-02-05

- [1738780170.501019] <@U0331FWGQRM>: <@U0840UVFVA8> <@U033G4KN4TD> <@U0331FZS7JT> 
2/18 13時で行こうと思います！
宜しくお願いします！
  - files: [{"id": "F08CATN1R5X", "created": 1738780151, "timestamp": 1738780151, "name": "IMG_7346.png", "title": "IMG_7346", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 396351, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08CATN1R5X/img_7346.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08CATN1R5X/download/img_7346.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08CATN1R5X-7fe2a02bbc/img_7346_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08CATN1R5X-7fe2a02bbc/img_7346_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08CATN1R5X-7fe2a02bbc/img_7346_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08CATN1R5X-7fe2a02bbc/img_7346_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 221, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08CATN1R5X-7fe2a02bbc/img_7346_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08CATN1R5X-7fe2a02bbc/img_7346_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 332, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08CATN1R5X-7fe2a02bbc/img_7346_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1734, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08CATN1R5X-7fe2a02bbc/img_7346_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 443, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08CATN1R5X-7fe2a02bbc/img_7346_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 472, "thumb_1024_h": 1024, "original_w": 1290, "original_h": 2796, "thumb_tiny": "AwAwABay8w6qfpkGmec/qn5GpvJX+4tKII/4lUn6UARLPGBy35A077RF/eP5VJ5EP/PNaPIh/uLQA/Gc9RRtxzk0nc9OaXPHagAx7UYoozQBEodhnfS+XJ/z0/SmoGAO4/rSlhghW57fNTAGWRR/rP0pvz/3/wBKQiU9W/Wk2Sev60gP/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08CATN1R5X/img_7346.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F08CATN1R5X-40773f5ae5", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-02-06

- [1738852750.747309] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0> <@U0331FZS7JT>
中国出張memo
・巻締機
・缶メーカー
・篩
・スティック
・セミオート充填機
- [1738852830.804909] <@U0331FWGQRM>: *巻締機*
Company Name: Guangdong Xtime Packaging Equiment Co., Ltd.
Chinese company name: 广东喜泰包装设备有限公司
Address: 17-She Industrial Park Hecun, Chengjiao Street, Conghua District, Guangzhou, Guangdong, China.
Chinese address: 广州市从化区城郊街荷村十七社工业园
Post code: 510900
*Attn: Ray Huang(黄权锐）←担当*
Tel: <tel:+8613726829643|+86-137 2682 9643>
- [1738853690.692659] <@U08BA1AGC0H>: <@U08BA1AGC0H>さんがチャンネルに参加しました

## 2025-02-12

- [1739383614.976819] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0> cc<@U0331FZS7JT>
東陽機械製作所訪問について。

時間：2/18（火） 13:00

〒４６３－００６８
名古屋市守山区瀬古1丁目623番地
TEL:052-793-1600

大曽根駅のタクシーに上記を伝えれば間違いないとのこと。

当日何かあれば、佐々木様の携帯まで
連絡くださいとのこと。
<tel:08036839564|080-3683-9564>

## 2025-02-17

- [1739795958.212359] <@U0331FWGQRM>: <@U03BLQ65GK0> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
明日の出張は宜しくお願いします。
メモを記しておきます:sweat_drops:

＜経緯＞
以前にスティックの要望がお客様からあったので、
機械を購入しようと思い松井から東陽機械に連絡させていただいた。
→価格が思っていたよりも高くて、手も足も出なかった。
→しかし、やはり問い合わせが増えてきた。
→今回、改めて購入検討を進めようという話になった。

＜確認して頂きたいこと殴り書きメモ＞
・2連の価格（購入するなら1連ではなくこれかな？）
（静パックと互換性があるのが望ましいという意図。フィルム共通）
・現状は外注で行っております。静パックというところです。
　からの、静パックさんが使用している機械って御社のですか？
　で、NOであれば、ほぼ三光の機械で確定。（海外製でなければ。。。）
・高い買い物なので、国内のスティック製造機械メーカーには相見積もりを取らせてもらっております。
（のジャブで、相手からの情報を引き出したい。）

・競合はどこになるのですか？神奈川の会社さんですか？
からの、仲良いんですか？とか揺さぶって、あわよくば、韓国の機械メーカーの名前を聞き出せれば嬉しい。
・補助金を使用したいと思っている。と言って、購入時期は4月以降を示唆させる。
・支払いのタイミングはどうなりますか？など要確認。
- [1739848540.923799] <@U0331FZS7JT>: <@U03BLQ65GK0> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>

お疲れ様です。
追加で確認をお願いします。

〈追加の質問メモ〉
・機械の保証期間はどのくらいですか？延長保証はありますか？
・納品期間短縮：急ぎで欲しい場合、短縮できる可能性はありますか？
・初回購入時のサービスなどありますか？
三光（納期半年）よりも短くできる場合や保証期間の条件など、三光と比較して良い要件の場合、三光にそれを伝えてより良い条件に持っていきたい狙い。

宜しくお願いします:man-bowing:

## 2025-02-21

- [1740126538.025179] <@U0331FZS7JT>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0> <@U0331FWGQRM> <@U05KGS6HN9H>
ボールミル
<https://www.alibaba.com/product-detail/Matcha-Processing-Machine-Small-Lead-Ball_1600944600745.html?spm=a2700.galleryofferlist.normal_offer.d_image.728013a08fgGh6|https://www.alibaba.com/product-detail/Matcha-Processing-Machine-Small-Lead-Ball_160[…]pm=a2700.galleryofferlist.normal_offer.d_image.728013a08fgGh6>
  - attachments: [{"from_url": "https://www.alibaba.com/product-detail/Matcha-Processing-Machine-Small-Lead-Ball_1600944600745.html?spm=a2700.galleryofferlist.normal_offer.d_image.728013a08fgGh6", "service_icon": "http://www.alibaba.com/favicon.ico", "thumb_url": "https://sc04.alicdn.com/kf/H2afe8acc7a2540419cea35af98c5af68m.jpg", "thumb_width": 800, "thumb_height": 800, "id": 1, "original_url": "https://www.alibaba.com/product-detail/Matcha-Processing-Machine-Small-Lead-Ball_1600944600745.html?spm=a2700.galleryofferlist.normal_offer.d_image.728013a08fgGh6", "fallback": "www.alibaba.com: Matcha Processing Machine Small Lead Ball Milling Machine Matcha Grinder - Buy Matcha Grinder,Small Lead Ball Milling Machine,Ball Milling Machine Product on Alibaba.com", "text": "Matcha Processing Machine Small Lead Ball Milling Machine Matcha Grinder - Buy Matcha Grinder,Small Lead Ball Milling Machine,Ball Milling Machine Product on <http://Alibaba.com|Alibaba.com>", "title": "Matcha Processing Machine Small Lead Ball Milling Machine Matcha Grinder - Buy Matcha Grinder,Small Lead Ball Milling Machine,Ball Milling Machine Product on Alibaba.com", "title_link": "https://www.alibaba.com/product-detail/Matcha-Processing-Machine-Small-Lead-Ball_1600944600745.html?spm=a2700.galleryofferlist.normal_offer.d_image.728013a08fgGh6", "service_name": "www.alibaba.com"}]
- [1740127448.613769] <@U0331FZS7JT>: <https://www.alibaba.com/product-detail/Tencan-Fast-Delivery-300L-Roll-Ball_1600918155176.html?spm=a2700.galleryofferlist.normal_offer.d_image.235f13a0opoDkf|https://www.alibaba.com/product-detail/Tencan-Fast-Delivery-300L-Roll-Ball_160091815[…]pm=a2700.galleryofferlist.normal_offer.d_image.235f13a0opoDkf>
  - attachments: [{"from_url": "https://www.alibaba.com/product-detail/Tencan-Fast-Delivery-300L-Roll-Ball_1600918155176.html?spm=a2700.galleryofferlist.normal_offer.d_image.235f13a0opoDkf", "service_icon": "http://www.alibaba.com/favicon.ico", "thumb_url": "https://sc04.alicdn.com/kf/H76bb0c2fd0394140a7afa5829e7c02e8D.jpg", "thumb_width": 650, "thumb_height": 650, "id": 1, "original_url": "https://www.alibaba.com/product-detail/Tencan-Fast-Delivery-300L-Roll-Ball_1600918155176.html?spm=a2700.galleryofferlist.normal_offer.d_image.235f13a0opoDkf", "fallback": "www.alibaba.com: Tencan Fast Delivery 300l Roll Ball Grinding Mill Multi Jars Balls Supplier Rolling Ball Mill Machine - Buy Rolling Ball Mill Machine,Roller Ball Mill,300l Roll Ball Grinding Mill Product on Alibaba.com", "text": "Tencan Fast Delivery 300l Roll Ball Grinding Mill Multi Jars Balls Supplier Rolling Ball Mill Machine - Buy Rolling Ball Mill Machine,Roller Ball Mill,300l Roll Ball Grinding Mill Product on <http://Alibaba.com|Alibaba.com>", "title": "Tencan Fast Delivery 300l Roll Ball Grinding Mill Multi Jars Balls Supplier Rolling Ball Mill Machine - Buy Rolling Ball Mill Machine,Roller Ball Mill,300l Roll Ball Grinding Mill Product on Alibaba.com", "title_link": "https://www.alibaba.com/product-detail/Tencan-Fast-Delivery-300L-Roll-Ball_1600918155176.html?spm=a2700.galleryofferlist.normal_offer.d_image.235f13a0opoDkf", "service_name": "www.alibaba.com"}]

## 2025-02-24

- [1740460268.515069] <@U05KGS6HN9H>: <@U03BLQ65GK0> <@U0840UVFVA8>
参考までですが、広州近辺で篩機取り扱いがあると思われるメーカーです。
  - files: [{"id": "F08ET5S77NZ", "created": 1740460252, "timestamp": 1740460252, "name": "広州奇正機械.pdf", "title": "広州奇正機械.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 261918, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08ET5S77NZ/__________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08ET5S77NZ/download/__________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08ET5S77NZ-d61d5ee859/___________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08ET5S77NZ/__________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08ET5S77NZ-0d49340cfd", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08EVSYQGD9", "created": 1740460255, "timestamp": 1740460255, "name": "広州泰龍塑料機械.pdf", "title": "広州泰龍塑料機械.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 476866, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08EVSYQGD9/________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08EVSYQGD9/download/________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08EVSYQGD9-3557a9deae/_________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1341, "thumb_pdf_h": 1899, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08EVSYQGD9/________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08EVSYQGD9-e2199659a8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08EVSZ4HUK", "created": 1740460258, "timestamp": 1740460258, "name": "広東鑫奕智能装備.pdf", "title": "広東鑫奕智能装備.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 214051, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08EVSZ4HUK/________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08EVSZ4HUK/download/________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08EVSZ4HUK-947263c0a7/_________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1113, "thumb_pdf_h": 1576, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08EVSZ4HUK/________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08EVSZ4HUK-fc21626faa", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08EF90ARJB", "created": 1740460260, "timestamp": 1740460260, "name": "仏山高明冠宇機械.pdf", "title": "仏山高明冠宇機械.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 340993, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08EF90ARJB/________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08EF90ARJB/download/________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08EF90ARJB-ae68b6947b/_________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1113, "thumb_pdf_h": 1576, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08EF90ARJB/________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08EF90ARJB-30ed7b9562", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-02-26

- [1740623299.300239] <@U05KGS6HN9H>: <@U03BLQ65GK0> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
TOP-Yから2連ステック機の情報が入りましたので共有致します。
◆取り扱いはあるそうですが、サイズは固定（専用機として）使用
した方が良いとのことです。
構造的に現行DXD機に対して、Forming tubeの構造も異なり、サイズ
変更する場合にはかなり交換が必要な物があるようです。万一変更が
上手くが出来ない場合、元に戻したくとも、復旧させることはメーカー
エンジニアでも相当困難とのことです。
・溶断は、ヒート→下に引っ張る→カットの順。現行機はステック端が
開く問題がありますが、2連機は溶着されておりカット端は開くことが
ないそうです。
・カット形状は、丸角/フラット/ギザのいずれか選べますが、2連同時
には1種類の形状でしかカット不可（NG例：片側フラット、片側ギザ）
・今度の展示会では、2連機は出展無し。
  - files: [{"id": "F08FAP885E0", "created": 1740622336, "timestamp": 1740622336, "name": "粉末2連ステック機.mp4", "title": "粉末2連ステック機.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 23527041, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F08FAP885E0-28f61b4f75/______2__________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F08FAP885E0-28f61b4f75/______2__________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08FAP885E0/download/______2__________________.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F08FAP885E0-28f61b4f75/file.m3u8?_xcb=3e5f4&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTM0NTk4NyxBVkVSQUdFLUJBTkRXSURUSD05MjcyMzksQ09ERUNTPSJhdmMxLjY0MDAxZixtcDRhLjQwLjUiLFJFU09MVVRJT049MTI3Mng3MjAsRlJBTUUtUkFURT0yOS45NzAKZGF0YTphcHBsaWNhdGlvbi92bmQuYXBwbGUubXBlZ3VybDtiYXNlNjQsSTBWWVZFMHpWUW9qUlZoVUxWZ3RWa1ZTVTBsUFRqb3pDaU5GV0ZRdFdDMVVRVkpIUlZSRVZWSkJWRWxQVGpvM0NpTkZXRlF0V0MxTlJVUkpRUzFUUlZGVlJVNURSVG94Q2lORldGUXRXQzFRVEVGWlRFbFRWQzFVV1ZCRk9sWlBSQW9qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UmtGUU9EZzFSVEF0TWpobU5qRmlOR1kzTlM5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01EQXhMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURoR1FWQTRPRFZGTUMweU9HWTJNV0kwWmpjMUwyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNREl1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd09FWkJVRGc0TlVVd0xUSTRaall4WWpSbU56VXZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TXk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSa0ZRT0RnMVJUQXRNamhtTmpGaU5HWTNOUzltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURBMExuUnpDaU5GV0ZSSlRrWTZOaTR3TURZc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGhHUVZBNE9EVkZNQzB5T0dZMk1XSTBaamMxTDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01EVXVkSE1LSTBWWVZFbE9Sam8yTGpBd05pd0thSFIwY0hNNkx5OW1hV3hsY3k1emJHRmpheTVqYjIwdlptbHNaWE10ZEcxaUwxUXdNek5FTnpCU1VqWklMVVl3T0VaQlVEZzROVVV3TFRJNFpqWXhZalJtTnpVdlptbHNaVjlJWHpJMk5GOHhNamd3ZURjeU1GOHpOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOaTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFJrRlFPRGcxUlRBdE1qaG1OakZpTkdZM05TOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREEzTG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EaEdRVkE0T0RWRk1DMHlPR1kyTVdJMFpqYzFMMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TURndWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdPRVpCVURnNE5VVXdMVEk0WmpZeFlqUm1OelV2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd09TNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UmtGUU9EZzFSVEF0TWpobU5qRmlOR1kzTlM5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01ERXdMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURoR1FWQTRPRFZGTUMweU9HWTJNV0kwWmpjMUwyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNVEV1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd09FWkJVRGc0TlVVd0xUSTRaall4WWpSbU56VXZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF4TWk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSa0ZRT0RnMVJUQXRNamhtTmpGaU5HWTNOUzltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURFekxuUnpDaU5GV0ZSSlRrWTZOaTR3TURZc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGhHUVZBNE9EVkZNQzB5T0dZMk1XSTBaamMxTDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01UUXVkSE1LSTBWWVZFbE9Sam8yTGpBd05pd0thSFIwY0hNNkx5OW1hV3hsY3k1emJHRmpheTVqYjIwdlptbHNaWE10ZEcxaUwxUXdNek5FTnpCU1VqWklMVVl3T0VaQlVEZzROVVV3TFRJNFpqWXhZalJtTnpVdlptbHNaVjlJWHpJMk5GOHhNamd3ZURjeU1GOHpOVEF3UzBKUVUxODNVVlpDVWw4d01EQXhOUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFJrRlFPRGcxUlRBdE1qaG1OakZpTkdZM05TOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREUyTG5SekNpTkZXRlJKVGtZNk5pNHdNRFlzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EaEdRVkE0T0RWRk1DMHlPR1kyTVdJMFpqYzFMMlpwYkdWZlNGOHlOalJmTVRJNE1IZzNNakJmTXpVd01FdENVRk5mTjFGV1FsSmZNREF3TVRjdWRITUtJMFZZVkVsT1JqbzJMakF3Tml3S2FIUjBjSE02THk5bWFXeGxjeTV6YkdGamF5NWpiMjB2Wm1sc1pYTXRkRzFpTDFRd016TkVOekJTVWpaSUxVWXdPRVpCVURnNE5VVXdMVEk0WmpZeFlqUm1OelV2Wm1sc1pWOUlYekkyTkY4eE1qZ3dlRGN5TUY4ek5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE9DNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UmtGUU9EZzFSVEF0TWpobU5qRmlOR1kzTlM5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01ERTVMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURoR1FWQTRPRFZGTUMweU9HWTJNV0kwWmpjMUwyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNakF1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd09FWkJVRGc0TlVVd0xUSTRaall4WWpSbU56VXZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF5TVM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSa0ZRT0RnMVJUQXRNamhtTmpGaU5HWTNOUzltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURJeUxuUnpDaU5GV0ZSSlRrWTZOaTR3TURZc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGhHUVZBNE9EVkZNQzB5T0dZMk1XSTBaamMxTDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01qTXVkSE1LSTBWWVZFbE9Sam8yTGpBd05pd0thSFIwY0hNNkx5OW1hV3hsY3k1emJHRmpheTVqYjIwdlptbHNaWE10ZEcxaUwxUXdNek5FTnpCU1VqWklMVVl3T0VaQlVEZzROVVV3TFRJNFpqWXhZalJtTnpVdlptbHNaVjlJWHpJMk5GOHhNamd3ZURjeU1GOHpOVEF3UzBKUVUxODNVVlpDVWw4d01EQXlOQzUwY3dvalJWaFVTVTVHT2pVdU5UQTFMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFJrRlFPRGcxUlRBdE1qaG1OakZpTkdZM05TOW1hV3hsWDBoZk1qWTBYekV5T0RCNE56SXdYek0xTURCTFFsQlRYemRSVmtKU1h6QXdNREkxTG5SekNpTkZXRlF0V0MxRlRrUk1TVk5VQ2c9PQo=", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F08FAP885E0-28f61b4f75/______2___________________trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 149649, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F08FAP885E0-28f61b4f75/______2___________________thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 960, "thumb_video_h": 544, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08FAP885E0/______2__________________.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F08FAP885E0-afde0f104a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08EU44SMSB", "created": 1740622996, "timestamp": 1740622996, "name": "现DXD端边 开口.jpg", "title": "现DXD端边 开口.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 102679, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08EU44SMSB/___dxd_____________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08EU44SMSB/download/___dxd_____________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08EU44SMSB-b2667e8915/___dxd______________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08EU44SMSB-b2667e8915/___dxd______________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08EU44SMSB-b2667e8915/___dxd______________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 203, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08EU44SMSB-b2667e8915/___dxd______________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 270, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08EU44SMSB-b2667e8915/___dxd______________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08EU44SMSB-b2667e8915/___dxd______________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 405, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08EU44SMSB-b2667e8915/___dxd______________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 450, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08EU44SMSB-b2667e8915/___dxd______________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 540, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08EU44SMSB-b2667e8915/___dxd______________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 576, "original_w": 1706, "original_h": 960, "thumb_tiny": "AwAbADClRRV2CzwA8w69E/xoEUyCMZHUZFJU9+cT4HZRVbPvQMdS0zNGaANGK3jSQNHksPXnFSyzpCMyNz6d6oSyukeFYjPoaqdTzSQ2S3EvnzF8YHQCo6KKYgopKKAP/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08EU44SMSB/___dxd_____________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08EU44SMSB-5f9fd7badb", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08EU455CPR", "created": 1740623000, "timestamp": 1740623000, "name": "切口.png", "title": "切口.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 90814, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08EU455CPR/______.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08EU455CPR/download/______.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08EU455CPR-b73794df3d/_______64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08EU455CPR-b73794df3d/_______80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08EU455CPR-b73794df3d/_______360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 196, "thumb_360_h": 271, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08EU455CPR-b73794df3d/_______160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 196, "original_h": 271, "thumb_tiny": "AwAwACKlTo0MjhV6mm1oW0PlR5P3j19qzbsNuxNGojQKvald9i+56UgIAyegqJ3z87dOwrMgTbnqTmjaPU1H+8PPFGJPUVXKwsJZwZPmuOB90etWh8ze3ehHjlXKH8PShsqvvSd7gxkjBmwPujrVaWYiUYG4A81O/wAsf+16+9QpGATk/e5Iq4K+oIl3xH+MUu6L++Khyn9wUZT+4K1GVomaNg6tirqTlly4x71VRR1P5U4Mx7YHYVDSe4MmmkHGSceg6mo1Y56deooEbOQSeKWVPLiJUHOaaVkA8REjOR+dHkt6j86r7JP+eYpdkn/PIVQH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08EU455CPR/______.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F08EU455CPR-609dd43ebf", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1740628746.914359] <@U05KGS6HN9H>: <@U03BLQ65GK0> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
杭州のメーカーChamaから、ボールミルの情報を共有致します。
（中文英文ありますが内容同じようです）
  - files: [{"id": "F08FXTF04Q0", "created": 1740628707, "timestamp": 1740628707, "name": "球磨抹茶机.pdf", "title": "球磨抹茶机.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 483105, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08FXTF04Q0/_______________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08FXTF04Q0/download/_______________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08FXTF04Q0-30aaebe72e/________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08FXTF04Q0/_______________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08FXTF04Q0-572bafe721", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08F9F5D0JW", "created": 1740628712, "timestamp": 1740628712, "name": "Ball-mill type Matcha tea processing machine英文.pdf", "title": "Ball-mill type Matcha tea processing machine英文.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 578094, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08F9F5D0JW/ball-mill_type_matcha_tea_processing_machine______.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08F9F5D0JW/download/ball-mill_type_matcha_tea_processing_machine______.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08F9F5D0JW-0fd3b9fa81/ball-mill_type_matcha_tea_processing_machine_______thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08F9F5D0JW/ball-mill_type_matcha_tea_processing_machine______.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08F9F5D0JW-1630ed4b7f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-02-27

- [1740649530.531479] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0>
急ぎ対応または確認して欲しい内容をまとめましたので、
確認をお願いします。
で、少しミーティングしましょう。

*▼サンプル*
サウジ
TSE-LOL-SPL-001-25
サンプル4種　各20g
◯①NO Upp1 出雲抹茶G
◯②NO Upp1 出雲抹茶R
◯③NO Upp1 出雲抹茶T
*~バニラ場所確認~OK*④NO Vanilla matcha 鹿児島B90%×キタマバニラ10%

*→明日2/28発送*

-------
ベトナム
TSE-CAO-SPL-001-25
各種50gでお願いします。
*~確認~ OK*鹿児島1A
◯ 鹿児島B
◯ 鹿児島D
袋：清和10966（白艶）
ラベル：品名ラベル
印字・窒素・エージレス：指定なし
箱：ボタニカル×1
*→明日2/28発送*
------

*▼注文*
オランダ Jinbo Cafe pengfei shen
TSE-JIN-001-25
①新製品: 30袋 x (1kg zip bag,シルバー):Non-organic Upper grade 2 (出雲精茶R) - JIN3*→代替品在庫(1000kg)OK*
袋指定: シルバー
エージレス：無し
品名ラベル貼り：表面あり
賞味期限印字：なし
②新製品: 5袋 x (1kg zip bag,シルバー):Non-organic Regular grade 2 (出雲精茶W) - JIN4→*在庫(175kg)OK*
袋指定: シルバー
エージレス：無し
品名ラベル貼り：表面あり
賞味期限の印字：なし
③リピート製品(価格が異なる為、商品コードはJIN5)：
  300缶 x 50g缶 (ホワイト), Non-organic Upper grade 2 (出雲精茶R) - JIN5→*原料在庫OK（製缶のスケジュール確認）*
  カスタムラベル:あり (胴・フタ) ← 2/22追記 ※胴ラベルは新デザインとなります。

*→出雲抹茶である必要はない*

------

カナダ：ワビサビ
TSE-WSM-002-25
鹿児島B 1kg bulk bag ×16bag （16kg）*→茗広 から3/1に35kg納品*
袋指定なし

~有機抹茶Bの在庫確認~
*発送日確認*
-----
TSE-SOL-004-25
オランダ SOL-Solaiman Aakouk(alibaba) 様

出雲抹茶G1kg×10袋
追加で10袋（計20kg同日出荷可能か）→*可能（出雲精茶で今粉砕中）*
~不可能な場合はいつなら可能か~
*出荷可能日　3/10（月）*
-----

メモ：セバスチャン用のRの代替品：1000kg程度在庫あり

## 2025-03-03

- [1741050947.012709] <@U08FZUNPSQ3>: <@U08FZUNPSQ3>さんがチャンネルに参加しました

## 2025-03-05

- [1741222028.906569] <@U0331FWGQRM>: メモ
静パック　印字文字数
半角英数字12文字以内
- [1741222084.580379] <@U0331FWGQRM>: ※文字長さ32mm以内であればOK

半角英数字2mm/文字→16文字max??と思ったが、
　安全を見て12文字以内とのこと。（全角なら6文字）
（なので、1, 2文字くらいなら増えてもいけそう）

## 2025-03-11

- [1741753713.339059] <@U0331FWGQRM>: EXP20/01/2027　（13文字）26mm
EXP 20/01/2027　（14文字）28mm
- [1741754872.869699] <@U0331FWGQRM>: スティックの長手方向に対して、
垂直方向に文字を印字できるかどうかについて
→不可。（望月様確認済み）

## 2025-03-29

- [1743231653.134459] <@U03BLQ65GK0>: <@U0840UVFVA8> <@U033G4KN4TD>
焙煎・粉砕・篩・合組について、製造指示時を出す際に製造完了後の仮の出来高数と単価を算出するシートを作成しました。
黄色で網掛けしたセルに必要事項を記入するかプルダウンから選ぶことで、自動算出するようになっています。
入庫表に仮入庫する際に使用して下さい。
原本は
共有フォルダ→工場フォルダ　に入っています。
  - files: [{"id": "F08L75VED17", "created": 1743231441, "timestamp": 1743231441, "name": "製造後単価・出来高算出表.xlsx", "title": "製造後単価・出来高算出表.xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 13064, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08L75VED17/____________________________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08L75VED17/download/____________________________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08L75VED17-a43a049051/_____________________________________converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08L75VED17-a43a049051/_____________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08L75VED17/____________________________________.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F08L75VED17-8006086ce6", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-03-31

- [1743469444.842439] <@U08L89G6JSG>: <@U08L89G6JSG>さんがチャンネルに参加しました

## 2025-04-13

- [1744592905.412829] <@U08N3SKSL75>: <@U08N3SKSL75>さんがチャンネルに参加しました

## 2025-04-20

- [1745195461.261169] <@U08NVD403GV>: <@U08NVD403GV>さんがチャンネルに参加しました

## 2025-04-25

- [1745647826.720899] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0331FZS7JT> <@U0840UVFVA8> <@U05KGS6HN9H> （追記あればお願いします！）
雑談MTG　議事録　2025/04/26
ボールミル　100万円/台　リードタイム：製造1ヶ月＋輸送（約1ヶ月）
　→ボールは肥料粉砕用として通関。
　　10mmと20mmを75kgずつ（合計100kgで提案されたが、少なく感じたので1.5倍注文することに）
ビーズミル　2000万円/台　　リードタイム：製造8ヶ月＋輸送（約1ヶ月）
スティック充填機　350万円　リードタイム：製造3ヶ月＋輸送（約1ヶ月）

購入予定
・ボールミル10台（出雲精茶5台 / 黄色倉庫5台に設置）
　→黄色倉庫に設置の工事が必要（仕様検討ののち、見積依頼が必要）
・ビーズミル1台（茶詰場の奥に設置）
・スティック充填機（茶詰場の奥に設置）

## 2025-04-26

- [1745653326.381619] <@U0331FZS7JT>: <@U03BLQ65GK0>
ここに各社の見積もり貼り付けてもらって良いですか？
よろしくお願いします。
- [1745654209.179489] <@U03BLQ65GK0>: <@U05KGS6HN9H>
見積もりここに貼り付けお願いします！

## 2025-04-28

- [1745830768.771759] <@U05KGS6HN9H>: <@U03BLQ65GK0>
ボールミル10台の見積（PI＝支払い資料）です。
先に確認した通り機械とボールで分けてもらっています。
手付金50％着金でスタート、出荷前残金50％着金で出荷ですが、
5台分（ボール込み）USD7300×5台×50％＝USD18250が送金済みです。
ボール量追加や値引き等で少々ややこしいので、合わせて金額資料を
ご参考ください。
総額（機械10台+ボール1500kg）　USD76250
・手付金→USD38125（内USD18250送金済み）
　　　　◆手付残金USD19875送金必要
・出荷前→USD38125送金必要
  - files: [{"id": "F08PHLX1AET", "created": 1745830752, "timestamp": 1745830752, "name": "2025-4-26-ball mill machine PI(1).pdf", "title": "2025-4-26-ball mill machine PI(1).pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 373165, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08PHLX1AET/2025-4-26-ball_mill_machine_pi_1_.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08PHLX1AET/download/2025-4-26-ball_mill_machine_pi_1_.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08PHLX1AET-50330bc758/2025-4-26-ball_mill_machine_pi_1__thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08PHLX1AET/2025-4-26-ball_mill_machine_pi_1_.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08PHLX1AET-069cd9a8a0", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08Q1TC0W2F", "created": 1745830757, "timestamp": 1745830757, "name": "2025-4-26-mill ball  PI(1).pdf", "title": "2025-4-26-mill ball  PI(1).pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 353996, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08Q1TC0W2F/2025-4-26-mill_ball__pi_1_.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08Q1TC0W2F/download/2025-4-26-mill_ball__pi_1_.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08Q1TC0W2F-be3e7a618c/2025-4-26-mill_ball__pi_1__thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08Q1TC0W2F/2025-4-26-mill_ball__pi_1_.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08Q1TC0W2F-df9694c9d6", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08QMC4QS8G", "created": 1745830762, "timestamp": 1745830762, "name": "Ball mill_金額資料（20250428）.pdf", "title": "Ball mill_金額資料（20250428）.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 340848, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08QMC4QS8G/ball_mill________________20250428___.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08QMC4QS8G/download/ball_mill________________20250428___.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08QMC4QS8G-9f2dc35f94/ball_mill________________20250428____thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 2109, "thumb_pdf_h": 1491, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08QMC4QS8G/ball_mill________________20250428___.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08QMC4QS8G-a7fe65b47f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1745835675.697789] <@U03BLQ65GK0>: <@U0331FZS7JT> <@U0331FWGQRM>
池田製茶機械のビーズミルの見積書とパンフです
  - files: [{"id": "F08QB7U9A73", "created": 1745835639, "timestamp": 1745835639, "name": "桃翠園様25-4.pdf", "title": "桃翠園様25-4.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 317792, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08QB7U9A73/____________25-4.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08QB7U9A73/download/____________25-4.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08QB7U9A73-cb3f734abb/____________25-4_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08QB7U9A73/____________25-4.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08QB7U9A73-f3fda32092", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08Q1QFGDLJ", "created": 1745835641, "timestamp": 1745835641, "name": "ビーズミル機パンフ.pdf", "title": "ビーズミル機パンフ.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 482015, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08Q1QFGDLJ/____________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08Q1QFGDLJ/download/____________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08Q1QFGDLJ-99118cdddd/_____________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 2165, "thumb_pdf_h": 1633, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08Q1QFGDLJ/____________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08Q1QFGDLJ-a38f770f89", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-05-02

- [1746236212.719199] <@U066P20UQH1>: <!channel> 

FAYから*クレーム*です。

製品に画像の通り、異物混入があったとのことです。
送られてきた写真の袋の番号から001-25のものと思われます。
原因の究明と対策をお願い致します。

お客様には下記を伝えています。
・製品の保証（返金または次回からその分の価格の相殺）
・異物が何だった（確定できなかった場合想定含む）の報告をします（画像から植物由来のものであるので人体への害はないと思いますが）

先方にはGWで休みなので、報告まで少しお時間いただきますと伝えています。
ご確認よろしくお願いします。

  - files: [{"id": "F08REPPBFH6", "created": 1746236168, "timestamp": 1746236168, "name": "IMG_4461.jpg", "title": "IMG_4461", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 290279, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08REPPBFH6/img_4461.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08REPPBFH6/download/img_4461.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08REPPBFH6-455b8956bd/img_4461_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08REPPBFH6-455b8956bd/img_4461_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08REPPBFH6-455b8956bd/img_4461_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08REPPBFH6-455b8956bd/img_4461_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08REPPBFH6-455b8956bd/img_4461_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08REPPBFH6-455b8956bd/img_4461_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08REPPBFH6-455b8956bd/img_4461_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08REPPBFH6-455b8956bd/img_4461_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08REPPBFH6-455b8956bd/img_4461_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1080, "original_h": 1440, "thumb_tiny": "AwAwACSeZAWzjg1CU54/I1bYblx3qAjnvmgaIS5j5BIPtViEtJDufnPTiovLLsFZSB9KsYwAF4A6UAyMopPSjy19Kfz6UfhSEEsyxD1aogXIyzbP502PDu8jdv0qF3LPk0wJyAeDM9NZ5YMHdvSoeT0NSQvztalcCwkyOudwHsad5if31/OqUsZSQhRkdaZhv7tMCbZtDNuH0qFuH5qU8BQTnimlcjn86QDtw20xc76MEVJGp4PHFSlYCwQM80mF9qru5dsg4FN+b+9Vgf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08REPPBFH6/img_4461.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08REPPBFH6-a7bc9cf141", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08QU5GUFU2", "created": 1746236168, "timestamp": 1746236168, "name": "IMG_4462.jpg", "title": "IMG_4462", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 53941, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08QU5GUFU2/img_4462.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08QU5GUFU2/download/img_4462.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GUFU2-6a363f81ff/img_4462_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GUFU2-6a363f81ff/img_4462_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GUFU2-6a363f81ff/img_4462_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 221, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GUFU2-6a363f81ff/img_4462_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 294, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GUFU2-6a363f81ff/img_4462_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GUFU2-6a363f81ff/img_4462_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 441, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GUFU2-6a363f81ff/img_4462_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 490, "thumb_800_h": 800, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GUFU2-6a363f81ff/img_4462_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 588, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GUFU2-6a363f81ff/img_4462_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 628, "thumb_1024_h": 1024, "original_w": 662, "original_h": 1080, "thumb_tiny": "AwAwAB2w0AJ+Xio2gk7YNWiVQEtgAVXe7H8C/iaAFhhZCSxFTY9Kpi5bPUflUq3RxyoP6UADxhgMk8dOage2ccqQam3PkZT8jS+aO/H1FRcuyZQbcpweDQrke9TXbKduOo71XzTRD0NLfkUzOXNNKqOgxSKo9T+dSWSnBHSqE6hZSF6VbIO04YiqBJJyeTTFI//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08QU5GUFU2/img_4462.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08QU5GUFU2-59cd6a6752", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08QVAMCFDJ", "created": 1746236168, "timestamp": 1746236168, "name": "IMG_4463.jpg", "title": "IMG_4463", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 1366791, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08QVAMCFDJ/img_4463.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08QVAMCFDJ/download/img_4463.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08QVAMCFDJ-db4fc63d47/img_4463_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08QVAMCFDJ-db4fc63d47/img_4463_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08QVAMCFDJ-db4fc63d47/img_4463_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08QVAMCFDJ-db4fc63d47/img_4463_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08QVAMCFDJ-db4fc63d47/img_4463_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08QVAMCFDJ-db4fc63d47/img_4463_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08QVAMCFDJ-db4fc63d47/img_4463_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08QVAMCFDJ-db4fc63d47/img_4463_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08QVAMCFDJ-db4fc63d47/img_4463_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACSOO0iZFYswJGeoqX7EmOHf86ptjcvug/lWjZrm2T2z/OgCE2KYzvemmzH/AD0er2M80jCgCj9k/wCmr0fZf+mr1ZI5ooAz2xmP/dFaNkf9HX8f51mMf9V/uf1NaNmf9HXPqaALH1pGpP50jUAMPWkpCeaMikBmlsiMDPAwfzrRtlaOIK4wcnvVT7LcoOJAB7MajInBx5p/76NMDUJpDmswLOT/AK0/99GpBbzn/lr/AOPGgCeZtrD6UzzKiNrKTzID+JpPssn98frQB//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08QVAMCFDJ/img_4463.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08QVAMCFDJ-e12cb8580b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08QU5GMSR0", "created": 1746236168, "timestamp": 1746236168, "name": "IMG_4464.jpg", "title": "IMG_4464", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 1161199, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08QU5GMSR0/img_4464.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08QU5GMSR0/download/img_4464.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GMSR0-72da73166d/img_4464_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GMSR0-72da73166d/img_4464_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GMSR0-72da73166d/img_4464_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GMSR0-72da73166d/img_4464_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GMSR0-72da73166d/img_4464_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GMSR0-72da73166d/img_4464_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GMSR0-72da73166d/img_4464_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GMSR0-72da73166d/img_4464_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08QU5GMSR0-72da73166d/img_4464_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACSJYJwvATFKIrkdIlP41djGQDUgHtQBneVcA58rP40hSfOTD+taW2mOpxwcH1pAZrOQcPFyPem+YP8Ann+tWpLcu5Ytyab9k/2qLgXI+QKjug/yhDx3FKhYcAj8qSYnKk0xrchCyj+9+dBMw7v+dLvAFIZPQE0XLsiB55VPVzSfaZf9upN5BOE/Wje3939aCbFtDxUdyfu/Wog14B/qB/n8ahmkuDgOgFBKZIcMp7HtTgxxjA9qrKJmOAoqTyLnH3Vx160rFXAkrgE/nSb/AHoa1mc5YqD9aT7HL6r+dFhXP//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08QU5GMSR0/img_4464.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08QU5GMSR0-12e862598d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1746243830.817709] <@U066P20UQH1>: ロット番号の共有をいただきました

  - files: [{"id": "F08QJP28YJJ", "created": 1746243825, "timestamp": 1746243825, "name": "IMG_4478.jpg", "title": "IMG_4478", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 230838, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08QJP28YJJ/img_4478.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08QJP28YJJ/download/img_4478.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08QJP28YJJ-7a4c63d5a3/img_4478_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08QJP28YJJ-7a4c63d5a3/img_4478_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08QJP28YJJ-7a4c63d5a3/img_4478_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 218, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08QJP28YJJ-7a4c63d5a3/img_4478_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 290, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08QJP28YJJ-7a4c63d5a3/img_4478_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08QJP28YJJ-7a4c63d5a3/img_4478_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 435, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08QJP28YJJ-7a4c63d5a3/img_4478_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1323, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08QJP28YJJ-7a4c63d5a3/img_4478_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 581, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08QJP28YJJ-7a4c63d5a3/img_4478_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 619, "thumb_1024_h": 1024, "original_w": 967, "original_h": 1599, "thumb_tiny": "AwAwAB2wFpdoquLlvr+FIZpD2f8ACnYdiwQAOeKYNrdCD9Kru5xyCaltDuiJPrRYVhyKuB2PrTjGu4nPtTUbaakznmgYxwqJ8o5Pc0iHauAMd6JOfXAp0S5BpgyskhYYXG4H9KsKeOo+lQvGUZinCnnjmm7nHp+VAEz9Cc1LCfk/GqTM7cevoKsRHZGq+lMTP//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08QJP28YJJ/img_4478.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08QJP28YJJ-2d30388812", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-05-06

- [1746589948.835299] <@U08RVRNBY00>: <@U08RVRNBY00>さんがチャンネルに参加しました

## 2025-05-07

- [1746604979.932809] <@U0331FWGQRM>: <@U0331FZS7JT> <@U03BLQ65GK0> <@U0840UVFVA8>
*カメタニ粉砕*
30kg機
ボール100kg
18時間
24台所有・中国製

## 2025-05-08

- [1746748309.417819] <@U0331FZS7JT>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
本件、進捗ありますか？
ご確認よろしくお願いします。

## 2025-05-14

- [1747206691.336039] <@U066P20UQH1>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
記録のために、報告書の投稿をお願いいたします:woman-bowing:
FAYフォルダの`250502_異物混入連絡`にもお願いします。

## 2025-05-15

- [1747372201.135849] <@U0331FWGQRM>: <@U0840UVFVA8> <@U03BLQ65GK0> <@U03BLQ65GK0>
ボールミル粉砕場所など用途としてどうでしょう。
<https://www.tm-21.net/theme/chintai_detail/?hdata1=HO0235&prif=32&from=map>
<https://www.tm-21.net/theme/chintai_detail/?hdata1=GW0255&prif=32&from=map>
<https://www.tm-21.net/theme/chintai_detail/?hdata1=IE0001&prif=32&from=map>
  - attachments: [{"from_url": "https://www.tm-21.net/theme/chintai_detail/?hdata1=HO0235&prif=32&from=map", "service_icon": "https://www.tm-21.net/theme/sn-default/images/favicon.ico", "id": 1, "original_url": "https://www.tm-21.net/theme/chintai_detail/?hdata1=HO0235&amp;prif=32&amp;from=map", "fallback": "山陰（鳥取県・島根県）最大級の不動産情報サイト「山陰不動産ナビ」: 高岡テナント/出雲市高岡町/貸し事務所 | 山陰（鳥取県・島根県）最大級の不動産情報サイト「山陰不動産ナビ」", "text": "山陰不動産ナビは山陰（鳥取県・島根県）最大級の不動産情報サイトです。山陰不動産ナビは出雲市北部の高岡テナントの情報が掲載されているサイトです。", "title": "高岡テナント/出雲市高岡町/貸し事務所 | 山陰（鳥取県・島根県）最大級の不動産情報サイト「山陰不動産ナビ」", "title_link": "https://www.tm-21.net/theme/chintai_detail/?hdata1=HO0235&prif=32&from=map", "service_name": "山陰（鳥取県・島根県）最大級の不動産情報サイト「山陰不動産ナビ」"}, {"from_url": "https://www.tm-21.net/theme/chintai_detail/?hdata1=GW0255&prif=32&from=map", "service_icon": "https://www.tm-21.net/theme/sn-default/images/favicon.ico", "id": 2, "original_url": "https://www.tm-21.net/theme/chintai_detail/?hdata1=GW0255&amp;prif=32&amp;from=map", "fallback": "山陰（鳥取県・島根県）最大級の不動産情報サイト「山陰不動産ナビ」: ☆人気の白枝エリア：倉庫、店舗、事務所として利用可！駐車場最大12台！☆/出雲市白枝町1035番地4/貸し倉庫 | 山陰（鳥取県・島根県）最大級の不動産情報サイト「山陰不動産ナビ」", "text": "山陰不動産ナビは山陰（鳥取県・島根県）最大級の不動産情報サイトです。山陰不動産ナビは出雲市北部の☆人気の白枝エリア：倉庫、店舗、事務所として利用可！駐車場最大12台！☆の情報が掲載されているサイトです。", "title": "☆人気の白枝エリア：倉庫、店舗、事務所として利用可！駐車場最大12台！☆/出雲市白枝町1035番地4/貸し倉庫 | 山陰（鳥取県・島根県）最大級の不動産情報サイト「山陰不動産ナビ」", "title_link": "https://www.tm-21.net/theme/chintai_detail/?hdata1=GW0255&prif=32&from=map", "service_name": "山陰（鳥取県・島根県）最大級の不動産情報サイト「山陰不動産ナビ」"}]

## 2025-05-23

- [1748029634.422979] <@U0331FWGQRM>: 
  - files: [{"id": "F06BC9HR6QM", "created": 1703346680, "timestamp": 1703346680, "name": "無題", "title": "無題", "mimetype": "application/vnd.slack-docs", "filetype": "quip", "pretty_type": "Canvas", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": true, "size": 0, "mode": "quip", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06BC9HR6QM/canvas?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06BC9HR6QM/download/canvas?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "permalink": "https://grp-ssm9297.slack.com/docs/T033D70RR6H/F06BC9HR6QM", "permalink_public": "https://slack-files.com/T033D70RR6H-F06BC9HR6QM-9aacb302eb", "url_static_preview": "https://grp-ssm9297.slack.com/docs/T033D70RR6H/F06BC9HR6QM/mobile", "quip_thread_id": "bXa9AAfIhhT", "updated": 1732331356, "update_notification": 0, "is_starred": false, "skipped_shares": true, "teams_shared_with": [], "is_restricted_sharing_enabled": true, "has_rich_preview": false, "file_access": "visible", "access": "owner", "org_or_workspace_access": "none", "canvas_creator_id": "U0331FZS7JT", "team_pref_version_history_enabled": true, "canvas_printing_enabled": true, "is_ai_suggested": false}]

## 2025-05-25

- [1748218315.210719] <@U0331FWGQRM>: <@U0331FZS7JT> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0>
確認したい、もしくは決まっていなければ、
検討したいのですが、

出雲抹茶R：今後は品質や数量によって他産地の碾茶やモガをブレンドします
なのか、
出雲抹茶R：￥6,869/kg
（出雲１茶碾茶が¥6,500/kg（以前は¥4,000/kg）、出雲精茶での粉砕賃¥300と歩留(99%)）

なのか、表現を明確に分けたいです。

つまり、
出雲抹茶Rの意味を
品質を基準として製造するのか、
原料（一茶碾茶）を基準とするのか、
どちらにするのか、という意味です。

認識齟齬を防ぐために、さらに言い換えますと、
出雲抹茶R＝昨年の出雲抹茶Rと同じ品質＝他産地の碾茶やモガをブレンドで調整
or
出雲抹茶R＝出雲精茶一茶抹茶＝￥6,869/kg
- [1748220990.433089] <@U0331FZS7JT>: <@U0331FWGQRM> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0>
確定してないので、検討として・・・

出雲抹茶R：品質基準
今後の出雲抹茶R＝昨年の出雲抹茶Rと同じ品質＝他産地の碾茶やモガをブレンドで調整
が良いかと思っています。
例年「おくみどり」の品質が良いからこれを元に他の茶をブレンドし昨年産のものに合わせていく。

原料が集まった段階で、昨年の出雲抹茶R品質のものを合組・保管。
出雲抹茶指定のお客様用に出来高から一定数量保管する（<@U03BLQ65GK0> 一茶おくみどり 2t保管したい）

品質基準の方が汎用性があるのと、来年以降も対応が可能になると思います。
価格は鹿児島からのR品質の碾茶価格は¥5,000/kg以上と聞いていますが、まだ細かい数字は降りてきてないので、確定し次第共有します！
まだ他産地１茶碾茶が集まってないので、すぐ出荷する分については一旦原価￥6,869/kgとなります。

いかがでしょうか？？

## 2025-05-27

- [1748403070.395839] <@U05KGS6HN9H>: <@U03BLQ65GK0> <@U0331FZS7JT> <@U0331FWGQRM> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
現時点におけるボールミルに関しての情報共有となります。
①ボール→肥料撹拌粉砕用の普通貨物として輸入（LCL混載便）
②機械→食衛法届申請を経て輸入（40F+20F）

①ボール輸入にあたりメーカー輸出ライセンスによる障害（中国側
税関で長期STOPするリスク）が提起されましたが、メーカー側が
MSDSを取得し通関申告することで回避できる見込み。
当初は支障が発生した場合、LCL混載で他荷主貨物も止まることから、
福通Gより②と合わせて当社の貨物だけでコンテナを仕立てる提案も
ありましたが、目途が立った為、現地側でも予定通りLCL混載の輸出便
を手配済み。6/2-3神戸入港予定、早ければ6/6～9頃、出雲精茶に入荷
予定です。

②機械の仕上りが予定より早まり、1回目で40Fコンテナに8台を
積載して輸入を予定致します。（取出し口網は先ず6台分）
一部の部品交換調整があり、8台の輸出梱包完了は5/30-31見込み。
5/31完了の場合、中国祝日（端午節）の関係で6/3-4上海港倉庫入れ
の予定になる為、推測では6/6上海出港→6/9神戸入港或いは、6/7上海→6/10神戸と思われます。5/30までに梱包完了させ少しでも早い船に
積めるよう要請中です。船スケジュール情報が確定後、食衛法届を
進めます。

※その他の画像動画関係は、以下に保存しております。
桃翠園（共有フォルダ_松井Google  Drive）\●工場\機械仕様書・見積書\202503中国出張関係\ボールミル（chama杭州）\動画\出荷前確認
  - files: [{"id": "F08TW0ARS15", "created": 1748403062, "timestamp": 1748403062, "name": "動作確認3.mp4", "title": "動作確認3.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 12764503, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "complete", "locale": "en-US", "preview": {"content": "Oh Yeah. You. But Yeah. Now. No.", "has_more": false}}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F08TW0ARS15-ac51f100b8/____________3.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F08TW0ARS15-ac51f100b8/____________3.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08TW0ARS15/download/____________3.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "vtt": "https://files.slack.com/files-tmb/T033D70RR6H-F08TW0ARS15-ac51f100b8/file.vtt?_xcb=62e66&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F08TW0ARS15-ac51f100b8/file.m3u8?_xcb=62e66&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MjEwNDQ5OCxBVkVSQUdFLUJBTkRXSURUSD0xNjQxMDc3LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTYwOHgxMDgwLEZSQU1FLVJBVEU9MjkuOTcwLFNVQlRJVExFUz0ic3VicyIKZGF0YTphcHBsaWNhdGlvbi92bmQuYXBwbGUubXBlZ3VybDtiYXNlNjQsSTBWWVZFMHpWUW9qUlZoVUxWZ3RWa1ZTVTBsUFRqb3pDaU5GV0ZRdFdDMVVRVkpIUlZSRVZWSkJWRWxQVGpvM0NpTkZXRlF0V0MxTlJVUkpRUzFUUlZGVlJVNURSVG94Q2lORldGUXRXQzFRVEVGWlRFbFRWQzFVV1ZCRk9sWlBSQW9qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0VkZjd1FWSlRNVFV0WVdNMU1XWXhNREJpT0M5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFZGY3dRVkpUTVRVdFlXTTFNV1l4TURCaU9DOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TWk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRWRmN3UVZKVE1UVXRZV00xTVdZeE1EQmlPQzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd015NTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0VkZjd1FWSlRNVFV0WVdNMU1XWXhNREJpT0M5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOQzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFZGY3dRVkpUTVRVdFlXTTFNV1l4TURCaU9DOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TlM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRWRmN3UVZKVE1UVXRZV00xTVdZeE1EQmlPQzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd05pNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0VkZjd1FWSlRNVFV0WVdNMU1XWXhNREJpT0M5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOeTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFZGY3dRVkpUTVRVdFlXTTFNV1l4TURCaU9DOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3T0M1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRWRmN3UVZKVE1UVXRZV00xTVdZeE1EQmlPQzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd09TNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0VkZjd1FWSlRNVFV0WVdNMU1XWXhNREJpT0M5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXhNQzUwY3dvalJWaFVTVTVHT2pFdU9EWTVMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFZGY3dRVkpUTVRVdFlXTTFNV1l4TURCaU9DOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF4TVM1MGN3b2pSVmhVTFZndFJVNUVURWxUVkFvPQojRVhULVgtTUVESUE6VFlQRT1TVUJUSVRMRVMsR1JPVVAtSUQ9InN1YnMiLE5BTUU9IkVuZ2xpc2giLERFRkFVTFQ9WUVTLEFVVE9TRUxFQ1Q9WUVTLEZPUkNFRD1OTyxMQU5HVUFHRT0iZW5nIixVUkk9ImRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzJNREFLSTBWWVZDMVlMVTFGUkVsQkxWTkZVVlZGVGtORk9qRUtJMFZZVkMxWUxWQk1RVmxNU1ZOVUxWUlpVRVU2Vms5RUNpTkZXRlJKVGtZNk5qRXVPVEk0TEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRWRmN3UVZKVE1UVXRZV00xTVdZeE1EQmlPQzltYVd4bExuWjBkQW9qUlZoVUxWZ3RSVTVFVEVsVFZBPT0iCg==", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F08TW0ARS15-ac51f100b8/____________3_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 61928, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F08TW0ARS15-ac51f100b8/____________3_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08TW0ARS15/____________3.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F08TW0ARS15-7c47e058d0", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-05-28

- [1748485110.769259] <@U08U8MMTH43>: <@U08U8MMTH43>さんがチャンネルに参加しました

## 2025-05-29

- [1748571750.805669] <@U05KGS6HN9H>: <@U03BLQ65GK0>
<@U0331FZS7JT> <@U0331FWGQRM> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
②ボールミル機械（8台）5/30時点の情報共有です。まだ今後遅れが
出る可能性がある為、確定ではありませんが、荷受の具合もあります
のでザックリした見込みです。
　上海出港　6/6（金）
　神戸入港　6/9（月）予定
　食衛法届申請～通関　6/10～
　コンテナ搬出～トラック積載　6/12～
全てが順調に推移した場合で、6/13頃の出雲精茶搬入が最短の
見込みです。但し前述した通り船の遅れや検疫所（届け）認可状況次第
という要素があります。確定後、速やかに情報共有致します。
貨物梱包サイズから、出雲精茶には10t車×2台での搬入予定。トラック
横からフォークリフト降ろしで想定をお願い致します。

## 2025-06-02

- [1748914893.676079] <@U08V56G9U92>: <@U08V56G9U92>さんがチャンネルに参加しました
- [1748929832.647659] <@U05KGS6HN9H>: <@U03BLQ65GK0>
<@U0331FZS7JT> <@U0331FWGQRM> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
6/3時点での情報共有です。
ボールミル機械（40Fコンテナで8台、LCL混載で2台）、
前航海からの遅れ（タイ港混雑影響）で上海出港日と
神戸入港日が遅れております。
《6/3現在の動静》
上海出港　6/7（土）
神戸入港　6/10（火）午前予定
引き続き最短での出雲精茶入れを目指します。

## 2025-06-08

- [1749449056.477319] <@U05KGS6HN9H>: <@U03BLQ65GK0>
<@U0331FZS7JT> <@U0331FWGQRM> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
6/9時点での情報共有です。
《機械》
福通Gさんから明日6/10予定通り船入港としてボールミル
納品につき連絡が入りました。
最短6/14（土）9:00着で機械8台の出雲精茶納品トラックを
押さえて頂いています。現状4t車×2の予定です。
もし残り2台が間に合えば、10t車×1+4t車×1で10台納品。
（間に合わなければ翌週別便で2台納入）
《ボール》
前後しますがボールは6/13（金）出雲精茶着の予定です。

## 2025-06-10

- [1749599327.854389] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
多久和さんにGoogle Driveのアクセス権付与しました。

## 2025-06-16

- [1750068090.369679] <@U0331FZS7JT>: <!channel>
ボールミルのテスト製造の進捗等こちらで教えて下さい。
よろしくお願いします。

## 2025-06-18

- [1750230866.410059] <@U0331FZS7JT>: <@U03BLQ65GK0> <@U0840UVFVA8>
中国製機械での粉砕について
12時間
18時間
24時間
30時間
36時間

で粒度分布の確認をお願いします。
- [1750242597.388229] <@U0331FZS7JT>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0>
碧翠園 有機抹茶代替品製造確認
- [1750242951.005429] <@U0331FZS7JT>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0>

碧翠園　国産有機抹茶
①¥12,000/kg
②¥10,500/kg

①②有機抹茶¥9000/kgの代替品としても使えるモノだったので
改めて使えるか確認をお願いします。

<https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1750038848092819?thread_ts=1746176377.833279&amp;cid=C03C62NBSDP>

このキャンセルになった原料使えそうですか？
水宗園の7400です。
かなり質高いので合わせられそうか確認をお願いします。

<@U041RJKV5JA>
既に確認されているかもしれませんが
水宗園に9000の碾茶で急ぎ200kg納品可能か確認しています。
碧翠園にも少しでも在庫いけるか確認していますので
わかり次第共有します。
  - attachments: [{"from_url": "https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1750038848092819?thread_ts=1746176377.833279&amp;cid=C03C62NBSDP", "ts": "1750038848.092819", "author_id": "U066P20UQH1", "channel_id": "C03C62NBSDP", "channel_team": "T033D70RR6H", "is_msg_unfurl": true, "is_reply_unfurl": true, "message_blocks": [{"team": "T033D70RR6H", "channel": "C03C62NBSDP", "ts": "1750038848.092819", "message": {"blocks": [{"type": "rich_text", "block_id": "0kVxR", "elements": [{"type": "rich_text_section", "elements": [{"type": "usergroup", "usergroup_id": "S073HEMKWV7"}, {"type": "text", "text": " "}, {"type": "usergroup", "usergroup_id": "S088LEJ1U5T"}, {"type": "text", "text": "\nお客さんに状況を確認したところ、先方のお客さんからの返信がないとのことです。\n一旦こちらはキャンセル扱いとします。インボイス、指示書等破棄でお願いいたします"}, {"type": "emoji", "name": "woman-bowing", "unicode": "1f647-200d-2640-fe0f"}]}]}]}}], "id": 1, "original_url": "https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1750038848092819?thread_ts=1746176377.833279&amp;cid=C03C62NBSDP", "fallback": "[June 15th, 2025 6:54 PM] haru.nboc: <!subteam^S073HEMKWV7> <!subteam^S088LEJ1U5T>\nお客さんに状況を確認したところ、先方のお客さんからの返信がないとのことです。\n一旦こちらはキャンセル扱いとします。インボイス、指示書等破棄でお願いいたします:woman-bowing:", "text": "<!subteam^S073HEMKWV7> <!subteam^S088LEJ1U5T>\nお客さんに状況を確認したところ、先方のお客さんからの返信がないとのことです。\n一旦こちらはキャンセル扱いとします。インボイス、指示書等破棄でお願いいたします:woman-bowing:", "author_name": "Haruka Hayashi", "author_link": "https://grp-ssm9297.slack.com/team/U066P20UQH1", "author_icon": "https://avatars.slack-edge.com/2024-04-12/6955353714228_179323cb3551f7c8ecfe_48.png", "author_subname": "Haruka Hayashi", "mrkdwn_in": ["text"], "footer": "Slack の会話内のスレッド"}]
- [1750244322.322349] <@U0331FZS7JT>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0>
2025年産仕入れ１茶碾茶仕上げ加工について
※宇治と八女
- [1750245710.608619] <@U0331FZS7JT>: メモ
国産有機抹茶10500代替品
7400 95% + 9000 5%
- [1750246230.837569] <@U0331FZS7JT>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0>

サプライヤー
宇治碾茶：利招園茶舗・水宗園・茗広
八女碾茶：水宗園

フロー
・宇治碾茶
品種ごとに合組→排出
筋切り前から投入→仕上げ碾茶（保管）

・八女碾茶
品質ごとに合組→排出
筋切り前から投入→仕上げ碾茶（保管）
焙煎（DR）を行う
※DRは全量ではない

## 2025-06-19

- [1750325050.071859] <@U0331FZS7JT>: <@U0840UVFVA8> <@U03BLQ65GK0>
茗広碾茶さえみどり
筋切り前から投入
歩留確認→モガだったら利招園茶舗の「うじひかり」を流す。

よろしくお願いします。

目的：歩留確認し、原価を確認するため

## 2025-06-20

- [1750408383.629939] <@U0331FZS7JT>: <@U0840UVFVA8> <@U03BLQ65GK0>
メモ
荒碾茶歩留：75%

## 2025-06-21

- [1750503560.386669] <@U0331FZS7JT>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
*2025年産 通常ラインナップのサンプル製造について*
- [1750504009.438069] <@U0331FZS7JT>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
*▼通常ラインナップ*
Organic・Non-organic
Upp-1,2
Mid-1,2
Reg-1,2
Low-1,2

*各10g×500袋（各5kg）*
の製造をお願いします。
出来るものから進めて下さい。

スケジュールが確認出来次第、至急共有をお願いします。
<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
スピード＋数優先で各10gでのサンプル製造を依頼しました。
もしお客様によって20gが良いということがあれば（こっちから言わずに向こうがそう言ってきたら）、２袋出荷で対応をお願いします。
よろしくお願いします。

## 2025-06-22

- [1750641342.264529] <@U03BLQ65GK0>: <@U0331FZS7JT> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
サンプル製造フロー
①Rの中身決定→要スケジューリング
②原料準備（粉砕）
・Non-organic　R：数量35kg粉砕（必要量詰め時2g考慮で29.3kg）
→①決定し次第すぐに
・Non-organic　R：数量20kg・粉砕済み（必要量詰め時+2g考慮で19.8kg）

・Organic　R：数量30kg粉砕（必要量詰め時+2g考慮で24.8kg※Gに使用する出雲翠のオーガニックは無いため製造不可→G 5kg分減）
→セバスチャン案件終わり次第粉砕開始（今週中？）
・Organic　A：数量25kg粉砕（必要量詰め時+2g考慮で19.8kg）

③合組
Organic・Non-organicでそれぞれ6.1kg合組（詰め時+2gと合組時のロス100gとして必要量+1.1kg）

④小分

以上4ステップです。

<@U0331FZS7JT>
【ペンディング事項】
・Rの中身
①を早急に決める必要がありますが、今集まっているもの（未入荷の水宗園含め）で締めてはどうでしょう？
数量的に不安ではありますが、サンプル提出のほうが個人的には急いだほうが良いと思うので、
現状でサンプル作成進めたほうが良いのではと思います。

・出雲精茶の一茶碾
今年の出雲精茶の一茶碾を現在色々なものに使用していますが、一旦これを止めないと合組の比率が確定できませんので、一旦色を良くして出荷する系のものを止める（出荷延期）か、色悪いもので出すの対応のどちらを取るのかの決定をお願いします。

<!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
上記ペンディング事項が決まりましたら製造スタートします。（始めれるものは進めますが）
それ以降の小分についてはその後決定し共有をお願いします。

## 2025-06-23

- [1750668407.412109] <@U0331FZS7JT>: <@U03BLQ65GK0> <@U0840UVFVA8> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
粉砕数量のところは多分メモ？なのであまりよく分かっていませんが、製造フローについて、理解しました。

> 【ペンディング事項】
> ・Rの中身
その締めで一旦良いと思います。
品質確定と数量出し（水宗園から連絡あり次第/今月中）優先で進めたいと思います。

> ・出雲精茶の一茶碾
これについてはそのまま出荷の対応をお願いします。
量が決まっている（これ以上増えない）原料：色が悪い原料
量が決まっていない（調整可能）原料：色の良い今年の出雲精茶他の１茶碾
→色を調整するためのRの比率をこれまでの数字から算出し、それで対応し、
今年のRはそれで使用された原料から抜いた数宇を元に、比率を出して製造で良いと思います。

細かく確認したいことなどあれば教えて下さい。

## 2025-06-30

- [1751298509.024519] <@U0331FWGQRM>: <@U0331FZS7JT> <@U0840UVFVA8> <@U03BLQ65GK0>
製造の状況のMTGを水曜日か木曜日あたりにできますか？
時間はいつでも大丈夫です。
会議室がないので社宅がいいかな？と思っております。宜しくお願い致します。

※私の都合ですみませんが、7/2以降でお願いしたいです。
- [1751301807.000149] <@U0331FZS7JT>: <@U0331FWGQRM> <@U03BLQ65GK0> <@U0840UVFVA8>
２日（水）午前中以外であればいつでも時間大丈夫です。
社宅が良いと思います！
よろしくお願いします。
- [1751323466.617179] <@U0840UVFVA8>: <@U0331FWGQRM> <@U0331FZS7JT> <@U03BLQ65GK0>
水曜日、木曜日ともに終日可能です。
よろしくお願いします。
- [1751323685.870309] <@U03BLQ65GK0>: <@U0331FWGQRM> <@U0331FZS7JT> <@U0840UVFVA8> 
両日の時間いつでも大丈夫です。
よろしくお願いします。
- [1751337172.032689] <@U0331FWGQRM>: <@U0331FZS7JT> <@U0840UVFVA8> <@U03BLQ65GK0>
では水曜日の14時で宜しくお願いします。

## 2025-07-02

- [1751445734.008869] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0840UVFVA8> <@U0331FZS7JT> <@U08L89G6JSG>
茶審査を正確に行うためには自然光がいいと思っている。 しかし、自然光の場合、天気に左右されるため、安定した茶審査を行う環境を整えるためにLEDなどの照明を整えた審査室を作りたい。 このようなLEDなどの照明で正しく色を審査できるのでしょうか？


ChatGPT:

茶審査において、自然光の使用は理想的とされていますが、安定性の観点からLEDなどの人工照明を用いた審査環境の整備は十分に有効です。以下に詳しくご説明します。

:white_check_mark: 結論：LED照明でも正確な色審査は可能
LED照明でも、
*演色性（Color Rendering Index, CRI）* と *色温度* を適切に設定すれば、自然光に近い光環境を再現でき、安定かつ正確な色評価が可能です。

:mag: 重要な照明の条件
1. *演色性（CRI：Color Rendering Index）*
    ◦ CRIは、光源が色をどれだけ自然に見せられるかを示す指標で、*100が自然光に最も近い*とされます。
    ◦ 茶審査用途には *CRI 95以上*（できれば98〜99）がおすすめです。
2. *色温度*
    ◦ 太陽光に近い色温度は *5000K〜6500K*（昼白色〜昼光色）です。
    ◦ 審査室では *D50（5000K）またはD65（6500K）規格*が基準とされることが多いです（特に印刷・食品業界など）。
3. *照度*
    ◦ 茶審査に必要な照度は、作業面で *1000〜1500ルクス程度*が目安です。
    ◦ 均一に照らすために *拡散型の照明設計*を採用するのが望ましいです。
:gear: 審査室の設計上のポイント
• *壁面・天井・机の色はニュートラルグレー（反射を抑える）*
• *日光や外部の光が入らないよう遮光性を確保*
• *色評価用LED（高CRI仕様）を採用*（例：演色評価用LED製品や「Ra98高演色LED」など）
:test_tube: 実例と参考
• 日本茶業中央会や製茶試験場では、色評価や水色審査にD65の照明条件が推奨されることがあります。
• 高演色LED照明は、食品工場や印刷工場、繊維業界などでも既に導入されており、色の微細な違いを評価する目的で使用されています。
:white_check_mark: 推奨製品・照明設計会社（例）
• *オーデリック（ODELIC）*、*パナソニック*、*岩崎電気* などのLEDメーカーは、演色評価用照明を提供。
• *コニカミノルタ*などが照明の色評価用環境設計や照度測定機器の提供を行っています。
:pushpin: まとめ
項目推奨値CRI（演色性）95以上（理想は98〜99）色温度5000〜6500K（D50またはD65）照度1000〜1500ルクスその他拡散光、遮光、反射防止設計が重要

## 2025-07-09

- [1752048990.502099] <@U033G4KN4TD>: <@U0331FZS7JT> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
Non-organic
Upp-1：出雲抹茶G
Upp-2：出雲抹茶R
Mid-1：出雲抹茶T
Mid-2：出雲抹茶N
Reg-1：出雲抹茶F
Reg-2：出雲抹茶W
Low-1：出雲抹茶H
Low-2：出雲抹茶P
上記*Non-Organicは、7月25日完成予定(取り急ぎ各50～100個）*

袋について、10ｇサンプルのため
吉村AL-Dで対応してよろしいでしょうか？

*Organicは未定*

## 2025-07-13

- [1752459187.158539] <@U0331FZS7JT>: <@U03BLQ65GK0> <@U0840UVFVA8>
CC：<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
*2025年 八女抹茶（要碾茶仕上+DR/サプライヤー水宗園）製造+供給量・価格確定について*
※7月19日(土)確定目標
- [1752459215.396409] <@U0331FZS7JT>: <@U03BLQ65GK0> <@U0840UVFVA8>
▼目的
水宗園から届いている八女碾茶（1茶）を星野製茶の抹茶にブレンドして供給量を増やす

▼数量
*オクミドリ：540kg（未仕上げ＋ロットによって要DR）*
(ロットNo.9803/9810/9811/9812/9814)
*ヤブキタ：270kg（未仕上げ＋ロットによって要DR）*
(ロットNo.8723/9798/9799)
※オクNo.9803のみサンプルがないため製品で要確認

▼資料
共有フォルダ（桃翠園→価格関係）
八女抹茶価格(20250714)の２ページ目に内容まとめています。
歩留は概算を<@U03BLQ65GK0> に確認し反映しています

▼製造フロー
資料内の八女碾茶を仕上げ+DR+粉砕する（宇治抹茶の隙間で最低量）
出来上がりの品質を確認してブレンド比率を決める
※原料は全て出雲精茶にある

▼スケジュール確認
<@U03BLQ65GK0> <@U0840UVFVA8>
今週中に全量決めたいので、
土曜日に最低数量（各10kg程度）整うように準備をお願いします。
宇治の仕上げと粉砕のスケジュールも確認したいので、連絡します。
- [1752465658.287789] <@U0331FZS7JT>: <@U03BLQ65GK0> <@U0840UVFVA8>
メモ
・各ロット15kgずつ仕上げる
・真空唐箕でも自動投入で選別可能
- [1752475114.907209] <@U095LLEH09G>: <@U095LLEH09G>さんがチャンネルに参加しました

## 2025-07-18

- [1752881654.789709] <@U0331FZS7JT>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
CC：<@U0840UVFVA8> <@U03BLQ65GK0>
すみません粉砕が遅れているので、7月22日（火）に確定させます。
よろしくお願いします。
- [1752885931.773399] <@U0331FZS7JT>: <@U0840UVFVA8> <@U03BLQ65GK0>
<!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
CC：<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
*宇治抹茶 単一品種*
粉砕スケジュール(供給可能日・粉砕数量)について
- [1752885936.929479] <@U0331FZS7JT>: 2025年7月19日時点、粉砕の進捗どんな感じですか？
・さみどり
・ごこう
・うじひかり
・あさひ
・やぶきた
・きらり-31

## 2025-07-24

- [1753410366.273039] <@U0331FZS7JT>: <@U03BLQ65GK0> <@U0840UVFVA8>
CC：<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>

2025年
八女抹茶の製造（仕上げ+合組+粉砕・ブレンド）完了予定：８月末
*出荷可能時期：8月末-9月頭を予定*

<@U05KGS6HN9H><@U041RJKV5JA> <@U08U8MMTH43>
星野製茶に月当たりで供給制限があれば
全アイテムを7月8月9月分で各月分を1日着で発注願います。
※7月1日はもう無理なので、8月1日あたりに7,8月分を納品いただけるように交渉願います。

もし３ヶ月(7,8,9月)分、まとめて先に発注できるようであれば、10月から続きの発注をお願いします。

よろしくお願いします。
  - files: [{"id": "F097ELDANN6", "created": 1753409942, "timestamp": 1753409942, "name": "・八女抹茶価格（20250714).xlsx", "title": "・八女抹茶価格（20250714).xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 88397, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F097ELDANN6/________________________20250714_.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F097ELDANN6/download/________________________20250714_.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F097ELDANN6-69d0bb7b3d/________________________20250714__converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F097ELDANN6-69d0bb7b3d/________________________20250714__thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1113, "thumb_pdf_h": 788, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F097ELDANN6/________________________20250714_.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F097ELDANN6-e6124492ac", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1753411231.343329] <@U0331FZS7JT>: <@U0840UVFVA8> <@U03BLQ65GK0>
<!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>

宇治単一品種（香岳園以外）
【要合組→粉砕】
・さみどり
・ごこう
・うじひかり
・やぶきた
*→8月18日(月)以降出荷可能*

【粉砕のみ】
・あさひ
・きらり-31
*→8月4日(月)以降出荷可能*

## 2025-07-29

- [1753779513.119049] <@U033G4KN4TD>: <@U0331FZS7JT> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
 <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
Organic
Top-2：鹿児島製茶 有機抹茶A
Upp-1： 鹿児島製茶 有機抹茶A 90%, 有機抹茶B 10%
Upp-2： 鹿児島製茶 有機抹茶A 50%, 有機抹茶B 50%
Mid-1： 鹿児島製茶 有機抹茶B
Mid-2：鹿児島製茶 有機抹茶C
Reg-1：鹿児島製茶 有機抹茶D
Reg-2：水宗園 有機抹茶34号
Low-1：まるゑい 有機抹茶3000
Low-2：まるゑい 有機抹茶MEA(1C)

上記Organicサンプルについて*8月5日頃完成予定(取り急ぎ各100個）*
Non-Organic同様AL-Dに袋詰めします。

```Top-2：鹿児島製茶 有機抹茶A 
Upp-1： 鹿児島製茶 有機抹茶A 90%, 有機抹茶B 10%
Upp-2： 鹿児島製茶 有機抹茶A 50%, 有機抹茶B 50%```
上記で使用の鹿児島製茶/有機抹茶Aについて下記情報共有いたします。

鹿児島製茶/有機抹茶A：年間供給量1040㎏　＋　水宗園/有機抹茶＠13000：年間供給量300㎏
＝1340㎏
鹿児島/有機抹茶A：約77.6％　＋　水宗園/有機抹茶＠13000：約22.4％
上記割合で合組後使用していく方向となりました。
品質確認済( <@U0331FZS7JT> <@U0840UVFVA8>)

よろしくお願いいたします。

## 2025-07-31

- [1754002132.027569] <@U033G4KN4TD>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
> Upp-1： 鹿児島製茶 有機抹茶A 90%, 有機抹茶B 10%
上記Organic Matcha Upper Grade-1の原料名についてご相談です。
原料名が決まっておらず、何がよいでしょうか…？
例）
有機抹茶AA
有機抹茶AB
有機抹茶A90
有機抹茶E

皆様ご意見ください。
よろしくお願いいたします。
- [1754007735.503889] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
有機抹茶A90
が分かりやすいので、良いかなと思いました。
- [1754009198.746639] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
原料やその比率については常に変わるので、
原料の比率に基づくネーミングは避けた方がいいかと思います。

比率でネーミングすると、
有機抹茶A90は年度によって品質がブレます。
2026年になれば、有機抹茶A90のネーミングが無効化されます。
いつのA90？という議論が必ず出ます。
またMTGで話し合いましょう。

## 2025-08-01

- [1754038142.710089] <@U0331FZS7JT>: <@U0840UVFVA8> <@U0331FWGQRM> <@U08L89G6JSG> <@U033G4KN4TD>
茶詰め・品管
<https://www.tm-21.net/theme/chintai_detail/?hdata1=HM0433&prif=32&from=map>
  - attachments: [{"from_url": "https://www.tm-21.net/theme/chintai_detail/?hdata1=HM0433&prif=32&from=map", "service_icon": "https://www.tm-21.net/theme/sn-default/images/favicon.ico", "id": 1, "original_url": "https://www.tm-21.net/theme/chintai_detail/?hdata1=HM0433&amp;prif=32&amp;from=map", "fallback": "山陰（鳥取県・島根県）最大級の不動産情報サイト「山陰不動産ナビ」: 学頭テナントビル　2F【9号線沿い！】/出雲市斐川町学頭227-7/貸し事務所 | 山陰（鳥取県・島根県）最大級の不動産情報サイト「山陰不動産ナビ」", "text": "山陰不動産ナビは山陰（鳥取県・島根県）最大級の不動産情報サイトです。山陰不動産ナビは出雲市斐川町の学頭テナントビル　2F【9号線沿い！】の情報が掲載されているサイトです。", "title": "学頭テナントビル　2F【9号線沿い！】/出雲市斐川町学頭227-7/貸し事務所 | 山陰（鳥取県・島根県）最大級の不動産情報サイト「山陰不動産ナビ」", "title_link": "https://www.tm-21.net/theme/chintai_detail/?hdata1=HM0433&prif=32&from=map", "service_name": "山陰（鳥取県・島根県）最大級の不動産情報サイト「山陰不動産ナビ」"}]

## 2025-08-06

- [1754487871.874849] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0> <@U0331FZS7JT>
スティック製造機械と袋自動充填機械について、
進捗を改めて確認させてください。

※Sebastyanからスティックの機械はどうなったの？？？と聞かれました。

## 2025-08-19

- [1755656777.758399] <@U0331FZS7JT>: <@U0331FWGQRM> <@U03BLQ65GK0> <@U0840UVFVA8> <@U033G4KN4TD> <@U08L89G6JSG>
11:30開始
<https://us02web.zoom.us/j/82995242107?pwd=1yLIpI8AnSxfTLHWYQokIdxgirDTjh.1>
よろしくお願いします。
- [1755663994.080469] <@U0331FWGQRM>: <@U05KGS6HN9H> cc <@U03BLQ65GK0> <@U0331FZS7JT> <@U0840UVFVA8> <@U033G4KN4TD> <@U08L89G6JSG>
ボールミル追加で10台購入したいので、
見積もりとってもらえますか？
最短の納期の確認もお願いします。仕様は前回と同じでOKです。

<@U03BLQ65GK0> 会長曰く、ボールについては前回分が余ってるらしいので不要のようです。

宜しくお願い致します！
- [1755668992.207929] <@U05KGS6HN9H>: <@U0331FWGQRM>
<@U03BLQ65GK0> <@U0331FZS7JT> <@U0840UVFVA8> <@U033G4KN4TD> <@U08L89G6JSG>
Chamaに見積依頼しております。
・合計20台購入することになるので価格面の優待を要請しています。
（現在Chama側で協議中）
・納期につき、現在別ユーザーの碾茶ライン設備を製造中の為、
今発注しても11/20頃の完成（出来る限り前倒しを検討）になる旨、
先ず返信がありました。
- [1755669248.136429] <@U0331FWGQRM>: <@U05KGS6HN9H> 
価格交渉ありがとうございます
碾茶ライン？！
どこですかね。うっすら聞いてもらえますか？笑　後々仕入れたいので:laughing:

納期優先したいので、
一括納品でなくても、5台だけ先にとかで、
10月初旬に入荷とかでもok、とお伝えください
宜しくお願いします:sweat_drops:
- [1755669323.109579] <@U05KGS6HN9H>: <@U0331FWGQRM>
了解しました。
取り急ぎの情報でしたので、納期面を
もう少し折衝してみたいと思います。
- [1755670681.731409] <@U0331FZS7JT>: <@U05KGS6HN9H>
CC：<@U0331FWGQRM> <@U0840UVFVA8> <@U08L89G6JSG> <@U03BLQ65GK0> <@U033G4KN4TD>
篩について
今回：不要
前回：4台購入
今、10台のボールミルに対し、２台を使用しているとのことで
前回購入した残りの2台は今回の10台に使用で問題ない旨<@U0840UVFVA8> に確認しました。

## 2025-08-21

- [1755762583.302629] <@U0331FWGQRM>: <@U033G4KN4TD> <@U08L89G6JSG> cc <@U03BLQ65GK0> <@U0331FZS7JT> <@U0840UVFVA8>
製造チームの人員確保について

・固定アルバイト
・単発タイミー
・外部委託（労働支援作業所など）
・外部委託（企業/インプレックス、島根有機）

Sebastyan, Omatchaなどの袋詰め作業が今後も増えることが予想されますので、柔軟に対応できる体制を整えたいと思います。
下記を進めてもらえますか。よろしくお願いしましす。
またMTGさせてください。必要であれば連絡、相談ください。
- [1755762799.546559] <@U0331FWGQRM>: :star:*️アルバイト*
indeed, ハローワーク, チラシなど
indeedの情報を共有しますので、アルバイトの採用時に使用してください。
採用する場合は上長に確認報告してください
ログイン：<mailto:daiki.oka@tousuien.jp|daiki.oka@tousuien.jp>
パスワード：tousuien

*タイミー：*
都度

:star:*外注_作業所：*
<@U03BLQ65GK0> 会長から情報共有があると思います。
かなり使えると思うので、これは有意義に、
そして最優先して進めてもいいと思います。

*外注_企業*
今まで通りでOKかと思います。
- [1755823825.129739] <@U05KGS6HN9H>: <@U0331FWGQRM>
<@U03BLQ65GK0> <@U0331FZS7JT> <@U0840UVFVA8> <@U033G4KN4TD> <@U08L89G6JSG>
見積及び情報を取得いたしました。ご確認ご検討をお願い致します。
《機械》
納期も含め折衝したところ、現行機10台を購入したメーカー（納期90日
11/20完成）とは別メーカーでも同型機を製造しており、こちらであれば
現時点で空きがあり、30日で10台完成まで対応可能とのことです。
現行機メーカーでは分割対応で納期前倒し等も不可の為、この提案が
ありました。スペック的には同等のようです。
※Chamaは商社的メーカーで、協力メーカーから仕入れた機械を海外に販売
　しています。
※両メーカー機械が同品番JY-6CSAV20の為、品番後ろに【SS】があるのが
　新規品として識別しています。
◆現行機と新規品SSの比較概要ご参考ください。
・送風ファンがある分、新規品SSが高そうですが同価格（FOB上海USD6150/台）
・粉砕量は共に20kg（容器寸法は現行、SSとも同じ）
・回転速度（rpm）：現行機のrpmは未計測で不明ですが設定値は58Hz
（但し速度設定不可）、新規品SSは最大60Hzで50rpm（最少0Hzで5rpm）から、
　58Hzで調整入力すれば同rpmになるとのことです。
・SSは今月スリランカ向けでちょうど生産（380V3相）していたタイミング
　でした。画像と動画ご参照ください。
《ボール》
再確認で粉砕ボールが500kg不足の為、合わせて見積を取得しました。
前回10台分：10㎜径（750kg）+20㎜径（750kg）＝1500kg輸入
→1台：10㎜径（50kg）+20㎜径（50kg）＝100kg使用
→10台×100kg×1000kg使用、残り在庫500kg（→追加分不足500kg）
前回同様に、機械とは別で単独輸出入を想定した条件を伝えて見積を
取得しております。前回同様、肥料粉砕用での輸入を想定します。
  - files: [{"id": "F09B56EEQT1", "created": 1755823646, "timestamp": 1755823646, "name": "20250821_ボールミル比較概要.pdf", "title": "20250821_ボールミル比較概要.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 686176, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09B56EEQT1/20250821____________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09B56EEQT1/download/20250821____________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09B56EEQT1-a650f2758f/20250821_____________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09B56EEQT1/20250821____________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09B56EEQT1-7b57a0855b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09BMLMD0R2", "created": 1755823656, "timestamp": 1755823656, "name": "現行機見積_2025-8-20-ball mill machine PI.pdf", "title": "現行機見積_2025-8-20-ball mill machine PI.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 344420, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09BMLMD0R2/________________2025-8-20-ball_mill_machine_pi.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09BMLMD0R2/download/________________2025-8-20-ball_mill_machine_pi.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09BMLMD0R2-4cd2c3b48b/________________2025-8-20-ball_mill_machine_pi_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09BMLMD0R2/________________2025-8-20-ball_mill_machine_pi.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09BMLMD0R2-0db8416ce7", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09B56FHDPZ", "created": 1755823662, "timestamp": 1755823662, "name": "SS見積_2025-8-20-ball mill machine PI.pdf", "title": "SS見積_2025-8-20-ball mill machine PI.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 349720, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09B56FHDPZ/ss_______2025-8-20-ball_mill_machine_pi.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09B56FHDPZ/download/ss_______2025-8-20-ball_mill_machine_pi.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09B56FHDPZ-11dcf192f4/ss_______2025-8-20-ball_mill_machine_pi_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09B56FHDPZ/ss_______2025-8-20-ball_mill_machine_pi.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09B56FHDPZ-c0d9a39b24", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09BX54MMDF", "created": 1755823671, "timestamp": 1755823671, "name": "【現行機カタログ】球磨抹茶机.pdf", "title": "【現行機カタログ】球磨抹茶机.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 483105, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09BX54MMDF/__________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09BX54MMDF/download/__________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09BX54MMDF-4cccb5e996/___________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09BX54MMDF/__________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09BX54MMDF-b310769960", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09BHKWDHM0", "created": 1755823678, "timestamp": 1755823678, "name": "【SSカタログ】Ball-mill Type Matcha Tea Processing Machine.pdf", "title": "【SSカタログ】Ball-mill Type Matcha Tea Processing Machine.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 835358, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09BHKWDHM0/___ss_______________ball-mill_type_matcha_tea_processing_machine.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09BHKWDHM0/download/___ss_______________ball-mill_type_matcha_tea_processing_machine.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09BHKWDHM0-ce1e8f8738/___ss_______________ball-mill_type_matcha_tea_processing_machine_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09BHKWDHM0/___ss_______________ball-mill_type_matcha_tea_processing_machine.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09BHKWDHM0-15fb5970cd", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09BHKYKMNE", "created": 1755823696, "timestamp": 1755823696, "name": "スリランカ出荷機_動画1.mp4", "title": "スリランカ出荷機_動画1.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 4598453, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "complete", "locale": "en-US", "preview": {"content": "Hello.", "has_more": false}}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F09BHKYKMNE-5bab8c5fad/_______________________________1.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F09BHKYKMNE-5bab8c5fad/_______________________________1.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09BHKYKMNE/download/_______________________________1.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "vtt": "https://files.slack.com/files-tmb/T033D70RR6H-F09BHKYKMNE-5bab8c5fad/file.vtt?_xcb=a8611&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F09BHKYKMNE-5bab8c5fad/file.m3u8?_xcb=a8611&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTU0NjMyMCxBVkVSQUdFLUJBTkRXSURUSD0xMzg3Mzg5LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTEyODB4NzIwLEZSQU1FLVJBVEU9MjkuOTcwLFNVQlRJVExFUz0ic3VicyIKZGF0YTphcHBsaWNhdGlvbi92bmQuYXBwbGUubXBlZ3VybDtiYXNlNjQsSTBWWVZFMHpWUW9qUlZoVUxWZ3RWa1ZTVTBsUFRqb3pDaU5GV0ZRdFdDMVVRVkpIUlZSRVZWSkJWRWxQVGpvM0NpTkZXRlF0V0MxTlJVUkpRUzFUUlZGVlJVNURSVG94Q2lORldGUXRXQzFRVEVGWlRFbFRWQzFVV1ZCRk9sWlBSQW9qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE1UWtoTFdVdE5Ua1V0TldKaFlqaGpOV1poWkM5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01EQXhMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURsQ1NFdFpTMDFPUlMwMVltRmlPR00xWm1Ga0wyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNREl1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd09VSklTMWxMVFU1RkxUVmlZV0k0WXpWbVlXUXZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TXk1MGN3b2pSVmhVU1U1R09qVXVNRGN5TEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTVRa2hMV1V0TlRrVXROV0poWWpoak5XWmhaQzltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURBMExuUnpDaU5GV0ZRdFdDMUZUa1JNU1ZOVUNnPT0KI0VYVC1YLU1FRElBOlRZUEU9U1VCVElUTEVTLEdST1VQLUlEPSJzdWJzIixOQU1FPSJFbmdsaXNoIixERUZBVUxUPVlFUyxBVVRPU0VMRUNUPVlFUyxGT1JDRUQ9Tk8sTEFOR1VBR0U9ImVuZyIsVVJJPSJkYXRhOmFwcGxpY2F0aW9uL3ZuZC5hcHBsZS5tcGVndXJsO2Jhc2U2NCxJMFZZVkUwelZRb2pSVmhVTFZndFZrVlNVMGxQVGpvekNpTkZXRlF0V0MxVVFWSkhSVlJFVlZKQlZFbFBUam8yTURBS0kwVllWQzFZTFUxRlJFbEJMVk5GVVZWRlRrTkZPakVLSTBWWVZDMVlMVkJNUVZsTVNWTlVMVlJaVUVVNlZrOUVDaU5GV0ZSSlRrWTZNak11TURnNUxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE1UWtoTFdVdE5Ua1V0TldKaFlqaGpOV1poWkM5bWFXeGxMblowZEFvalJWaFVMVmd0UlU1RVRFbFRWQT09Igo=", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F09BHKYKMNE-5bab8c5fad/_______________________________1_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 23089, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F09BHKYKMNE-5bab8c5fad/_______________________________1_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 1280, "thumb_video_h": 720, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09BHKYKMNE/_______________________________1.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F09BHKYKMNE-debcb3f407", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09BCNR78SX", "created": 1755823705, "timestamp": 1755823705, "name": "スリランカ出荷機_動画2.mp4", "title": "スリランカ出荷機_動画2.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 5510393, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "complete", "locale": "en-US", "preview": {"content": "だからそう、そう。じゃあ、ここにから飲むから。", "has_more": false}}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F09BCNR78SX-7b3ea25b02/_______________________________2.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F09BCNR78SX-7b3ea25b02/_______________________________2.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09BCNR78SX/download/_______________________________2.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "vtt": "https://files.slack.com/files-tmb/T033D70RR6H-F09BCNR78SX-7b3ea25b02/file.vtt?_xcb=ae03b&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F09BCNR78SX-7b3ea25b02/file.m3u8?_xcb=ae03b&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTk2NDc2NSxBVkVSQUdFLUJBTkRXSURUSD0xNzcwMzgwLENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTEyODB4NzIwLEZSQU1FLVJBVEU9MjkuOTcwLFNVQlRJVExFUz0ic3VicyIKZGF0YTphcHBsaWNhdGlvbi92bmQuYXBwbGUubXBlZ3VybDtiYXNlNjQsSTBWWVZFMHpWUW9qUlZoVUxWZ3RWa1ZTVTBsUFRqb3pDaU5GV0ZRdFdDMVVRVkpIUlZSRVZWSkJWRWxQVGpvM0NpTkZXRlF0V0MxTlJVUkpRUzFUUlZGVlJVNURSVG94Q2lORldGUXRXQzFRVEVGWlRFbFRWQzFVV1ZCRk9sWlBSQW9qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE1UWtOT1VqYzRVMWd0TjJJelpXRXlOV0l3TWk5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01EQXhMblJ6Q2lORldGUkpUa1k2Tmk0d01EWXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURsQ1EwNVNOemhUV0MwM1lqTmxZVEkxWWpBeUwyWnBiR1ZmU0Y4eU5qUmZNVEk0TUhnM01qQmZNelV3TUV0Q1VGTmZOMUZXUWxKZk1EQXdNREl1ZEhNS0kwVllWRWxPUmpvMkxqQXdOaXdLYUhSMGNITTZMeTltYVd4bGN5NXpiR0ZqYXk1amIyMHZabWxzWlhNdGRHMWlMMVF3TXpORU56QlNValpJTFVZd09VSkRUbEkzT0ZOWUxUZGlNMlZoTWpWaU1ESXZabWxzWlY5SVh6STJORjh4TWpnd2VEY3lNRjh6TlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TXk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTVRa05PVWpjNFUxZ3ROMkl6WldFeU5XSXdNaTltYVd4bFgwaGZNalkwWHpFeU9EQjROekl3WHpNMU1EQkxRbEJUWHpkUlZrSlNYekF3TURBMExuUnpDaU5GV0ZSSlRrWTZNeTQzTURRc0NtaDBkSEJ6T2k4dlptbHNaWE11YzJ4aFkyc3VZMjl0TDJacGJHVnpMWFJ0WWk5VU1ETXpSRGN3VWxJMlNDMUdNRGxDUTA1U056aFRXQzAzWWpObFlUSTFZakF5TDJacGJHVmZTRjh5TmpSZk1USTRNSGczTWpCZk16VXdNRXRDVUZOZk4xRldRbEpmTURBd01EVXVkSE1LSTBWWVZDMVlMVVZPUkV4SlUxUUsKI0VYVC1YLU1FRElBOlRZUEU9U1VCVElUTEVTLEdST1VQLUlEPSJzdWJzIixOQU1FPSJFbmdsaXNoIixERUZBVUxUPVlFUyxBVVRPU0VMRUNUPVlFUyxGT1JDRUQ9Tk8sTEFOR1VBR0U9ImVuZyIsVVJJPSJkYXRhOmFwcGxpY2F0aW9uL3ZuZC5hcHBsZS5tcGVndXJsO2Jhc2U2NCxJMFZZVkUwelZRb2pSVmhVTFZndFZrVlNVMGxQVGpvekNpTkZXRlF0V0MxVVFWSkhSVlJFVlZKQlZFbFBUam8yTURBS0kwVllWQzFZTFUxRlJFbEJMVk5GVVZWRlRrTkZPakVLSTBWWVZDMVlMVkJNUVZsTVNWTlVMVlJaVUVVNlZrOUVDaU5GV0ZSSlRrWTZNamN1TnpJM0xBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE1UWtOT1VqYzRVMWd0TjJJelpXRXlOV0l3TWk5bWFXeGxMblowZEFvalJWaFVMVmd0UlU1RVRFbFRWQT09Igo=", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F09BCNR78SX-7b3ea25b02/_______________________________2_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 27727, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F09BCNR78SX-7b3ea25b02/_______________________________2_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 1280, "thumb_video_h": 720, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09BCNR78SX/_______________________________2.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F09BCNR78SX-9d28631b52", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09BKH2NU6S", "created": 1755823814, "timestamp": 1755823814, "name": "ボール見積_2025-8-20-mill ball  PI.pdf", "title": "ボール見積_2025-8-20-mill ball  PI.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 324524, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09BKH2NU6S/________________2025-8-20-mill_ball__pi.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09BKH2NU6S/download/________________2025-8-20-mill_ball__pi.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09BKH2NU6S-f11e800639/________________2025-8-20-mill_ball__pi_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09BKH2NU6S/________________2025-8-20-mill_ball__pi.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09BKH2NU6S-5e7e63e0e8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1755824889.990579] <@U0331FWGQRM>: <@U05KGS6HN9H> <@U03BLQ65GK0> <@U0331FZS7JT> <@U0840UVFVA8> <@U033G4KN4TD> <@U08L89G6JSG>
問題なさそうに見えますね！
念の為に1年保証つけてくれたら購入するとか、
条件つけて交渉してみてもいいかもですね。
（元々ついてます？？）

> 新規品SSは最大60Hzで50rpm（最少0Hzで5rpm）から、
> 58Hzで調整入力すれば同rpmになるとのことです。
→ここについてはよく理解できませんが、調整できるのならいいかと思います。

というか、扇風機いいですね！
無いよりはあったほうが冷却機能としてはいいと思います。
既存ボールミルに自分たちで改造して、扇風機ってつけれるんですかね？w
これも聞けそうなら、タイミング見て聞いてもらえると助かります。
（その場合、改造に必要な扇風機と改造に必要な部品の見積もりを入手する必要があるかと思います）
- [1755825148.552939] <@U03BLQ65GK0>: <@U05KGS6HN9H> <@U0331FWGQRM> <@U0331FZS7JT> <@U0840UVFVA8> <@U033G4KN4TD> <@U08L89G6JSG>
ありがとうございます！
昨日口頭でもお願いした件＋追加で確認してもらいたいことがありますので、確認をお願いできますでしょうか。

・機械全体のサイズではなく粉砕ポット（本体）のサイズ
・回転速度については、Hzを合わせれば同rpmというのはモーターの回転数だと思いますが、念の為それは本体の回転「速度」ではなく「数」も一緒になるということで合っているか
・原料排出時の網は何個無料で付くのか（こちらのボールのサイズ伝えないと網のサイズ決まらないならお伝え下さい）+台数分付かないなら追加購入可能か
・速度MAXで粉砕している時の動画がもらえるか
・今回送ってもらった動画のボールミル機は現在提案受けているものと同じものか（何だか小さい気がするんですが。。。）

以上です。
よろしくお願いします！

## 2025-08-23

- [1755941894.596719] <@U05KGS6HN9H>: <@U0331FWGQRM> <@U03BLQ65GK0>
<@U0331FZS7JT> <@U0840UVFVA8> <@U033G4KN4TD> <@U08L89G6JSG>
取り急ぎまして、概要資料を更新しております。
・機械の保証期間は1年とのことです。
・ポット容器サイズは844.5㎜長×660㎜短幅（702㎜長幅）
　→現行機と同じサイズとのこと。
・58Hzにセットすれば、誤差1％程度で現行機と同回転数になるとのことです。
・10㎜/20㎜ボール対応の網は1台1枚付属での価格（別途購入は不要）
・日本製モーター（現行機モーターも日本製）であれば最大60Hz/50rpm
　となるが、現物が無い為、中国製モーター（最大50Hz/42rpmまで）の
　動画が届きました。最大と最少の動画です。
ご確認と検討をお願い致します。
  - files: [{"id": "F09BQ804K7U", "created": 1755941767, "timestamp": 1755941767, "name": "20250823_ボールミル比較概要.pdf", "title": "20250823_ボールミル比較概要.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 753349, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09BQ804K7U/20250823____________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09BQ804K7U/download/20250823____________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09BQ804K7U-6da4ebc6cf/20250823_____________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09BQ804K7U/20250823____________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09BQ804K7U-10fa8cd083", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09BBDM73C7", "created": 1755941774, "timestamp": 1755941774, "name": "中国製モーター_最大50Hz.mp4", "title": "中国製モーター_最大50Hz.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 1229289, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F09BBDM73C7-e4a1ef7a69/____________________________50hz.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F09BBDM73C7-e4a1ef7a69/____________________________50hz.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09BBDM73C7/download/____________________________50hz.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F09BBDM73C7-e4a1ef7a69/file.m3u8?_xcb=a3d3c&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTg0NTI3MixBVkVSQUdFLUJBTkRXSURUSD0xODQ1MjcyLENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTYxMngxMDgwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pVdU16Y3lMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNVFrSkVUVGN6UXpjdFpUUmhNV1ZtTjJFMk9TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TVM1MGN3b2pSVmhVTFZndFJVNUVURWxUVkFvPQo=", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F09BBDM73C7-e4a1ef7a69/____________________________50hz_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 5372, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F09BBDM73C7-e4a1ef7a69/____________________________50hz_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 544, "thumb_video_h": 960, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09BBDM73C7/____________________________50hz.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F09BBDM73C7-57799f7d40", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09BQ80D5NW", "created": 1755941779, "timestamp": 1755941779, "name": "中国製モーター_最少.mp4", "title": "中国製モーター_最少.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 4699788, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F09BQ80D5NW-bd00149fa7/____________________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F09BQ80D5NW-bd00149fa7/____________________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09BQ80D5NW/download/____________________________.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F09BQ80D5NW-bd00149fa7/file.m3u8?_xcb=47ee7&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTQyMTExMixBVkVSQUdFLUJBTkRXSURUSD0xMzg2MDU0LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTYwOHgxMDgwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNVFsRTRNRVExVGxjdFltUXdNREUwT1daaE55OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TVM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTVRbEU0TUVRMVRsY3RZbVF3TURFME9XWmhOeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01pNTBjd29qUlZoVVNVNUdPakl1T0RBekxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE1UWxFNE1FUTFUbGN0WW1Rd01ERTBPV1poTnk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNeTUwY3dvalJWaFVMVmd0UlU1RVRFbFRWQW89Cg==", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F09BQ80D5NW-bd00149fa7/_____________________________trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 14814, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F09BQ80D5NW-bd00149fa7/_____________________________thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09BQ80D5NW/____________________________.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F09BQ80D5NW-84d8cf7b7b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-08-25

- [1756115975.839179] <@U05KGS6HN9H>: <@U0331FWGQRM> <@U03BLQ65GK0>
<@U0331FZS7JT> <@U0840UVFVA8> <@U033G4KN4TD> <@U08L89G6JSG>
Chamaより発注検討状況（現行機或いは新規品SS）の確認が入りました。
新規品SS（納期30日完成）のメーカーに、他ユーザーからも20数台の注文が
入ったようです。SS発注の場合は他ユーザー分と合わせて製造を段取りし、
ボールミル完了後は碾茶ライン設備の製造に入るようです。
ChamaからSS製造メーカーに製造状況（納期への影響等）を確認中です。
- [1756134134.958379] <@U0331FWGQRM>: <@U05KGS6HN9H> cc <@U03BLQ65GK0> <@U0331FZS7JT>
つまり購入の決定を急かされている感じですか？
購入しますという最終意思表示待ちですか？
- [1756161578.330259] <@U05KGS6HN9H>: <@U0331FWGQRM>
<@U03BLQ65GK0> <@U0331FZS7JT>
検討中という点は伝えていますが、催促されている感じです。
現行機（納期90日）かSS（納期30日）か、意思表示が必要です。
- [1756164400.257629] <@U0331FWGQRM>: <@U03BLQ65GK0> 
懸念点は解消されましたでしょうか？
このss機で購入進めて大丈夫ですか？？
私はいいと思っております。
- [1756164878.280209] <@U03BLQ65GK0>: <@U0331FWGQRM>
すみません、足立さんとは会話して解決していて共有してませんでした。
問題ありません。
<@U05KGS6HN9H>
よろしくお願いします。
- [1756168137.326219] <@U03BLQ65GK0>: *外注_作業所について*
先日<@U08L89G6JSG>に共有した、
三葉園さんなどに茶詰めを依頼してはどうか という件について、
今年私が出雲精茶の一茶の被覆作業を依頼した際にこういう流れでやりました　というのをこちらにも共有しておきます。

【依頼の流れ】
特定非営利活動法人　島根県障がい者就労事業振興センター
tel　<tel:0852672671|0852-67-2671>／fax　<tel:0852672672|0852-67-2672>
こちらが県内の障害者就労支援施設の取りまとめ（？）をしていて、
こちらに相談し、詳しい業務内容や注意事項などを伝えます（打ち合わせをします）。
↓
何度か打ち合わせをし、添付資料のような依頼の詳細を記載したものを作成してもらい、
これを全事業所に向けてメールで流してもらいます。
その後必要であれば説明会を行います。（その案内文も参考として送ります。※これも先方作成＋先方案内です）
↓
作業を希望する事業所に対して、作業の詳細な説明を実践を交えて行い、
・いつから受けてもらえるか
・原料や資材の受け渡しや納品方法
・依頼してからの納期の目処
・小分け用の器具類（スプーンや計量器、手袋　等）の手配どうするか
など細かな部分を決めていき、スタートしていきます。

単価については公平を期すために一袋◯◯円ということは事前に通知して、
全事業所に対して同じ単価でお願いをします。

以上が以来までの流れです。

これのメリットは一斉案内による周知の広さですが、
少々時間がかかるというデメリットもあります。
（1ヶ月はかかると見ておいたほうが良いと思います）
なので、個別でこちらでも依頼を進める＋一斉依頼をする　が良いと思います。
事業所リストも以前いただいていたものを共有します。
※一昨年ぐらいのものなので、増えたり減ったりしている可能性があります

以上です。
<@U08L89G6JSG> <@U0840UVFVA8> <@U033G4KN4TD>
こちら進めるかどうかは決めの問題ですが、懸念点何かありますか？
無ければもう進めたほうが良いと思います（後回しにするデメリットが大きい為最優先で）
※進める場合スケジュール感の共有をお願いします。
何か不明点あれば相談して下さい。
よろしくお願いします！
  - files: [{"id": "F09C3FA6EKE", "created": 1756167383, "timestamp": 1756167383, "name": "250127 出雲精茶作業依頼仕様書.xlsx", "title": "250127 出雲精茶作業依頼仕様書.xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 1407344, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09C3FA6EKE/250127__________________________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09C3FA6EKE/download/250127__________________________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09C3FA6EKE-9a17b507ac/250127___________________________________converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09C3FA6EKE-9a17b507ac/250127___________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09C3FA6EKE/250127__________________________________.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F09C3FA6EKE-11087849cc", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09C1L1DKU6", "created": 1756167390, "timestamp": 1756167390, "name": "事業所リスト.xlsx", "title": "事業所リスト.xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 30142, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09C1L1DKU6/__________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09C1L1DKU6/download/__________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09C1L1DKU6-b1a675144b/___________________converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09C1L1DKU6-b1a675144b/___________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09C1L1DKU6/__________________.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F09C1L1DKU6-4e172cf0a5", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09CDLHQB41", "created": 1756167394, "timestamp": 1756167394, "name": "250318出雲精茶現地説明会 案内.docx", "title": "250318出雲精茶現地説明会 案内.docx", "mimetype": "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "filetype": "docx", "pretty_type": "Word Document", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 1230556, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09CDLHQB41/250318__________________________________.docx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09CDLHQB41/download/250318__________________________________.docx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09CDLHQB41-11ae11a10c/250318___________________________________converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09CDLHQB41-11ae11a10c/250318___________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09CDLHQB41/250318__________________________________.docx", "permalink_public": "https://slack-files.com/T033D70RR6H-F09CDLHQB41-fd37385101", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-08-26

- [1756198159.162439] <@U05KGS6HN9H>: <@U03BLQ65GK0>
<@U0331FWGQRM> <@U0331FZS7JT> <@U0840UVFVA8> <@U033G4KN4TD> <@U08L89G6JSG>
機械は「各台とも送風ファンと取出網付き」を追記した添付の
送金PIをChamaより取得し、主任に送金を依頼しております。
手配を進めます。
  - files: [{"id": "F09CFGGQ6BT", "created": 1756198138, "timestamp": 1756198138, "name": "2025-8-20-ball mill machine PI - SS - 2.pdf", "title": "2025-8-20-ball mill machine PI - SS - 2.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 321794, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09CFGGQ6BT/2025-8-20-ball_mill_machine_pi_-_ss_-_2.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09CFGGQ6BT/download/2025-8-20-ball_mill_machine_pi_-_ss_-_2.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09CFGGQ6BT-300d2c5483/2025-8-20-ball_mill_machine_pi_-_ss_-_2_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09CFGGQ6BT/2025-8-20-ball_mill_machine_pi_-_ss_-_2.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09CFGGQ6BT-2fb1e6fd83", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09C02E9RFX", "created": 1756198148, "timestamp": 1756198148, "name": "2025-8-20-mill ball  PI(1).pdf", "title": "2025-8-20-mill ball  PI(1).pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 325850, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09C02E9RFX/2025-8-20-mill_ball__pi_1_.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09C02E9RFX/download/2025-8-20-mill_ball__pi_1_.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09C02E9RFX-0cfad2d2d9/2025-8-20-mill_ball__pi_1__thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09C02E9RFX/2025-8-20-mill_ball__pi_1_.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09C02E9RFX-2af1f15d0c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-09-01

- [1756720800.511159] <@U05KGS6HN9H>: <@U0331FWGQRM>
<@U03BLQ65GK0> <@U0331FZS7JT> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
2連ステック機械（中国/柯田包装/Coretamp:※3月展示会で見つけたメーカー）
ザックリとした納期を伺いましたが、通常受注～完成までで稼働日30～35日
との回答です。（機械筐体の在庫あり。スクリューやステック形状型等を別注で作成）
EXW条件ですので、完成後に当社手配便で引取り出荷となる見込みです。
  - files: [{"id": "F09D9PSKTKK", "created": 1756692915, "timestamp": 1756692915, "name": "LC-240B-P50-02N. Coretamp. 250311..pdf", "title": "LC-240B-P50-02N. Coretamp. 250311..pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 871036, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09D9PSKTKK/lc-240b-p50-02n._coretamp._250311..pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09D9PSKTKK/download/lc-240b-p50-02n._coretamp._250311..pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09D9PSKTKK-f5b2488072/lc-240b-p50-02n._coretamp._250311._thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09D9PSKTKK/lc-240b-p50-02n._coretamp._250311..pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09D9PSKTKK-88d8b279a8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1756788858.865609] <@U09DF1SDTQR>: <@U09DF1SDTQR>さんがチャンネルに参加しました

## 2025-09-11

- [1757646179.595699] <@U03BLQ65GK0>: <!channel>
*黄色倉庫 ボールミル導入に伴う電気工事進捗共有*
• 電源を引っ張ってくる電線工事を現在手配中。
• 工事は中国電力対応（公共事業的な立ち位置のためスピードは遅め）。
•  →「早く進めてほしい」と依頼は継続中。
• 中電の工事実施は *10月中予定*。
•  → その後にコンセント設置などを大成電気が行い、電気工事全体の完了は *10月末頃の見通し*。


## 2025-09-29

- [1759129479.951879] <@U03BLQ65GK0>: <@U08L89G6JSG> <@U0840UVFVA8> <@U033G4KN4TD>
江角木芸後の作業場について進捗状況を共有します。
・契約は9/26に完了
・電気の契約は9/29に完了（100Vのみ。200V使用が必要となれば改めて申し込み）
・休憩室の方は11/1より利用開始可能（このタイミングで、休憩室の電気と全体の上下水道の契約を申し込む必要有り）
※10月も上下水道使用できるが、大家の江角さんが支払っておられるので、大量に水を使用するというのはなるべく避けて下さい（そんなことあんまりないと思いますが）
・休憩室に付いているエアコンはそのまま使用して良い

以上です。
以下は使用を開始した際の注意事項です。

・最初にクリーニング業者、電気工事の業者などが入る際にはやくも不動産へ一報を入れる（現状の確認で業者が入る前に撮影するためです）
・ブロワなどで建物の外に向かって抹茶などを吹き出さない（ご近所の洗濯物を汚すなどのトラブル回避のため）
・ゴミは持ち帰って桃翠園で処分

この他共有事項あればスレッドへの返信で共有をお願いします。
- [1759130331.989759] <@U03BLQ65GK0>: ToDo
・休憩室の電気と上下水道契約（11/1から利用開始できるように）
・コンセント増設
・照明変更（LED)
・エアコン設置（各部屋1台で合計2台）
・南側ガラスにすりガラス調フィルム貼り付け
・出入り口の扉と鍵変更（古いため開きにくい）
・外に器具洗浄用の水洗い場の設置
・清掃用具、ゴミ箱 準備
・下駄箱準備
・ロッカー準備
・手洗い場自動水栓設置と石鹸、ペーパータオルの準備
・入室用のコロコロ準備
・作業台などの作業用の各備品の準備
- [1759134920.769419] <@U08L89G6JSG>: <@U03BLQ65GK0>
エアコンの見積もりきました
ご確認お願いします！
  - files: [{"id": "F09HLJTQAKG", "created": 1759134913, "timestamp": 1759134913, "name": "新拠点 エアコン見積もり.pdf", "title": "新拠点 エアコン見積もり.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U08L89G6JSG", "user_team": "T033D70RR6H", "editable": false, "size": 3183921, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09HLJTQAKG/__________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09HLJTQAKG/download/__________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09HLJTQAKG-766861aade/___________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09HLJTQAKG/__________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09HLJTQAKG-f70c1c5ca6", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1759135783.637779] <@U03BLQ65GK0>: <@U08L89G6JSG>
ありがとうございます！
ちょっと高すぎますね。。
中古の調査と、家庭用ではどうなのかとか検討をお願いします。
【中古エアコン販売サイト】
<https://aircon-hanbai.jp/>
<https://aircon-mart.com/?utm_source=chatgpt.com>
<https://r-mugendou.com/kanto/heroskin.cgi?table=eacon&utm_source=chatgpt.com>

中古ではないが、安いサイト
<https://www.tenpos.com/c/aircon-all/floor-standing>
  - attachments: [{"from_url": "https://aircon-mart.com/?utm_source=chatgpt.com", "ts": 1705973551, "service_icon": "https://aircon-mart.com/cms/wp-content/uploads/2024/12/icon-240x240.png", "id": 1, "original_url": "https://aircon-mart.com/?utm_source=chatgpt.com", "fallback": "新品/中古 業務用エアコン取り付け工事・販売はエアコンマート - 中古エアコン販売・取り付け工事のご相談はエアコンマートへ！業務用エアコンの取付工事も承っております！: 新品/中古 業務用エアコン取り付け工事・販売はエアコンマート", "text": "新品・中古エアコン販売・取り付け工事を承ります。東京都・神奈川県・埼玉県・千葉県・大阪府・京都府・兵庫県・奈良県などが家庭用・業務用エアコン取り付け工事が可能なエリアです。工事費用のお見積もりは無料です。", "title": "新品/中古 業務用エアコン取り付け工事・販売はエアコンマート", "title_link": "https://aircon-mart.com/?utm_source=chatgpt.com", "service_name": "新品/中古 業務用エアコン取り付け工事・販売はエアコンマート - 中古エアコン販売・取り付け工事のご相談はエアコンマートへ！業務用エアコンの取付工事も承っております！"}, {"from_url": "https://www.tenpos.com/c/aircon-all/floor-standing", "image_url": "https://tools.itembox.design/item/common/img01/ogp.png?t=20250926184226", "image_width": 1200, "image_height": 630, "image_bytes": 5711, "service_icon": "https://www.tenpos.com/favicon.ico", "id": 2, "original_url": "https://www.tenpos.com/c/aircon-all/floor-standing", "fallback": "テンポスドットコム: 床置形のエアコンなら | テンポスドットコム通販サイト", "text": "床置形のエアコンならテンポスドットコム通販サイト", "title": "床置形のエアコンなら | テンポスドットコム通販サイト", "title_link": "https://www.tenpos.com/c/aircon-all/floor-standing", "service_name": "テンポスドットコム"}]
- [1759190335.600769] <@U03BLQ65GK0>: <@U08L89G6JSG>
台車やオリコンなどの中古品のサイトもありますので共有します。
<https://matebank.jp/>
  - attachments: [{"from_url": "https://matebank.jp/", "service_icon": "https://cxq6cqqh.user.webaccel.jp/html/user_data/assets/img/common/apple-touch-icon.webp", "id": 1, "original_url": "https://matebank.jp/", "fallback": "物流機器リユース（中古）＆レンタルのマテバンク", "text": "マテバンクは、日本最大級のマテハン（物流機器）の中古買取・販売とレンタルのサービスです。マテハンにかかるコスト削減に貢献します。", "title": "物流機器リユース（中古）＆レンタルのマテバンク", "title_link": "https://matebank.jp/", "service_name": "matebank.jp"}]

## 2025-09-30

- [1759300828.253009] <@U08L89G6JSG>: <@U03BLQ65GK0> <@U0840UVFVA8> <@U033G4KN4TD>
清掃の見積もりが届きました。
ご確認お願いいたします。
フロアはワックスなし
厨房クリーニングは換気扇のクリーニングです。
キッチンは無料で対応してくださるとのことです。
よろしくお願いいたします。
<https://acrobat.adobe.com/id/urn:aaid:sc:AP:209686c6-95a5-4f08-b20a-d1956561e223>
  - attachments: [{"image_url": "https://cdn-sharing.adobecc.com/rendition/id/urn:aaid:sc:AP:209686c6-95a5-4f08-b20a-d1956561e223;page=0;size=500;type=image%2Fjpeg?access_token=1759343950_urn%3Aaaid%3Asc%3AAP%3A209686c6-95a5-4f08-b20a-d1956561e223%3Bpublic_45a766d97ac015e06f04c9784ea7fc690cb19746&api_key=dc_sendtrack", "image_width": 353, "image_height": 500, "image_bytes": 42399, "from_url": "https://acrobat.adobe.com/id/urn:aaid:sc:AP:209686c6-95a5-4f08-b20a-d1956561e223", "service_icon": "https://acrobat.adobe.com/favicon.ico", "id": 1, "original_url": "https://acrobat.adobe.com/id/urn:aaid:sc:AP:209686c6-95a5-4f08-b20a-d1956561e223", "fallback": "Adobe Acrobat: 見積書・注文書.pdf", "text": "View this file, and add comments too.", "title": "見積書・注文書.pdf", "title_link": "https://acrobat.adobe.com/id/urn:aaid:sc:AP:209686c6-95a5-4f08-b20a-d1956561e223", "service_name": "Adobe Acrobat"}]

## 2025-10-01

- [1759302389.788169] <@U03BLQ65GK0>: <@U08L89G6JSG>
ありがとうございます。
せっかく見積もりとってもらったのに申し訳有りませんが、清掃業者の件は見送りたいと思います。
理由は端的に言えば自分たちでできるレベルの清掃だと思うためです。（専門業者が入らないと使用できないほど汚染状況のひどくはない+高所作業などの専門的な清掃が必要でもないため）
具体的に言うと、
床：掃き掃除とモップがけ
キッチン＆トイレ：常識的な範囲で清掃
これで十分であると思います。
また、大家さんからも、ある程度は清掃してから明け渡していただけると言われてますので、業者入れるほどでもないかと思います。
よろしくお願いします。

## 2025-10-05

- [1759713177.727779] <@U03BLQ65GK0>: <@U08L89G6JSG> <@U0840UVFVA8> <@U033G4KN4TD>
プレスオールターナティブの学生工作隊様より以下注文が来ていますので製造をお願いします。
煎茶パウダー　1kg
内容：プレス様より預かっている2024年産楠煎茶を1kg粉砕加工をお願いします。

以上です。
また、本日メール追加でほうじ茶のパッキング依頼と、そのまま煎茶とほうじ茶各1kgの出荷依頼も来ていますので確認と対応をお願いします。

それぞれ出荷日決まりましたら連絡下さい。
よろしくお願いします。

## 2025-10-08

- [1759908893.672359] <@U033G4KN4TD>: <@U03BLQ65GK0>
10月21日出荷で進めていきます。
よろしくお願いいたします。

## 2025-10-15

- [1760514445.881179] <@U03BLQ65GK0>: <@U08L89G6JSG> <@U0840UVFVA8> <@U033G4KN4TD>
江角木芸さんの件について、現状の整理と今後の進め方を共有します。

■ 現状
• 電気の契約は10/1開始分を9月末に完了済みで、*現在「桃翠園」として使用できる状態*になっています。
• *自治会・隣接住民への挨拶等、外部対応はすべて完了*しています。
• さらに、本日 *11月からの休憩室側の電気および全体の水道契約*も完了しました。
■ 今後の進め方
内部の運用面については、*基本的に皆さん主体で進めていただく*認識です。
 進行の判断軸は以下の通りです。
1. 「こういうことをしたい」→ どう進めたら良いか分からない → *私に相談*
2. 「こういうことをしたい」→ 見積取得 → *私に決裁確認を取る*
なお、「やるべきこと」については、先日共有した *ToDoリスト*を参考にしてください。

■ 稼働について
11/1から家賃が発生しますので、*同日からの稼働開始は必須*です。
 衛生区としての完全な運用でなくても、*できる範囲から着手*しましょう。

ご対応よろしくお願いします。

