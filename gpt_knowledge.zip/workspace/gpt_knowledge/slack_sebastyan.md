# Slack channel: sebastyan

## 2024-05-25

- [1716680932.634339] <@U0331FWGQRM>: <@U0331FWGQRM>さんがチャンネルに参加しました
- [1716680949.046799] <@U0331FZS7JT>: <@U0331FZS7JT>さんがチャンネルに参加しました
- [1716680949.107199] <@U0331FZTHEK>: <@U0331FZTHEK>さんがチャンネルに参加しました
- [1716680949.164869] <@U033G4KN4TD>: <@U033G4KN4TD>さんがチャンネルに参加しました
- [1716680949.224389] <@U03BLQ65GK0>: <@U03BLQ65GK0>さんがチャンネルに参加しました
- [1716680949.297639] <@U041RJKV5JA>: <@U041RJKV5JA>さんがチャンネルに参加しました
- [1716680949.365459] <@U05KGS6HN9H>: <@U05KGS6HN9H>さんがチャンネルに参加しました
- [1716680949.427679] <@U0606SPN4BW>: <@U0606SPN4BW>さんがチャンネルに参加しました
- [1716680949.502419] <@U066P20UQH1>: <@U066P20UQH1>さんがチャンネルに参加しました
- [1716681062.991939] <@U0331FWGQRM>: *Lemon ginger matcha*
- [1716681100.852239] <@U0331FWGQRM>: フィードバック

Have you ever used citric acid in your powders? Our current manufacturer uses citric acid and combination with lemon powder for a more sour/acidic flavor. I think the lemon ginger Matcha needs some citric acid. And I think Ginger needs to increase to a minimum of 20%.
- [1716681179.116809] <@U0331FWGQRM>: *Raspberry coconuts matcha*
- [1716681200.571619] <@U0331FWGQRM>: フィードバック

Raspberry Coconut Matcha: 
just like the samples that you received, there needs to be at least double the amount of flavor and it should be equal %, raspberry and coconut. And it should be artificial raspberry, this hopefully will improve the color. The good news is 1% Stevia is a perfect amount of sweetness.
- [1716681222.493199] <@U0331FWGQRM>: *Mango matcha*
- [1716681232.726819] <@U0331FWGQRM>: フィードバック

Mango: I barely tasted any flavor, and it was almost like a hint of peach. Very different to our mango matcha. Needs a lot more flavor. 

If you would like to test on your own, I am using 50 ML water and 150 ML milk.
- [1716681256.401009] <@U0331FWGQRM>: *Vanilla matcha*
- [1716681268.860119] <@U0331FWGQRM>: Vanilla: 
I think this needs a lot more flavor and maybe we increase to 1.5% stevia.
- [1716682124.554169] <@U0331FWGQRM>: Other flavors I would like you to source (will provide details on % but these will be lemon based, with citric acid)
• Pineapple Lemon Matcha
• Peach Lemon Matcha
• Strawberry Mint Lemon Matcha
• Watermelon Mint Lemon Matcha
• Passionfruit Lemon Matcha
• Ginger lemon matcha（追加）
- [1716700971.248329] <@U0331FZS7JT>: Sachetサイズメモ
W：35mm
H：123mm
パウダー入ってるとこ(シール部分以外)
H：102mm
開けた際の注ぎ口(パウダー排出口)
W：14mm
H：7mm
  - files: [{"id": "F07557JNMEW", "created": 1716700423, "timestamp": 1716700423, "name": "IMG_2120.jpg", "title": "IMG_2120", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 738004, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07557JNMEW/img_2120.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07557JNMEW/download/img_2120.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07557JNMEW-37218726d5/img_2120_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07557JNMEW-37218726d5/img_2120_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07557JNMEW-37218726d5/img_2120_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07557JNMEW-37218726d5/img_2120_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07557JNMEW-37218726d5/img_2120_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07557JNMEW-37218726d5/img_2120_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07557JNMEW-37218726d5/img_2120_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07557JNMEW-37218726d5/img_2120_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07557JNMEW-37218726d5/img_2120_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACRpHOakVNyg1S3N6mtC1bFuv41lUdkUhjLtIpGYKM028dhIuOOKrFiepq4PQTJDIM880nmL6VHijFUIi3Vo2xJtk9eTWZ3rUtV/0eI+1ZVdiokF4T5q54+WoM1PfczD/dFVsVUPhQnuPzRmm4NGDViGogckFgv1q9FMiRqm8cDFVrN0R2Ltt4q358P/AD0/WpcU9x3sQTgTSBhIg4xyaYIf+msf51cE8P8Az0H5iniWL++v6U0rKwFLyv8AppH/AN9UeV/00j/76q95kX95f0pfMi/vL+lAj//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07557JNMEW/img_2120.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07557JNMEW-4921aae15c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F075U1F5CGG", "created": 1716700423, "timestamp": 1716700423, "name": "IMG_2121.jpg", "title": "IMG_2121", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 791212, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F075U1F5CGG/img_2121.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F075U1F5CGG/download/img_2121.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F075U1F5CGG-8ed043e61a/img_2121_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F075U1F5CGG-8ed043e61a/img_2121_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F075U1F5CGG-8ed043e61a/img_2121_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F075U1F5CGG-8ed043e61a/img_2121_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F075U1F5CGG-8ed043e61a/img_2121_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F075U1F5CGG-8ed043e61a/img_2121_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F075U1F5CGG-8ed043e61a/img_2121_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F075U1F5CGG-8ed043e61a/img_2121_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F075U1F5CGG-8ed043e61a/img_2121_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACRmMGpI/vr9RVaF2aVATwTWhsC88VDlZ2Ha48f8ev8AwE1UZtozVjdizJ/2DWazlutWIkLjPNJvWocUYoAWNsSp/vCtNiOc9qyo+Zk/3hWqRhGzWFTdFIYDmzP+4az6vL/x5n/dNZ/NbEj6KZzS5NADUYLIrHoDmrovUc7cNk8dKz6KTinuO5pr/wAeh/3TVAU3e2Mbmx9aVG55qhEgXil209cEUuBSA//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F075U1F5CGG/img_2121.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F075U1F5CGG-9800df02e0", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0752ALQBGV", "created": 1716700942, "timestamp": 1716700942, "name": "IMG_2122.jpg", "title": "IMG_2122", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 798545, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0752ALQBGV/img_2122.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0752ALQBGV/download/img_2122.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0752ALQBGV-82b9bc0fde/img_2122_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0752ALQBGV-82b9bc0fde/img_2122_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0752ALQBGV-82b9bc0fde/img_2122_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0752ALQBGV-82b9bc0fde/img_2122_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0752ALQBGV-82b9bc0fde/img_2122_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0752ALQBGV-82b9bc0fde/img_2122_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0752ALQBGV-82b9bc0fde/img_2122_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0752ALQBGV-82b9bc0fde/img_2122_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0752ALQBGV-82b9bc0fde/img_2122_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACSmHYd6kWYg8ioc1JDG0xIUgYqXpqxllJlPXiplIboRVR7d40LEjAqMMR0NCaewM0DIoOCaPNT1rP3H1o3H1qhFfNaNkD9nBDYyT/Bms2r1g7MCmcBRxSk0ldjRcKlhhmUj0Kf/AF6Z9nT+7F+RFMnmeKPcDk5xyKgF9L6LSi01oDLP2df7kf8A301H2df7kf8A301Qfbpf7q/rR9ul/ur+tUIo9quWAOJD9BVPFWrSdIUbdnJPYVE9tBrcs33+pUHu39KoBSDU13cLKqhc8HPIqBXPelTVoje5MIyRS+UaYsmBS+afWrEf/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0752ALQBGV/img_2122.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0752ALQBGV-0cd5a67b58", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-05-27

- [1716805082.774369] <@U0331FWGQRM>: For these lemon flavors, I would like to recommend: 15% (0.3g) citric acid per 2g. But we might need to increase serving size to 4g to accommodate 1g lemon powder. Let me get back to you.

## 2024-06-03

- [1717420900.334149] <@U0331FZS7JT>: 【翻訳メモ】
クエン酸をパウダーに使用したことはありますか？
現在のメーカーは、より酸味のある味を出すために、クエン酸とレモンパウダーを組み合わせて使用しています。
レモンジンジャー抹茶にはクエン酸が必要だと思います。
そして、ジンジャーの含有量を最低20％に増やす必要があると思います。
→クエン酸確認：キタマ
- [1717421239.307229] <@U0331FZS7JT>: サンプルと同様に、風味の量を少なくとも2倍にし、ラズベリーとココナッツを同じ割合にする必要があります。
色を改善するために人工ラズベリーを使用する必要があります。
良い知らせは、ステビア1％がちょうど良い甘さを提供することです。
- [1717421378.518159] <@U0331FZS7JT>: 【翻訳メモ】
マンゴー：ほとんど風味を感じず、ほのかにピーチのような味がしました。これは私たちのマンゴー抹茶とは大きく異なります。風味をもっと強くする必要があります。ご自身でテストされる場合は、水50 mlとミルク150 mlを使用しています。
Lキタマに新しいサンプル発注
- [1717421446.505419] <@U0331FZS7JT>: 【翻訳メモ】
バニラ：
もっと風味を強くする必要があると思います。また、ステビアを1.5％に増やすと良いかもしれません。
- [1717421533.971239] <@U0331FZS7JT>: 【翻訳メモ】
これらのレモンフレーバーについては、2gあたり15%（0.3g）のクエン酸を推奨します。ただし、1gのレモンパウダーを追加するために、サービングサイズを4gに増やす必要があるかもしれません。後ほど改めてお知らせします。

## 2024-06-04

- [1717547836.871339] <@U0331FWGQRM>: *Dextrin*
- [1717547848.124689] <@U0331FWGQRM>: <@U0331FZS7JT>
Were you able to do some research regarding dextrin?
デキストリンの調査はどうですか？
- [1717551146.306949] <@U0331FZS7JT>: <@U0331FWGQRM>
今、デキストリンをいくつか取り寄せているので準備が出来次第サンプル製造に取り掛かります。

（進捗詳細）
サンプルがキタマと明石屋から届きます。
届き次第（おそらく今週中）、セバスチャンからもらったサンプルと比較して最終的に風味が近い方を選択します！
- [1717555887.899349] <@U0331FWGQRM>: *2g per sachet*
- [1717555929.938669] <@U0331FWGQRM>: <@U0331FZS7JT>
原料：Non organic Matcha Upper grade - 2　（B2）
  - files: [{"id": "F076E8YDGMC", "created": 1717555906, "timestamp": 1717555906, "name": "WhatsApp Image 2024-06-05 at 09.59.24.jpeg", "title": "WhatsApp Image 2024-06-05 at 09.59.24.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 120606, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F076E8YDGMC/whatsapp_image_2024-06-05_at_09.59.24.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F076E8YDGMC/download/whatsapp_image_2024-06-05_at_09.59.24.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F076E8YDGMC-79215088a5/whatsapp_image_2024-06-05_at_09.59.24_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F076E8YDGMC-79215088a5/whatsapp_image_2024-06-05_at_09.59.24_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F076E8YDGMC-79215088a5/whatsapp_image_2024-06-05_at_09.59.24_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F076E8YDGMC-79215088a5/whatsapp_image_2024-06-05_at_09.59.24_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F076E8YDGMC-79215088a5/whatsapp_image_2024-06-05_at_09.59.24_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F076E8YDGMC-79215088a5/whatsapp_image_2024-06-05_at_09.59.24_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F076E8YDGMC-79215088a5/whatsapp_image_2024-06-05_at_09.59.24_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 800, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F076E8YDGMC-79215088a5/whatsapp_image_2024-06-05_at_09.59.24_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F076E8YDGMC-79215088a5/whatsapp_image_2024-06-05_at_09.59.24_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 1024, "original_w": 1440, "original_h": 1440, "thumb_tiny": "AwAwADDToopHYIpY9BQAM23sT9KaJAWA5BPrUKzeYxOMbRSecFmTdwDkUrq1wLVFFFMAqrenCqAevarVVr1CYwwGdvWplsBBbn5ZP93NMnP+rPsf6U63ztl/3cUyflY8+/8ASkvhAuWchePB/hqxVezj2RZI5bmrFUtgCjrRRTAqvGsAYr/F2psaJM6bhnGeKsSxeZj29abHBscNkUWAmAwMCiiigD//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F076E8YDGMC/whatsapp_image_2024-06-05_at_09.59.24.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F076E8YDGMC-add4a0e5de", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1717556740.480919] <@U0331FWGQRM>: <@U0331FZS7JT> <@U041RJKV5JA> <@U033G4KN4TD> <@U05KGS6HN9H>
上記5000pcs注文（予定）
・静パック製造可否確認
・出荷予定日
・印字可否確認
表面印字：PURER BIO MATCHA
裏面印字：ロット番号と賞味期限の印字可否確認
　　　　　裏面は不可ならなくてもOK
- [1717556969.836159] <@U0331FWGQRM>: 
  - files: [{"id": "F076PDPADEY", "created": 1717556967, "timestamp": 1717556967, "name": "お見積書NO.202201274.pdf", "title": "お見積書NO.202201274.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 91558, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F076PDPADEY/____________no.202201274.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F076PDPADEY/download/____________no.202201274.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F076PDPADEY-29d9173854/____________no.202201274_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F076PDPADEY/____________no.202201274.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F076PDPADEY-2f8aec5e92", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1717557029.974729] <@U0331FWGQRM>: 見積もり取り直し必要かもですが、宜しくお願いします。
- [1717565618.840319] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
静パック宛に抹茶（出雲抹茶R）を20gサンプル送付をお願いします。

## 2024-06-06

- [1717724421.015479] <@U0331FWGQRM>: Lot / Exp date
- [1717724466.199349] <@U0331FWGQRM>: <@U041RJKV5JA>
31x10mm　のスペースに印字可能ですか？
（Neelsの時は30x15で要望出しました。）
  - files: [{"id": "F076TMYANUE", "created": 1717724432, "timestamp": 1717724432, "name": "PHOTO-2024-06-07-10-12-19.jpg", "title": "PHOTO-2024-06-07-10-12-19.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 55540, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F076TMYANUE/photo-2024-06-07-10-12-19.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F076TMYANUE/download/photo-2024-06-07-10-12-19.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F076TMYANUE-62f0675d72/photo-2024-06-07-10-12-19_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F076TMYANUE-62f0675d72/photo-2024-06-07-10-12-19_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F076TMYANUE-62f0675d72/photo-2024-06-07-10-12-19_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 204, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F076TMYANUE-62f0675d72/photo-2024-06-07-10-12-19_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 272, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F076TMYANUE-62f0675d72/photo-2024-06-07-10-12-19_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F076TMYANUE-62f0675d72/photo-2024-06-07-10-12-19_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 408, "original_w": 780, "original_h": 442, "thumb_tiny": "AwAbADB9R/8AfX50+rP2SPGeaySuaN2Kf5/nSHr/ABfnVv7NH6P+VAtY2OMMPqKrlYuZFTr6/nR+DVPcRLCRt79c1BuUjIPFSUiSp/tXGNn61XooTsDVyYzqRjy//HqUXIXpH/49Vekp8zFyokuJROACuBjHWodg9yfU06kpXKsf/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F076TMYANUE/photo-2024-06-07-10-12-19.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F076TMYANUE-fc90db0533", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1717725469.568749] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
色々とテストして、OKとなった場合、
お客様にはテストした汚い袋の写真を見せるのではなく、

綺麗な袋に印字されたものを見せたいので、
枠を書いてそこに印字している写真をください:sweat_drops:

宜しくお願いします！
- [1717735886.572969] <@U033G4KN4TD>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
清和No.10418（140×220）にテスト印字してみました。
31×10㎜の間に印字可能です。
画像の赤枠部分(資材下から25～55㎜）は、機械の構造上印字が出来ない為、
赤枠以外の所へ印字が出来ると現場はやり易いと感じました。
  - files: [{"id": "F076U7ER76J", "created": 1717735510, "timestamp": 1717735510, "name": "印字テスト1.pdf", "title": "印字テスト1.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 140664, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F076U7ER76J/_______________1.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F076U7ER76J/download/_______________1.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F076U7ER76J-3252f89727/_______________1_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F076U7ER76J/_______________1.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F076U7ER76J-417efa2b6e", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1717738095.521559] <@U0331FWGQRM>: <@U033G4KN4TD> 
細かいテストありがとうございます。
可能と伝えます。
赤枠の無い、袋に1箇所だけ印字した画質のいい写真を貰えますか？？
- [1717738142.168289] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U03BLQ65GK0>
お客様にこの部分は可能で、
この部分は出来ない、のような事は、
伝えられないので、
全ての場所に印字可能に出来るようにお願いします。

不可な理由は固定金具の構造上の問題ですか？
金具を変えればできそうですか？

- [1717740746.450619] <@U033G4KN4TD>: <@U0331FWGQRM>
写真撮り直したのでご確認お願いします。
  - files: [{"id": "F0773GQQELC", "created": 1717739616, "timestamp": 1717739616, "name": "S__204480515_0.jpg", "title": "S__204480515_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 190106, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0773GQQELC/s__204480515_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0773GQQELC/download/s__204480515_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0773GQQELC-7ae0bdcbd8/s__204480515_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0773GQQELC-7ae0bdcbd8/s__204480515_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0773GQQELC-7ae0bdcbd8/s__204480515_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0773GQQELC-7ae0bdcbd8/s__204480515_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0773GQQELC-7ae0bdcbd8/s__204480515_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0773GQQELC-7ae0bdcbd8/s__204480515_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0773GQQELC-7ae0bdcbd8/s__204480515_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0773GQQELC-7ae0bdcbd8/s__204480515_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0773GQQELC-7ae0bdcbd8/s__204480515_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACShBGJZlQkgH0q0bFP7zVDZqftCH/PStFsAd8/WgCn9iT+835UGyUITvbgZ6VZGeuf1pW5jfr900AZFFSeW3pR5belAFmylHmKm0ZPerrN2wMVl2f8Ax9J/ntWkwoAUsNvCgHuaCwVGIOcDNMpJf9RJ/umgCH7af7q/lR9tP9xPyqhmjNAE9kM3Kfj/ACrTOOlZEchjcMuMj1qf7dL6J+VAF7FNm/495P8AdNUvtsvov5UPeSshU7cEY6UAVqKD1ooA/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0773GQQELC/s__204480515_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0773GQQELC-5b2e414c49", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F076LFNJL31", "created": 1717739630, "timestamp": 1717739630, "name": "S__204480517_0.jpg", "title": "S__204480517_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 188149, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F076LFNJL31/s__204480517_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F076LFNJL31/download/s__204480517_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F076LFNJL31-1865f7b382/s__204480517_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F076LFNJL31-1865f7b382/s__204480517_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F076LFNJL31-1865f7b382/s__204480517_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F076LFNJL31-1865f7b382/s__204480517_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F076LFNJL31-1865f7b382/s__204480517_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F076LFNJL31-1865f7b382/s__204480517_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F076LFNJL31-1865f7b382/s__204480517_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F076LFNJL31-1865f7b382/s__204480517_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F076LFNJL31-1865f7b382/s__204480517_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACSiK0IP+PdPpVJUzV+FSIUAx070AKaAR3pdpxk4A96TKe5+lAATzRR8vqfypPl9T+VAFeCRAuGXJq2u1og2MD0xmssNitCBj5CfSgCRyr4BUjFN2DPDUbiaXJoAPKz/ABCjyv8AaFLz60YPrQBk1Yiu1SNVKE4qu3Sm0AXfty/88z+dH20f3D+dUqegzxQBb+2/9Mz+dH23/pn+tVCMGjFAH//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F076LFNJL31/s__204480517_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F076LFNJL31-922eb816dc", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-06-07

- [1717749010.920829] <@U033G4KN4TD>: <@U0331FWGQRM> <@U03BLQ65GK0>
&gt; 不可な理由は固定金具の構造上の問題ですか？
&gt; 金具を変えればできそうですか？
すみません。いろいろ試してみた所、赤枠部分も印字可能でした。
ただ、後印字やロットの打ち直し(中身が入っている商品)になる場合、画像の部分が限界の位置になるため、
赤線部分より下へ印字出来るようカートリッジが動かせないか、
またカートリッジの高さ変更も可能か
センサーの事も含め、会長の方からキーエンスへ連絡して頂いてます。
よろしくお願いします。
  - files: [{"id": "F076YMS6FD3", "created": 1717747335, "timestamp": 1717747335, "name": "aa.pdf", "title": "aa.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 354169, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F076YMS6FD3/aa.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F076YMS6FD3/download/aa.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F076YMS6FD3-89004806e1/aa_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1286, "thumb_pdf_h": 909, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F076YMS6FD3/aa.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F076YMS6FD3-f8418a3786", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1717749123.393029] <@U0331FWGQRM>: <@U033G4KN4TD> <@U03BLQ65GK0> cc <@U0331FZS7JT> 
キーエンスに依頼する前に、
何を依頼するかmtgさせてください。

宜しくお願いします。

## 2024-06-08

- [1717832799.687349] <@U0331FWGQRM>: <@U033G4KN4TD> <@U03BLQ65GK0> 
この辺とか使えそうか聞く人願います。
※［センサーアーム］とかで検索しても出てきます。

<https://www.setubiprookoku.com/smartphone/list.html?category_code=sensorbracket_iwata_sensorstand|https://www.setubiprookoku.com/smartphone/list.html?category_code=sensorbracket_iwata_sensorstand>

## 2024-06-09

- [1717975913.090749] <@U033G4KN4TD>: <@U0331FWGQRM> <@U03BLQ65GK0>
&gt; 何を依頼するかmtgさせてください。
6/10(月)会長・福井→いつでも大丈夫です。
6/11(火)会長→来社対応アリ
よろしくお願いします。
- [1717977759.746439] <@U0331FWGQRM>: <@U033G4KN4TD> <@U03BLQ65GK0> 
今日の夕方どうでしょう？（16:00とか17:00とか）
- [1717979336.792119] <@U03BLQ65GK0>: <@U0331FWGQRM>
了解です、16時でお願いします。
- [1718002677.824079] <@U0331FZS7JT>: <@U0331FWGQRM> <@U03BLQ65GK0> <@U033G4KN4TD>

<https://us02web.zoom.us/j/86055753360?pwd=18GQC5y7Wg22ybAAYNGNVYVEPqAUAE.1>

お願いします！

## 2024-06-10

- [1718068197.121119] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> cc <@U0331FZS7JT>
本件進捗報告願います。

シルバーの印字可能ですか?

6月末に
60g 3000袋
2g 5000袋（スティック）
出荷okですか？

  - files: [{"id": "F07858CD6LQ", "created": 1718068184, "timestamp": 1718068184, "name": "IMG_4950.png", "title": "IMG_4950", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 1216795, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07858CD6LQ/img_4950.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07858CD6LQ/download/img_4950.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07858CD6LQ-b53edb90a5/img_4950_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07858CD6LQ-b53edb90a5/img_4950_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07858CD6LQ-b53edb90a5/img_4950_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07858CD6LQ-b53edb90a5/img_4950_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 221, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07858CD6LQ-b53edb90a5/img_4950_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07858CD6LQ-b53edb90a5/img_4950_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 332, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07858CD6LQ-b53edb90a5/img_4950_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1734, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07858CD6LQ-b53edb90a5/img_4950_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 443, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07858CD6LQ-b53edb90a5/img_4950_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 472, "thumb_1024_h": 1024, "original_w": 1290, "original_h": 2796, "thumb_tiny": "AwAwABbQJO7IxRuPtSZ+lAx6igBwIHrS7hTaKAEwPSl/AUUUAFFFFIAopceppMr/AHhTAKKMUYoA/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07858CD6LQ/img_4950.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07858CD6LQ-3e3e408d0f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1718079738.135739] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
60g 3000袋の可否をまず教えてください。

そして、
2g 5000スティックについては、
手で切れるタイプの袋かどうか確認願います。

その上で、パターンとしては、

手で切れる場合→最悪、Dipoで印字

手できれない場合→吉村で購入→無地or文字入りフィルム
- [1718081342.675239] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
追記）
60g 3000bag　はN2ガスなしでOKです。

その上で出荷可能日検討願います！
- [1718082031.063619] <@U033G4KN4TD>: <@U0331FWGQRM> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
&gt; 60g 3000袋
原料(出雲抹茶R)不足分　粉砕6/20～6/24 (出雲精茶→桃翠園)
商品完成予定6/27
6/28出荷可能です。
よろしくお願いします。
(清和255　4000枚本日6/11届きました）
- [1718086351.209659] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
健祥さんが無地のアルミスティックを持ってるようなので、確認してもらえますか?
（静パックはレスポンスが遅いらしいです:sweat_drops:）

5000本注文ですが、
10000本発注でもokです！
スピード重視でお願いします:sweat_drops:

価格も確認願います！
- [1718086512.610809] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
健祥
担当：姫野さん
<tel:080-9432-0995|080-9432-0995>

日高さんからの紹介と言えば大丈夫とのこと。
本日昼頃、日高さんから共有されました！
よろしくお願いします。
- [1718087215.247839] <@U041RJKV5JA>: <@U0331FZS7JT> <@U0331FWGQRM>
 <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
5,000本から発注できるとの事です。
見積をいただくことになりました。
明日にはいただけるよう依頼しておきます。
よろしくお願いいたします。

## 2024-06-11

- [1718089663.734829] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
加工賃ですがロット5000包で1包当り約8円+段ボール代（1箱に2,000包～2,500包）＋送料
明日（6/12）には見積書をお送りいただけるとの事です。
また、スティックは手で切れるタイプとなります。
充填テストが必要で、抹茶20ｇを送って欲しいとの事ですので、対象の抹茶（出雲抹茶R)を送ります。
よろしくお願いいたします。
- [1718089894.213379] <@U0331FWGQRM>: <@U041RJKV5JA> 
何度も連投すみませんが、
注文してから納品までのリードタイムも確認お願いします:sweat_drops:
- [1718092080.281489] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
リードタイム：2週間～3週間（纏まった注文が来ることがある為、幅を持たせてくださいとの事）
本日、充填テスト用サンプルを出荷します。
ご確認いただき充填可能となった場合、今週中に原料を納品できれば、
6月21日（金）には完成するとの事です。（たまたま製造スケジュールが空いているそうです）
よろしくお願いいたします。
- [1718120403.748809] <@U0331FWGQRM>: <@U041RJKV5JA> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
健祥さんに２点確認お願いします。
１、上に記載している（1箱に2,000包～2,500包）←このケースサイズをざっくり確認願います。
２、無地スティックのサンプル入手願います。（印字可否テスト用）

※出荷時のケースGross weightとケースサイズ数量を知りたいので、“１”を知りたいです。
スティックの重さは、桃翠園に在庫しているスティック50本＝OOgとかからざっくり算出できるかと思います。

## 2024-06-12

- [1718176134.096749] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
見積書が届きました。
フォルダに格納しておきます。
スティックサンプルは明日発送すると連絡がございました。
届き次第、印字可否の確認をいたします。
よろしくお願いいたします。
【加工賃】
・2g×5,000包以上　8円/包
・2g×10,000包以上　7.5円/包
【段ボールサイズ、重量】
・472×325×418㎜
・重量　1.1㎏
【段ボール代、送料】
・段ボール＋送料＝1,470円
【スティック重量】
・0.9g
  - files: [{"id": "F077Q9ZA7PV", "created": 1718176108, "timestamp": 1718176108, "name": "桃翠園様御見積書24.6.12.pdf", "title": "桃翠園様御見積書24.6.12.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 77467, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F077Q9ZA7PV/________________________24.6.12.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F077Q9ZA7PV/download/________________________24.6.12.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F077Q9ZA7PV-53e3345f43/________________________24.6.12_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F077Q9ZA7PV/________________________24.6.12.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F077Q9ZA7PV-912408630c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1718186397.162549] <@U05KGS6HN9H>: <@U0331FWGQRM>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
従来DHLで出荷しておりますが、005（60ｇ×3000）と006（スティック）
請求用INVOICEはFedex、Ship用はDHLとなっているようです。
ご確認をお願い致します。
- [1718186549.135159] <@U0331FWGQRM>: <@U05KGS6HN9H> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
005はokですが、（fedexが正解）

006は作成中です:sweat_drops:
ケースサイズ、グロスウェイトざっくりわかりますか?
- [1718192910.944939] <@U0331FZS7JT>: <@U0331FWGQRM> <@U041RJKV5JA>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>

静パックから返信きました。
見積書の中に事前の確認事項について記載がありますが（リードタイムは不明記）、健祥さんで進めて良いですね。
O：印字（但しスペース無し→PURERBIOMATCHA）
X：マジックカット（手で切れない）
↓
日高さんにPURER BIO MATCHAの印字とマジックカットのフィルム製造のリードタイムを確認をしたところ、
最短納期で1ヶ月後とのことです:sweat_drops:
Dipoでの印字については、袋サイズに合った台座を準備したら問題ないと思う！とのことでした。

ご確認、よろしくお願いします。
  - files: [{"id": "F077K53P1T8", "created": 1718192677, "timestamp": 1718192677, "name": "(株)桃翠園様　抹茶2ｇスティック充填お見積書NO202406043.pdf", "title": "(株)桃翠園様　抹茶2ｇスティック充填お見積書NO202406043.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 175620, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F077K53P1T8/__________________________2____________________________________no202406043.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F077K53P1T8/download/__________________________2____________________________________no202406043.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F077K53P1T8-3d368ec5f6/__________________________2____________________________________no202406043_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F077K53P1T8/__________________________2____________________________________no202406043.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F077K53P1T8-2622e87c81", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1718193394.504769] <@U0331FWGQRM>: <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
もし健祥さんがOKであればという仮定の上でですが、
明日か明後日？に健祥さんからスティックのサンプルが届くと思うので、
印字テストをお願いします。

万が一健祥さんがダメな場合は、
・情報図書館に依頼（MOQについては交渉）
・吉村から無地のフィルムを購入して静パックへ納品。
を検討する必要があると思います。
健祥さんで行けるといいのですが。
- [1718193893.662399] <@U0331FZS7JT>: <@U0331FWGQRM> <@U041RJKV5JA> 
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 

情報図書館の件、了解です！
サイズもですが、印字がちゃんと真ん中にできるか(ブレないか)等も含めて確認します！

次回受注を見越して、今回Dipoで上手く行った場合、それを吉村に送って事前にフィルム製造着手したほうが良さそうですね。

<@U041RJKV5JA> 
念の為というか、いざ発注となったら、そのミスを想定して少し多め(+500本程度)の発注をお願いします。
ちょっと多いかもしれませんが、念には念をということで。

- [1718242201.993249] <@U05KGS6HN9H>: <@U0331FWGQRM>
<@U041RJKV5JA> <@U033G4KN4TD>
006（スティック）のケースサイズ、グロスウェイトですが、
健祥様ケースサイズが当社No.6に近似しており、梱包数は
約2000本/箱の見込みとなります。
1本あたり約3ｇと仮定して、No.6ケース自重（1.26Kg）と
合わせG/Wは7.3Kgくらいではないかと思われます。
- [1718248987.308879] <@U041RJKV5JA>: <@U0331FWGQRM>
 <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
健祥より抹茶の充填可能との連絡がありました。
よろしくお願いいたします。
- [1718249196.931469] <@U0331FWGQRM>: <@U041RJKV5JA> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
あとは、袋の品質と、
印字ですね！！

スティックが明日届くと思いますが、
印字の準備お願いします！:raised_hands:

## 2024-06-13

- [1718279746.239679] <@U0331FWGQRM>: <@U05KGS6HN9H> <@U033G4KN4TD> <@U041RJKV5JA>
&gt; 006（スティック）のケースサイズ、グロスウェイトですが、
&gt; 健祥様ケースサイズが当社No.6に近似しており、梱包数は
&gt; 約2000本/箱の見込みとなります。
とりあえず、送料算出の為に、
GB用に2500入れるとして、x2箱で計算します。
当日、No.6に入ればそれでお願いします。
- [1718331626.285399] <@U033G4KN4TD>: <@U0331FWGQRM> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
Dipoにて印字テストを行いました。
ご確認お願いいたします。
  - files: [{"id": "F077WCAPD9U", "created": 1718331559, "timestamp": 1718331559, "name": "S__206143494_0.jpg", "title": "S__206143494_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 248901, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F077WCAPD9U/s__206143494_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F077WCAPD9U/download/s__206143494_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCAPD9U-06946421b0/s__206143494_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCAPD9U-06946421b0/s__206143494_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCAPD9U-06946421b0/s__206143494_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCAPD9U-06946421b0/s__206143494_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCAPD9U-06946421b0/s__206143494_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCAPD9U-06946421b0/s__206143494_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCAPD9U-06946421b0/s__206143494_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCAPD9U-06946421b0/s__206143494_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCAPD9U-06946421b0/s__206143494_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADB3kp/dX8qPIT+4v5VMzKgyxxTZGYp+6GSe/pQBEUgU4YJn0xUirbHA2pk+1VvIlzyhNKIJeuw1N2BZe3i7Rr+VV54EELkIoIHpVmEsEw4Oe1E67reQjuppgNuRkD6VEoCDJJyfRTVrmkYZGDVAVQSTx5h+gNOBYH7sh+op7Rvj5dp+tOiSQH5tg+gqdQGxynaSEb8qexIt2z/dNSYx0pk3+ok/3TTApG+l/up+VNN/L6J+VQGmGgCz9um/2fyppvp+zAfgKgpDQBP9tuD/AMtP0FIbmZgQ0jEHqKgpwoA//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F077WCAPD9U/s__206143494_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F077WCAPD9U-23827632fe", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07831G19DG", "created": 1718331564, "timestamp": 1718331564, "name": "S__206143496_0.jpg", "title": "S__206143496_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 303927, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07831G19DG/s__206143496_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07831G19DG/download/s__206143496_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07831G19DG-1dabb934cf/s__206143496_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07831G19DG-1dabb934cf/s__206143496_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07831G19DG-1dabb934cf/s__206143496_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07831G19DG-1dabb934cf/s__206143496_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07831G19DG-1dabb934cf/s__206143496_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07831G19DG-1dabb934cf/s__206143496_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07831G19DG-1dabb934cf/s__206143496_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07831G19DG-1dabb934cf/s__206143496_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07831G19DG-1dabb934cf/s__206143496_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1478, "original_h": 1108, "thumb_tiny": "AwAjADC3RTXlVDzTJmdkHlDI7kUxCtPGhwW59qQXMZHWq4yOsSn6rSkg9YkH0BqLsdi4CGGRyKYVU9VB/CoYiyyDg7T7HFWCQTgGmtQK9wMuQDzmkBSNeXGT65q1mmSxiVNpqhFfzV6+cPzpRKP+e2fxFRSWzp23Ad6RIHfgL+dRzMZZWZSeuf8AgQp4cbxtFNit1jHIDN64p4RQchQDVAPNFBopiFooFFABTTTqaaBn/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07831G19DG/s__206143496_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07831G19DG-9787e8c36c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F077NEEF5E3", "created": 1718331567, "timestamp": 1718331567, "name": "S__206143495_0.jpg", "title": "S__206143495_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 155729, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F077NEEF5E3/s__206143495_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F077NEEF5E3/download/s__206143495_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F077NEEF5E3-48e387ffbb/s__206143495_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F077NEEF5E3-48e387ffbb/s__206143495_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F077NEEF5E3-48e387ffbb/s__206143495_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F077NEEF5E3-48e387ffbb/s__206143495_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F077NEEF5E3-48e387ffbb/s__206143495_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F077NEEF5E3-48e387ffbb/s__206143495_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F077NEEF5E3-48e387ffbb/s__206143495_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F077NEEF5E3-48e387ffbb/s__206143495_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F077NEEF5E3-48e387ffbb/s__206143495_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADCQim7KdnNFMBmynBaXNLmkAAcUxlqSmmgAOPSmSDgFc1JSUwIQ8g6H8xml8xz1Y/lipaXFKwDUBCijJp3SkoAU0lLSUwClpKWgAPSmmnHpTTSA/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F077NEEF5E3/s__206143495_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F077NEEF5E3-4bc383f4ed", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F077WCB88TY", "created": 1718331570, "timestamp": 1718331570, "name": "S__206143497_0.jpg", "title": "S__206143497_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 181615, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F077WCB88TY/s__206143497_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F077WCB88TY/download/s__206143497_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCB88TY-577ea29cb5/s__206143497_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCB88TY-577ea29cb5/s__206143497_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCB88TY-577ea29cb5/s__206143497_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCB88TY-577ea29cb5/s__206143497_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCB88TY-577ea29cb5/s__206143497_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCB88TY-577ea29cb5/s__206143497_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCB88TY-577ea29cb5/s__206143497_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCB88TY-577ea29cb5/s__206143497_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F077WCB88TY-577ea29cb5/s__206143497_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADCTzSVweajdiRQvIoKkj7p/KkBIHIA4oWQg9KbztHB/KlAP90/lQA8Pk9Kc0uxCaaOOoI/CoJZAW56CmIgE5HarxuYlx+8XOOxrKzRmlYZpfa17TUfa07yqazM0ZoA05LiNoH2SKTjpVBmJpoozTAbSUUUgA9aXFN706mAHim5pWpooA//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F077WCB88TY/s__206143497_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F077WCB88TY-a02c014f91", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F078RQT89ME", "created": 1718331573, "timestamp": 1718331573, "name": "S__206143491_0.jpg", "title": "S__206143491_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 259757, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F078RQT89ME/s__206143491_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F078RQT89ME/download/s__206143491_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F078RQT89ME-e3596c3369/s__206143491_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F078RQT89ME-e3596c3369/s__206143491_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F078RQT89ME-e3596c3369/s__206143491_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F078RQT89ME-e3596c3369/s__206143491_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F078RQT89ME-e3596c3369/s__206143491_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F078RQT89ME-e3596c3369/s__206143491_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F078RQT89ME-e3596c3369/s__206143491_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F078RQT89ME-e3596c3369/s__206143491_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F078RQT89ME-e3596c3369/s__206143491_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADB9vEjx5YZOam8iP+7+tR25224J9TT/ADQ6/IQD70hgY4R1A/OkEcDHAAJ+tRFHPdT/AMCpvlODkFfzpfIRY8iL+5UNwqoV2jGRU6sdoyOahvf4PxpvYaFiUm1UDrSGNooyQob8afAQIE5HT1pzuApIIJ+tAil5o/55j86cspLYWMZPvT2Mbn5ozn1BqSIov3QF55zS1AkUPwCBj61Fe9E+pqfcv94fnUF4QUXBB5pvYaKRpKU0lQUFLRRQAmaMmkopgf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F078RQT89ME/s__206143491_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F078RQT89ME-b83112709f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07831GHP8A", "created": 1718331576, "timestamp": 1718331576, "name": "S__206143493_0.jpg", "title": "S__206143493_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 229996, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07831GHP8A/s__206143493_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07831GHP8A/download/s__206143493_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07831GHP8A-8ed2db8911/s__206143493_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07831GHP8A-8ed2db8911/s__206143493_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07831GHP8A-8ed2db8911/s__206143493_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07831GHP8A-8ed2db8911/s__206143493_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07831GHP8A-8ed2db8911/s__206143493_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07831GHP8A-8ed2db8911/s__206143493_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07831GHP8A-8ed2db8911/s__206143493_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07831GHP8A-8ed2db8911/s__206143493_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07831GHP8A-8ed2db8911/s__206143493_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADCWzRTaoSoyfb3qby1/uj8qjhPl2kfHagyeam0Hae/ekA1pIVOMAn2FOSWEnGAPqKi8lf8Anqv5UvkqekgP0FTqBZIGOgqhqKgIhx3xV1QVjx1x3NQagmbbPoQaoCbBeFORnAJphjaOM7QpP481JH/qk5/hFKWA7j86YFLznH8Kj8KBJIxwMZPoKlaVG++qk+ucULNGn3Qi++6p1AkEb7cFx78Uy8GLR/w/nTxcx45kTP1qG5nje3dRIpJHABqgMyiiigBVAzTsCmr1p9ADSMUnenGmnrQB/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07831GHP8A/s__206143493_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07831GHP8A-9aae56a733", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1718335454.021529] <@U0331FWGQRM>: <@U033G4KN4TD> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U0331FZS7JT>
むっちゃ良い感じですね！！！:raised_hands:
ありがとうございます！

社長にも伝えたのですが、
シワのない袋で印字して写真を何枚か欲しいです。
定規を当ててサイズ感もわかるカットも欲しいです。

追加）カットして粉を出す動画も欲しいです:sweat_drops:

※画像に並べるとむっちゃちっちゃく見えて、
シワも相まって、しょぼく見えてしまします！
提案の最終段階なので、ここは綺麗な写真を送って、
お、これなら安心だね！と思ってもらいたいです！
ただの、印象の問題なのですが、印象がかなり大事だと思っております。
写真の露出とかはこちらで加工するので問題ないです！
- [1718339972.191879] <@U033G4KN4TD>: <@U0331FWGQRM> <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
シワが少ないものを厳選して再度撮影しました！
ご確認お願いいたします。
  - files: [{"id": "F07838YF0G3", "created": 1718339706, "timestamp": 1718339706, "name": "740032458.939307.mp4", "title": "740032458.939307.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 2165089, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F07838YF0G3-d4a6ba1b84/740032458.939307.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F07838YF0G3-d4a6ba1b84/740032458.939307.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07838YF0G3/download/740032458.939307.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F07838YF0G3-d4a6ba1b84/file.m3u8?_xcb=29557&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9OTIxNTMxLEFWRVJBR0UtQkFORFdJRFRIPTkyMTUzMSxDT0RFQ1M9ImF2YzEuNjQwMDFmLG1wNGEuNDAuNSIsUkVTT0xVVElPTj02MDh4MTA4MCxGUkFNRS1SQVRFPTI5Ljk3MApkYXRhOmFwcGxpY2F0aW9uL3ZuZC5hcHBsZS5tcGVndXJsO2Jhc2U2NCxJMFZZVkUwelZRb2pSVmhVTFZndFZrVlNVMGxQVGpvekNpTkZXRlF0V0MxVVFWSkhSVlJFVlZKQlZFbFBUam8zQ2lORldGUXRXQzFOUlVSSlFTMVRSVkZWUlU1RFJUb3hDaU5GV0ZRdFdDMVFURUZaVEVsVFZDMVVXVkJGT2xaUFJBb2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNPRE00V1VZd1J6TXRaRFJoTm1KaE1XSTROQzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01TNTBjd29qUlZoVVNVNUdPak11TWpNM0xBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzT0RNNFdVWXdSek10WkRSaE5tSmhNV0k0TkM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNaTUwY3dvalJWaFVMVmd0UlU1RVRFbFRWQW89CiNFWFQtWC1TVFJFQU0tSU5GOkJBTkRXSURUSD02MzIwNTAsQVZFUkFHRS1CQU5EV0lEVEg9NjMyMDUwLENPREVDUz0iYXZjMS42NDAwMWUsbXA0YS40MC41IixSRVNPTFVUSU9OPTQwNng3MjAsRlJBTUUtUkFURT0yOS45NzAKaHR0cHM6Ly9maWxlcy5zbGFjay5jb20vZmlsZXMtdG1iL1QwMzNENzBSUjZILUYwNzgzOFlGMEczLWQ0YTZiYTFiODQvZmlsZV9IXzI2NF8xMjgweDcyMF8zNTAwS0JQU183UVZCUi5tM3U4Cg==", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F07838YF0G3-d4a6ba1b84/740032458.939307_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 9242, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F07838YF0G3-d4a6ba1b84/740032458.939307_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07838YF0G3/740032458.939307.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F07838YF0G3-b5cba45e05", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07838Z89BM", "created": 1718339722, "timestamp": 1718339722, "name": "S__206184455_0.jpg", "title": "S__206184455_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 193784, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07838Z89BM/s__206184455_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07838Z89BM/download/s__206184455_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07838Z89BM-82004df08c/s__206184455_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07838Z89BM-82004df08c/s__206184455_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07838Z89BM-82004df08c/s__206184455_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07838Z89BM-82004df08c/s__206184455_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07838Z89BM-82004df08c/s__206184455_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07838Z89BM-82004df08c/s__206184455_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07838Z89BM-82004df08c/s__206184455_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07838Z89BM-82004df08c/s__206184455_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07838Z89BM-82004df08c/s__206184455_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADCYrTStPopiGBaeFpwB9KMe1ACYpjLUuOKQigCH7RH6H8qY00Z6Z6VIbaP/AGvzpPs0f+1+dGoEG8erU4SAd2/Gpfs0f+1+dL9mT1alYdxqToFwSfyp32iP+8fypPsqf3mo+yJ/eagCY0UGiqEFFFFAC0UlFAH/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07838Z89BM/s__206184455_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07838Z89BM-19a65948f5", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F078G2FDDFB", "created": 1718339726, "timestamp": 1718339726, "name": "S__206184456_0.jpg", "title": "S__206184456_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 146860, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F078G2FDDFB/s__206184456_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F078G2FDDFB/download/s__206184456_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FDDFB-5609916d73/s__206184456_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FDDFB-5609916d73/s__206184456_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FDDFB-5609916d73/s__206184456_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FDDFB-5609916d73/s__206184456_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FDDFB-5609916d73/s__206184456_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FDDFB-5609916d73/s__206184456_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FDDFB-5609916d73/s__206184456_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FDDFB-5609916d73/s__206184456_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FDDFB-5609916d73/s__206184456_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACSJhTSOKlIzTSKQBAQsoz6VIY90xZzlR0qJELyBR3NWrgoi8E5PQUNFJ2EM6KcE0n2mP1qkck0UrBzFrFNYVJimkUyR9um2NpD34FQSHexPbtViZwYkVBgYquaAIyKNtOyKMj1pgWCRTCw/CmFmdtq5J9BSCNmfYx20gCSUED2FQtJmprizMablk3exFVM84PWgB240bjSUUwP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F078G2FDDFB/s__206184456_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F078G2FDDFB-fe75eec609", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F078G2FHDCZ", "created": 1718339729, "timestamp": 1718339729, "name": "S__206184458_0.jpg", "title": "S__206184458_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 151707, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F078G2FHDCZ/s__206184458_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F078G2FHDCZ/download/s__206184458_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FHDCZ-60c589c8fe/s__206184458_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FHDCZ-60c589c8fe/s__206184458_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FHDCZ-60c589c8fe/s__206184458_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FHDCZ-60c589c8fe/s__206184458_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FHDCZ-60c589c8fe/s__206184458_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FHDCZ-60c589c8fe/s__206184458_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FHDCZ-60c589c8fe/s__206184458_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FHDCZ-60c589c8fe/s__206184458_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F078G2FHDCZ-60c589c8fe/s__206184458_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACRcUhFPpjGkAw03FKTUkMLTH0X1pgLHEGXLd6d5KVISEO0dB0pPMqS7ERNRseeKC+fapbaREZiy54yD6UyB0dtgBpeP9mnSXKoNqDn+VV5rkyNxwKhzTAlMrk5LUnmP/epmaM0AMO/ODU4jkW3bAyT6VFghhkHmr0Uqqv0pbgZe+l31Jd4kkLqMH+dVxTAk3Uu6mUUAf//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F078G2FHDCZ/s__206184458_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F078G2FHDCZ-54dd9261ff", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0785SB9E9J", "created": 1718339732, "timestamp": 1718339732, "name": "S__206184459_0.jpg", "title": "S__206184459_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 94615, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0785SB9E9J/s__206184459_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0785SB9E9J/download/s__206184459_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SB9E9J-3f61cab7ba/s__206184459_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SB9E9J-3f61cab7ba/s__206184459_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SB9E9J-3f61cab7ba/s__206184459_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 336, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SB9E9J-3f61cab7ba/s__206184459_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 448, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SB9E9J-3f61cab7ba/s__206184459_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SB9E9J-3f61cab7ba/s__206184459_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 673, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SB9E9J-3f61cab7ba/s__206184459_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 747, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SB9E9J-3f61cab7ba/s__206184459_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 897, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SB9E9J-3f61cab7ba/s__206184459_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 957, "original_w": 1108, "original_h": 1035, "thumb_tiny": "AwAsADB1IRS0hNIBpphpSabmmAVNbrnLelJBA0xyeF9asyKEUBBgLSY1uQE0xjSF/Smkk+1MQhNWIbb+KUYHYVNDbrENz4Zu3tUU9zg4ByR2oAmeZY146Y4xVSSd3PBwPQVCWLHLHNGaAE3iml80jKAakhiWQ4OfwNAEkk7CBF3HkVX3UtwNmxQSQM9ahyaS2Am3UbqiyaXNMD//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0785SB9E9J/s__206184459_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0785SB9E9J-ca9c94ad32", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F077WP4V0HL", "created": 1718339735, "timestamp": 1718339735, "name": "S__206184453_0.jpg", "title": "S__206184453_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 322983, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F077WP4V0HL/s__206184453_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F077WP4V0HL/download/s__206184453_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F077WP4V0HL-2bb4d17d8a/s__206184453_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F077WP4V0HL-2bb4d17d8a/s__206184453_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F077WP4V0HL-2bb4d17d8a/s__206184453_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F077WP4V0HL-2bb4d17d8a/s__206184453_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F077WP4V0HL-2bb4d17d8a/s__206184453_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F077WP4V0HL-2bb4d17d8a/s__206184453_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F077WP4V0HL-2bb4d17d8a/s__206184453_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F077WP4V0HL-2bb4d17d8a/s__206184453_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F077WP4V0HL-2bb4d17d8a/s__206184453_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADCbyoyBuQEgdSKPKjz9xfypXdU+9TJSzriMjB6nNACF4EOMLn2FPR4ScAL+VVhbyeg/OnfZ3/2fzpXYFtkUjoPwqCVSsbEdgafFuVcNz9DT8Bl/SmBDcAs2BTAoVcc59SKfPOY3wADx3qB52fsBQ2A/C/5IoztGQBxUIYk9vyp+T7H8KVwJYpHIyFbFSoTg5yMmoo5W4GAB9KkbcBkFaLhYeQD1ApMD0FLRViENJmlNNNADTIQe1ODEoW4zUbdacv8Aqj9aljP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F077WP4V0HL/s__206184453_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F077WP4V0HL-7c21339978", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0783901BHR", "created": 1718339738, "timestamp": 1718339738, "name": "S__206184457_0.jpg", "title": "S__206184457_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 150852, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0783901BHR/s__206184457_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0783901BHR/download/s__206184457_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0783901BHR-1b221314d4/s__206184457_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0783901BHR-1b221314d4/s__206184457_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0783901BHR-1b221314d4/s__206184457_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0783901BHR-1b221314d4/s__206184457_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0783901BHR-1b221314d4/s__206184457_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0783901BHR-1b221314d4/s__206184457_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0783901BHR-1b221314d4/s__206184457_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0783901BHR-1b221314d4/s__206184457_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0783901BHR-1b221314d4/s__206184457_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACSJhTSOKlIzTCKQC25Cyc9xUnl5mLvyB0qJE3yBfU1ZuWRV4J3HoPShopOwjXCKcGk+1J/kVTOc0UWDmLOKRhTyKaRQSSW6bUaQ/QVBId7E9u1WJZAYUVAQO+armgCMijFOyKTIpgWSRUZbNMLM52qCT6ClRG85Q3GDmkAszBAo79artJmrF5bkjzFcf7pqj3wetC2AfuNG40lFMD//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0783901BHR/s__206184457_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0783901BHR-6445994d7d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F078390547M", "created": 1718339741, "timestamp": 1718339741, "name": "S__206184451_0.jpg", "title": "S__206184451_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 304318, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F078390547M/s__206184451_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F078390547M/download/s__206184451_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F078390547M-610ba436c2/s__206184451_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F078390547M-610ba436c2/s__206184451_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F078390547M-610ba436c2/s__206184451_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F078390547M-610ba436c2/s__206184451_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F078390547M-610ba436c2/s__206184451_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F078390547M-610ba436c2/s__206184451_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F078390547M-610ba436c2/s__206184451_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F078390547M-610ba436c2/s__206184451_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F078390547M-610ba436c2/s__206184451_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADCO2jMyfMSCh+Vh1qU2ik53H8qW2AjtULd+akMm5P3ZGffigCA2cK/ec/jSpZQdmJP1ppgkLZJUn/epRA45yo/GldgTSW4Mew4Ye/UVRuoFjRdq45rRjLbcNyfamTxedCQOvUfWmATg4CKDgCoSPKTJRj78VZJqOUnAxTYit5q9dhP4il87HRKeC3dj+VKcngEn61OoxY3kZchTj61KmdvzDFA4AAFLTAKTrRS0xBgUYFFFACGjtQaO1Az/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F078390547M/s__206184451_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F078390547M-86e96c8398", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0785SBSCE8", "created": 1718339745, "timestamp": 1718339745, "name": "S__206184454_0.jpg", "title": "S__206184454_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 285059, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0785SBSCE8/s__206184454_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0785SBSCE8/download/s__206184454_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SBSCE8-1940438e01/s__206184454_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SBSCE8-1940438e01/s__206184454_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SBSCE8-1940438e01/s__206184454_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SBSCE8-1940438e01/s__206184454_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SBSCE8-1940438e01/s__206184454_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SBSCE8-1940438e01/s__206184454_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SBSCE8-1940438e01/s__206184454_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SBSCE8-1940438e01/s__206184454_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0785SBSCE8-1940438e01/s__206184454_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADCXFJinNwpNN8xR1yKYhQKUCmedH/epwlQ8Bs/hQA/FGKajbiR0xTsGgBJMLGzegqoZskkp196uSJvQrnGah+xj++fyoaBEAlH9z9aUSj+5+tTfYx/fP5UfYx/z0P5UrDuMSdVySrc0/wC1J/db9KPsY/56fpR9j/6afpQBZNFBoFUIKKKKACikpaQH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0785SBSCE8/s__206184454_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0785SBSCE8-0de97916b7", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1718340174.039909] <@U041RJKV5JA>: <@U0331FWGQRM>
 <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
健祥指定の加工依頼書に記入し、月曜日より製造を依頼します。
ご確認お願いいたします。
  - files: [{"id": "F0780FSP2MT", "created": 1718340156, "timestamp": 1718340156, "name": "加工依頼書.pdf", "title": "加工依頼書.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 696005, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0780FSP2MT/_______________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0780FSP2MT/download/_______________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0780FSP2MT-8af7d6deb4/________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0780FSP2MT/_______________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F0780FSP2MT-9798ec5f52", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1718340890.177819] <@U0331FWGQRM>: <@U033G4KN4TD> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
お客様から“perfect”と返事が来ました！:+1:
ありがとうございます
  - files: [{"id": "F0783AJ3QEP", "created": 1718340881, "timestamp": 1718340881, "name": "スクリーンショット 2024-06-14 13.54.37.png", "title": "スクリーンショット 2024-06-14 13.54.37.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 366898, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0783AJ3QEP/____________________________2024-06-14_13.54.37.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0783AJ3QEP/download/____________________________2024-06-14_13.54.37.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0783AJ3QEP-c07541715f/____________________________2024-06-14_13.54.37_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0783AJ3QEP-c07541715f/____________________________2024-06-14_13.54.37_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0783AJ3QEP-c07541715f/____________________________2024-06-14_13.54.37_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 239, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0783AJ3QEP-c07541715f/____________________________2024-06-14_13.54.37_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 318, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0783AJ3QEP-c07541715f/____________________________2024-06-14_13.54.37_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0783AJ3QEP-c07541715f/____________________________2024-06-14_13.54.37_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 477, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0783AJ3QEP-c07541715f/____________________________2024-06-14_13.54.37_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 530, "thumb_800_h": 800, "original_w": 543, "original_h": 819, "thumb_tiny": "AwAwAB/QqpPaSSTF1ZQD61bqjcEi4bk9u9IBPsMn95f1qW3tpIZMkqQR2qvz6n86dbki4UbjznvQBfJxUDhfNZu59asVTnZlmbFDGtBSqHnGBT4gm8YC7vWqys4OetWIiC4IP6UrFXRZqvLC7SFhjB96sUUyCoYHHdfzpYonWUE7cD3q1j1oPAoA/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0783AJ3QEP/____________________________2024-06-14_13.54.37.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F0783AJ3QEP-5780c4d2a1", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1718340950.017899] <@U0331FWGQRM>: *支払いについて*
- [1718341071.574599] <@U0331FWGQRM>: <@U0331FZS7JT> cc <@U0331FZTHEK>
下記のような交渉が来ております。
今回は無理だと伝えて、
次回以降は“50% upfront and 50% after 30 days”でOKだと伝えましょうか？
次回以降もリスク高い？？？
どうでしょう？

ーーーーーーーーーーー
Now since we are ordering a little more this time (3000 and 5000), I was wondering if we could possible start talking about payment terms? For example, 50% upfront and 50% after 30 days?

Of course I understand if it is too soon for you. :slightly_smiling_face:

-----
今回は少し多めに（3000本と5000本）注文するので、支払い条件について話し合えないだろうか？例えば、前金50％、30日後50％とか。
もちろん、あなたにとって早すぎるのであれば、私は理解しています。）
-----
- [1718341132.551219] <@U0331FWGQRM>: *60g bag（Bio Matcha）*
- [1718341175.169399] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U0331FZS7JT>
＜情報共有＞
By the way, just as a forecast, most likely starting now we would like you to ship 3000 60g at the end of every month.
ーーー
ちなみに予想ですが、おそらく今から毎月末に60gを3000個出荷していただきたいと思っています。
ーーー
- [1718341321.020739] <@U041RJKV5JA>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本件に使用するスティックの素材は“本アルミ”となります。
アルミ蒸着の袋もあるのか吉村に確認しましたが光を通しやすく、内容物の劣化が進みやすい為、使用しているところは無いとの事です。
よろしくお願いいたします。
- [1718341492.354959] <@U0331FZS7JT>: <@U0331FWGQRM> <@U0331FZTHEK> <@U03BLQ65GK0> 
メモ兼ねて

50%事前、50%30日以内、OKです！
オネシャス！
- [1718341786.544989] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
ありがとうございます！

＜情報共有＞
<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
確認したかった理由は、スティックのシワをもし突っ込まれた時の説明材料を揃えたかった為です。
> アルミ蒸着の袋もあるのか吉村に確認しましたが光を通しやすく、内容物の劣化が進みやすい為、使用しているところは無い
アルミだからシワになるのは仕方がない。
▶︎他に素材の選択肢としてアルミ蒸着があるかもしれないが、品質としてお勧めできない。

## 2024-06-18

- [1718732716.104469] <@U0331FWGQRM>: *Chai Matcha*
- [1718732811.284719] <@U0331FWGQRM>: <@U0331FZS7JT>
なんでこんなに高いんだ？とのこと。
ジンジャーはキタマの50000/kgはマストです:sweat_drops:
今回送ったサンプルの味の評価を見てからなのか、
その前にサンプル作るのかは微妙なところですが。。。
  - files: [{"id": "F078GRRQYLW", "created": 1718732803, "timestamp": 1718732803, "name": "スクリーンショット 2024-06-19 2.46.40.png", "title": "スクリーンショット 2024-06-19 2.46.40.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 383847, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F078GRRQYLW/____________________________2024-06-19_2.46.40.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F078GRRQYLW/download/____________________________2024-06-19_2.46.40.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F078GRRQYLW-458e9e04a1/____________________________2024-06-19_2.46.40_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F078GRRQYLW-458e9e04a1/____________________________2024-06-19_2.46.40_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F078GRRQYLW-458e9e04a1/____________________________2024-06-19_2.46.40_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 218, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F078GRRQYLW-458e9e04a1/____________________________2024-06-19_2.46.40_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 291, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F078GRRQYLW-458e9e04a1/____________________________2024-06-19_2.46.40_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F078GRRQYLW-458e9e04a1/____________________________2024-06-19_2.46.40_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 436, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F078GRRQYLW-458e9e04a1/____________________________2024-06-19_2.46.40_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 485, "thumb_800_h": 800, "original_w": 548, "original_h": 904, "thumb_tiny": "AwAwAB28wCqxA561AZJAMr/KrBG4EUzyhjhjSAr/AGiXjnr7VYjdmzmm/Z1PUt+lPSPZn5ic+tAD6OKMUY9qAE49aWjGOlITigBaaTzTqT8DQDEyfQ0Hntil/Cg0hH//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F078GRRQYLW/____________________________2024-06-19_2.46.40.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F078GRRQYLW-25c6032ef8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1718746129.375149] <@U0331FZS7JT>: <@U0331FWGQRM> 
了解です。
昨日送ったサンプルの評価はまだだけど、
キタマのジンジャーの風味で、セバスチャンのターゲットのチャイ抹茶と近い感じにするようにサンプル作成に取り掛かります！

## 2024-06-19

- [1718853420.117339] <@U0331FZS7JT>: 桃翠園のVanilla Matcha1に対し、セバスチャンの抹茶2.8で同じ味の濃さ＋甘味、フレーバーだけ桃翠園が少し強い

## 2024-06-20

- [1718888848.970649] <@U0331FWGQRM>: <@U0331FZS7JT>
次はこの試作を進めてくれとのこと。
ブレンド比率については情報待ちなので、
それがきたら、（温度感がよくわからんので）すぐに動き始めた方がいいかもです。:sweat_drops:

## 2024-06-22

- [1719082785.965129] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
セバスチャン商品の賞味期限とロット番号の印字について。
- [1719084018.283229] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
有機商品については賞味期限とロット番号を印字する必要があるそうです。
なので、下記で言うと、007のみ印字が必要らしいです。
その論理で、sachet（スティック）は印字が無くてもOKと言われました。
しかし、その考えでいくと、
005のBio matcha 60gは印字不要で、
007のMatcha 60gはExpだけでなく、Lotも必要となりややこしくなります。

なので、今後はsachetを除く全ての商品にLotとExpを印字する、と言うことに決まりました。

そして質問なのですが、今回の出荷分について、
sachetを除く全ての袋にロット番号と賞味期限を印字可能ですか？

※事前に確認したところ、今回もし間に合わなければ、次回からでいい。
という許可は得ました。（が、確認して連絡する、と伝えている状況です）
ーーーーーーーーーーー
TSE-MTL-005 : 28th June
∟Bio matcha 60gx3000bags（非有機）

TSE-MTL-006 : 28th June
∟Purer Bio matcha 2g sachetx5000（非有機）
Print : PURER BIO MATCHA

TSE-MTL-007 : 26th June
∟Matcha 60gx100bags (organic)（有機）
ーーーーーーーーーーー

## 2024-06-23

- [1719196893.686839] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
今回出荷分については既に賞味期限の印字を終えており、007は梱包も完了しております。
次回受注分よりの対応とさせていただきたいのですが、よろしいでしょうか。

## 2024-06-26

- [1719441859.443729] <@U0331FWGQRM>: <@U0331FZS7JT> 
フィードバック

もっとレモンジュースのような味にするためにクエン酸が必要

Ginger lemon matcha: 
We need the citric acid to make it taste more like lemon juice.

- [1719441958.244699] <@U0331FWGQRM>: <@U0331FZS7JT> 
フィードバック

ラズベリーの味はしっかりしていてとてもいいのですが、ココナッツの味がしません。もっとココナッツの味が欲しい。そうすれば完璧です。

Raspberry coconut: The raspberry taste is strong and very nice, but we don’t taste coconut. We need more coconut flavor. Then it’s perfect.
- [1719442042.093409] <@U0331FWGQRM>: <@U0331FZS7JT> 
フィードバック

残念ながらマンゴーの味は好きではない。未熟なタイ産マンゴーのような苦味に近い味で、私たちは熟して甘いインド産マンゴーのような味が好みです。私たちのマンゴーと味を比べましたか？

Mango: Unfortunately we don’t like the type of mango flavor. It tastes like an unripe thai mango almost bitter, and we prefer it to taste like a ripe, sweet Indian mango. Have you compared the flavor to our mango?
- [1719442142.925159] <@U0331FWGQRM>: <@U0331FZS7JT> 
フィードバック

まだテスト中だが、今のところ気に入っている。

Vanilla: We are still testing but like it so far.

## 2024-06-30

- [1719791594.136009] <@U0331FZS7JT>: 翻訳メモ
〈Chai-2〉
デキストリンを増量した新しいチャイ抹茶2を試してみた。素晴らしい改良だと思うが、スパイスのジンジャー・シナモン・クローブの比率が違うような気がする。
ジンジャーはオリジナルより多く、クローブはかなり少なく、シナモンは少し少ない。ステビアはどのくらい入っていますか？
他のブレンドと同じで、色にはまだ満足していません。b2は素晴らしく、もしお客様が比較したら、フレーバー・ミックスに安い抹茶を加えたと思われるでしょう。

〈Chai-1〉
新しいロットのチャイ抹茶1を試しました。生姜が少なくてずっといい。でも、クローブの数が少ないか、あまり香りの良くないタイプを使っているような気がする。
また、ステビアを少し減らす必要があると思う。風味を増すためにパウダーを追加すると、甘くなりすぎるからだ。30％くらい減らしてもいいかな？
色以外に混ぜやすさについて何かできることはないでしょうか？
デキストリンは入っていないよりはマシですが、それでも本当によくかき混ぜて、塊を少し崩す必要があります。
他に加えられる材料はありますか？
キサンタンガムとか？
- [1719803484.555379] <@U0331FZS7JT>: 高砂香料mango flavor で同じラインの香り
味・風味のバランス
サンプル１に対しターゲット2.3で同じ濃さ
※~高砂に見積もり依頼中~
- [1719813997.633039] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
出荷時（のケースラベルなど）について。

## 2024-07-03

- [1720025673.760949] <@U0331FZS7JT>: メモ
1:2.8で同じ味の濃さ
- [1720025719.225509] <@U0331FZS7JT>: メモ
1:2.5で同じ味の濃さ
ダマほぼない

## 2024-07-10

- [1720602460.120679] <@U0331FWGQRM>: ・MFDは書く必要がないとのこと▶︎日付のみでOK
・少なくとも、A5サイズくらいの商品ラベルにしてくれとのこと。
  - files: [{"id": "F07AV0Z6325", "created": 1719822356, "timestamp": 1719822356, "name": "ケースラベル_メモ.jpg", "title": "ケースラベル_メモ.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 222193, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07AV0Z6325/____________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07AV0Z6325/download/____________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07AV0Z6325-422b7433a3/_____________________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07AV0Z6325-422b7433a3/_____________________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07AV0Z6325-422b7433a3/_____________________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 203, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07AV0Z6325-422b7433a3/_____________________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 270, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07AV0Z6325-422b7433a3/_____________________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07AV0Z6325-422b7433a3/_____________________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 405, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07AV0Z6325-422b7433a3/_____________________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 450, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07AV0Z6325-422b7433a3/_____________________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 540, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07AV0Z6325-422b7433a3/_____________________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 576, "original_w": 1706, "original_h": 960, "thumb_tiny": "AwAbADCSgKSMgZpKfHnBxSSuxt2Q3a3dTSnb0AbNPAI5x+tNIy7Z9KbiJSG7T6UlPAUH3HNMHvSasNO4U9YmYAjHNR0oJHc/nSGP8pgcZH50ohY5+YD8aZuPqfzpMn1NAEsgKjnHPHBqE9aXJPUk009TQ3cErH//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07AV0Z6325/____________________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07AV0Z6325-f81537b3dc", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-07-16

- [1721199145.347949] <@U0331FWGQRM>: 有機商品については、
invoiceの商品名は“organic”の文字が必要とのこと。

添付参照
  - files: [{"id": "F07CPR2KGLV", "created": 1721199140, "timestamp": 1721199140, "name": "TSE-MTL-001-24_invoice_revised2_20240708.pdf", "title": "TSE-MTL-001-24_invoice_revised2_20240708.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 142389, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07CPR2KGLV/tse-mtl-001-24_invoice_revised2_20240708.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07CPR2KGLV/download/tse-mtl-001-24_invoice_revised2_20240708.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07CPR2KGLV-8414859d0c/tse-mtl-001-24_invoice_revised2_20240708_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07CPR2KGLV/tse-mtl-001-24_invoice_revised2_20240708.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07CPR2KGLV-cf48b516bc", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07CL3M38R4", "created": 1721199142, "timestamp": 1721199142, "name": "TSE-MTL-001-24_packing list_revised2_20240708.pdf", "title": "TSE-MTL-001-24_packing list_revised2_20240708.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 140263, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07CL3M38R4/tse-mtl-001-24_packing_list_revised2_20240708.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07CL3M38R4/download/tse-mtl-001-24_packing_list_revised2_20240708.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07CL3M38R4-8af970e0a7/tse-mtl-001-24_packing_list_revised2_20240708_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07CL3M38R4/tse-mtl-001-24_packing_list_revised2_20240708.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07CL3M38R4-adda471ebb", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-07-18

- [1721315592.073429] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
今後、すべての商品について、
プラスチックバッグに入れてくださいとのこと。水に濡れるのを防ぎたいとのことです。
  - files: [{"id": "F07D4915STE", "created": 1721315564, "timestamp": 1721315564, "name": "2e92b19c-44cd-448a-bcac-a826fbc47416.jpg", "title": "2e92b19c-44cd-448a-bcac-a826fbc47416", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 163727, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07D4915STE/2e92b19c-44cd-448a-bcac-a826fbc47416.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07D4915STE/download/2e92b19c-44cd-448a-bcac-a826fbc47416.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07D4915STE-36d8db677c/2e92b19c-44cd-448a-bcac-a826fbc47416_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07D4915STE-36d8db677c/2e92b19c-44cd-448a-bcac-a826fbc47416_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07D4915STE-36d8db677c/2e92b19c-44cd-448a-bcac-a826fbc47416_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07D4915STE-36d8db677c/2e92b19c-44cd-448a-bcac-a826fbc47416_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07D4915STE-36d8db677c/2e92b19c-44cd-448a-bcac-a826fbc47416_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07D4915STE-36d8db677c/2e92b19c-44cd-448a-bcac-a826fbc47416_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07D4915STE-36d8db677c/2e92b19c-44cd-448a-bcac-a826fbc47416_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07D4915STE-36d8db677c/2e92b19c-44cd-448a-bcac-a826fbc47416_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07D4915STE-36d8db677c/2e92b19c-44cd-448a-bcac-a826fbc47416_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1200, "original_h": 1600, "thumb_tiny": "AwAwACS0aaXA71FJL1ANREknJ5pXHYseb2UE0qu5b5hgVD5xCgKAD7CnR3XzbXGKVx2Jy+OxNJ5n+y1PDKRkUZFArFLqeKeIvX8hSxRiNRu6nmpeoJHUdKdguMEQxwMDvVe4XawIq0gbBznn1qCUbs96BDVPy9adk+tMWMgcml8v3NSUWFw42Hr2NPiQ+Xz1zUK53qQcc9anJ2jaOTVJk2GOwHA5NM2926moprpIvlT53/QVUEzmTezEmizY72Lp8zJ2x5H1pP3v/PL9adEwKZHen7hRYLn/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07D4915STE/2e92b19c-44cd-448a-bcac-a826fbc47416.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07D4915STE-3ae55ea2ed", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1721315982.754859] <@U0331FWGQRM>: <@U0331FZS7JT> 
Xanthanについて。

ところで、抹茶をスプーンだけで混ぜやすくするために、デキストリンやキサンタンガムのようなもので解決できないのであれば、そのようなものはすべて省いて、ステビアとフレーバーで抹茶を作りましょう。

By the way, if we cannot find a solution with dextrin or something like xanthan gum to make the matcha easy to mix with just a spoon, then let’s just leave out all that and just do matcha with stevia and flavor
- [1721316061.156409] <@U0331FWGQRM>: サービングサイズについては、
他の味と同じ、200mlあたり理想は2～3g
クエン酸、レモンパウダー入りのフレーバーは水割りだけです。

## 2024-07-19

- [1721408279.263019] <@U0331FWGQRM>: *商品に使用する袋について（60g袋・sachetなど）*
- [1721408375.809529] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
今後60gに使用する袋は縦が短くて、横に長いやつ（過去に一度臨時で使用した）ものがいいそうです。

写真の左（2192)
  - files: [{"id": "F07D1TQT2NA", "created": 1721408357, "timestamp": 1721408357, "name": "左_風袋2192（応急代用品）.jpg", "title": "左_風袋2192（応急代用品）.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 254328, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07D1TQT2NA/__________2192_____________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07D1TQT2NA/download/__________2192_____________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07D1TQT2NA-53688d2ad5/__________2192______________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07D1TQT2NA-53688d2ad5/__________2192______________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07D1TQT2NA-53688d2ad5/__________2192______________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 203, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07D1TQT2NA-53688d2ad5/__________2192______________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 270, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07D1TQT2NA-53688d2ad5/__________2192______________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07D1TQT2NA-53688d2ad5/__________2192______________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 405, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07D1TQT2NA-53688d2ad5/__________2192______________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 450, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07D1TQT2NA-53688d2ad5/__________2192______________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 540, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07D1TQT2NA-53688d2ad5/__________2192______________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 576, "original_w": 1706, "original_h": 960, "thumb_tiny": "AwAbADB6/dFDOFOMUKflFMPMhyO1IBwkBOAKacBiST1oPbAxk0qnlvrTAchySAc470401fvn6U7NIBAKYxwSM4/CpKQqM5oAh53LznBoYkNwfwAqUIvoKdtHp1oAjQgn5d3TvUmKB/KhjgcUAf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07D1TQT2NA/__________2192_____________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07D1TQT2NA-890d3f7494", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-07-20

- [1721490645.565809] <@U0331FWGQRM>: *注文スケジュール、概要*
- [1721490711.342229] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <@U03BLQ65GK0>

From Sebastyan
我々の生産スケジュールをご理解いただくためにお伝えしますと、最終製品は11月1日までにスイスの倉庫に到着する必要があります。

順調に進めば、バッグの製造はまもなく開始され、9月15日頃に貴社の倉庫に出荷される予定です。その後、10月15日までに製造・出荷していただければと思います。

フレーバーが完璧に仕上がれば、各フレーバーの注文はおおよそ3,000ユニットとなります：

	•	マンゴー
	•	バニラ
	•	チャイ
	•	シナモン
	•	ラズベリーココナッツ
	•	ピーチレモン
	•	パイナップルレモン
	•	ストロベリーレモン
	•	ジンジャーレモン
また、非オーガニックのB2は約5,000ユニットの注文となります。

製造リードタイムが30日であると想定していますので、バッグが到着するまでにフレーバーを完成させるための時間があと2か月あるという認識でよろしいでしょうか？
- [1721492056.824969] <@U0331FWGQRM>: <@U0331FZS7JT> 

パイナップル、ピーチ、ストロベリーのフレーバーは既に調達できていますか？
Have you already been able to source flavor for pineapple, peach and strawberry?
- [1721498549.493499] <@U0331FWGQRM>: To Sebastyan
ご連絡ありがとうございます。

本プロジェクトのスケジュールについては理解しました。ご提示いただいた内容に大きな問題はないと考えています。

主な懸念は、9月15日から10月15日の1か月間で27,000袋を梱包する必要があることです。

この点については、製造部門と十分に協議いたします。

フレーバーの最終決定後に量産する必要があるため、フレーバーを完成させるための実際の期間は2か月未満となります。

すべての材料は9月15日までに準備する必要があります。

- [1721498632.853029] <@U0331FWGQRM>: From Sebastyan
承知いたしました。これはあくまで理想的なシナリオを前提としています。例えば、ストロベリーやマンゴーの良いフレーバーが得られない場合、それらは生産せず、ブラックフライデー後に改良と完成を行います。

## 2024-07-21

- [1721629649.510959] <@U0331FZS7JT>: 【メモ】
パイナップル：キタマ
ピーチ：キタマ
スイカ：キタマ
パッションフルーツ：キタマ
レモン：キタマ
ミント：キタマ
ストロベリー：高砂

## 2024-07-22

- [1721641581.692359] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U03BLQ65GK0>
Sachetもらしいです。。。
なのでトータルとしては下記です。

:black_small_square:60g bag
9 flavors: 60g/bag x 3,000 bags each flavor
Non-organic B2: 60g/bag x 5,000 bags

:black_small_square:Sachet
9 flavors: ??g/sachet x 5000-10000 sachets each flavor
Non-organic B2: 2g/sachet x ??? sachets

ーーーーーー
From Sebastyan
サシェはおそらく2gになる予定です。
私たちは自社デザインのサシェを使用したいのですが、間に合わない場合はカスタムテキスト入りの無地のアルミサシェを使用します。
概算は正しいようです。B2 2gサシェは最低5,000個になります。
- [1721714629.352279] <@U0331FWGQRM>: *Sachetについて*
静パックにて充填検討中。
フレーバーの香りの問題については、
別途、清掃代を頂くかもしれないとのこと。
そして、サンプル現物を確認したいらしいので数十グラムでいいので、サンプル出来次第欲しいとのこと。（50g程度でOKかと。）

吉村の日高様より助言を頂いたのは
比重の違いにより、商品の濃さにバラツキが出る可能性について言及されていた。
この問題については別途検討。（例えば2000pcずつ原料を投入すればいいのでは？）

## 2024-07-23

- [1721726091.155569] <@U0331FWGQRM>: <@U0331FZS7JT>
ラフデザイン（60g resealable bag, 2g stick）
  - files: [{"id": "F07DMC02T5Z", "created": 1721726054, "timestamp": 1721726054, "name": "WhatsApp Image 2024-07-19 at 00.15.48.jpeg", "title": "WhatsApp Image 2024-07-19 at 00.15.48.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 218505, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07DMC02T5Z/whatsapp_image_2024-07-19_at_00.15.48.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07DMC02T5Z/download/whatsapp_image_2024-07-19_at_00.15.48.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07DMC02T5Z-18102f9b0e/whatsapp_image_2024-07-19_at_00.15.48_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07DMC02T5Z-18102f9b0e/whatsapp_image_2024-07-19_at_00.15.48_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07DMC02T5Z-18102f9b0e/whatsapp_image_2024-07-19_at_00.15.48_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 230, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07DMC02T5Z-18102f9b0e/whatsapp_image_2024-07-19_at_00.15.48_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 307, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07DMC02T5Z-18102f9b0e/whatsapp_image_2024-07-19_at_00.15.48_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07DMC02T5Z-18102f9b0e/whatsapp_image_2024-07-19_at_00.15.48_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 460, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07DMC02T5Z-18102f9b0e/whatsapp_image_2024-07-19_at_00.15.48_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 511, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07DMC02T5Z-18102f9b0e/whatsapp_image_2024-07-19_at_00.15.48_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 613, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07DMC02T5Z-18102f9b0e/whatsapp_image_2024-07-19_at_00.15.48_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 654, "original_w": 1565, "original_h": 1000, "thumb_tiny": "AwAeADC7K5VsD6nnFErsgBHNJMgd1J/hPrSsw4+YdPWs5MSTuLuPlBu/pQGJjJ5z6ZpuQYxllzn1o+URsA65PripV7l20FjcsWDZUgetEblnwc0Kw243DOPUUkaqJM9+nWh7jWw2dtrj3OKbMDs3DjA5qaSEOcnFDRMe4p8ruxqSRX3f6OGHrySOlSIpMZDEZ65xT/I+UA4ODml8o4YE5z61p0ByI4xgMSd34UQ58zk5/DpUqxFVwMYpEi2Nn5feosxXP//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07DMC02T5Z/whatsapp_image_2024-07-19_at_00.15.48.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07DMC02T5Z-65e418ba46", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07DES6539U", "created": 1721726065, "timestamp": 1721726065, "name": "WhatsApp Image 2024-07-23 at 00.49.11 (1).jpeg", "title": "WhatsApp Image 2024-07-23 at 00.49.11 (1).jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 24774, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07DES6539U/whatsapp_image_2024-07-23_at_00.49.11__1_.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07DES6539U/download/whatsapp_image_2024-07-23_at_00.49.11__1_.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07DES6539U-69c3710276/whatsapp_image_2024-07-23_at_00.49.11__1__64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07DES6539U-69c3710276/whatsapp_image_2024-07-23_at_00.49.11__1__80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07DES6539U-69c3710276/whatsapp_image_2024-07-23_at_00.49.11__1__360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 102, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07DES6539U-69c3710276/whatsapp_image_2024-07-23_at_00.49.11__1__480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 136, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07DES6539U-69c3710276/whatsapp_image_2024-07-23_at_00.49.11__1__160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07DES6539U-69c3710276/whatsapp_image_2024-07-23_at_00.49.11__1__720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 203, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07DES6539U-69c3710276/whatsapp_image_2024-07-23_at_00.49.11__1__800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 226, "thumb_800_h": 800, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07DES6539U-69c3710276/whatsapp_image_2024-07-23_at_00.49.11__1__960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 271, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07DES6539U-69c3710276/whatsapp_image_2024-07-23_at_00.49.11__1__1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 289, "thumb_1024_h": 1024, "original_w": 292, "original_h": 1034, "thumb_tiny": "AwAwAA20QgOC3NKFUjINMkDM5wD+VPiB2kHI571zmr2GrNu3cY29aiiug4O7IxUxA64pghUEkIeetSpXHGyWpNtPqKWmbh6tQHA9T9aZNj//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07DES6539U/whatsapp_image_2024-07-23_at_00.49.11__1_.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07DES6539U-966d7ebd48", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-07-24

- [1721806408.674769] <@U0331FWGQRM>: *製造について*
- [1721806521.390319] <@U0331FWGQRM>: 杉本製茶にてブレンド、小分け作業を行う。

※確認事項
２階のシーラーは稼働する？

## 2024-07-25

- [1721917409.190409] <@U0331FWGQRM>: *cinnamon matcha*
- [1721917434.413039] <@U0331FWGQRM>: <@U0331FZS7JT>
比率は未定でしたっけ？
- [1721918270.038499] <@U0331FWGQRM>: 
  - files: [{"id": "F07E1UW51H9", "created": 1721918266, "timestamp": 1721918266, "name": "スクリーンショット 2024-07-25 23.37.41.png", "title": "スクリーンショット 2024-07-25 23.37.41.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 74238, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07E1UW51H9/____________________________2024-07-25_23.37.41.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07E1UW51H9/download/____________________________2024-07-25_23.37.41.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07E1UW51H9-47f25ea2e6/____________________________2024-07-25_23.37.41_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07E1UW51H9-47f25ea2e6/____________________________2024-07-25_23.37.41_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07E1UW51H9-47f25ea2e6/____________________________2024-07-25_23.37.41_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 94, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07E1UW51H9-47f25ea2e6/____________________________2024-07-25_23.37.41_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 126, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07E1UW51H9-47f25ea2e6/____________________________2024-07-25_23.37.41_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07E1UW51H9-47f25ea2e6/____________________________2024-07-25_23.37.41_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 189, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07E1UW51H9-47f25ea2e6/____________________________2024-07-25_23.37.41_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 210, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07E1UW51H9-47f25ea2e6/____________________________2024-07-25_23.37.41_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 252, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07E1UW51H9-47f25ea2e6/____________________________2024-07-25_23.37.41_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 269, "original_w": 1570, "original_h": 412, "thumb_tiny": "AwAMADCQ9TRSnqaSgA7VdXG0fSqVXl+6PpQAUUUUAf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07E1UW51H9/____________________________2024-07-25_23.37.41.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07E1UW51H9-86f4a8db64", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1721918325.585789] <@U0331FZS7JT>: <@U0331FWGQRM>
失礼しました:sweat_drops:
Cinnnamon (1)
Upper-2：84%
Stevia：1%
Cinnamon：15%

Connamon (2)
Upper-2：90.5%
Stevia：1.5%
Cinnamon flavor：8%

で作ります！
反映します:pray:
- [1721918515.134479] <@U0331FWGQRM>: <@U0331FZS7JT>
いいよ！そのままこっちでするわ！

フレーバーはFlav.
天然のものはNat.
を追記したんやけど、それだけあってるか確認して欲しいです！
- [1721922179.848739] <@U0331FWGQRM>: *<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> cc <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>* 
*Sachetについて、*
フィルムはセバスチャン側で製造し、桃翠園に送るとのこと。
そして、そのフィルムを使用して充填して欲しいとのこと。

一応、日本側でも見積もりを取って欲しいとのこと。
- [1721953688.343929] <@U0331FWGQRM>: *Sachetについて、*
フィルムはセバスチャン側で製造し、桃翠園に送るとのこと。そして、そのフィルムを使用して充填して欲しいとのこと。

一応、日本側でも見積もりを取って欲しいとのこと。

検討中のsachetサイズは~3x10.5cm~→<http://3x10.cm|3.5x10cm>
（2g充填予定？）

※“Purer Bio Matcha”（＝Non org upp-2）は、
10.7 x 2.9cm　らしい。（銀色のやつ）

## 2024-07-26

- [1721979287.432319] <@U0331FWGQRM>: sachetのサイズについて
幅は2.5か3.5しかできないと伝えると、サイズ変更となった。
3.0x10.5▶︎3.5x10

## 2024-07-28

- [1722229780.214449] <@U0331FZS7JT>: From Sebastyan
Mango feedback is still the same. I think we need to try flavor from a different supplier.
マンゴーのフィードバックは相変わらずだ。別のサプライヤーの味を試す必要があると思う。
↓対策
①~高砂はラインとして似ているが甘味の香りが強い？~
~→小川香料にフレーバーとブレンドして再度試作~
多少寄るが微妙に異なる。
②長谷川香料に再度連絡済み（明日7/30電話来る：担当 片岡様）
③曽田香料にサンプル依頼（MOQ：30kg）100kgだとかなり安くなる→両方見積もり依頼
曽田香料：サンプル送ったら同じような香りで製造することも可能（製造の所要時間は何とも言えない）

一旦これでサンプル製造開始＋他社も合間で確認

## 2024-08-04

- [1722766534.630039] <@U0331FZS7JT>: メモ

ココナッツ・ラズベリーについては、ラズベリーを3％減らし、ココナッツを15％に増やすことをお勧めします。
↓
修正し、再度サンプル製造
- [1722766564.660419] <@U0331FZS7JT>: 私はミントなしのストロベリーレモンが好きです。
クエン酸とレモンを減らして、ストロベリーフレーバーを15％に増やすことはできますか？
ストロベリーフレーバーをもっと強くする必要があります。

## 2024-08-19

- [1724065845.508279] <@U0331FWGQRM>: <@U0331FZS7JT>
ChaiとMangoの味調整がペンディング
- [1724065852.037749] <@U0331FWGQRM>: *Chai*
使用するCinnamonが別のものがいい（カシアシナモン）がいいとのこと。
※Cinnamon matchaに使用するシナモンはセイロンシナモンでOKとのこと。。

*Mango*
曽田香料でフレーバー調整中。
- [1724066285.518149] <@U0331FWGQRM>: *<@U0331FZS7JT>* 
*7種フレーバーについて*
原料8/21出荷　　to静パック
　　8/23製造開始@静パック
8/29から9/10　印字

9/10出荷予定
- [1724110662.951109] <@U0331FWGQRM>: <@U041RJKV5JA> cc <@U0331FZS7JT>
フレーバー抹茶用のオリジナルSachetを、
Sebastyan側で製造し
→静パックにフィルムを納品
→充填、製袋、
するにあたり、
フィルムの規格
（長さ、厚み、何連なのか、など）が必要です。

そのダイラインが必要なのですが、
静パックに連絡して、入手してもらえますか？

先日聞いた時は、まずは充填可能か確認してからとのことでした。
→3.5x10.0cnで可能と確認済みのはずですので、再度確認願います。


まとめると、

*・フィルムの仕様*
（フィルムの厚みや、幅、その他、こんなフィルムだと不可などの条件など）

*・3.5x10.0のダイライン*
- [1724124302.338779] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
確認なのですが、
この印字ってこれより文字大きくできないんでしたっけ？？

Sebastyanがgreat!!って言ってるのに、
もう少し大きくてもいいけどね、
って、呟いてて、
本音はもう少し大きくていいらしいです:sweat_drops:
（無理なら無理って言いますので、可否確認を意図した質問です）
  - files: [{"id": "F07HM1U5KEW", "created": 1724124184, "timestamp": 1724124184, "name": "IMG_5838.png", "title": "IMG_5838", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 2777391, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07HM1U5KEW/img_5838.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07HM1U5KEW/download/img_5838.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07HM1U5KEW-6792d0741f/img_5838_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07HM1U5KEW-6792d0741f/img_5838_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07HM1U5KEW-6792d0741f/img_5838_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07HM1U5KEW-6792d0741f/img_5838_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 221, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07HM1U5KEW-6792d0741f/img_5838_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07HM1U5KEW-6792d0741f/img_5838_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 332, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07HM1U5KEW-6792d0741f/img_5838_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1734, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07HM1U5KEW-6792d0741f/img_5838_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 443, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07HM1U5KEW-6792d0741f/img_5838_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 472, "thumb_1024_h": 1024, "original_w": 1290, "original_h": 2796, "thumb_tiny": "AwAwABbQJO7igEnuKTOBuOBj17UeYP76fnQA4fL60u4UzerHhgT7GloAjuBm3kHqpqipLEcljjqRir8vETHuBVRZT3wT61LKRJbY3n6VZqvGwNycAD5O1T0ITGzkiCQgZO04FUeMjKBTjpk1ougdGUnAIwagW1iB4f8ACm0CG23MpOO3WrNNjhMZOGJB7VJg0JAz/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07HM1U5KEW/img_5838.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07HM1U5KEW-01f3b052d1", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1724124551.215369] <@U033G4KN4TD>: <@U0331FWGQRM>
*3行で字を大きく*という事でしょうか？
それとも*下の2行を1行目くらいまで大きく*でしょうか？
(午後色々試してみます。)
- [1724124937.368249] <@U0331FWGQRM>: <@U033G4KN4TD> 
内容はこちらです！
取り急ぎ
  - files: [{"id": "F07HPH7B09J", "created": 1724124926, "timestamp": 1724124926, "name": "IMG_5839.png", "title": "IMG_5839", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 499701, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07HPH7B09J/img_5839.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07HPH7B09J/download/img_5839.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07HPH7B09J-70fa861299/img_5839_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07HPH7B09J-70fa861299/img_5839_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07HPH7B09J-70fa861299/img_5839_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07HPH7B09J-70fa861299/img_5839_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 221, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07HPH7B09J-70fa861299/img_5839_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07HPH7B09J-70fa861299/img_5839_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 332, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07HPH7B09J-70fa861299/img_5839_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1734, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07HPH7B09J-70fa861299/img_5839_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 443, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07HPH7B09J-70fa861299/img_5839_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 472, "thumb_1024_h": 1024, "original_w": 1290, "original_h": 2796, "thumb_tiny": "AwAwABbSLAUnmD0NIx5wDim5/wBqgCUHI4opqnIxTqAGP17fjSc+gpXHzfdzTcf7NAEi9O1LTU+70xTqAGlMnOTSbPen0UAIq4paKKAP/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07HPH7B09J/img_5839.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07HPH7B09J-9db3ac02d4", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1724128043.263789] <@U0331FWGQRM>: <@U033G4KN4TD> 
大きくする文字は全部（全体的に）らしいです:sweat_drops:
- [1724130205.174749] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
wordデータ貰ったので、使うかわからないですが、共有しておきます。
  - files: [{"id": "F07HJD9VDQV", "created": 1724130172, "timestamp": 1724130172, "name": "Matcha Sachet Text.docx", "title": "Matcha Sachet Text.docx", "mimetype": "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "filetype": "docx", "pretty_type": "Word Document", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 16092, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07HJD9VDQV/matcha_sachet_text.docx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07HJD9VDQV/download/matcha_sachet_text.docx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07HJD9VDQV-c1742b0dcf/matcha_sachet_text_converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07HJD9VDQV-c1742b0dcf/matcha_sachet_text_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07HJD9VDQV/matcha_sachet_text.docx", "permalink_public": "https://slack-files.com/T033D70RR6H-F07HJD9VDQV-d8c8ae03d8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-08-20

- [1724149743.893379] <@U033G4KN4TD>: <@U0331FWGQRM>
それぞれの商品名の文字最大サイズで印字テストをおこないました。
ココナッツやストロベリーなど文字数が多いと、枠に収まらなくなり
印字不可です。
(画像のように✕がつきます)
気になる点として、
①商品ごとに文字サイズを変えても大丈夫なのか
②一番文字数の多いものに合わせた方が良いのか
以上２点を先方へ聞いていただきたいです。
よろしくお願いします。
  - files: [{"id": "F07J1AY0H9P", "created": 1724149192, "timestamp": 1724149192, "name": "PINEAPPLE LEMON.jpg", "title": "PINEAPPLE LEMON.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 79993, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07J1AY0H9P/pineapple_lemon.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07J1AY0H9P/download/pineapple_lemon.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1AY0H9P-95847c3d5c/pineapple_lemon_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1AY0H9P-95847c3d5c/pineapple_lemon_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1AY0H9P-95847c3d5c/pineapple_lemon_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 179, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1AY0H9P-95847c3d5c/pineapple_lemon_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 239, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1AY0H9P-95847c3d5c/pineapple_lemon_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1AY0H9P-95847c3d5c/pineapple_lemon_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 359, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1AY0H9P-95847c3d5c/pineapple_lemon_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 399, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1AY0H9P-95847c3d5c/pineapple_lemon_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 479, "original_w": 975, "original_h": 486, "thumb_tiny": "AwAXADCcye1G5iMiomJxxSbnxjdj86AHmSQHBB9uKb5soPzA4+lN5PfP4GgA+v6UASebkDil3ZqBsgjn9Keme5oAdSYFKaKADaPSkwPSlooAjcDPSlU0j9aFpAf/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07J1AY0H9P/pineapple_lemon.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07J1AY0H9P-b614235d5c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07HKQ3GMHT", "created": 1724149195, "timestamp": 1724149195, "name": "PEACH LEMON.jpg", "title": "PEACH LEMON.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 77208, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07HKQ3GMHT/peach_lemon.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07HKQ3GMHT/download/peach_lemon.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ3GMHT-a0b55701f6/peach_lemon_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ3GMHT-a0b55701f6/peach_lemon_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ3GMHT-a0b55701f6/peach_lemon_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 185, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ3GMHT-a0b55701f6/peach_lemon_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 246, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ3GMHT-a0b55701f6/peach_lemon_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ3GMHT-a0b55701f6/peach_lemon_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 369, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ3GMHT-a0b55701f6/peach_lemon_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 410, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ3GMHT-a0b55701f6/peach_lemon_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 492, "original_w": 975, "original_h": 500, "thumb_tiny": "AwAYADCcyEdqN7EfKOcUwmmBm9gfrQA7zpB/Dn8KaZ5f7opCzHqef96jLYPI/M0AKlwzHBFSb6r9zyKerZpASGk2+5pTRTATb7mjHufzpaSgCB+vU/nSrSSfeoWkM//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07HKQ3GMHT/peach_lemon.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07HKQ3GMHT-872651fdba", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07HNHJ6S2F", "created": 1724149198, "timestamp": 1724149198, "name": "GINGER LEMON.jpg", "title": "GINGER LEMON.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 77240, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07HNHJ6S2F/ginger_lemon.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07HNHJ6S2F/download/ginger_lemon.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNHJ6S2F-0bcae94613/ginger_lemon_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNHJ6S2F-0bcae94613/ginger_lemon_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNHJ6S2F-0bcae94613/ginger_lemon_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 194, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNHJ6S2F-0bcae94613/ginger_lemon_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 258, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNHJ6S2F-0bcae94613/ginger_lemon_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNHJ6S2F-0bcae94613/ginger_lemon_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 387, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNHJ6S2F-0bcae94613/ginger_lemon_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 430, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNHJ6S2F-0bcae94613/ginger_lemon_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 516, "original_w": 961, "original_h": 517, "thumb_tiny": "AwAZADCyTSE8cdajLkCmeY3oPzoAlHme35UYmPTaKi8xv8tSb2xnj/vqgCwAwB3Hmlqv5r4PI/OnLISOooAKbj3NOooAbt+tGPc06igBhHHU0imnN0pq0gP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07HNHJ6S2F/ginger_lemon.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07HNHJ6S2F-1c44d18400", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07HNHJC551", "created": 1724149201, "timestamp": 1724149201, "name": "STRAWBERRY LEMON.jpg", "title": "STRAWBERRY LEMON.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 74686, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07HNHJC551/strawberry_lemon.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07HNHJC551/download/strawberry_lemon.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNHJC551-10f5049ac3/strawberry_lemon_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNHJC551-10f5049ac3/strawberry_lemon_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNHJC551-10f5049ac3/strawberry_lemon_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 198, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNHJC551-10f5049ac3/strawberry_lemon_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 263, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNHJC551-10f5049ac3/strawberry_lemon_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNHJC551-10f5049ac3/strawberry_lemon_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 395, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNHJC551-10f5049ac3/strawberry_lemon_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 439, "original_w": 913, "original_h": 501, "thumb_tiny": "AwAaADCzuX1ppk/u4OPWoWYjoP1pNzDoB+JoAf8AaSP4P1pPtf8AsfrTNzHPQfQil+b2/OgCVLhX46Gn7xVXlWyNv509WJ9KAHEUm33paKAE2+9GPc06koAjYc9TSrTX+9TloA//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07HNHJC551/strawberry_lemon.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07HNHJC551-7fc9582ed6", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07HR5NLK6G", "created": 1724149203, "timestamp": 1724149203, "name": "CINNAMON.jpg", "title": "CINNAMON.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 87245, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07HR5NLK6G/cinnamon.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07HR5NLK6G/download/cinnamon.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07HR5NLK6G-660518586a/cinnamon_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07HR5NLK6G-660518586a/cinnamon_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07HR5NLK6G-660518586a/cinnamon_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 228, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07HR5NLK6G-660518586a/cinnamon_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 304, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07HR5NLK6G-660518586a/cinnamon_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07HR5NLK6G-660518586a/cinnamon_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 455, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07HR5NLK6G-660518586a/cinnamon_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 506, "original_w": 958, "original_h": 606, "thumb_tiny": "AwAeADC1TGdV604yD0qIyryDg/jQAefH6n8qXz4z0yfoKZ5ig8bB7Uvmr3CfrQBIrhulOqr5wDHGKkEtAAxOO9NwfQ/lT6KAI8HPT9BSNn0P5VLio3oAhOdx6/lT0z3ph605TSGf/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07HR5NLK6G/cinnamon.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07HR5NLK6G-6b3cf64610", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07HKQ49ADT", "created": 1724149206, "timestamp": 1724149206, "name": "COCONUT RASPBERRY.jpg", "title": "COCONUT RASPBERRY.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 88484, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07HKQ49ADT/coconut_raspberry.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07HKQ49ADT/download/coconut_raspberry.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ49ADT-33077b7c33/coconut_raspberry_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ49ADT-33077b7c33/coconut_raspberry_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ49ADT-33077b7c33/coconut_raspberry_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 206, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ49ADT-33077b7c33/coconut_raspberry_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 275, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ49ADT-33077b7c33/coconut_raspberry_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ49ADT-33077b7c33/coconut_raspberry_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 413, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ49ADT-33077b7c33/coconut_raspberry_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 459, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07HKQ49ADT-33077b7c33/coconut_raspberry_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 550, "original_w": 1003, "original_h": 575, "thumb_tiny": "AwAbADC5TSwyeCcVEzgetM8zHQH8qAJfOX0b8qTz1J4DflUJOe35CkJLDkNz7UAWtwNGaqbipx8xp6uSehFADzzTNvvT6KAGbT7UFeOo/KnmkPSgCu33u1PSoz96nrSGf//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07HKQ49ADT/coconut_raspberry.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07HKQ49ADT-d18bbee4cb", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07HNMB4GFL", "created": 1724149558, "timestamp": 1724149558, "name": "S__217759754.jpg", "title": "S__217759754.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 307093, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07HNMB4GFL/s__217759754.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07HNMB4GFL/download/s__217759754.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNMB4GFL-55b3c86ce3/s__217759754_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNMB4GFL-55b3c86ce3/s__217759754_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNMB4GFL-55b3c86ce3/s__217759754_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNMB4GFL-55b3c86ce3/s__217759754_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNMB4GFL-55b3c86ce3/s__217759754_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNMB4GFL-55b3c86ce3/s__217759754_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNMB4GFL-55b3c86ce3/s__217759754_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNMB4GFL-55b3c86ce3/s__217759754_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07HNMB4GFL-55b3c86ce3/s__217759754_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADBwjY89BTvJ+tSSSLGMn8qrtPIeisB7CsyiTyfY0eT7God0h/5ZSGjMvaKQUa9hXJjCe2ajZHQZIyPWgTTIMlGwOuaetyrfw8+lAyGZ9241J5SbVyzZIHeq8vAYGrSnAGT2HarpksYI4/7zfnTjFH0O786eM4zk0uDnqa11JuRNbx7GIBzg9zVYHDZq6w689qpKMkVlMpFmdQUyetVSWH8TfnVub/VmqjdagYhJ/vN+dJ+J/Og0UXAUAelTooCgjvUIqdfuj6UID//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07HNMB4GFL/s__217759754.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07HNMB4GFL-0c502ae2ed", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07H85BQ831", "created": 1724149652, "timestamp": 1724149652, "name": "745842423.921478.mp4", "title": "745842423.921478.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 1197087, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "complete", "locale": "en-US", "preview": {"content": "Pérez y", "has_more": false}}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F07H85BQ831-1ff2072b64/745842423.921478.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F07H85BQ831-1ff2072b64/745842423.921478.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07H85BQ831/download/745842423.921478.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "vtt": "https://files.slack.com/files-tmb/T033D70RR6H-F07H85BQ831-1ff2072b64/file.vtt?_xcb=93436&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F07H85BQ831-1ff2072b64/file.m3u8?_xcb=93436&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTcxMDg4NyxBVkVSQUdFLUJBTkRXSURUSD0xNzEwODg3LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTEyODB4NzIwLEZSQU1FLVJBVEU9MjkuOTcwLFNVQlRJVExFUz0ic3VicyIKZGF0YTphcHBsaWNhdGlvbi92bmQuYXBwbGUubXBlZ3VybDtiYXNlNjQsSTBWWVZFMHpWUW9qUlZoVUxWZ3RWa1ZTVTBsUFRqb3pDaU5GV0ZRdFdDMVVRVkpIUlZSRVZWSkJWRWxQVGpvM0NpTkZXRlF0V0MxTlJVUkpRUzFUUlZGVlJVNURSVG94Q2lORldGUXRXQzFRVEVGWlRFbFRWQzFVV1ZCRk9sWlBSQW9qUlZoVVNVNUdPalF1TmpBMUxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzU0RnMVFsRTRNekV0TVdabU1qQTNNbUkyTkM5bWFXeGxYMGhmTWpZMFh6RXlPREI0TnpJd1h6TTFNREJMUWxCVFh6ZFJWa0pTWHpBd01EQXhMblJ6Q2lORldGUXRXQzFGVGtSTVNWTlVDZz09CiNFWFQtWC1NRURJQTpUWVBFPVNVQlRJVExFUyxHUk9VUC1JRD0ic3VicyIsTkFNRT0iRW5nbGlzaCIsREVGQVVMVD1ZRVMsQVVUT1NFTEVDVD1ZRVMsRk9SQ0VEPU5PLExBTkdVQUdFPSJlbmciLFVSST0iZGF0YTphcHBsaWNhdGlvbi92bmQuYXBwbGUubXBlZ3VybDtiYXNlNjQsSTBWWVZFMHpWUW9qUlZoVUxWZ3RWa1ZTVTBsUFRqb3pDaU5GV0ZRdFdDMVVRVkpIUlZSRVZWSkJWRWxQVGpvMk1EQUtJMFZZVkMxWUxVMUZSRWxCTFZORlVWVkZUa05GT2pFS0kwVllWQzFZTFZCTVFWbE1TVk5VTFZSWlVFVTZWazlFQ2lORldGUkpUa1k2TkM0Mk1EUXNDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURkSU9EVkNVVGd6TVMweFptWXlNRGN5WWpZMEwyWnBiR1V1ZG5SMENpTkZXRlF0V0MxRlRrUk1TVk5VIgo=", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F07H85BQ831-1ff2072b64/745842423.921478_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 4604, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F07H85BQ831-1ff2072b64/745842423.921478_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 1280, "thumb_video_h": 720, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07H85BQ831/745842423.921478.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F07H85BQ831-8260e23d27", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07J1BVPCPK", "created": 1724149656, "timestamp": 1724149656, "name": "S__217759756.jpg", "title": "S__217759756.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 150682, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07J1BVPCPK/s__217759756.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07J1BVPCPK/download/s__217759756.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1BVPCPK-60ede96ac9/s__217759756_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1BVPCPK-60ede96ac9/s__217759756_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1BVPCPK-60ede96ac9/s__217759756_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1BVPCPK-60ede96ac9/s__217759756_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1BVPCPK-60ede96ac9/s__217759756_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1BVPCPK-60ede96ac9/s__217759756_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1BVPCPK-60ede96ac9/s__217759756_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1BVPCPK-60ede96ac9/s__217759756_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07J1BVPCPK-60ede96ac9/s__217759756_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADCwJUbowpC/PtWam7AOat25L/KzfSlcbRPnNJSFQo5f9KaXQHufrTEP3CgNUSZYH61JQBTA3MFUVYWIAAelJbR4XcepqcCkNjNg780mAO1SGmmgQmcUZoopgPAxThSCnCkA00w080w0AFJS0lAH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07J1BVPCPK/s__217759756.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07J1BVPCPK-141afed070", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-08-27

- [1724776193.997629] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
セバスチャン（おそらく中国？）から、下記が届くそうです。（明日発送とのこと）
・60g bag　各種（x 各3袋）
・sachet　各種
・sachet 用film

60g bagについて、
１つは桃翠園保管用で、
残り２つには抹茶を入れて（低品質の抹茶でOK）、写真撮影用のbag として発送お願いします。
送り先はロサンゼルスです。
ーーー
ATTN: Sebastyan Meixger
ADDRESS: 6933 Santa Monica Blvd., APT 703, CA 90038 Los Angeles, USA
Postal code: 90038
Phone: <tel:+14243826807|+1 424-382-6807>
ーーー
  - files: [{"id": "F07K40P9AC9", "created": 1724776169, "timestamp": 1724776169, "name": "WhatsApp Image 2024-08-28 at 00.53.59.jpeg", "title": "WhatsApp Image 2024-08-28 at 00.53.59.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 90072, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07K40P9AC9/whatsapp_image_2024-08-28_at_00.53.59.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07K40P9AC9/download/whatsapp_image_2024-08-28_at_00.53.59.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40P9AC9-ef1684f273/whatsapp_image_2024-08-28_at_00.53.59_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40P9AC9-ef1684f273/whatsapp_image_2024-08-28_at_00.53.59_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40P9AC9-ef1684f273/whatsapp_image_2024-08-28_at_00.53.59_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40P9AC9-ef1684f273/whatsapp_image_2024-08-28_at_00.53.59_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40P9AC9-ef1684f273/whatsapp_image_2024-08-28_at_00.53.59_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40P9AC9-ef1684f273/whatsapp_image_2024-08-28_at_00.53.59_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40P9AC9-ef1684f273/whatsapp_image_2024-08-28_at_00.53.59_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40P9AC9-ef1684f273/whatsapp_image_2024-08-28_at_00.53.59_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40P9AC9-ef1684f273/whatsapp_image_2024-08-28_at_00.53.59_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 810, "original_h": 1080, "thumb_tiny": "AwAwACQL5H4ZxTUY7u2adANyLxntTjEFO4CpEPPzBXxyetKKRd5jHTPvQC4PzL+IptjQ6loooGR4bI2kLSq0mORUMgXzPmYjjjFOUNj5JAfrSGSHzSflCge5oG/POPwpjsBIR5u32xT495AJII9qLgPopaKYiBnYNgR7hS7kJ5BQ+4qQCl2hvvDNKwxgMLnOVJPrTvLXcGXjHpSmGM/wilVQvSgLi0UhODSbqYj/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07K40P9AC9/whatsapp_image_2024-08-28_at_00.53.59.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07K40P9AC9-f80b7dd156", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07JNE0DE3F", "created": 1724776172, "timestamp": 1724776172, "name": "WhatsApp Image 2024-08-28 at 00.54.17.jpeg", "title": "WhatsApp Image 2024-08-28 at 00.54.17.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 85141, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07JNE0DE3F/whatsapp_image_2024-08-28_at_00.54.17.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07JNE0DE3F/download/whatsapp_image_2024-08-28_at_00.54.17.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE0DE3F-3de2ad3e3d/whatsapp_image_2024-08-28_at_00.54.17_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE0DE3F-3de2ad3e3d/whatsapp_image_2024-08-28_at_00.54.17_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE0DE3F-3de2ad3e3d/whatsapp_image_2024-08-28_at_00.54.17_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE0DE3F-3de2ad3e3d/whatsapp_image_2024-08-28_at_00.54.17_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE0DE3F-3de2ad3e3d/whatsapp_image_2024-08-28_at_00.54.17_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE0DE3F-3de2ad3e3d/whatsapp_image_2024-08-28_at_00.54.17_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE0DE3F-3de2ad3e3d/whatsapp_image_2024-08-28_at_00.54.17_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE0DE3F-3de2ad3e3d/whatsapp_image_2024-08-28_at_00.54.17_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE0DE3F-3de2ad3e3d/whatsapp_image_2024-08-28_at_00.54.17_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 810, "original_h": 1080, "thumb_tiny": "AwAwACR8lyEOAuaDdAD7v6ikClXcfjSGUA7SP0qbGis+g4XI252/qKUXIAyUP5imLMmduP0qZcEYKjHbiiw2l2JQeKXNJRSMyI/fP0qu67WwW5NTf8tG9gKaXJcKpHB5zTNIuxFtOM5OM9cVYQEYBOakQHytrcnvUcZ/nimLmuTUUlFSQVwTvf60isQ6hl3MOc9M05kJYkd6b5Z9T+dUUhzSykYCbc981IgAUY7VGA23GTj605Vx6/jQFrEtFJmjNSI//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07JNE0DE3F/whatsapp_image_2024-08-28_at_00.54.17.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07JNE0DE3F-89b695bb3d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07K40Q5J49", "created": 1724776175, "timestamp": 1724776175, "name": "WhatsApp Image 2024-08-28 at 00.54.23.jpeg", "title": "WhatsApp Image 2024-08-28 at 00.54.23.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 67931, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07K40Q5J49/whatsapp_image_2024-08-28_at_00.54.23.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07K40Q5J49/download/whatsapp_image_2024-08-28_at_00.54.23.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40Q5J49-5a78e3b5de/whatsapp_image_2024-08-28_at_00.54.23_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40Q5J49-5a78e3b5de/whatsapp_image_2024-08-28_at_00.54.23_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40Q5J49-5a78e3b5de/whatsapp_image_2024-08-28_at_00.54.23_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40Q5J49-5a78e3b5de/whatsapp_image_2024-08-28_at_00.54.23_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40Q5J49-5a78e3b5de/whatsapp_image_2024-08-28_at_00.54.23_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40Q5J49-5a78e3b5de/whatsapp_image_2024-08-28_at_00.54.23_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40Q5J49-5a78e3b5de/whatsapp_image_2024-08-28_at_00.54.23_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40Q5J49-5a78e3b5de/whatsapp_image_2024-08-28_at_00.54.23_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07K40Q5J49-5a78e3b5de/whatsapp_image_2024-08-28_at_00.54.23_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 810, "original_h": 1080, "thumb_tiny": "AwAwACSwWAOO9G8DHPWoznzv+A0m4Dr9KhtlJXJg6nvTgwPQ1CClSKBSTYND80ZooqySA/60fSkePdyDjFB/1nHpQ3TINRIpDQORjn3xUq/eFQiQIMLyf5VNFwgz1FKOpTJaKKK0MysrZkb2AFOyFPsaYF2kn1px57VLVykxQFJ6CnhccjpTOMYxTw3y4xQkDaHZozTc0uaok//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07K40Q5J49/whatsapp_image_2024-08-28_at_00.54.23.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07K40Q5J49-64bf3fdbb5", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07JR7BRJG3", "created": 1724776178, "timestamp": 1724776178, "name": "WhatsApp Image 2024-08-28 at 00.54.25.jpeg", "title": "WhatsApp Image 2024-08-28 at 00.54.25.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 80375, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07JR7BRJG3/whatsapp_image_2024-08-28_at_00.54.25.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07JR7BRJG3/download/whatsapp_image_2024-08-28_at_00.54.25.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07JR7BRJG3-34541a1895/whatsapp_image_2024-08-28_at_00.54.25_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07JR7BRJG3-34541a1895/whatsapp_image_2024-08-28_at_00.54.25_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07JR7BRJG3-34541a1895/whatsapp_image_2024-08-28_at_00.54.25_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07JR7BRJG3-34541a1895/whatsapp_image_2024-08-28_at_00.54.25_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07JR7BRJG3-34541a1895/whatsapp_image_2024-08-28_at_00.54.25_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07JR7BRJG3-34541a1895/whatsapp_image_2024-08-28_at_00.54.25_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07JR7BRJG3-34541a1895/whatsapp_image_2024-08-28_at_00.54.25_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07JR7BRJG3-34541a1895/whatsapp_image_2024-08-28_at_00.54.25_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07JR7BRJG3-34541a1895/whatsapp_image_2024-08-28_at_00.54.25_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 810, "original_h": 1080, "thumb_tiny": "AwAwACSx9aTI9aa/VR70mEU/NxUNvoMk49aBTB5ZGQRTwoGB6UJsYtFLRVCInGWX60SgEDLBeO4pT95frTJXYyKihSc96QDWjKoGBBHFTKwZiV6UoJBwMfSjvQFx2KMUCjNMCDdmZR6AmkUKrk4Ofp0p2Oc96WkAu/1B/Kn44B9aZuPrTtxIwaACiiimB//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07JR7BRJG3/whatsapp_image_2024-08-28_at_00.54.25.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07JR7BRJG3-c77d8988f6", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07JAPM2VPH", "created": 1724776181, "timestamp": 1724776181, "name": "WhatsApp Image 2024-08-28 at 00.54.32.jpeg", "title": "WhatsApp Image 2024-08-28 at 00.54.32.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 136237, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07JAPM2VPH/whatsapp_image_2024-08-28_at_00.54.32.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07JAPM2VPH/download/whatsapp_image_2024-08-28_at_00.54.32.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07JAPM2VPH-50ec1c6923/whatsapp_image_2024-08-28_at_00.54.32_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07JAPM2VPH-50ec1c6923/whatsapp_image_2024-08-28_at_00.54.32_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07JAPM2VPH-50ec1c6923/whatsapp_image_2024-08-28_at_00.54.32_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07JAPM2VPH-50ec1c6923/whatsapp_image_2024-08-28_at_00.54.32_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07JAPM2VPH-50ec1c6923/whatsapp_image_2024-08-28_at_00.54.32_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07JAPM2VPH-50ec1c6923/whatsapp_image_2024-08-28_at_00.54.32_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07JAPM2VPH-50ec1c6923/whatsapp_image_2024-08-28_at_00.54.32_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07JAPM2VPH-50ec1c6923/whatsapp_image_2024-08-28_at_00.54.32_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07JAPM2VPH-50ec1c6923/whatsapp_image_2024-08-28_at_00.54.32_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 810, "original_h": 1080, "thumb_tiny": "AwAwACSNbJiuSvP1p4sj/d/8eq0CcDntSg496kViqLM+g/76pHtikbNgcD1q6D9KjYM0EgYYwD+NMdjPFGaSiqAvrzGh9VFKOelERxbx/wC6Kdn2P5ioATB9qdn924OOh/lSHlSMdfelA3Z6c9aAM0dKWm5o3VQF+I/uYx/sinVFbkNBGSf4alJAXgnP1pAOwSOKcnB5IqLepUhmC/jTBLBGdxlBI9KAKL8Ow9zTc0jsC7EdCaTNMD//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07JAPM2VPH/whatsapp_image_2024-08-28_at_00.54.32.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07JAPM2VPH-ddaeb8f3f7", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07JRAHDHS6", "created": 1724776184, "timestamp": 1724776184, "name": "WhatsApp Image 2024-08-28 at 00.54.36.jpeg", "title": "WhatsApp Image 2024-08-28 at 00.54.36.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 97801, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07JRAHDHS6/whatsapp_image_2024-08-28_at_00.54.36.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07JRAHDHS6/download/whatsapp_image_2024-08-28_at_00.54.36.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07JRAHDHS6-e25172d0c8/whatsapp_image_2024-08-28_at_00.54.36_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07JRAHDHS6-e25172d0c8/whatsapp_image_2024-08-28_at_00.54.36_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07JRAHDHS6-e25172d0c8/whatsapp_image_2024-08-28_at_00.54.36_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07JRAHDHS6-e25172d0c8/whatsapp_image_2024-08-28_at_00.54.36_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07JRAHDHS6-e25172d0c8/whatsapp_image_2024-08-28_at_00.54.36_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07JRAHDHS6-e25172d0c8/whatsapp_image_2024-08-28_at_00.54.36_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07JRAHDHS6-e25172d0c8/whatsapp_image_2024-08-28_at_00.54.36_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07JRAHDHS6-e25172d0c8/whatsapp_image_2024-08-28_at_00.54.36_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07JRAHDHS6-e25172d0c8/whatsapp_image_2024-08-28_at_00.54.36_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 810, "original_h": 1080, "thumb_tiny": "AwAwACSwKCQoyTgCgGmXB/ct9KQAZ4/72fwqSokjQ/8ALMdqmxTKduglGKWikSMBqO5P7o08Go7g/JTAlhb92mf7op+QSaitmXyE3dcY/WnKeOufwoGx/FLx60w0lIQwGopz8tPBoIDUwGW7L5IDFccg5qcMCMqciofJXOen0qRQFXA6UFO1h+aM03NGaRJ//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07JRAHDHS6/whatsapp_image_2024-08-28_at_00.54.36.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07JRAHDHS6-88568fa68f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07JNE264BF", "created": 1724776186, "timestamp": 1724776186, "name": "WhatsApp Image 2024-08-28 at 01.02.06.jpeg", "title": "WhatsApp Image 2024-08-28 at 01.02.06.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 142436, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07JNE264BF/whatsapp_image_2024-08-28_at_01.02.06.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07JNE264BF/download/whatsapp_image_2024-08-28_at_01.02.06.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE264BF-265eaf9b1c/whatsapp_image_2024-08-28_at_01.02.06_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE264BF-265eaf9b1c/whatsapp_image_2024-08-28_at_01.02.06_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE264BF-265eaf9b1c/whatsapp_image_2024-08-28_at_01.02.06_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 203, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE264BF-265eaf9b1c/whatsapp_image_2024-08-28_at_01.02.06_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 270, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE264BF-265eaf9b1c/whatsapp_image_2024-08-28_at_01.02.06_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE264BF-265eaf9b1c/whatsapp_image_2024-08-28_at_01.02.06_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 405, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE264BF-265eaf9b1c/whatsapp_image_2024-08-28_at_01.02.06_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 450, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE264BF-265eaf9b1c/whatsapp_image_2024-08-28_at_01.02.06_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 540, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07JNE264BF-265eaf9b1c/whatsapp_image_2024-08-28_at_01.02.06_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 576, "original_w": 1080, "original_h": 608, "thumb_tiny": "AwAbADBscJCYyKhYjdheferbkbMA89KrBecDvQBJEBt525PTika33McEDIp4UqQMcH9Ke5APoaAGTFkjA4zjmqrTscDg4GOlWbk7oCR1z+lUOQc80AaUgAUEdjUPQ7lODUsvSq+SCcUAS+cR1xmlLq/+9VYk5q7HGgKEL1AoAULlMN3FZsqlWKnqDitQ9TVS5UeeOOoGaAP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07JNE264BF/whatsapp_image_2024-08-28_at_01.02.06.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07JNE264BF-4bf71135ac", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07KE4BQ95E", "created": 1724776189, "timestamp": 1724776189, "name": "WhatsApp Video 2024-08-28 at 01.05.32.mp4", "title": "WhatsApp Video 2024-08-28 at 01.05.32.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 3466556, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F07KE4BQ95E-f21dec7318/whatsapp_video_2024-08-28_at_01.05.32.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F07KE4BQ95E-f21dec7318/whatsapp_video_2024-08-28_at_01.05.32.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07KE4BQ95E/download/whatsapp_video_2024-08-28_at_01.05.32.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F07KE4BQ95E-f21dec7318/file.m3u8?_xcb=cc927&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTU3ODM3MyxBVkVSQUdFLUJBTkRXSURUSD0xNTAxNzQ2LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTYxMngxMDgwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1MwVTBRbEU1TlVVdFpqSXhaR1ZqTnpNeE9DOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TVM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNTMFUwUWxFNU5VVXRaakl4WkdWak56TXhPQzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01pNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzUzBVMFFsRTVOVVV0WmpJeFpHVmpOek14T0M5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNeTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1MwVTBRbEU1TlVVdFpqSXhaR1ZqTnpNeE9DOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TkM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNTMFUwUWxFNU5VVXRaakl4WkdWak56TXhPQzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd05TNTBjd29qUlZoVVNVNUdPalF1TWpjeExBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzUzBVMFFsRTVOVVV0WmpJeFpHVmpOek14T0M5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOaTUwY3dvalJWaFVMVmd0UlU1RVRFbFRWQW89CiNFWFQtWC1TVFJFQU0tSU5GOkJBTkRXSURUSD05NDA4MTMsQVZFUkFHRS1CQU5EV0lEVEg9OTAzNzUyLENPREVDUz0iYXZjMS42NDAwMWUsbXA0YS40MC41IixSRVNPTFVUSU9OPTQwOHg3MjAsRlJBTUUtUkFURT0yOS45NzAKaHR0cHM6Ly9maWxlcy5zbGFjay5jb20vZmlsZXMtdG1iL1QwMzNENzBSUjZILUYwN0tFNEJROTVFLWYyMWRlYzczMTgvZmlsZV9IXzI2NF8xMjgweDcyMF8zNTAwS0JQU183UVZCUi5tM3U4Cg==", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F07KE4BQ95E-f21dec7318/whatsapp_video_2024-08-28_at_01.05.32_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 34300, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F07KE4BQ95E-f21dec7318/whatsapp_video_2024-08-28_at_01.05.32_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 480, "thumb_video_h": 848, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07KE4BQ95E/whatsapp_video_2024-08-28_at_01.05.32.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F07KE4BQ95E-0a3ee626dc", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1724780287.589769] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
ヤバいです。。。

下記内容を10月中ば可能ですか？
とのことです。
<@U0331FZS7JT> 明日またMTGさせてください。

&lt;60g bag&gt;
-Vanilla x 3000 bag
-Cinnamon x 2000 bag
~-Coconut Raspberry x 2000 bag~
-Peach Lemon x 2000 bag
-Pineapple Lemon x 2000 bag
-Ginger Lemon x 2000 bag
-Strawberry Lemon x 2000 bag

&lt;2.5g sachet&gt;
-Vanilla x 5000 sachet
-Cinnamon x 5000 sachet
~-Coconut Raspberry x 5000 sachet~
-Peach Lemon x 5000 sachet
-Pineapple Lemon x 5000 sachet
-Ginger Lemon x 5000 sachet
-Strawberry Lemon x 5000 sachet
- [1724780450.892029] <@U0331FWGQRM>: メモ
-Coconut Raspberry x 2000 bag
の注文は来年にするとのこと。（今回はなし）

*sachetについて*
中国からフィルムが届いたら、
それを持って静パックへ行って相談する。

（タイミング的に吉村での製造では間に合わないか。。間に合えば吉村でもフィルムを製造したかった。）
- [1724802910.901939] <@U0331FWGQRM>: メモ
静パックの元々のスケジュール
・ 25㎜巾スケジュール
　 9/12(木）～9/21(土）までの7日間

・ 35㎜巾スケジュール
　*9/28(水）～10/7(月）までの7日間*

ーーー
25㎜×130Pの場合の製造スケジュールを再検討
・Strawberry Lemon Matcha 9/3（水）
・Lemon Ginger Matcha 9/5（木）
・Pineapple Lemon Matcha 9/11(水）
・Peach Lemon Matcha 9/17(火）
・Raspberry Coconut Matcha 9/18(水）
・Cinnamon Matcha 9/19(木）
・Vanilla Matcha 9/20(金）
- [1724803737.614239] <@U0331FWGQRM>: やりとり全文

● *Sebastyan （Matcha Land）：*
各フレーバーのバッグを3つずつお送りします。1つはあなたが保管してかまいませんが、残りの2つのバッグに60gの超低品質の抹茶粉末を詰め、熱シールして私に送り返してください。写真撮影用に使用します。
● *Sebastyan （Matcha Land）：*
それは可能ですか？
● *Sebastyan （Matcha Land）：*
バッグは開封しません。
○ *Koshiro Matsui：*
OK、はい、それは可能です！サンプルバッグを受け取り次第、行います。
● *Sebastyan （Matcha Land）：*
サシェの幅は35mmだと思いますが、問題は長さだけですよね？
● *Sebastyan （Matcha Land）：*
長さは10.5で、11にする必要があります。
○ *Koshiro Matsui：*
はい、正しいです。
○ *Koshiro Matsui：*
以前に受け取った画像では幅が30mmと表示されていたので心配していましたが、あなたの理解は正しいです。
○ *Koshiro Matsui：*
配送先はいつも通りでよろしいですか？以下の通りです。
ATTN: MatchaLand
Sebastyan Meixger
ADDRESS: Hegnaustrasse 58, 8602 Wangen, Switzerland
Postal code: 8602
Phone: <tel:+41794059719|+41-794059719>
● *Sebastyan （Matcha Land）：*
いいえ、ロサンゼルスでお願いします。
○ *Koshiro Matsui：*
OK、こちらで合っていますか？
ATTN: Sebastyan Meixger
ADDRESS: 6933 Santa Monica Blvd., APT 703, CA 90038 Los Angeles, USA
Postal code: 90038
Phone: <tel:+14243826807|+1 424-382-6807>
● *Sebastyan （Matcha Land）：*
はい。
● *Sebastyan （Matcha Land）：*
タイミング的に、サシェの生産を一時停止して、フルサイズのバッグに切り替えるのは遅すぎますか？
● *Sebastyan （Matcha Land）：*
少なくともシルバーサシェの製造を停止してください。
● *Sebastyan （Matcha Land）：*
パッケージのことです。
● *Sebastyan （Matcha Land）：*
9月末までかかるのは、やはり時間がかかりすぎます。
● *Sebastyan （Matcha Land）：*
その代わりに、各フレーバーの更新版を私に送ってもらい、その後フル生産に移行したいと思います。
○ *Koshiro Matsui：*
シルバーサシェ（TSE-MTL-009-24）の生産を一時停止することは可能です。
60gのフレーバー付き抹茶バッグについては、どのタイプを何個注文する予定ですか？生産数量に応じて、出荷予定日は大きく異なる可能性があります。
● *Sebastyan （Matcha Land）：*
理解しました。
● *Sebastyan （Matcha Land）：*
ありがとうございます。
● *Sebastyan （Matcha Land）：*
目標は10月中旬に出荷することです。
● *Sebastyan （Matcha Land）：*
サンドラからパッケージを受け取ってから出荷までにどれくらいかかりますか？（もし既に材料を注文し、製品を混ぜている場合）
● *Sebastyan （Matcha Land）：*
*受け取り＝工場に配送された場合
○ *Koshiro Matsui：*
数量によります。各タイプのバッグをどれくらい注文するかが分からないと、必要な時間を見積もるのが難しいです。
● *Sebastyan （Matcha Land）：*
最小は2000個、
● *Sebastyan （Matcha Land）：*
最大は4000個です。
● *Sebastyan （Matcha Land）：*
フレーバーごとに異なります。
● *Sebastyan （Matcha Land）：*
そしてサシェフレーバーごとに5000個です。
○ *Koshiro Matsui：*
以下の数量で注文する予定で、出荷予定日を知りたいということでしょうか？
&lt;60gバッグ&gt;
• バニラ x 2000バッグ
• シナモン x 2000バッグ
• ココナッツラズベリー x 2000バッグ
• ピーチレモン x 2000バッグ
• パイナップルレモン x 2000バッグ
• ジンジャーレモン x 2000バッグ
• ストロベリーレモン x 2000バッグ
○ *Koshiro Matsui：*
原材料を調達し、混合を開始する必要がありますので、正確な数量を教えていただけますか？
現在、日本では夜遅いので、明日の朝、工場長に確認します。
○ *Koshiro Matsui：*
シルバーサシェではなく、デザインされたサシェを指しているのですか？
○ *Koshiro Matsui：*
シルバーサシェ（TSE-MTL-009-24）2000個の注文を一時停止ではなく、完全にキャンセルしたいということでしょうか？
● *Sebastyan （Matcha Land）：*
これは最小限の注文ですが、特定のフレーバー、たとえばバニラは最低3000個になります。
● *Sebastyan （Matcha Land）：*
はい、理解していただきありがとうございます。しかし、原材料は引き続き使用します。
● *Sebastyan （Matcha Land）：*
デザインされたサシェです。
○ *Koshiro Matsui：*
確認ですが、以下の注文を10月中旬までに出荷可能か確認すればよろしいでしょうか？
&lt;60gバッグ&gt;
• バニラ x 3000バッグ
• シナモン x 2000バッグ
• ピーチレモン x 2000バッグ
• パイナップルレモン x 2000バッグ
• ジンジャーレモン x 2000バッグ
• ストロベリーレモン x 2000バッグ
&lt;2.5gサシェ&gt;
• バニラ x 5000サシェ
• シナモン x 5000サシェ
• ピーチレモン x 5000サシェ
• パイナップルレモン x 5000サシェ
• ジンジャーレモン x 5000サシェ
• ストロベリーレモン x 5000サシェ
● *Sebastyan （Matcha Land）：*
はい、お願いします。
● *Sebastyan （Matcha Land）：*
*一点だけ変更があります。ココナッツラズベリーは生産しません。これは後ほど、来年に発売予定です。
○ *Koshiro Matsui：*
&lt;60gバッグ&gt;
• バニラ x 3000バッグ
• シナモン x 2000バッグ
• ピーチレモン x 2000バッグ
• パイナップルレモン x 2000バッグ
• ジンジャーレモン x 2000バッグ
• ストロベリーレモン x 2000バッグ
&lt;2.5gサシェ&gt;
• バニラ x 5000サシェ
• シナモン x 5000サシェ
• ピーチレモン x 5000サシェ
• パイナップルレモン x 5000サシェ
• ジンジャーレモン x 5000サシェ
• ストロベリーレモン x 5000サシェ
● *Sebastyan （Matcha Land）：*
はい。
○ *Koshiro Matsui：*
OK、明日確認します。
- [1724805495.991379] <@U0331FWGQRM>: Todo
・サンプル袋3袋届いたら2袋詰めて送る（中身なんんでもOK）
（進捗確認）
・8/31に“全”栄養成分入手？
→ピーチのみデータの納期が遅くなる。
　9/5？状況不明

・セバスチャンにUpdate版のブレンド抹茶のサンプルを送る。各何g必要か確認。
※今週末にブレンド抹茶が帰ってくる。
そこから一部ピックしてサンプルとしてセバスチャンに発送。
→OKなら製造開始？？
- [1724805770.693839] <@U0331FWGQRM>: 60g袋　工数
300-400袋/5h・人（700-800袋/5h・人）
- [1724816383.545679] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
Sachetを除いて、<60g designed bag>だけの場合、もし9/25に袋が届いたら、いつ出荷可能ですか？
10/8くらいにします？
10/4にします？:sweat_drops:

-Vanilla x 3000 bag
-Cinnamon x 2000 bag
-Peach Lemon x 2000 bag
-Pineapple Lemon x 2000 bag
-Ginger Lemon x 2000 bag
-Strawberry Lemon x 2000 bag
- [1724819925.359919] <@U0331FWGQRM>: ーーーーーーーーーーーー
*( B2 : Non organic )*
*60g bags* 
Early October shipment: 4,000
Early November shipment: 5,000
Early December shipment: 4,000

*2.0g Silver sachet with text*
Early October: 5,000
Early November 10,000
Early December: to be determined
ーーーーーーーーーーーー
- [1724819950.835159] <@U0331FWGQRM>: ーーーーーーーーーーーー
*60g flavors:*

Early October:
-Vanilla 3,000
-Cinnamon 2,000
-Peach Lemon 2,000
-Pineapple Lemon 2,000
-Ginger Lemon 2,000
-Strawberry Lemon 2,000

Early November:
-Vanilla 4,000 bag
-Cinnamon 3,000
-Peach Lemon 3,000
-Pineapple Lemon 3,000
-Ginger Lemon 3,000
-Strawberry Lemon 3,000

Early December (estimate will most likely change)
-Vanilla 3,000
-Cinnamon 2,000
-Peach Lemon 2,000
-Pineapple Lemon 2,000
-Ginger Lemon 2,000
-Strawberry Lemon 2,000
ーーーーーーーーーーーー
- [1724820029.313939] <@U0331FWGQRM>: *Sachet flavors*
ーーーーーーーーーーーー
*（B2 sachet と同じ）*
Early October: 5,000
Early November 10,000
Early December: to be determined
ーーーーーーーーーーーー
- [1724820503.671319] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
:flag-ch:Sebastyan注文予定
- [1724820514.095899] <@U0331FWGQRM>: ーーーーーーーーーーーー
*( B2 : Non organic )*
*60g bags*
Early October shipment: 4,000
Early November shipment: 5,000
Early December shipment: 4,000

*2.0g Silver sachet with text*
Early October: 5,000
Early November 10,000
Early December: to be determined
ーーーーーーーーーーーー

ーーーーーーーーーーーー
*60g flavors:*

Early October:
-Vanilla 3,000
-Cinnamon 2,000
-Peach Lemon 2,000
-Pineapple Lemon 2,000
-Ginger Lemon 2,000
-Strawberry Lemon 2,000

Early November:
-Vanilla 4,000 bag
-Cinnamon 3,000
-Peach Lemon 3,000
-Pineapple Lemon 3,000
-Ginger Lemon 3,000
-Strawberry Lemon 3,000

Early December (estimate will most likely change)
-Vanilla 3,000
-Cinnamon 2,000
-Peach Lemon 2,000
-Pineapple Lemon 2,000
-Ginger Lemon 2,000
-Strawberry Lemon 2,000
ーーーーーーーーーーーー

ーーーーーーーーーーーー
*Sachet flavors*
*（B2 sachet と同じ）*
Early October: 5,000
Early November 10,000
Early December: to be determined
ーーーーーーーーーーーー
- [1724820622.525599] <@U0331FWGQRM>: *10月初旬出荷*

*B2 matcha* (10/1)
B2 60g bags x 4,000（桃翠園）
B2 2.0g Silver sachet with text x 5,000（健祥）

*60g Flavor*（桃翠園）(10/10)
-Vanilla 3,000
-Cinnamon 2,000
-Peach Lemon 2,000
-Pineapple Lemon 2,000
-Ginger Lemon 2,000
-Strawberry Lemon 2,000

*2.5g Sachet flavors*（静パック）
-Vanilla x 5000 sachet
-Cinnamon x 5000 sachet
-Peach Lemon x 5000 sachet
-Pineapple Lemon x 5000 sachet
-Ginger Lemon x 5000 sachet
-Strawberry Lemon x 5000 sachet
- [1724825149.482489] <@U0331FZS7JT>: 【原料メモ】※今の比率・数量の場合/随時更新します。
*Early October*
抹茶：582.45kg/フレーバー用(10/10出荷)＋250kg/B2(10/1出荷)=832.45kg
バニラ：32.725kg
シナモン：21.2kg
ビーチ：23.85kg
レモン：66.25kg
パイナップル：21.2kg
ジンジャー：9.275kg
ストロベリー：21.2kg
クエン酸：77.35kg

*Early November*
抹茶：873.9kg/フレーバー用＋320kg/B2=1193.9kg
バニラ：45.05kg
シナモン：32.8kg
ビーチ：36.9kg
レモン：102.5kg
パイナップル：32.8kg
ジンジャー：14.35kg
ストロベリー：32.8kg
クエン酸：118.9kg

*Early December*
抹茶：
バニラ：
シナモン：
ビーチ：
レモン：
パイナップル：
ジンジャー：
ストロベリー：
クエン酸：

## 2024-08-28

- [1724908910.508899] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
サンプル袋の追跡番号です。
1Z RW1 581 04 5612 7103
  - files: [{"id": "F07JY47BX7F", "created": 1724908885, "timestamp": 1724908885, "name": "WhatsApp Image 2024-08-29 at 14.06.14.jpeg", "title": "WhatsApp Image 2024-08-29 at 14.06.14.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 49807, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07JY47BX7F/whatsapp_image_2024-08-29_at_14.06.14.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07JY47BX7F/download/whatsapp_image_2024-08-29_at_14.06.14.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07JY47BX7F-f4c788d616/whatsapp_image_2024-08-29_at_14.06.14_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07JY47BX7F-f4c788d616/whatsapp_image_2024-08-29_at_14.06.14_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07JY47BX7F-f4c788d616/whatsapp_image_2024-08-29_at_14.06.14_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 343, "thumb_360_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07JY47BX7F-f4c788d616/whatsapp_image_2024-08-29_at_14.06.14_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 385, "original_h": 404, "thumb_tiny": "AwAwAC29N2pgOD34pZijkDdgj2NNjEe3YTuGeMAigCVZABgqQfSnqwYZFRKIQ2VByPrTxKp6GgB9FM81eOvPtS7x6N+VAFWYYZuDkmljGXHbPp/SkZHMhy3GeuB/jSASjBBP5D/GgCEzoknEIyhwDu+tAuFR8CP7oGPm9qn+yq3LMgJ5Py//AF6Psals70yf9n/69AD7eNJY0lwQR0Gc9DVmqZMkH7tDwMYG3rnP+FThZiAfNA9tn/16AIbqVoidvPy55+tVmvJQpI29AamvSHJ2Mp+XH3h61TeNipxj7oH3hQBYF1IQTx2pUuZCoPGcioVQhT93oP4hSopCAErnI/iFAF62YzKxY8hscVNt/wBpvzqtaOkaOHdAS5I+YVY86L/nqn/fQoA//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07JY47BX7F/whatsapp_image_2024-08-29_at_14.06.14.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07JY47BX7F-17aeb32e98", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-08-31

- [1725104006.153119] <@U0331FZS7JT>: <@U0331FWGQRM>
CC：<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
お待たせしました！
栄養成分の結果が来ました。
【各種フレーバーとハーブ+クエン酸の結果】
「桃翠園」→「検査結果（残留農薬・重金属・放射線・栄養成分・粒度分布）」→「●提出用（海外営業用）」→「Flavor」というフォルダ
に入れています。
※直近での商品にはならない、ラズベリーとココナッツも入れています！

【抹茶(B2・出雲抹茶R)】については
「●提出用（海外営業用）」フォルダに「Nutritional Ingredient Analysis_Matcha」というタイトルでデータを格納しています！
よろしくお願いします:man-bowing:

## 2024-09-01

- [1725232403.341769] <@U041RJKV5JA>: <@U0331FWGQRM>
 <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
静パックへ送付分のスティック用原料が返送されてきましたのでご連絡いたします。
- [1725234500.999119] <@U0331FZS7JT>: <@U0331FWGQRM> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
サンプル袋到着しました。
60g bag 各１枚
サシェ 各2枚
ロール 1個
添付画像はSebastyanフォルダに格納しています！
  - files: [{"id": "F07KD083621", "created": 1725234468, "timestamp": 1725234468, "name": "New bag_20240902.jpg", "title": "New bag_20240902.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 433499, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07KD083621/new_bag_20240902.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07KD083621/download/new_bag_20240902.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07KD083621-04debd4629/new_bag_20240902_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07KD083621-04debd4629/new_bag_20240902_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07KD083621-04debd4629/new_bag_20240902_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07KD083621-04debd4629/new_bag_20240902_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07KD083621-04debd4629/new_bag_20240902_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07KD083621-04debd4629/new_bag_20240902_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07KD083621-04debd4629/new_bag_20240902_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07KD083621-04debd4629/new_bag_20240902_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07KD083621-04debd4629/new_bag_20240902_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADBEgLKDuAB6UGBueRgHGSanhAMKewpX9Bj7xqUDZVMTgkcce9IImZsEgcZzVlsEvxnp/Kkxh8AZ+T+tOw76EJtyCvzA7jjikaEqu7IP0qywAZSPU/ypso/dnpR1AjSMlFIXOfepNgCnjPPrUaSKAODkCpBNHtIbuSelJjEMYy2Ae3ANJsUjJyePWgypluwOAKTz0UgA9qBMCinbgEdcjNI2PLJwQfQ0rTKXX6EUkrq6YB5+lUthIgzQSaKQ1JQhJpMnNBpO9Ah1KKSlFMD/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07KD083621/new_bag_20240902.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07KD083621-22188dbcea", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07KJAZ4G2Y", "created": 1725234472, "timestamp": 1725234472, "name": "Sache design_20240902.jpg", "title": "Sache design_20240902.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 561830, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07KJAZ4G2Y/sache_design_20240902.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07KJAZ4G2Y/download/sache_design_20240902.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07KJAZ4G2Y-6e7a849053/sache_design_20240902_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07KJAZ4G2Y-6e7a849053/sache_design_20240902_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07KJAZ4G2Y-6e7a849053/sache_design_20240902_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07KJAZ4G2Y-6e7a849053/sache_design_20240902_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07KJAZ4G2Y-6e7a849053/sache_design_20240902_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07KJAZ4G2Y-6e7a849053/sache_design_20240902_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07KJAZ4G2Y-6e7a849053/sache_design_20240902_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07KJAZ4G2Y-6e7a849053/sache_design_20240902_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07KJAZ4G2Y-6e7a849053/sache_design_20240902_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADCNh81DAlOhxVkAiXgc4qJj/ooP+1UlEacr605Bul2jg4pzECePb3FMtzm4Ln1IoEyVo8nBYCmkbSQetTHbnJIHHTNRSkGTI6YFNEpj3Yghl61Ac7MDO0VKjbmGR2pi82x/3qTLImEmQTnP8P0pI423HIO3v9amOf3RPQ8U+P70i+3agTIxGvZDj60oXHTtThkg0q/1piSsR4yBQOF29utKPuj6UlIoQgYx2pV+UkjjjFIe9FAiRaeBg01adQB//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07KJAZ4G2Y/sache_design_20240902.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07KJAZ4G2Y-6f21dd9d93", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1725236129.801899] <@U0331FWGQRM>: <@U041RJKV5JA> cc <@U0331FZS7JT>
~返送されてきた原料を小袋に詰めてセバスチャン（ロサンゼルス）に送ってください。~
~宜しくお願いします。~
- [1725238114.809989] <@U0331FZS7JT>: <@U0331FWGQRM> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
添付画像はSebastyanフォルダに格納しています！
ご確認お願いします。
※すみません健康診断でちょっと抜けます:sweat_drops:
  - files: [{"id": "F07KFSEKTEF", "created": 1725237998, "timestamp": 1725237998, "name": "Bag size_G_20240902.jpg", "title": "Bag size_G_20240902.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 453691, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07KFSEKTEF/bag_size_g_20240902.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07KFSEKTEF/download/bag_size_g_20240902.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07KFSEKTEF-55823072a2/bag_size_g_20240902_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07KFSEKTEF-55823072a2/bag_size_g_20240902_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07KFSEKTEF-55823072a2/bag_size_g_20240902_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07KFSEKTEF-55823072a2/bag_size_g_20240902_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07KFSEKTEF-55823072a2/bag_size_g_20240902_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07KFSEKTEF-55823072a2/bag_size_g_20240902_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07KFSEKTEF-55823072a2/bag_size_g_20240902_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07KFSEKTEF-55823072a2/bag_size_g_20240902_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07KFSEKTEF-55823072a2/bag_size_g_20240902_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACSw8ZK4U4NQ4bON3ftVlemaYdnmbdpLHmkzROxXxkk9algQhQxORikAz0HWpY/lAXHGMiglMhmGXH0qPbVlwCc03ZTFYeHUIMnHvVaS78hwi4lYdT6e2aZNKUiZe/8AKqKH5hQNs2YG8wBiAN3OKbHJ5hBHAGR+tNt2IjX6VDZyAqy9wxpCReHIoqsJyM8d6X7R/s1QXRXmi3K2OpqssTHhkYH1xVwmgNTsZ8zCIlVAPUCmxZWIqBjLEk0m7k09fu0im9BQKXFITz2pM/Sgg//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07KFSEKTEF/bag_size_g_20240902.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07KFSEKTEF-084fbd17ac", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07K9AXJUTY", "created": 1725238001, "timestamp": 1725238001, "name": "Bag size_H_20240902.jpg", "title": "Bag size_H_20240902.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 569034, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07K9AXJUTY/bag_size_h_20240902.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07K9AXJUTY/download/bag_size_h_20240902.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07K9AXJUTY-038c224c90/bag_size_h_20240902_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07K9AXJUTY-038c224c90/bag_size_h_20240902_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07K9AXJUTY-038c224c90/bag_size_h_20240902_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07K9AXJUTY-038c224c90/bag_size_h_20240902_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07K9AXJUTY-038c224c90/bag_size_h_20240902_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07K9AXJUTY-038c224c90/bag_size_h_20240902_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07K9AXJUTY-038c224c90/bag_size_h_20240902_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07K9AXJUTY-038c224c90/bag_size_h_20240902_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07K9AXJUTY-038c224c90/bag_size_h_20240902_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACRiqWOB1p3lNntTrcfvPwqd5NjY2k8Zok3fQlJMqiMnAHrQ6FMZxzU6cFTjqaLrov1o1uNrQr0UZozVkEtt/rD9KlkQF8lGJxxiobc4cn2p4bzJxhjgc1D3KWwuCVUKOQaS43bE3dc02NstxTrr7q/Wn1G9ivSUGjNUQPiPz8jI71YQlR8qDn3qnmlDH1P50mrjTsPhY+bwMnnipLgkouRjmqwBBzn8jTiSepJpWG2JRQTSZqiT/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07K9AXJUTY/bag_size_h_20240902.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07K9AXJUTY-f9b5ece02b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07K1D78GHM", "created": 1725238003, "timestamp": 1725238003, "name": "Bag size_W_20240902.jpg", "title": "Bag size_W_20240902.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 582855, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07K1D78GHM/bag_size_w_20240902.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07K1D78GHM/download/bag_size_w_20240902.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07K1D78GHM-2e0c95b71e/bag_size_w_20240902_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07K1D78GHM-2e0c95b71e/bag_size_w_20240902_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07K1D78GHM-2e0c95b71e/bag_size_w_20240902_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07K1D78GHM-2e0c95b71e/bag_size_w_20240902_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07K1D78GHM-2e0c95b71e/bag_size_w_20240902_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07K1D78GHM-2e0c95b71e/bag_size_w_20240902_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07K1D78GHM-2e0c95b71e/bag_size_w_20240902_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07K1D78GHM-2e0c95b71e/bag_size_w_20240902_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07K1D78GHM-2e0c95b71e/bag_size_w_20240902_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACSPFFLVtgoHOBTk7EJXKfFJVv5P71R3IxHx6ikpPsPlIKKQUVZJaaGIdJM/iKSR8jB/lVYfeH1q1NIeACMmpZSGoqsOTipmjSRcMxHPqKQ59R+FQ3H+rH1pDJPssX/PQ/mKPssX/PQ/mKpUYqibir94fWre0BtwUk1TBwetSCRuzGhq4J2LO5s/dNMuCTDnGMEVF5r/AN40jSOwwxyKmxVxlFFFUQf/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07K1D78GHM/bag_size_w_20240902.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07K1D78GHM-f48e0efa19", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1725240369.547729] <@U0331FWGQRM>: <@U0331FZS7JT> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
素材が、アルミ蒸着についてはOKとのこと。
ーーー
教えてくれてありがとう。たいていの場合、パッケージは箱に閉まってあるか、誰かの家の戸棚の中にあって、長時間日光にさらされることはないと思う。でも、次の生産に向けて、サンドラにこのことを話してみます。
ーーー
- [1725245106.115139] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
~*60g bagについて質問です。*~
~10月10日出荷分の数量について：~
~本当に必要な数量をよりよく理解するために、顧客とプレオーダーを行う予定です。少なく注文することはありませんが、あるフレーバーに予想以上の需要がある場合、どれくらい前に知る必要がありますか？~

~例えば 例えば、2000の代わりにシナモン抹茶3000とか、2000の代わりにピーチレモン4000とか。~

~9月15日なら間に合いますか？~

↑一旦、無視してください！
- [1725248962.076449] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
変更です:sweat_drops:

60gの袋についてですが、ロスに送らなくていいそうです。
ーーー
抹茶を袋に詰めて、十分なスペースがあること／袋が十分な大きさであることを確認してください
ーーー
とのことなので、
粉を入れて、動画と写真を共有してもらえますか？
宜しくお願いします！
- [1725249689.308789] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
どれか１つ（抹茶の袋でOK）に粉を入れて60gが入るかどうかだけ、先に結論を、slackか電話でください。

入らない場合、製造を変更しなければならないので。
宜しくお願いします。
- [1725250014.878929] <@U041RJKV5JA>: <@U0331FWGQRM>
60g充填可能です。
十分な余裕があります。
後程、動画と写真をお送りします。

## 2024-09-02

- [1725275648.396909] <@U0331FWGQRM>: 
  - files: [{"id": "F07KLNPNTJQ", "created": 1725275644, "timestamp": 1725275644, "name": "IMG_6022 3.jpg", "title": "IMG_6022 3.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 191813, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07KLNPNTJQ/img_6022_3.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07KLNPNTJQ/download/img_6022_3.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLNPNTJQ-552764d69e/img_6022_3_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLNPNTJQ-552764d69e/img_6022_3_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLNPNTJQ-552764d69e/img_6022_3_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLNPNTJQ-552764d69e/img_6022_3_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLNPNTJQ-552764d69e/img_6022_3_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLNPNTJQ-552764d69e/img_6022_3_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLNPNTJQ-552764d69e/img_6022_3_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLNPNTJQ-552764d69e/img_6022_3_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07KLNPNTJQ-552764d69e/img_6022_3_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACRtODuejMahjZip3VagVfK3MO9JIpuyItp9KQjGKt/LjIA/KqV5IwcAHAHpQ0SpNgetFQea396jzW/vUWHctBI1GOaljHyYUkDPTFR4yeaeo+TqeM0kVO1iRshQuefaoW8tj8yA/hUqjCg1CBmqbJgIUi7J+lGyP+7+gp2KMVNy7IBwKkjwVIPrTMUqkr079RQiZaoceAT6CoM81KfuEAYzTQnrQwirAGzRmgr9fwpNo/2qRR//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07KLNPNTJQ/img_6022_3.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07KLNPNTJQ-a7bce6fba0", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1725288601.995099] <@U0331FWGQRM>: 20240902　whatsapp
セバスチャンから
ーーーーー
今後の輸送やピックアップについてですが、
フォワーダーの日本国内の担当者の連絡先を入手しました。
今後、出荷の詳細を私に確認してから、直接彼らに梱包リストを送ってください。その後、SWISSのチームが見積もりをメールで送ってくれます。

Gian-Andrea Silvani
HABA-SPED Logistics Japan K.K.

M&amp;N Building, Office 103
3-40-13 Sendagaya, Shibuya-Ku
Tokyo 151-0051, Japan

Tel: <tel:+81364340446|+81 3 6434 0446>
Fax: <tel:+81364340447|+81 3 6434 0447>
E-mail <mailto:gian.silvani@habasped.org|gian.silvani@habasped.org>
<http://www.habasped.co.jp|www.habasped.co.jp>
- [1725322344.234329] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
健祥へ加工依頼しております2g スティックの納期連絡がございました。
９月９日（月）着となります。
加工本数：15,300本（10月、11月納品分）
よろしくお願いいたします。
- [1725322452.968229] <@U0331FWGQRM>: <@U041RJKV5JA> 
ありがとうございます！
入荷したら、期間が開くので、
冷蔵保管するなど品質管理に注意願います！
宜しくお願い致します。
- [1725345849.715059] <@U041RJKV5JA>: <@U0331FWGQRM>
 <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本日、DHLにてフレーバー抹茶7種を各50gずつ出荷しました。
AWB NO. 9154366992
よろしくお願いいたします。

## 2024-09-03

- [1725425604.611609] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
各フレーバー着日
【キタマ】
・バニラフレーバー：40kg:arrow_right:9/6（金）
・ビーチフレーバー：30kg:arrow_right:9/6（金）
・レモンフレーバー：80kg:arrow_right:9/6（金）
・パイナップルフレーバー：30kg:arrow_right:9/6（金）
・有機シナモンパウダー：20kg:arrow_right:9/4（水）
・有機ジンジャーパウダー：10kg:arrow_right:9/4（水）
・クエン酸：100kg:arrow_right:9/3（火）

【高砂香料】
・ストロべリーフレーバー：20kg:arrow_right:9/9（月）
※9/4(本日)以前注文した9kg着

## 2024-09-25

- [1727282369.667049] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
理由はよく分かりませんが、
100%抹茶（つまりFlavored matcha以外）の賞味期限は一致させてください。とのことです。
賞味期限の管理が煩雑になるのを防ぎたいようです。

例えば、下記です。
*TSE-MTL-009-1（Shipped on 24th Sep.）*
　　MATCHA LAND Bio Matcha 60g flat bag with Label x 4000bags

*TSE-MTL-010（will ship on 4th Oct.）*
　　MATCHA LAND Matcha 60g flat bag with Label x 50bags

## 2024-10-30

- [1730274623.090659] <@U03BLQ65GK0>: <@U0331FWGQRM> <@U0331FZS7JT> cc<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
セバスチャン向け各フレーバーの袋不良の内容です。
（一度に上げられるデータが10個までなので続いて送ります）
不良の内容は
・チャック不良
・シワ
・折れ曲がり
・汚れ
・傷
・印刷剥がれ
・印刷不良
で上から順に数量が多いです。
※チャック不良以外は全部で54枚です。
  - files: [{"id": "F07TNUHTAA3", "created": 1730274065, "timestamp": 1730274065, "name": "シワ1.JPG", "title": "シワ1.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 2847349, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07TNUHTAA3/______1.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07TNUHTAA3/download/______1.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUHTAA3-2940361c4e/______1_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUHTAA3-2940361c4e/______1_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUHTAA3-2940361c4e/______1_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUHTAA3-2940361c4e/______1_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUHTAA3-2940361c4e/______1_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUHTAA3-2940361c4e/______1_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUHTAA3-2940361c4e/______1_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUHTAA3-2940361c4e/______1_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUHTAA3-2940361c4e/______1_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 4032, "original_h": 3024, "thumb_tiny": "AwAkADB8LDfxUT5WVyJCDmnpw4OMU24yJTgnn3qWCHmdg4XaG96UTneQSuO2KgY/vc8YzmnwjnPAwO1AyXzjuAxlSOtPhJKknnnApu7jB5ppAIO3IPXGaXMr2FYSMh41bHapJYlc5JI47VSjkdE2gjH0qTzpO7fpVATNFnoTmo/LkTCqM85J6U0TSf3v0pwnf2P4UgJAjDtmnKhGMjr2pizseqin+dnsAfWpUEmMpAU8U0dKcKsApaSloAUUo70gpR0NAH//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07TNUHTAA3/______1.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07TNUHTAA3-a9272d125b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07US92HGKA", "created": 1730274076, "timestamp": 1730274076, "name": "シワ2.JPG", "title": "シワ2.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 3133218, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07US92HGKA/______2.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07US92HGKA/download/______2.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07US92HGKA-91305cd1e8/______2_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07US92HGKA-91305cd1e8/______2_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07US92HGKA-91305cd1e8/______2_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07US92HGKA-91305cd1e8/______2_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07US92HGKA-91305cd1e8/______2_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07US92HGKA-91305cd1e8/______2_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07US92HGKA-91305cd1e8/______2_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07US92HGKA-91305cd1e8/______2_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07US92HGKA-91305cd1e8/______2_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACSO2TzGIJxxU/2YE53/AKVFaf6xv92rAH+cUhtEZtAf4x+VNa0ABIcce1Tf56UmTubB+XHSkKyKNFA6UUFFizH7xv8AdqwVwuc9s9KjtMZc+1OZh/k0MQAqwBG7mnBQAQM9KapB6/zqRMH/APXRqBm0UZozQMltGPz474qxg4zgfnWfHK0WdoBz60/7XJ/dWmIublC7uuPSnxShmACkH1qj9sf+6tOW9YfwD86BDG4Zh7mkzQz7nLYxk5xSZpFH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07US92HGKA/______2.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07US92HGKA-25537a1c6a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07US92UDL0", "created": 1730274082, "timestamp": 1730274082, "name": "チャック不良.MOV", "title": "チャック不良.MOV", "mimetype": "video/quicktime", "filetype": "mov", "pretty_type": "QuickTime Movie", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 73890408, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F07US92UDL0-25c259b529/__________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F07US92UDL0-25c259b529/__________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07US92UDL0/download/__________________.mov?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F07US92UDL0-25c259b529/file.m3u8?_xcb=54b05&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MzI3NTE5NCxBVkVSQUdFLUJBTkRXSURUSD0yOTcxMTI2LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTgxMHgxMDgwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1ZWTTVNbFZFVERBdE1qVmpNalU1WWpVeU9TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TVM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNWVk01TWxWRVREQXRNalZqTWpVNVlqVXlPUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01pNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzVlZNNU1sVkVUREF0TWpWak1qVTVZalV5T1M5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNeTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1ZWTTVNbFZFVERBdE1qVmpNalU1WWpVeU9TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TkM1MGN3b2pSVmhVU1U1R09qUXVOVE00TEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNWVk01TWxWRVREQXRNalZqTWpVNVlqVXlPUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd05TNTBjd29qUlZoVUxWZ3RSVTVFVEVsVFZBbz0KI0VYVC1YLVNUUkVBTS1JTkY6QkFORFdJRFRIPTE3ODg3MjMsQVZFUkFHRS1CQU5EV0lEVEg9MTY3NTIyMixDT0RFQ1M9ImF2YzEuNjQwMDFmLG1wNGEuNDAuNSIsUkVTT0xVVElPTj01NDB4NzIwLEZSQU1FLVJBVEU9MjkuOTcwCmh0dHBzOi8vZmlsZXMuc2xhY2suY29tL2ZpbGVzLXRtYi9UMDMzRDcwUlI2SC1GMDdVUzkyVURMMC0yNWMyNTliNTI5L2ZpbGVfSF8yNjRfMTI4MHg3MjBfMzUwMEtCUFNfN1FWQlIubTN1OAo=", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F07US92UDL0-25c259b529/___________________trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 28561, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F07US92UDL0-25c259b529/___________________thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 1440, "thumb_video_h": 1920, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07US92UDL0/__________________.mov", "permalink_public": "https://slack-files.com/T033D70RR6H-F07US92UDL0-e6cd4a74c7", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07TWS8H3CN", "created": 1730274103, "timestamp": 1730274103, "name": "印刷の色味.JPG", "title": "印刷の色味.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 2688279, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07TWS8H3CN/_______________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07TWS8H3CN/download/_______________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWS8H3CN-5f80c769d8/________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWS8H3CN-5f80c769d8/________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWS8H3CN-5f80c769d8/________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWS8H3CN-5f80c769d8/________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWS8H3CN-5f80c769d8/________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWS8H3CN-5f80c769d8/________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWS8H3CN-5f80c769d8/________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWS8H3CN-5f80c769d8/________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWS8H3CN-5f80c769d8/________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACSG2UPJhicYq2IE7FvzqrZ/678DViQNuyHwOBQRLcf5C/3m/OkNup/iP6VF5vGNx6VNHk87sqRxQIqTKEkKg5xUeamn/wBc1R8UjRbD7THmn/dqeUlmCKRnPOar2RzK3+7VgKPPJx2qZOyFa7GeW+ccdOtSQsCMZBI9OlBOD1NOX17mpjO+gnEqXAJmbFR7TUkp/fP9aZk1oUh9lw7/AEqyTGWyTz0qjBKIixIzn0qYXij/AJZ/rQS07lglSQNwpVZTwGyaqm8X/nn+tKLtf+eZ/OklYLMjlH75+e9Mx70O4Z2Ydzmk3Uyz/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07TWS8H3CN/_______________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07TWS8H3CN-d00988033c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07US94GLHE", "created": 1730274110, "timestamp": 1730274110, "name": "印刷剥がれ.JPG", "title": "印刷剥がれ.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 1714007, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07US94GLHE/__________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07US94GLHE/download/__________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07US94GLHE-e698bc28ea/___________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07US94GLHE-e698bc28ea/___________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07US94GLHE-e698bc28ea/___________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07US94GLHE-e698bc28ea/___________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07US94GLHE-e698bc28ea/___________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07US94GLHE-e698bc28ea/___________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07US94GLHE-e698bc28ea/___________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07US94GLHE-e698bc28ea/___________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07US94GLHE-e698bc28ea/___________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACSFTxQST0q4bSPHG786Q2ygcM/50rBdlN8qSDTc1c+z5OSz/nS/Zs/xt+hosF2UqKuNZqTzIc/Sk+xp/wA9D+VFguy0Vz3qnLLsdwd3y+9W2IqhOW85hs3Kfb2oAl+0KCwG47Tj+f8AhUjShQTz94L+YzVRSe4AzjPy/X/P40gdeNygc98+lAy+Ub1o2N608MSOlG4+lAhhOarO0qykAEg8jAqZm2qSBnHYVTkuTvBUtkdu1AizGzkEOpUjv2NRyrIzqVyeP84qTzMpllAbHTOaRZCmO+OM0xjRHMeSVX2JyaXypv76VbUgrkd6XNAH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07US94GLHE/__________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07US94GLHE-a52993aa07", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07U3CFN2QK", "created": 1730274116, "timestamp": 1730274116, "name": "汚れ1.JPG", "title": "汚れ1.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 3015823, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07U3CFN2QK/______1.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07U3CFN2QK/download/______1.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3CFN2QK-857ae55ec1/______1_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3CFN2QK-857ae55ec1/______1_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3CFN2QK-857ae55ec1/______1_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3CFN2QK-857ae55ec1/______1_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3CFN2QK-857ae55ec1/______1_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3CFN2QK-857ae55ec1/______1_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3CFN2QK-857ae55ec1/______1_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3CFN2QK-857ae55ec1/______1_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3CFN2QK-857ae55ec1/______1_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACSZGPlrj0pdzA8mmwjMa1JtHpSAhmc49hUIyqEnvz9farjjauOmetUpCWf5RwOntUvcpEbHLHPJpvHpUwCgYwT+NL8n90/nSuiOdlmHHljmpRtA61BAf3S0skbM4ZWxxirGTMocYJx70kMSwrgHJPeoFhYFckYA247EU9YipXAToOe4x6UATfL6Cj5PQVVNu4xhh0HU0n2d/wC8lADY7hI4wrZz7CnfbIv9r/vmqTOaZuPpQM0ftkPq3/fJp32yD+8f++TWaDTgc0rgaH2uH+8f++TS/aof7x/75NUAfrRn60XA/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07U3CFN2QK/______1.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07U3CFN2QK-2e4e028ee1", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07UG5VC3ND", "created": 1730274123, "timestamp": 1730274123, "name": "汚れ2.JPG", "title": "汚れ2.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 2834602, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07UG5VC3ND/______2.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07UG5VC3ND/download/______2.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07UG5VC3ND-b59bbde5e6/______2_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07UG5VC3ND-b59bbde5e6/______2_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07UG5VC3ND-b59bbde5e6/______2_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07UG5VC3ND-b59bbde5e6/______2_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07UG5VC3ND-b59bbde5e6/______2_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07UG5VC3ND-b59bbde5e6/______2_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07UG5VC3ND-b59bbde5e6/______2_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07UG5VC3ND-b59bbde5e6/______2_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07UG5VC3ND-b59bbde5e6/______2_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACStmlz6ipfLnx/9cUgSbOe/1FIi7Gg/WjOeKeIZiMEfqKSSJ05ZcA0DTdxKMUmPpRj6Uiy8VyODRs96Zlh3/WmNJKDwpI9c0zMsKvHWoriPjOSeehNOjZiOTj2zRO21B7mgaKu2jApd3tRu9qRY8Jzzio5jiTj0o6inkqeq5/CmQFr95voKdeHEa/WlQr2XB+lRXbfIv1oYLcjHIpaYCMUuRSLP/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07UG5VC3ND/______2.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07UG5VC3ND-e49f0c4839", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07U0KETRGD", "created": 1730274130, "timestamp": 1730274130, "name": "汚れ3.JPG", "title": "汚れ3.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 2658841, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07U0KETRGD/______3.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07U0KETRGD/download/______3.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0KETRGD-0f3185df5c/______3_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0KETRGD-0f3185df5c/______3_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0KETRGD-0f3185df5c/______3_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0KETRGD-0f3185df5c/______3_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0KETRGD-0f3185df5c/______3_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0KETRGD-0f3185df5c/______3_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0KETRGD-0f3185df5c/______3_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0KETRGD-0f3185df5c/______3_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0KETRGD-0f3185df5c/______3_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACSNSR2qRN7DODimQr5mctjHpUjQ+jn8qlCd7g2emGyahKO38LVIIM/xn8qU25xw/wClMXvEHlMf4W/Kjym/uv8AlVgW7gf6z+dH2d/+eh/WgPeIoDhTz3qbzkHv9RUdqAUbIzzQ8aF/u/qaCyVZUJ6D8qf5q5zgVXWKMtjafzqTyUA4Dc+9AaEvmj1o84etR+VHjofzo8qP+6fzNAEdt/qz9ac2Nxz+eaS34iH1NKwG4k7vyoAWPG7p196flehz+lRqF3Y5/KngDoC35UwF+X1I/EUfL6n86Auf4j+Ipdv+1+lAH//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07U0KETRGD/______3.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07U0KETRGD-4e46e2c96b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07TWSAF4FQ", "created": 1730274136, "timestamp": 1730274136, "name": "汚れ4.JPG", "title": "汚れ4.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 2868647, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07TWSAF4FQ/______4.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07TWSAF4FQ/download/______4.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWSAF4FQ-44ca6b933d/______4_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWSAF4FQ-44ca6b933d/______4_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWSAF4FQ-44ca6b933d/______4_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWSAF4FQ-44ca6b933d/______4_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWSAF4FQ-44ca6b933d/______4_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWSAF4FQ-44ca6b933d/______4_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWSAF4FQ-44ca6b933d/______4_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWSAF4FQ-44ca6b933d/______4_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07TWSAF4FQ-44ca6b933d/______4_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACRoTI47UHI7H8qe0QXne1NCZPDsDSJ94Qvx0NMPNSiPk4kb607yW/56tmgPeK2frRu+tWvIYcCU/lR5L/8APU/lRYLsdJc47N/3yaatyT2P5Ux/mJ5pp+tBRMt1nsfyqQS5GarouTjIqRU5+8M0AONx/st/3yaPtI/uv/3yahZmDHG7HsSKbuf/AG/++jTC49gDnkUzYSeop4IJxtYfUU4J7/pQA1Rg9RUwUEffpnl98/pSqCOMigBxGOrijA/vil2Ajkn8KPLHqaQH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07TWSAF4FQ/______4.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07TWSAF4FQ-5493272dce", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07TNUNAXD5", "created": 1730274142, "timestamp": 1730274142, "name": "傷.JPG", "title": "傷.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 1715761, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07TNUNAXD5/___.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07TNUNAXD5/download/___.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUNAXD5-d21200112c/____64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUNAXD5-d21200112c/____80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUNAXD5-d21200112c/____360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUNAXD5-d21200112c/____480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUNAXD5-d21200112c/____160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUNAXD5-d21200112c/____720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUNAXD5-d21200112c/____800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUNAXD5-d21200112c/____960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07TNUNAXD5-d21200112c/____1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACSx8oxy3PoKMp6v+VRhW9PoacFbOeP0pAOJXGfnP86MqOzn601UPoP8/hTihHp+NADcp3D/AJ//AF6Nyejfn/8AXpwDDj5T9TRz6J+dAEIZMYKcf71GYz/Bn/gVOG0kDBpzEIpJ6AZNOwDQYzwVA/GpdqFRhRiq4nTuePpU4dTgCkAGOMdVH5UmyL0H5U8jOKTaKqwiIOaXdms7z5R/F+gpRcy/3h+VTdjsXyFIwVGOlPGMDis/7TL6j8qUXcoH8P5UBY0Mj0FLkegrP+1y+i/lS/a5fRfyouwsf//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07TNUNAXD5/___.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07TNUNAXD5-aed54264d9", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1730274663.810469] <@U03BLQ65GK0>: <@U0331FWGQRM> <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
続きです
  - files: [{"id": "F07U3DD0GDR", "created": 1730274637, "timestamp": 1730274637, "name": "折れ曲がり.JPG", "title": "折れ曲がり.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 2528268, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07U3DD0GDR/__________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07U3DD0GDR/download/__________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DD0GDR-6c75b47a9e/___________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DD0GDR-6c75b47a9e/___________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DD0GDR-6c75b47a9e/___________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DD0GDR-6c75b47a9e/___________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DD0GDR-6c75b47a9e/___________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DD0GDR-6c75b47a9e/___________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DD0GDR-6c75b47a9e/___________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DD0GDR-6c75b47a9e/___________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DD0GDR-6c75b47a9e/___________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACSc0ZA6tTH3KjMRgAVFFllyT1qUKTsW/LJFNZNvWniQ7RTGJbrQxjDSUpFGKkYy6k3qdv8ADUEb7VZfTmpURWBCjO4d6qIfmGe4qyZaluKQ7BmpA+aphsH2NTrn8KTGmTZopmaM1JQ1W2FSO3NVp02SsB93dkEVM596Yr4NUhNDPLkIztPPT3q1Em1AM9KPOLLgnNND4NAkrDsCjikyKMj0pDP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07U3DD0GDR/__________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07U3DD0GDR-3ea9a4ae88", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07U0LC06KF", "created": 1730274647, "timestamp": 1730274647, "name": "折れ曲がり2.JPG", "title": "折れ曲がり2.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 2251407, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07U0LC06KF/__________________2.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07U0LC06KF/download/__________________2.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0LC06KF-895d51fe95/__________________2_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0LC06KF-895d51fe95/__________________2_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0LC06KF-895d51fe95/__________________2_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0LC06KF-895d51fe95/__________________2_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0LC06KF-895d51fe95/__________________2_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0LC06KF-895d51fe95/__________________2_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0LC06KF-895d51fe95/__________________2_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0LC06KF-895d51fe95/__________________2_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07U0LC06KF-895d51fe95/__________________2_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACR1yFEi5yNwxx9ajBAG4Z9eoq1MxUr8gYHjpnFIrkg7o9pHtQFxlqwLtzkkD+VF5jCfU0hSUuxQDB9TikulIjj3HJyeaGMrYFGBRRxUjLVzK68YI9MGpPn8r58bsc4qAQSSTHceAeT61O2R/wDXqiRU3Zx2/lTL3/Vp9anjXA561DfcRp/vUAinRzSUVJRaYpn/AFv4bhREqSH/AFucdt1ZwB9KXGe1MVjW8pgciRvpUV8fkT/eqgryJ9yRh7Zp5mkkUB2zigAJ96M+9A+lH4Uhn//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07U0LC06KF/__________________2.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07U0LC06KF-3e6be50909", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07U3DE1EM9", "created": 1730274654, "timestamp": 1730274654, "name": "表面の不良.JPG", "title": "表面の不良.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 2945071, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07U3DE1EM9/_______________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07U3DE1EM9/download/_______________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DE1EM9-1b3abc7270/________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DE1EM9-1b3abc7270/________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DE1EM9-1b3abc7270/________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DE1EM9-1b3abc7270/________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DE1EM9-1b3abc7270/________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DE1EM9-1b3abc7270/________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DE1EM9-1b3abc7270/________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DE1EM9-1b3abc7270/________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07U3DE1EM9-1b3abc7270/________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACR9sflb6092YHgkCoLQkh/qKmZCTkAH6mpE9w3N6mj5h/E1OVSOMJ+Jpcenl4oAYcj+I/nSZPqfzqTDHun5UbW9U/75oArWf8f4VZ2luc1Us+r/AIVazxihA9x6x+5p3lD1P50xTn1/OnhsCnoBE8kUZw7YP1NN8+D/AJ6D8zUpAJ5AP4Um1f7o/KkIzY5WiJ2gHPrTzdS+iflUIIpc570F2RMt1L/s/wDfNO+0y4+8P++ag7UA0Dsifz5f7/6Cjz5f7/6CmBhijcKQWR//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07U3DE1EM9/_______________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07U3DE1EM9-0b647bca4c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-11-11

- [1731348976.847619] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
Sebastyan様のスティック用のフィルムロールについて、
1連（桃翠園用）も2連（静パック用）も、
どちらも包装（箱・ビニール）を開封し、匂いを飛ばすようにしておいてください。
※埃等が被らないようにはしておいてください。

シンナーの匂いは飛ぶと思います。
（倉庫に置いている箱から出しているもは匂いが飛んでおりました）
シンナーの匂いを飛ばすのと同時に、芯のつぶれを直すための手配をお願いします。

方法１、フィルム会社から動画が送られてきました。
　　　　おそらく素人ではできないと思うので、下記2で進めてください。

方法２、先日連絡した企業に相談
<https://ono-plus.com/blog/%E3%83%95%E3%82%A3%E3%83%AB%E3%83%A0%E5%8A%A0%E5%B7%A5%E3%81%A7%E7%99%BA%E7%94%9F%E3%81%99%E3%82%8B%E5%95%8F%E9%A1%8C%E3%81%A8%E5%8E%9F%E5%9B%A0%E3%80%90%E7%B4%99%E7%AE%A1%E6%BD%B0%E3%82%8C%E7%B7%A8/|https://ono-plus.com/blog/%E3%83%95%E3%82%A3%E3%83%AB%E3%83%A0%E5%8A%A0%E5%B7%A5%E3[…]5%9B%A0%E3%80%90%E7%B4%99%E7%AE%A1%E6%BD%B0%E3%82%8C%E7%B7%A8/>
  - files: [{"id": "F080CPJ3VH9", "created": 1731348939, "timestamp": 1731348939, "name": "WhatsApp Video 2024-11-02 at 00.28.50.mp4", "title": "WhatsApp Video 2024-11-02 at 00.28.50.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 1591066, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F080CPJ3VH9-25e6ec46b4/whatsapp_video_2024-11-02_at_00.28.50.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F080CPJ3VH9-25e6ec46b4/whatsapp_video_2024-11-02_at_00.28.50.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F080CPJ3VH9/download/whatsapp_video_2024-11-02_at_00.28.50.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F080CPJ3VH9-25e6ec46b4/file.m3u8?_xcb=5dea1&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9OTk2NjU2LEFWRVJBR0UtQkFORFdJRFRIPTk0MDU2MyxDT0RFQ1M9ImF2YzEuNjQwMDFmLG1wNGEuNDAuNSIsUkVTT0xVVElPTj01MDB4MTA4MCxGUkFNRS1SQVRFPTI5Ljk3MApkYXRhOmFwcGxpY2F0aW9uL3ZuZC5hcHBsZS5tcGVndXJsO2Jhc2U2NCxJMFZZVkUwelZRb2pSVmhVTFZndFZrVlNVMGxQVGpvekNpTkZXRlF0V0MxVVFWSkhSVlJFVlZKQlZFbFBUam8zQ2lORldGUXRXQzFOUlVSSlFTMVRSVkZWUlU1RFJUb3hDaU5GV0ZRdFdDMVFURUZaVEVsVFZDMVVXVkJGT2xaUFJBb2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRNRU5RU2pOV1NEa3RNalZsTm1Wak5EWmlOQzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01TNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0TUVOUVNqTldTRGt0TWpWbE5tVmpORFppTkM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNaTUwY3dvalJWaFVTVTVHT2pJdU9EQXpMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE1FTlFTak5XU0RrdE1qVmxObVZqTkRaaU5DOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TXk1MGN3b2pSVmhVTFZndFJVNUVURWxUVkFvPQo=", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F080CPJ3VH9-25e6ec46b4/whatsapp_video_2024-11-02_at_00.28.50_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 14814, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F080CPJ3VH9-25e6ec46b4/whatsapp_video_2024-11-02_at_00.28.50_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 592, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F080CPJ3VH9/whatsapp_video_2024-11-02_at_00.28.50.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F080CPJ3VH9-25b22560fc", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-11-14

- [1731631596.808699] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
B2 matcha 60gと2g sachetって、今在庫どのくらいありますか？
（12月初旬出荷予定の分ってどのくらい在庫あるのか確認したい意図です）

## 2024-11-15

- [1731673499.487399] <@U0331FWGQRM>: <@U041RJKV5JA>
健祥で余分に準備はしてませんでしたっけ？
- [1731675298.864599] <@U041RJKV5JA>: <@U0331FWGQRM>
既に12月出荷分として11,812包確保しております。
B2 matcha 60g用の原料も会長に準備いただいております。

## 2024-11-16

- [1731750911.760049] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
b2 matcha 60g用の新しいラベルです！
b2 matcha 60gもジッパーバッグが間も無くできるらしいのですが、
それまではこのラベルで対応するらしいです。
  - files: [{"id": "F0812RNNNKX", "created": 1731750903, "timestamp": 1731750903, "name": "IMG_6736.png", "title": "IMG_6736", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 982869, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0812RNNNKX/img_6736.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0812RNNNKX/download/img_6736.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0812RNNNKX-160d5c8b9c/img_6736_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0812RNNNKX-160d5c8b9c/img_6736_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0812RNNNKX-160d5c8b9c/img_6736_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0812RNNNKX-160d5c8b9c/img_6736_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 221, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0812RNNNKX-160d5c8b9c/img_6736_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0812RNNNKX-160d5c8b9c/img_6736_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 332, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0812RNNNKX-160d5c8b9c/img_6736_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1734, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0812RNNNKX-160d5c8b9c/img_6736_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 443, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0812RNNNKX-160d5c8b9c/img_6736_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 472, "thumb_1024_h": 1024, "original_w": 1290, "original_h": 2796, "thumb_tiny": "AwAwABbQOd2RRk+lGMjrijaAeppAAwKXIpMAdDRQAmOvakwf7xpzEKuSCfpTRJuztRs+/FAmOH1JooPWkoGLweoB/Gjgdh+dG0dSaQBP7wNMBaSnYpMUAf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0812RNNNKX/img_6736.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F0812RNNNKX-d409780101", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F080R5E0L4F", "created": 1731750909, "timestamp": 1731750909, "name": "Matcha Label B2 60g.pdf", "title": "Matcha Label B2 60g", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 38996, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F080R5E0L4F/matcha_label_b2_60g.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F080R5E0L4F/download/matcha_label_b2_60g.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F080R5E0L4F-ae525f52f1/matcha_label_b2_60g_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 238, "thumb_pdf_h": 368, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F080R5E0L4F/matcha_label_b2_60g.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F080R5E0L4F-1353bfa875", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-11-17

- [1731907985.032529] <@U033G4KN4TD>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
受注のスレッドにも報告しておりますが
在庫と不良の数報告いたします。
【在庫】
Vanilla x 460枚
Cinnamon x 5,414枚
Peach Lemon x 5,416枚
Pineapple Lemon x 5,441枚
Ginger Lemon x 5,466枚
Strawberry Lemon x 3,635枚

【不良】
Vanilla x 1,024枚(チャック不良：1023枚、印刷不良：1枚)
Cinnamon x 27枚(シワ19枚、印刷不良(汚れ)：8枚)
Peach Lemon x 7枚(印刷不良(汚れ)：7枚)
Pineapple Lemon x 11枚(シワ：7枚、印刷不良(ニス付着)：4枚)
Ginger Lemon x 47枚(シワ43枚、キズ：2枚、印刷不良：2枚)
Strawberry Lemon x 26枚(シワ：23枚、印刷不良(汚れ)：3枚)

※在庫については、正確な数字ではありません。
1束＝100枚と仮定した数量です。
※未検品のため、不良袋が出る可能性があります。
  - files: [{"id": "F081BL5Q1GU", "created": 1731907947, "timestamp": 1731907947, "name": "Sebastyan袋報告.pdf", "title": "Sebastyan袋報告.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 1010907, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F081BL5Q1GU/sebastyan_________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F081BL5Q1GU/download/sebastyan_________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F081BL5Q1GU-be03a80c17/sebastyan__________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F081BL5Q1GU/sebastyan_________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F081BL5Q1GU-da2fb82869", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1731912928.414209] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
確認ありがとうございます。
不良品については返送不要となりました。
こちら側で破棄して良いとのことなので、破棄を宜しく願います。

## 2024-11-20

- [1732089899.783379] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
Chaiのフィルムロールが届き次第教えてください。
※おそらくこちらも芯のやり変えが必要かと思います。
- [1732151735.249249] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
フィルムロールが届きました。
今回も芯が変形しておりの交換が必要となります。
芯交換・巻き直しの手配を進めてもよろしいでしょうか。
  - files: [{"id": "F081TAGDUUB", "created": 1732151716, "timestamp": 1732151716, "name": "74C51BFC-2BEC-43A5-87FC-4E5D40A1760C.jpg", "title": "74C51BFC-2BEC-43A5-87FC-4E5D40A1760C.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 4411757, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F081TAGDUUB/74c51bfc-2bec-43a5-87fc-4e5d40a1760c.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F081TAGDUUB/download/74c51bfc-2bec-43a5-87fc-4e5d40a1760c.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F081TAGDUUB-ed5067c970/74c51bfc-2bec-43a5-87fc-4e5d40a1760c_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F081TAGDUUB-ed5067c970/74c51bfc-2bec-43a5-87fc-4e5d40a1760c_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F081TAGDUUB-ed5067c970/74c51bfc-2bec-43a5-87fc-4e5d40a1760c_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F081TAGDUUB-ed5067c970/74c51bfc-2bec-43a5-87fc-4e5d40a1760c_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F081TAGDUUB-ed5067c970/74c51bfc-2bec-43a5-87fc-4e5d40a1760c_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F081TAGDUUB-ed5067c970/74c51bfc-2bec-43a5-87fc-4e5d40a1760c_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F081TAGDUUB-ed5067c970/74c51bfc-2bec-43a5-87fc-4e5d40a1760c_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F081TAGDUUB-ed5067c970/74c51bfc-2bec-43a5-87fc-4e5d40a1760c_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F081TAGDUUB-ed5067c970/74c51bfc-2bec-43a5-87fc-4e5d40a1760c_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACScmgUyU7SBzjuar5dH+U5/rUWKuXKaaaJ1PAByOopwOexH1FKwxuKMU7FGKAGXaPw6ZI74qCNiBkHB+tWW3suF7daqyK3de9WtiWG/593fqasG7jMXycnp9KgSMk5PSmtETJtjX8BTEXI3Dxhqfx6io1jCKFyOKXA9qzKuMm3ou5M++Kqq5Em8feNX94HrRujVgQgz64q1cQsSttBYAZHSpMUzzBjoaPMHoamzDQUqSetG0/3v0pPMHoaXzB6GizC6P//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F081TAGDUUB/74c51bfc-2bec-43a5-87fc-4e5d40a1760c.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F081TAGDUUB-397bf6b2d7", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F081QHHSZ7X", "created": 1732151724, "timestamp": 1732151724, "name": "A63C65A4-8507-40C1-A8EC-9E96F9C6F1EC.jpg", "title": "A63C65A4-8507-40C1-A8EC-9E96F9C6F1EC.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 2614909, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F081QHHSZ7X/a63c65a4-8507-40c1-a8ec-9e96f9c6f1ec.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F081QHHSZ7X/download/a63c65a4-8507-40c1-a8ec-9e96f9c6f1ec.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F081QHHSZ7X-505c1aff5c/a63c65a4-8507-40c1-a8ec-9e96f9c6f1ec_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F081QHHSZ7X-505c1aff5c/a63c65a4-8507-40c1-a8ec-9e96f9c6f1ec_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F081QHHSZ7X-505c1aff5c/a63c65a4-8507-40c1-a8ec-9e96f9c6f1ec_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F081QHHSZ7X-505c1aff5c/a63c65a4-8507-40c1-a8ec-9e96f9c6f1ec_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F081QHHSZ7X-505c1aff5c/a63c65a4-8507-40c1-a8ec-9e96f9c6f1ec_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F081QHHSZ7X-505c1aff5c/a63c65a4-8507-40c1-a8ec-9e96f9c6f1ec_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F081QHHSZ7X-505c1aff5c/a63c65a4-8507-40c1-a8ec-9e96f9c6f1ec_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F081QHHSZ7X-505c1aff5c/a63c65a4-8507-40c1-a8ec-9e96f9c6f1ec_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F081QHHSZ7X-505c1aff5c/a63c65a4-8507-40c1-a8ec-9e96f9c6f1ec_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 4032, "original_h": 3024, "thumb_tiny": "AwAkADBBLuPyDGPWkJfPBoLPjIIPtjmlUjzeOjLS5h2EXceGOR71IqqOVCgj0pAMZyR0pvHIzzTuFhTn2ppjEnylcntSdZVHoMmrNqoYlucDjPvRzCsI7jooH1qHPzIfqKWkYY5HqDUlCPGHOSdtMVNp++DT5H2E4UnPpTVlBGdpGPWgBycux9Tir8WBEuBjiqUKZC5+tXQeKBFKlHWkpR1oGEg4qMcdqlfoKioAmi5qwOlV4asdqYj/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F081QHHSZ7X/a63c65a4-8507-40c1-a8ec-9e96f9c6f1ec.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F081QHHSZ7X-9066dbf644", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1732151978.458779] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
はい、宜しくお願い致します！

今回の件で、Ono plusに支払いした費用はフィルムメーカーが負担するらしいので、支払った金額はまた教えてください。
見積書（支払い確定金額）をここのスレッドに貼り付けてください。
※金額が確定するのが終わってからなのであれば、終わってからでokです。
宜しくお願いします。

## 2024-11-21

- [1732178973.659049] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
CHAI フィルムロール巻き直しスケジュール
・11月25日　ONO plusへ納品
・11月29日　出荷
・12月3日　静パック、桃翠園着
静パック　望月様に連絡済みです。
12月9日からのスティック加工を中止した場合に備え、工場の空き状況を確認しましたが、1月末まで既に埋まっているそうです。
よろしくお願いいたします。
- [1732232982.834809] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U0331FZS7JT>
ご確認有難うございます。

以下メモも兼ねて書かせていただきます。

今後の注文スケジュールを考慮すると、
下記内容はマストで押さえておきたい、ということになりますね。

*12月のスケジュールは抑えたままでキープして*
*・“からうち“で良いのでフィルムのテストを行っておく*
*・12月初旬頃にはブレンド比率を確定させたい*
*・自社のスティック機械を今年中に稼働できるようにしておきたい*

これらができなかった場合、
もし今年の12月半ば以降に注文があった場合、
スティックについては最短出荷でも
2月末頃になってしまうということになりそうですね。。。

## 2024-11-22

- [1732268313.960269] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U0331FZS7JT>
静パックでのスティック加工はチャイ抹茶を含め7種類となりますが、12月9日からの製造は6種類のみとなり
残り1種類の製造可能日は現在未定と連絡が入りました。
調整いただいても1月以降になるとの事です。
確定次第ご連絡いただき、ご報告いたします。

## 2024-11-26

- [1732678803.779399] <@U041RJKV5JA>: <@U0331FWGQRM>
 <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
静パックへ状況の確認をしました。
結論として、スティック加工は不可との事です。
理由として、
・空打ちしたスティックがきちんと接着出来ない。
　素材構成の問題の可能性有。水没試験もしたが、空気が漏れてくる。
・フィルムが蛇行しているため、加工が厳しい。
等、他にも理由があるためメールにて連絡するとの事でした。
また、シンナー臭がかなりあるそうです。
12月9日からの製造については、まだ抑えたままにしておくとの事でした。

ONO plusにも確認しましたが、今回のフィルムロールの仕上がりは正常ではないとの事です。
巻き直しても断面が蛇行しており、元々スリット幅が均一ではなかった可能性があるとの事。

自社にてスティック加工が可能となるよう、調整を進めて行きます。
- [1732679060.236499] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> 

今回の件で、方針がある程度見えてきましたね。

スティック製造については、
静パックで製造する場合は、弊社手配のフィルム（吉村など）しか使用しない。
ということにしましょう。

桃翠園の機械での製造については、
引き続きテストを進めてから決めていけたらと思います。

## 2024-11-27

- [1732704371.681589] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
（このフィルムメーカーで進めるために調べて欲しいのではないですが、）
フィルムメーカーから下記コメントが来てます。

接着不良については温度コントロールができるのなら、それで解決できませんか？


フィルムの蛇行について写真をみせてけれませんか？

とのことです。
写真や動画を用いて、どこがどのようにダメなのか確認したいようです。
宜しくお願い致します:sweat_drops:
- [1732768414.997299] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
静パックへ確認しました。
接着不良について、通常140℃～150℃にて加工するところ180℃に温度を上げて加工しても接着不良となったようです。
フィルム蛇行の写真や動画については工場内を関係者以外に見せることは出来ない為、提供不可との事です。
後日、製造不可の理由についてメールをいただく事になっております。
よろしくお願いいたします。
- [1732770947.265949] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <@U03BLQ65GK0>
2025年の現時点での注文予測について
- [1732771216.924519] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <@U03BLQ65GK0>
バニラ(20%)とB2については、
それぞれ少なくとも毎月3000～5000個の販売を見込んでいます。
*→比率が確定しているものについては、事前に製造しておいてOKとのことです。（シルバーの平袋ではなく、デザイン入りのジッパー袋を使用）*

第1四半期（1,2,3月）の予測は上記の通り、3000-5000ですが、最良のシナリオは毎月6000～7000個の販売です。
そして、第2四半期と第3四半期の予測も引き続き毎月6000～7000個です。

新しいフレーバーの需要については、まだ予測が難しい状況です。ブラックフライデーの後にもっと詳しい情報をお知らせできると思います。
- [1732771352.558009] <@U0331FWGQRM>: ＜Sebastyanからの意気込みメッセージを転記します＞
[2024/11/28 13:13:35] Sebastyan （Matcha Land）:
年末が近づく中で、あなたと一緒に仕事ができたことを大変嬉しく思います！2025年が楽しみで、いろいろな計画が進行中です。来年は注文量を倍増させることを目指しています。

[2024/11/28 13:19:16] Sebastyan （Matcha Land）:
さて、お願いがあります。私たちはますます成長しており、バニラ（の例）を見ても分かるように、需要が非常に急速に高まることがあります。そのため、注文を増やしたり、より早く対応を依頼する必要がある場合があります。2025年に向けてのお願いは、リードタイムにおいてMatcha Landを優先していただきたいということです。
私たちが御社にとって最大級の顧客の一つになりつつあると感じています。そのため、需要が突然増加したり、予期しない在庫不足が発生した場合、他の会社からの通常注文よりも私たちの製造を優先していただければと思います。
また、いくつかのフレーバーのレシピが最終決定される中で、長期的には在庫を事前に生産していただければと思います。これにより、すでに在庫がある状態で注文を追加しやすくなります。現在確定しているのは、B2（新しいパッケージが到着次第）、20%バニラ抹茶です。シナモンもこの最後のサンプルで確定することを期待しています。
- [1732777845.145569] <@U0331FWGQRM>: メモ
今までずっと商品に使用してきたのはCeylon cinnamon

7/31　Non Ceylon cinnamon（Cassia cinnamon）を使用できるか？
11/7　サンプル出荷Chai matcha（Cassia Cinnamonを使用）
11/13　サンプル出荷Cinnamon matcha（Cassia Cinnamonを使用）

11/7, 13のサンプル以外はCeylon cinnamonを使用。

※regular cinnamon（=Cassia cinnamon = non Ceylon cinnamon）

## 2024-11-28

- [1732856849.919439] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
12月９日からの静パックでのスティック加工について、最終判断をする日になりましたのでご連絡いたします。
いかがいたしましょうか。

静パック使用のフィルムと同様のフィルムにて、健祥でのB2抹茶スティック加工に備え、静パックで使用のフィルムが吉村製（エスプリ）であるか望月様に確認したところ、他社で静パックオリジナルとして製造したものとの事です。
エスプリで製袋したものと比較したところ、見た目はほぼ同じですが、厚みはエスプリの方が薄くなっております。
吉村に確認したところ、エスプリの厚みを調整する事は出来ないが、グラビアフィルムであれば近づける事は可能との事。
グラビアフィルムで製造した場合は１柄 1連で約8000mとロットは大きいですが、同じ巻き数をエスプリで製造した時と比較すると単価は下がるそうです。
静パックで加工したスティックを吉村に送り、グラビアフィルムの見積もりをいただきましょうか。

## 2024-11-29

- [1732905871.316689] <@U0331FWGQRM>: <@U041RJKV5JA> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U0331FZS7JT>
静パック製造について
~10000本2種類お願いします。~
10000本　バニラ
15000本　シナモン
宜しくお願いします。

Vanilla 20%
Cassia Cinnamon 20%

念の為2月の予約もお願い致します

(シナモンはカシアです。セイロン10%カシア10%ではありません)

## 2024-12-01

- [1733091474.944279] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
変更です。

Vanilla 20%  x10000本
*Cassia Cinnamon 20%  x15000本*

(シナモンはカシアです。セイロン10%カシア10%ではありません)
- [1733104651.280549] <@U082RF7UF1V>: <@U082RF7UF1V>さんがチャンネルに参加しました

## 2024-12-05

- [1733469344.452109] <@U0840UVFVA8>: <@U0840UVFVA8>さんがチャンネルに参加しました

## 2024-12-08

- [1733648848.464539] <@U0331FZS7JT>: 2024.12/8メモ
サンプル製造
•⁠  ⁠chocolate coconut
•⁠  ⁠⁠turmeric coconut (with very little black pepper, ginger, cassia cinnamon, cardamom and cloves)
•⁠  ⁠⁠pumpkin spice (with ginger, nutmeg, cassia cinnamon, cloves and pumpkin)
•⁠  ⁠⁠apple cinnamon (cassia)
- [1733650055.439619] <@U0331FZS7JT>: ・チョコレートフレーバー：キタマ
・ココナッツフレーバー：キタマ
・ターメリック：キタマ
・ブラックペッパー：確認（確か1kgあったはず）
・ジンジャー：キタマ
・カシア：キタマ
・カルダモン：~確認~キタマ
・クローブ：JHD
・パンプキン：曽田香料
・ナツメグ：~確認~キタマ
・アップル：~確認~曽田香料

その他メモ：pumpkin spiceについて
Starbucks that offers pumpkin spice lattes
→既に終売（期間限定）
口コミ：パンプキンの香り強くない（風味を探しに行っても気づかない人もいる）
スパイス強め
カレーか？と思うほどナツメグの香り強め
シナモン好きにはたまらない

## 2024-12-10

- [1733900099.321199] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
2024年12月入荷パッケージについて
- [1733900817.563389] <@U0331FWGQRM>: *バニラ抹茶の袋*
12/11入荷：1600枚
10月に入荷した時の袋と若干の違いあり。
【変化点】
*・切取り線部分：点線→一線*
・サイズ：18.4㎝→18.5㎝（横幅は変化なし）
・色：旧袋より若干ですが薄い色へ

先方に新の袋で統一か、前の残り460枚も使用していいか要確認。
- [1733900938.931299] <@U0331FWGQRM>: *B2 Matcha 60ｇ用の袋*
12/10入荷：2100枚
- [1733901090.946009] <@U0331FWGQRM>: 
  - files: [{"id": "F08594L1H16", "created": 1733901087, "timestamp": 1733901087, "name": "S__233586697.jpg", "title": "S__233586697.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 338567, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08594L1H16/s__233586697.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08594L1H16/download/s__233586697.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08594L1H16-742691d3ea/s__233586697_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08594L1H16-742691d3ea/s__233586697_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08594L1H16-742691d3ea/s__233586697_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08594L1H16-742691d3ea/s__233586697_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08594L1H16-742691d3ea/s__233586697_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08594L1H16-742691d3ea/s__233586697_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08594L1H16-742691d3ea/s__233586697_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08594L1H16-742691d3ea/s__233586697_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08594L1H16-742691d3ea/s__233586697_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACRtLihSM8mpPk/vCoKuR4oxTyB2yfwpu1uyn8qLBdCYpcUmaM0DLERC24bH6U+J9+eOnpUPP2NcZxnnHpmn27qTtAAIHJHeqIe5IGOB83ajLEj5uO9NGdoI9Kcuc8mgChmjNB60lSWTxzokQU7sj0FOFxGpz83vhRVWkJouKxaW7QKAVbij7Wu4Eb+O3HNUs0op3CxITkk+ppKQUtIZ/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08594L1H16/s__233586697.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08594L1H16-c61502cf43", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1733901117.633879] <@U0331FWGQRM>: バニラの袋、新旧比較
  - files: [{"id": "F084HEUSEUV", "created": 1733901094, "timestamp": 1733901094, "name": "旧切取り線.jpg", "title": "旧切取り線.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 279443, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F084HEUSEUV/_______________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F084HEUSEUV/download/_______________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F084HEUSEUV-c18cc6587e/________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F084HEUSEUV-c18cc6587e/________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F084HEUSEUV-c18cc6587e/________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F084HEUSEUV-c18cc6587e/________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F084HEUSEUV-c18cc6587e/________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F084HEUSEUV-c18cc6587e/________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F084HEUSEUV-c18cc6587e/________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F084HEUSEUV-c18cc6587e/________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F084HEUSEUV-c18cc6587e/________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADBtSKuah5P3Rk09d46qw/CkhuSRLtHekK4phZj1H6GjcT/+o0yeZBTgaiJbsCfwpRvPRT+VKw+dDrY/vfwq0WwMngVWtf8AWn6VPcY8h89MUIb3F80eo/Ol8wGqBZScjPXNMaUhSvTj09cUBY0931pVPX61VS4baOB0p8czEtwOtAiO0/1p+lWJTtToD9ar2n+tP0qef/V/iKQ2RYUjO1c/Sq06qMAKBk+lWR92q0/Vfqf5UxDImOwfXGKsw9W+tVYvuD/eqzD1b60DP//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F084HEUSEUV/_______________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F084HEUSEUV-e02778f3d8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F084NR746KE", "created": 1733901098, "timestamp": 1733901098, "name": "新切取り線.jpg", "title": "新切取り線.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 254611, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F084NR746KE/_______________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F084NR746KE/download/_______________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F084NR746KE-4233327ff5/________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F084NR746KE-4233327ff5/________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F084NR746KE-4233327ff5/________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F084NR746KE-4233327ff5/________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F084NR746KE-4233327ff5/________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F084NR746KE-4233327ff5/________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F084NR746KE-4233327ff5/________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F084NR746KE-4233327ff5/________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F084NR746KE-4233327ff5/________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADBBT9lQrJ8wGOpxUglfOAOPoaLBzocUwMmmkYpfMc8ED/vk00l27H/vk0WFzoWpEbBqEh+ysf8AgNA3D7wI+opDUk3YsucvFj+9/Q1JmmSf6yP/AHj/ACNOIoAXzF9f1pPMX1H51n4UDG4/3env/wDWpN4C5yecDJX6H+lA7GkGz0/nUF31Q/Wo7aZRvySctnpS3MilVx60B1LD/wCsj+p/lTz0pjf6yP6n+VPbpQIrNBGDnb79aheJP7tWmqB6BlWM7SMcbutSSHdECfWo0+8n+fWnt/qR/vUAf//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F084NR746KE/_______________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F084NR746KE-938868ee93", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1733901299.660199] <@U033G4KN4TD>: 12/11入荷　
切取り線
  - files: [{"id": "F084LAD807L", "created": 1733901251, "timestamp": 1733901251, "name": "S__233611275_0.jpg", "title": "S__233611275_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 215254, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F084LAD807L/s__233611275_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F084LAD807L/download/s__233611275_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F084LAD807L-487653b54d/s__233611275_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F084LAD807L-487653b54d/s__233611275_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F084LAD807L-487653b54d/s__233611275_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F084LAD807L-487653b54d/s__233611275_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F084LAD807L-487653b54d/s__233611275_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F084LAD807L-487653b54d/s__233611275_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F084LAD807L-487653b54d/s__233611275_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F084LAD807L-487653b54d/s__233611275_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F084LAD807L-487653b54d/s__233611275_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACS1hfajC+1QnrSpyT9KVwJPlzjIzS7BVRztuQfcVcFMQnl0eVT80uaBlXsaVO9MeTaduBTwTg8YweKkCC44kJ9gf1q4DxVO4+/9Vq1EcxqfamhLcfRRRTGRZU9j/wB80E+x/Kn7qM0rAVZ1dypVTwMVPb5EIDDBFOJpN1MViSio91LuoGf/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F084LAD807L/s__233611275_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F084LAD807L-61883bafe0", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F084LADE5C2", "created": 1733901255, "timestamp": 1733901255, "name": "S__233611274_0.jpg", "title": "S__233611274_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 354486, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F084LADE5C2/s__233611274_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F084LADE5C2/download/s__233611274_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F084LADE5C2-d60ba4b666/s__233611274_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F084LADE5C2-d60ba4b666/s__233611274_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F084LADE5C2-d60ba4b666/s__233611274_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F084LADE5C2-d60ba4b666/s__233611274_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F084LADE5C2-d60ba4b666/s__233611274_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F084LADE5C2-d60ba4b666/s__233611274_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F084LADE5C2-d60ba4b666/s__233611274_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F084LADE5C2-d60ba4b666/s__233611274_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F084LADE5C2-d60ba4b666/s__233611274_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACRu4npSh9v8f5U1ZBEv3QxNRtKC33Qv4VJVy3HL75FSeTFKSdo3HrWeHxnB75zVgMygMrZHWgNyY2if7X50fZE9W/OnpcoV+brTvtEfvTFZlWODzDuPT09ae/kR9EUt06Ux4pUjJ3/L/dzVfa3XFKwm2yQyEn7q/wDfIpwlDcFOf9nikhUMSGBHHHFPSKXBGAqn1p2Aj/dn+Jh+FJ+7/vn8qsC0GOTR9kX1pWC7J2wRg0KF9BVQXsTcElfqKmSWNvuuD+NMCYn3pFOaYWFKrc0ASYoxS0lAH//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F084LADE5C2/s__233611274_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F084LADE5C2-a3c21f6d83", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F084Z1A42DP", "created": 1733901275, "timestamp": 1733901275, "name": "S__233611272_0.jpg", "title": "S__233611272_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 241625, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F084Z1A42DP/s__233611272_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F084Z1A42DP/download/s__233611272_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1A42DP-767122ee04/s__233611272_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1A42DP-767122ee04/s__233611272_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1A42DP-767122ee04/s__233611272_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1A42DP-767122ee04/s__233611272_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1A42DP-767122ee04/s__233611272_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1A42DP-767122ee04/s__233611272_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1A42DP-767122ee04/s__233611272_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1A42DP-767122ee04/s__233611272_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1A42DP-767122ee04/s__233611272_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACS8aSioGu0H8LUCbsT8UlVjeL/cb86Ptqf3GpBzIsUVX+2J/caj7Yn9xqA5kWc1Sa3Yk/MvWrO6o91DBq5CLZwch1FKYJP+egqXeKXcKm4cqIhDKB/rBR5Mv/PUVNvFG4UXDlQ3NR5p9MxTZQgNRtKwl2YHUD8KlqFwonVicEKTjFIBv2ogn5R7Ufaz6CmeSrKpEnUdxR9nX/np+lPQZ//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F084Z1A42DP/s__233611272_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F084Z1A42DP-0fcf13c236", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1733901360.578249] <@U033G4KN4TD>: 10/2入荷
切取り点線
  - files: [{"id": "F084L7X7AKD", "created": 1733901321, "timestamp": 1733901321, "name": "S__233611277_0.jpg", "title": "S__233611277_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 190476, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F084L7X7AKD/s__233611277_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F084L7X7AKD/download/s__233611277_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F084L7X7AKD-e170a4bc0d/s__233611277_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F084L7X7AKD-e170a4bc0d/s__233611277_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F084L7X7AKD-e170a4bc0d/s__233611277_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F084L7X7AKD-e170a4bc0d/s__233611277_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F084L7X7AKD-e170a4bc0d/s__233611277_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F084L7X7AKD-e170a4bc0d/s__233611277_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F084L7X7AKD-e170a4bc0d/s__233611277_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F084L7X7AKD-e170a4bc0d/s__233611277_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F084L7X7AKD-e170a4bc0d/s__233611277_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACSkN54HWntDMo3NgfjVu2tdjNuzkHr6j2qywiiXcVH86m5VzMVpIz8y4GeauwT7fpUheOQYfaD71XeBo8lOV/lRcE0zQUhlyOlLVWKKXywVkAB5p3lTf89BTCyJG45PSqMs2Tu/75Hp706W4aVcHAX2qnIxY5pJGbfNohGOWz3qeC6KcMKgUZNWobdmIJGMd6Y7F2KZCg7U/wA1PWiIbECk5xT8imMpXdsjLvHykdh3qGK2ypDf/Xq1dPtAFVwzHpSAmjjjj+6vPqaeHqtvI9acrEmgZaB4pc1EG4pd1AH/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F084L7X7AKD/s__233611277_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F084L7X7AKD-76e4ee9e36", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F084Z1D7MDX", "created": 1733901325, "timestamp": 1733901325, "name": "S__233611276_0.jpg", "title": "S__233611276_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 209796, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F084Z1D7MDX/s__233611276_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F084Z1D7MDX/download/s__233611276_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1D7MDX-a1951af5f0/s__233611276_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1D7MDX-a1951af5f0/s__233611276_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1D7MDX-a1951af5f0/s__233611276_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1D7MDX-a1951af5f0/s__233611276_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1D7MDX-a1951af5f0/s__233611276_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1D7MDX-a1951af5f0/s__233611276_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1D7MDX-a1951af5f0/s__233611276_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1D7MDX-a1951af5f0/s__233611276_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1D7MDX-a1951af5f0/s__233611276_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACS5k+tJnOec4qrJzOx69f5VJbcRHjHPtUjGu7C8Qbjt44zVuqUpxdL9V/nVzNNEoM0UlFMZS3Egt82D04461Yixs4BHPcYpxIB44ppbmpGQXBxMD6AH9at1Quz+8H0q4rZUU0Stx9FJS0xkLEZpmMnqR+NITSZpDBoVY/Mc/U08Njj0pmaTNMRaU5UGlqKNvlp26gD/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F084Z1D7MDX/s__233611276_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F084Z1D7MDX-850115ce39", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1733901409.208839] <@U033G4KN4TD>: 色
10/2入荷時より12/11入荷袋の方が若干薄い
  - files: [{"id": "F084HFB45HT", "created": 1733901370, "timestamp": 1733901370, "name": "S__233611279_0.jpg", "title": "S__233611279_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 113868, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F084HFB45HT/s__233611279_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F084HFB45HT/download/s__233611279_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F084HFB45HT-fd19c2c02f/s__233611279_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F084HFB45HT-fd19c2c02f/s__233611279_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F084HFB45HT-fd19c2c02f/s__233611279_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 333, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F084HFB45HT-fd19c2c02f/s__233611279_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 444, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F084HFB45HT-fd19c2c02f/s__233611279_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F084HFB45HT-fd19c2c02f/s__233611279_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 666, "original_w": 774, "original_h": 716, "thumb_tiny": "AwAsADCzS/KOrfrRUEsas5dmIpAWRj1qNriNCVJ5HoKrrDG3ST9KjZcORnOKLkttFsXEZYDnJPpUtZw4ZT71o0BF3G1FNjBDD9amqFkDyZJHHbNDKGIg3AoCPx4NPI2ICUVifang4/u4prtyijBJ96QDVw5I8pRirA6VGVBbJGSOhp44poBcVT+ytuOHq7TT96mFiqbNj1k/IVKSQcgEHGOBUxpKVgId7Z6N/wB81IKXA9KQ0WA//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F084HFB45HT/s__233611279_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F084HFB45HT-787b08c7c8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F084DMVKVU6", "created": 1733901374, "timestamp": 1733901374, "name": "S__233611281_0.jpg", "title": "S__233611281_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 168407, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F084DMVKVU6/s__233611281_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F084DMVKVU6/download/s__233611281_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F084DMVKVU6-4909a5d80b/s__233611281_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F084DMVKVU6-4909a5d80b/s__233611281_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F084DMVKVU6-4909a5d80b/s__233611281_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 327, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F084DMVKVU6-4909a5d80b/s__233611281_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 435, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F084DMVKVU6-4909a5d80b/s__233611281_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F084DMVKVU6-4909a5d80b/s__233611281_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 653, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F084DMVKVU6-4909a5d80b/s__233611281_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 726, "original_w": 958, "original_h": 869, "thumb_tiny": "AwArADC0CByTge9L5iY+8v501gCpBGRUDCNTgx/kKVwLO9cfeX86Ny+o/Oq6rE+QEH405oowCSlFw1JsijI7VVxB6H9amjjVGJUYyKLhqOP3ahYAyHKg/jUshIXgZNQxR4yzY3H9KAHIpD5QjBp7/cP0oAAORTJldgFUDB70gG+WpTpgnod1Sxbv4sfhQFCqAAMClTg4oAcRkYpvlD0FPFLTAaIwDnjNIyZ64NSHpTaLARmMegoVdvSnnrSUWA//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F084DMVKVU6/s__233611281_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F084DMVKVU6-4b0de31aaf", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1733901419.860109] <@U033G4KN4TD>: 
  - files: [{"id": "F084Z1JFCMP", "created": 1733901414, "timestamp": 1733901414, "name": "755593988.359951.mp4", "title": "755593988.359951.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 4802428, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "complete", "locale": "en-US"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1JFCMP-9fe209bc0e/755593988.359951.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1JFCMP-9fe209bc0e/755593988.359951.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F084Z1JFCMP/download/755593988.359951.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "vtt": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1JFCMP-9fe209bc0e/file.vtt?_xcb=d0e2b&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1JFCMP-9fe209bc0e/file.m3u8?_xcb=d0e2b&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTA5MDgxMyxBVkVSQUdFLUJBTkRXSURUSD0xMDA3NDI0LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTYwOHgxMDgwLEZSQU1FLVJBVEU9MjkuOTcwLFNVQlRJVExFUz0ic3VicyIKZGF0YTphcHBsaWNhdGlvbi92bmQuYXBwbGUubXBlZ3VybDtiYXNlNjQsSTBWWVZFMHpWUW9qUlZoVUxWZ3RWa1ZTVTBsUFRqb3pDaU5GV0ZRdFdDMVVRVkpIUlZSRVZWSkJWRWxQVGpvM0NpTkZXRlF0V0MxTlJVUkpRUzFUUlZGVlJVNURSVG94Q2lORldGUXRXQzFRVEVGWlRFbFRWQzFVV1ZCRk9sWlBSQW9qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0TkZveFNrWkRUVkF0T1dabE1qQTVZbU13WlM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE5Gb3hTa1pEVFZBdE9XWmxNakE1WW1Nd1pTOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TWk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRORm94U2taRFRWQXRPV1psTWpBNVltTXdaUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd015NTBjd29qUlZoVVNVNUdPakF1TXpNMExBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0TkZveFNrWkRUVkF0T1dabE1qQTVZbU13WlM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOQzUwY3dvalJWaFVMVmd0UlU1RVRFbFRWQW89CiNFWFQtWC1NRURJQTpUWVBFPVNVQlRJVExFUyxHUk9VUC1JRD0ic3VicyIsTkFNRT0iRW5nbGlzaCIsREVGQVVMVD1ZRVMsQVVUT1NFTEVDVD1ZRVMsRk9SQ0VEPU5PLExBTkdVQUdFPSJlbmciLFVSST0iZGF0YTphcHBsaWNhdGlvbi92bmQuYXBwbGUubXBlZ3VybDtiYXNlNjQsSTBWWVZFMHpWUW9qUlZoVUxWZ3RWa1ZTVTBsUFRqb3pDaU5GV0ZRdFdDMVVRVkpIUlZSRVZWSkJWRWxQVGpvMk1EQUtJMFZZVkMxWUxVMUZSRWxCTFZORlVWVkZUa05GT2pFS0kwVllWQzFZTFZCTVFWbE1TVk5VTFZSWlVFVTZWazlFQ2lORldGUkpUa1k2TVRndU16VXhMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE5Gb3hTa1pEVFZBdE9XWmxNakE1WW1Nd1pTOW1hV3hsTG5aMGRBb2pSVmhVTFZndFJVNUVURWxUVkE9PSIK", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1JFCMP-9fe209bc0e/755593988.359951_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 18351, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F084Z1JFCMP-9fe209bc0e/755593988.359951_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F084Z1JFCMP/755593988.359951.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F084Z1JFCMP-7de7b4f5ff", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-12-11

- [1733967656.745139] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
健祥にて、静パック使用フィルムと同等素材のフィルムにてB2抹茶スティック加工を行う際に使用するグラビアフィルムの見積もりが届きました。
＜ロール製造数量＞
・8000ｍの場合＠27.5/包
　計算上のスティック加工可能数量：72,720本
・17,800ｍの場合＠1.76/包
　計算上のスティック加工可能数量：161,802本
現在使用してる健祥所有フィルムの価格は@1.5/包となります。
ご確認お願いいたします。
  - files: [{"id": "F084U8YCJ7N", "created": 1733967634, "timestamp": 1733967634, "name": "静パック使用ロールと同等品見積書.pdf", "title": "静パック使用ロールと同等品見積書.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 78436, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F084U8YCJ7N/___________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F084U8YCJ7N/download/___________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F084U8YCJ7N-40db6a28c7/____________________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F084U8YCJ7N/___________________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F084U8YCJ7N-327a8c3873", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1733980864.115509] <@U033G4KN4TD>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U0840UVFVA8>
12/11入荷の袋について
本日から抹茶詰めを行っていますが、
チャック部分から白い異物が出てきます。
  - files: [{"id": "F084PH2700M", "created": 1733980765, "timestamp": 1733980765, "name": "S__233758740_0.jpg", "title": "S__233758740_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 333977, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F084PH2700M/s__233758740_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F084PH2700M/download/s__233758740_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F084PH2700M-b5cfe10695/s__233758740_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F084PH2700M-b5cfe10695/s__233758740_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F084PH2700M-b5cfe10695/s__233758740_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F084PH2700M-b5cfe10695/s__233758740_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F084PH2700M-b5cfe10695/s__233758740_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F084PH2700M-b5cfe10695/s__233758740_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F084PH2700M-b5cfe10695/s__233758740_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F084PH2700M-b5cfe10695/s__233758740_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F084PH2700M-b5cfe10695/s__233758740_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACR9GaSigBc0tNzThQAUtFFADSMU4Mu0Dbk/SkamBsHIoAlB5wFpDyxNNEhznilBzSAdijFLRTArs5NMzQTTaAJFNSrVdTUyNQBOKKaGozQB/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F084PH2700M/s__233758740_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F084PH2700M-fb2c1f1fe2", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F084S9R6J8K", "created": 1733980769, "timestamp": 1733980769, "name": "S__233758741_0.jpg", "title": "S__233758741_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 176465, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F084S9R6J8K/s__233758741_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F084S9R6J8K/download/s__233758741_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F084S9R6J8K-5ebbd7a265/s__233758741_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F084S9R6J8K-5ebbd7a265/s__233758741_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F084S9R6J8K-5ebbd7a265/s__233758741_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F084S9R6J8K-5ebbd7a265/s__233758741_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F084S9R6J8K-5ebbd7a265/s__233758741_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F084S9R6J8K-5ebbd7a265/s__233758741_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F084S9R6J8K-5ebbd7a265/s__233758741_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F084S9R6J8K-5ebbd7a265/s__233758741_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F084S9R6J8K-5ebbd7a265/s__233758741_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACQZxtBbv29aWDJlXfwT0X0FRgYcyKPm/hz2pA6o+Tlj3NVKVzPYvsisAHAYD1pfJiH8C1XSfPRs+xqUFnOVJHsDWZaaY8RRf881/Kl8qL/nmv5VD5pBxv6e1Hmn+/QO5UzzyM0FVbsRVholXGTye1QNIiPhs/UVYJCAKp9algdkkHUg9arNKgbAyR7VMlzBgDaw+tILEzgF2PvTcCrEZGwEZAPPNOz70rE8hUkcs+ccdqjfDDkA1KVphFLmNbEBjX0p8cagg4pPNjzjH41MYyoBI4NO4D2kOetJ5h9aZtPrRsPrRdCsf//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F084S9R6J8K/s__233758741_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F084S9R6J8K-0d06ca43a1", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F085F6W8SM6", "created": 1733980818, "timestamp": 1733980818, "name": "S__233758738_0.jpg", "title": "S__233758738_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 185769, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F085F6W8SM6/s__233758738_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F085F6W8SM6/download/s__233758738_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6W8SM6-5b74a33563/s__233758738_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6W8SM6-5b74a33563/s__233758738_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6W8SM6-5b74a33563/s__233758738_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6W8SM6-5b74a33563/s__233758738_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6W8SM6-5b74a33563/s__233758738_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6W8SM6-5b74a33563/s__233758738_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6W8SM6-5b74a33563/s__233758738_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6W8SM6-5b74a33563/s__233758738_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6W8SM6-5b74a33563/s__233758738_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACSbyYySSoz7E05YI+y9PepVK4HqabK+1cDuamwXsVrhgoHUjoKi27kJHcVHcSM8pPYcYojkO0oDweRmnygpdxPJOf8A69Hk/wCc0vmN7flR5je35VNmXoX4yu0OTiop5Oc4wMcVAWKsCKM7myRmrcbMy3IwO5o2FjxS4JNWEiw4G4MfamkO4hgIxkDOKPJqwY5T/d/Ok8uX/Y/OkUViAaTbTqQ8VqzIVB+dWYVVTyRv9PSo7aPJ3Ht0FJJG65PDjPJFZyl0RW2pazSZqOEnywTk59afn2qSj//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F085F6W8SM6/s__233758738_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F085F6W8SM6-bc0771451f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F084UTH8068", "created": 1733980826, "timestamp": 1733980826, "name": "S__233758735_0.jpg", "title": "S__233758735_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 190413, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F084UTH8068/s__233758735_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F084UTH8068/download/s__233758735_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F084UTH8068-9756acf3dc/s__233758735_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F084UTH8068-9756acf3dc/s__233758735_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F084UTH8068-9756acf3dc/s__233758735_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F084UTH8068-9756acf3dc/s__233758735_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F084UTH8068-9756acf3dc/s__233758735_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F084UTH8068-9756acf3dc/s__233758735_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F084UTH8068-9756acf3dc/s__233758735_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F084UTH8068-9756acf3dc/s__233758735_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F084UTH8068-9756acf3dc/s__233758735_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACR5am+bzwaRVMp2qQPc9qe9qY1LF12jqelaXIsKxLphTg0nAJPNV1lQHrj3xVpdrr1H1pNJ6oLjhGMdTS+WPU1AJXX5QM49RS+fJ/d/SsrsvQhLDHWluJ98aoBtA7VPPDG4LJkN6etUSKpu4kMC+9TxSeXw33f1FEUJfq20dialnVIgiIoHGSe5ovYGOZEkO4swPsetJ5Mf/PR/zp8UDNEp34yM4xT/ALO3/PT9Kq8RWYghlPz5GT/D6VDJEDJ8wK+o9avBsVDcyhUOew/U1KKZHGg3bRwvUioFZZrhmkbCE8fSpGciA4+9JwPpU32aKSFVZefUdRSla4lcnAAA24x2xRzVE2lwhxHN8vbnFH2a7/56j/vqpsUf/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F084UTH8068/s__233758735_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F084UTH8068-ad3c4e10cd", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F085F6WRH88", "created": 1733980830, "timestamp": 1733980830, "name": "S__233758737_0.jpg", "title": "S__233758737_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 155828, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F085F6WRH88/s__233758737_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F085F6WRH88/download/s__233758737_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6WRH88-985a0786af/s__233758737_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6WRH88-985a0786af/s__233758737_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6WRH88-985a0786af/s__233758737_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6WRH88-985a0786af/s__233758737_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6WRH88-985a0786af/s__233758737_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6WRH88-985a0786af/s__233758737_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6WRH88-985a0786af/s__233758737_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6WRH88-985a0786af/s__233758737_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F085F6WRH88-985a0786af/s__233758737_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACR8Vq5bLkbO+DRdMAqgcc1akbEZ7VnXDFpOMbRxQJ7hnIyKcP3iY755qABuop6sQwxQ0NMcIGHA/nR5L0vmv/dH5UebJ/d/So1L0J5Jd3Gcn+VVytL745pS4CDA5z1q7WM0J047mnRpuYAU1VLEVMsbI+M89gDVJBcZJEVcgGm+WasvHKzZwv503yZfRfzqSiIgU0j2zUhBpDmtWjJMFx2qeFB979KihQux29O9DB4+SPxFRKVtA21LRNGaahJQbuuKdUGh/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F085F6WRH88/s__233758737_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F085F6WRH88-3d4565086b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1733985492.467099] <@U0331FWGQRM>: <@U041RJKV5JA> cc<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
ありがとうございます。
つまり、16万本分無地フィルムを製造すればトントンってことですね。
んー、現段階では踏み切れないですね。判断先延ばし（保留）にさせてください。

理由：
・MOQが大きすぎる？
・可能性として、抹茶sachetもデザインフィルムになる可能性が高い。
・現状、Sebastyanからの依頼がないので、良かれと思ってやってあげるには、コストがかかりすぎ？
- [1733985658.269479] <@U0331FWGQRM>: <@U033G4KN4TD> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
報告ありがとうございます。非常に助かります。

結論としては、手で粉を払って（方法は任せます）
出来るだけ取り除いて、充填作業を進めてください！！
- [1733987388.248569] <@U033G4KN4TD>: <@U0331FWGQRM>
42個異物に気づかず詰めてしまったものがあるようですが、廃棄でよろしいでしょうか？
篩を考えましたが、細かい異物もあるため篩下に落ちると思われます。
- [1733987803.933839] <@U033G4KN4TD>: メモ
12/12
バニラ抹茶　袋　1961枚入荷
- [1733988145.409299] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> cc <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
判断基準について目線合わせしたいので共有します。（半分雑談です。）
理解されていると思いますが、

そもそも論ですが、
袋はSebastyanが手配しておりますので、
袋の品質はそのメーカー及びSebastyanの管理下で行われる必要があります。
→なので、品質の検査は桃翠園がする必要はない、とまでは言えませんが、
　とりあえず、その責任はありません。
　ただ、Sebastyanからすると、この異物？については、知る術がないので、
　桃翠園から報告してあげなければならない。という状況です。
　なので、今回の報告は非常に助かります。
　
もし桃翠園が袋を手配していれば、桃翠園が、
袋の再製造、そのまま使用、メーカーへの補償問題、
お客様へは納期遅れの謝罪、などを桃翠園が判断しコントロールする必要があります。
（もちろんこの場合も、異物等があれば報告は欲しいのですが
桃翠園の品質管理基準を現場で判断できれば、その後のフローは現場でできる可能性もなくはありません。）

なので、一長一短ですが、
今回のような、手間が増えて、煩わしさはあるものの、
責任がないという点で営業的には客手配はメリットがあるのかな？
という見方もできるかもしれません。

## 2024-12-16

- [1734364843.087569] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
12月入荷分の袋の種類と各数量は
下記以外にありますか？？？
（MangoとかChai matchaは来てます？）

*B2 Matcha 60ｇ袋*
12/10入荷：2100枚
12/13入荷：1400枚（追記）

*Vanilla matcha 60g袋*
12/11入荷：1600枚
12/12入荷：1961枚
- [1734389454.549269] <@U033G4KN4TD>: 12/13　*B2 Matcha 60ｇ袋*　1400枚入荷しております。
&gt; （MangoとかChai matchaは来てます？）
B2、Vanilla以外は届いておりません。
<https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1734056411518189?thread_ts=1732252435.813509&amp;cid=C03C62NBSDP>
  - attachments: [{"from_url": "https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1734056411518189?thread_ts=1732252435.813509&amp;cid=C03C62NBSDP", "ts": "1734056411.518189", "author_id": "U033G4KN4TD", "channel_id": "C03C62NBSDP", "channel_team": "T033D70RR6H", "is_msg_unfurl": true, "is_reply_unfurl": true, "message_blocks": [{"team": "T033D70RR6H", "channel": "C03C62NBSDP", "ts": "1734056411.518189", "message": {"blocks": [{"type": "rich_text", "block_id": "3H78N", "elements": [{"type": "rich_text_section", "elements": [{"type": "text", "text": "12/13\nピュア抹茶の袋　1400枚入荷\nUPS：1ZX2W3290499256964\n（12/13時点ピュア抹茶トータル3500枚）"}]}]}]}}], "id": 1, "original_url": "https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1734056411518189?thread_ts=1732252435.813509&amp;cid=C03C62NBSDP", "fallback": "[December 12th, 2024 6:20 PM] tousuien04: 12/13\nピュア抹茶の袋　1400枚入荷\nUPS：1ZX2W3290499256964\n（12/13時点ピュア抹茶トータル3500枚）", "text": "12/13\nピュア抹茶の袋　1400枚入荷\nUPS：1ZX2W3290499256964\n（12/13時点ピュア抹茶トータル3500枚）", "author_name": "Fukui", "author_link": "https://grp-ssm9297.slack.com/team/U033G4KN4TD", "author_icon": "https://avatars.slack-edge.com/2022-02-16/3118194883458_b87877677a672efe50f6_48.png", "author_subname": "Fukui", "mrkdwn_in": ["text"], "footer": "Slack の会話内のスレッド"}]
- [1734403602.577899] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
下記リンクの件、返信来ましたか？

現時点でわかっている内容
ーーーーーー
・芯が潰れているため。
→新しい芯に巻き直しましたが、それでも製造ができませんでした。

・フィルムが蛇行しているため、加工が厳しい。
→フィルムを新しい芯に巻き直しても断面が蛇行しており、フィルムの幅がそもそも均一ではなかった可能性があるとの事。
スティック製造工場に製造中の写真や動画を要求しましたが、工場内を関係者以外に見せることは出来ない為、提供不可との事です。

・フィルムを製袋加工する工程でスティックがきちんと熱圧着出来ない。
素材構成の問題の可能性有。水没試験もしたが、空気が漏れてくる。
通常140℃～150℃にて加工するところ180℃に温度を上げて加工しても接着不良となったようです。

・シンナー臭がかなりあった。
ーーーーーー
<https://grp-ssm9297.slack.com/archives/C0757BTNYA0/p1732768414997299?thread_ts=1732089899.783379&amp;cid=C0757BTNYA0>
  - attachments: [{"from_url": "https://grp-ssm9297.slack.com/archives/C0757BTNYA0/p1732768414997299?thread_ts=1732089899.783379&amp;cid=C0757BTNYA0", "ts": "1732768414.997299", "author_id": "U041RJKV5JA", "channel_id": "C0757BTNYA0", "channel_team": "T033D70RR6H", "is_msg_unfurl": true, "is_reply_unfurl": true, "message_blocks": [{"team": "T033D70RR6H", "channel": "C0757BTNYA0", "ts": "1732768414.997299", "message": {"blocks": [{"type": "rich_text", "block_id": "T5D4p", "elements": [{"type": "rich_text_section", "elements": [{"type": "user", "user_id": "U0331FWGQRM"}, {"type": "text", "text": "\n "}, {"type": "usergroup", "usergroup_id": "S073HEMKWV7"}, {"type": "text", "text": "\n静パックへ確認しました。\n接着不良について、通常140℃～150℃にて加工するところ180℃に温度を上げて加工しても接着不良となったようです。\nフィルム蛇行の写真や動画については工場内を関係者以外に見せることは出来ない為、提供不可との事です。\n後日、製造不可の理由についてメールをいただく事になっております。\nよろしくお願いいたします。"}]}]}]}}], "id": 1, "original_url": "https://grp-ssm9297.slack.com/archives/C0757BTNYA0/p1732768414997299?thread_ts=1732089899.783379&amp;cid=C0757BTNYA0", "fallback": "[November 27th, 2024 8:33 PM] tousuien.s006: <@U0331FWGQRM>\n <!subteam^S073HEMKWV7>\n静パックへ確認しました。\n接着不良について、通常140℃～150℃にて加工するところ180℃に温度を上げて加工しても接着不良となったようです。\nフィルム蛇行の写真や動画については工場内を関係者以外に見せることは出来ない為、提供不可との事です。\n後日、製造不可の理由についてメールをいただく事になっております。\nよろしくお願いいたします。", "text": "<@U0331FWGQRM>\n <!subteam^S073HEMKWV7>\n静パックへ確認しました。\n接着不良について、通常140℃～150℃にて加工するところ180℃に温度を上げて加工しても接着不良となったようです。\nフィルム蛇行の写真や動画については工場内を関係者以外に見せることは出来ない為、提供不可との事です。\n後日、製造不可の理由についてメールをいただく事になっております。\nよろしくお願いいたします。", "author_name": "Hirakawa", "author_link": "https://grp-ssm9297.slack.com/team/U041RJKV5JA", "author_icon": "https://avatars.slack-edge.com/2022-09-11/4078874890257_aed9eafd9eee277ba076_48.png", "author_subname": "Hirakawa", "mrkdwn_in": ["text"], "footer": "Slack の会話内のスレッド"}]
- [1734403805.500119] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
あと、ONO plusからの請求書があれば全てフォルダに入れてもらえますか？
（ここにも貼り付けてください。）
宜しくお願い致します。
- [1734408337.679939] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
追加で確認（念の為）
この画像の時は、空気漏れは無かったんですよね？？
  - files: [{"id": "F085DRNJ18B", "created": 1734408333, "timestamp": 1734408333, "name": "de9732a5-0d93-4025-b405-bb888ee01d2c.jpg", "title": "de9732a5-0d93-4025-b405-bb888ee01d2c", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 109200, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F085DRNJ18B/de9732a5-0d93-4025-b405-bb888ee01d2c.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F085DRNJ18B/download/de9732a5-0d93-4025-b405-bb888ee01d2c.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F085DRNJ18B-c2b948a965/de9732a5-0d93-4025-b405-bb888ee01d2c_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F085DRNJ18B-c2b948a965/de9732a5-0d93-4025-b405-bb888ee01d2c_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F085DRNJ18B-c2b948a965/de9732a5-0d93-4025-b405-bb888ee01d2c_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F085DRNJ18B-c2b948a965/de9732a5-0d93-4025-b405-bb888ee01d2c_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F085DRNJ18B-c2b948a965/de9732a5-0d93-4025-b405-bb888ee01d2c_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F085DRNJ18B-c2b948a965/de9732a5-0d93-4025-b405-bb888ee01d2c_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F085DRNJ18B-c2b948a965/de9732a5-0d93-4025-b405-bb888ee01d2c_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F085DRNJ18B-c2b948a965/de9732a5-0d93-4025-b405-bb888ee01d2c_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F085DRNJ18B-c2b948a965/de9732a5-0d93-4025-b405-bb888ee01d2c_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 960, "original_h": 1280, "thumb_tiny": "AwAwACSD7Wf7g/Ol+2H+4PzqsatW8CSQbipY57HFKw7h9rP9wfnR9qJ/gH51KttFuYYPGO9RTxojgICOM8mnYVxftB/uijz2/uimAcUYosFyua0LE4t/xNZ9X7U4twPx/WgCSPmSYn+//QVXum/0g+wH8qlDhS2T1Ymq1y3+kN+H8qAE3Ub6j3UbqAGVKk5VcbQRjFSfZlP8Rpfsin+I0rjsMFwO8Y+uaikbe5YDGferH2Qf3z+VH2Qf3z+VFwsVaKtfZP8Ab/Sk+yf7f6UXCx//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F085DRNJ18B/de9732a5-0d93-4025-b405-bb888ee01d2c.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F085DRNJ18B-ca7a722984", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1734409517.607709] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
静パックより未だ報告がありませんので、催促いたします。
ONOplusからの請求書は未着ですので入手出来次第、報告いたします。
よろしくお願いいたします。
- [1734409631.091599] <@U0331FWGQRM>: <@U041RJKV5JA> 
あれば嬉しいですが、なければないで大丈夫です:sweat_drops:
（気まずくならないようにお願いします笑）

ついでに空気漏れはの確認もお願いします！

## 2024-12-17

- [1734438994.352549] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
2024/12/17
中国のフィルムメーカーが、
ロールフィルムのリベンジ版を作成して発送したそうです。
こちら送り状です。
- [1734439016.330059] <@U0331FWGQRM>: 
  - files: [{"id": "F08599Q69D4", "created": 1734439010, "timestamp": 1734439010, "name": "WhatsApp Image 2024-12-17 at 09.03.05.jpeg", "title": "WhatsApp Image 2024-12-17 at 09.03.05.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 61953, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08599Q69D4/whatsapp_image_2024-12-17_at_09.03.05.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08599Q69D4/download/whatsapp_image_2024-12-17_at_09.03.05.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08599Q69D4-0de83308fe/whatsapp_image_2024-12-17_at_09.03.05_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08599Q69D4-0de83308fe/whatsapp_image_2024-12-17_at_09.03.05_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08599Q69D4-0de83308fe/whatsapp_image_2024-12-17_at_09.03.05_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 264, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08599Q69D4-0de83308fe/whatsapp_image_2024-12-17_at_09.03.05_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 352, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08599Q69D4-0de83308fe/whatsapp_image_2024-12-17_at_09.03.05_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 384, "original_h": 523, "thumb_tiny": "AwAwACO1yGxkD6ipFG4/fU/QVHMSHGFJ4FKFmUcLj8aAJXQYyoG4dKQIT97GPpQrS/xIBx2NKrOT8ybR65zQAhVQcACkwPQU5vvUlAEDlg3BbH1prthFJdxyRx60pjIPMhGfU0qhADvk3c8fNjFAEfnDdnc/zcj25qzbjMQJYtnnmmKsJPXt/epWQkAQueDzyeBQBIwG7pSYHpSFRn7z/maTaP7z/maAIboglcEHp/WqxB2nj/PFaCiLj5OfpS748/d/8doAoxDB5/uCrVuwVnyQM471MDGem38qjZI0k3BCxPp0FADmdc/eX86Tcv8AeX86Uhc9F/Kkwvov5UAf/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08599Q69D4/whatsapp_image_2024-12-17_at_09.03.05.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08599Q69D4-9111bd163a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-12-19

- [1734596467.146029] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
12/26出荷予定分について。
袋の納品が遅れているため、
下記の★の商品は一部しか出荷できなくなる可能性があると思います。
その場合の出荷可能数量を教えてもらえますか？（現時点で袋詰めが可能な数量でOKです）
（※★以外の商品でももし予定通り出荷できないものがあれば教えてください）

*December 26*
TSE-MTL-013-24-1:
　B2 Matcha 60g x 5,000 bags　←★
　B2 Matcha 2.0g x 10,000 sachets

TSE-MTL-013-24-2B:
　Vanilla 60g x 3,000 bags　←★

TSE-MTL-013-24-3:
　Vanilla 2.5g x 10,000 sachets
　Cinnamon 2.5g x 15,000 sachets
- [1734669603.883299] <@U0331FWGQRM>: *B2 Matcha 60ｇ袋*
12/10入荷：2100
12/13入荷：1400
12/20入荷：1400

*Vanilla matcha 60g袋*
12/11入荷：1600
12/12入荷：1961
12/20入荷：1200

*Cinnamon matcha 60g袋*
12/20入荷：シナモン3400+3200

*Strawberry lemon matcha 60g袋*
12/20入荷：3600+3600

*Mango Matcha 60g袋*
12/20入荷：3500+3600

*Pineapple Lemon matcha 60g袋*
12/20入荷：3500
←印刷会社の製造ミスらしい。
（本当はいらないのに製造した。次回機会があれば使用してくださいとのこと。）
- [1734674076.894389] <@U0331FWGQRM>: 
  - files: [{"id": "F085YVDUYP4", "created": 1734674071, "timestamp": 1734674071, "name": "スクリーンショット 2024-12-20 14.06.49.png", "title": "スクリーンショット 2024-12-20 14.06.49.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 309485, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F085YVDUYP4/____________________________2024-12-20_14.06.49.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F085YVDUYP4/download/____________________________2024-12-20_14.06.49.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F085YVDUYP4-77c7f25bdb/____________________________2024-12-20_14.06.49_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F085YVDUYP4-77c7f25bdb/____________________________2024-12-20_14.06.49_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F085YVDUYP4-77c7f25bdb/____________________________2024-12-20_14.06.49_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 228, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F085YVDUYP4-77c7f25bdb/____________________________2024-12-20_14.06.49_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 304, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F085YVDUYP4-77c7f25bdb/____________________________2024-12-20_14.06.49_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F085YVDUYP4-77c7f25bdb/____________________________2024-12-20_14.06.49_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 457, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F085YVDUYP4-77c7f25bdb/____________________________2024-12-20_14.06.49_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 507, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F085YVDUYP4-77c7f25bdb/____________________________2024-12-20_14.06.49_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 609, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F085YVDUYP4-77c7f25bdb/____________________________2024-12-20_14.06.49_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 650, "original_w": 2434, "original_h": 1544, "thumb_tiny": "AwAeADB9Ph/1oplPhx5o4oAs7ec55+tLgFcHmkx/sj8qUAY6D8qAA4PWmyAeWxHbpTsewpsoxE3GKAKlSQ/60VHT4v8AWDmgCxtPqPypwHX+tN/ixx+VOHTH9KAFpkv+rane1NlP7tqAP//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F085YVDUYP4/____________________________2024-12-20_14.06.49.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F085YVDUYP4-2b30d1c938", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1734674252.387519] <@U0331FWGQRM>: 17箱送って、9箱受け取っている。
残りの8箱のうち、２箱がChai。
Chaiは他社商品（坪内製茶？）
残り6箱は抹茶２、バニラ2、ジンジャーレモン２

## 2024-12-20

- [1734755971.140789] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
佐川で12/21着で届くらしいです。
<tel:490455293602|490455293602>
宜しくお願い致します。

## 2024-12-22

- [1734913643.323979] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本件、今日中に、確認お願いします。
Sebastyanや、Shipping Agentにケース数変更連絡、
invoiceの変更を伝える必要があります。
・出荷日を延期した場合、何日に全量出荷可能か。
・出荷日をキープした場合、26日に何個、後日何個、出荷になるのか。
確認お願いします。
宜しくお願い致します。
- [1734932099.549159] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
出荷数量についてご連絡いたします。
&gt; ・出荷日を延期した場合、何日に全量出荷可能か。
1月6日であれば全量出荷可能です。　
&gt; ・出荷日をキープした場合、26日に何個、後日何個、出荷になるのか。
B2 Matcha 60g のみ全量発送が難しいです。
5,000 bags → 3,500 bags
不足分の1,500 bagsは1月6日（月）の出荷となります。
よろしくお願いたします。
- [1734934183.235299] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
残り8箱は届きましたか？
- [1734940595.308229] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
残り８箱届きました。
内訳は下記となります。
・バニラ　2ケース　7,000枚
・抹茶　2ケース　7,000枚
・チャイ　3ケース　10,500枚
・パイナップルレモン　1ケース　3,500枚
よろしくお願いたします。

## 2024-12-23

- [1735006250.975069] <@U0331FWGQRM>: メモ
Total contents are as follows:

Matcha: 8,400
Vanilla: 8,200
Cinnamon: 6,600
Strawberry: 7,200
Mango: 7,100
Pineapple: 7,000
Chai: 10,500
- [1735015119.631379] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
下記のとおり変更です。

*変更前*
・Shipment on December 26
TSE-MTL-013-24-1 （21cartons）← Split into two
TSE-MTL-013-24-2B
TSE-MTL-013-24-3
↓
*変更後*
・Shipment on December 26
TSE-MTL-013-24-1A　（16cartons）
TSE-MTL-013-24-2B
TSE-MTL-013-24-3

・Shipment on January 6
TSE-MTL-013-24-1B（5cartons）

## 2024-12-24

- [1735030084.534859] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
【TSE-MTL-013-24-1】
今回よりBIO Matcha 60gの包材が変更となっております。
新包材がデザインされているカートンラベルのフォーマットは有りますでしょうか？
- [1735031632.555929] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
遅くなりましたが、静パックで加工いただきましたスティックの空気漏れの確認を行いました。
結果、空気漏れは確認出来ませんでした。
ご確認お願いいたします。
  - files: [{"id": "F086CPKNBK4", "created": 1735031607, "timestamp": 1735031607, "name": "IMG_0552.MOV", "title": "IMG_0552.MOV", "mimetype": "video/quicktime", "filetype": "mov", "pretty_type": "QuickTime Movie", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 20993938, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "complete", "locale": "en-US"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F086CPKNBK4-9f18b567cb/img_0552.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F086CPKNBK4-9f18b567cb/img_0552.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F086CPKNBK4/download/img_0552.mov?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "vtt": "https://files.slack.com/files-tmb/T033D70RR6H-F086CPKNBK4-9f18b567cb/file.vtt?_xcb=1e123&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F086CPKNBK4-9f18b567cb/file.m3u8?_xcb=1e123&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9NDQyNTM1NixBVkVSQUdFLUJBTkRXSURUSD00NDI1MzU2LENPREVDUz0iYXZjMS42NDAwMjgsbXA0YS40MC41IixSRVNPTFVUSU9OPTE5MjB4MTA4MCxGUkFNRS1SQVRFPTI5Ljk3MCxTVUJUSVRMRVM9InN1YnMiCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE5rTlFTMDVDU3pRdE9XWXhPR0kxTmpkallpOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TVM1MGN3b2pSVmhVU1U1R09qUXVOek00TEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTROa05RUzA1Q1N6UXRPV1l4T0dJMU5qZGpZaTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01pNTBjd29qUlZoVUxWZ3RSVTVFVEVsVFZBbz0KI0VYVC1YLU1FRElBOlRZUEU9U1VCVElUTEVTLEdST1VQLUlEPSJzdWJzIixOQU1FPSJFbmdsaXNoIixERUZBVUxUPVlFUyxBVVRPU0VMRUNUPVlFUyxGT1JDRUQ9Tk8sTEFOR1VBR0U9ImVuZyIsVVJJPSJkYXRhOmFwcGxpY2F0aW9uL3ZuZC5hcHBsZS5tcGVndXJsO2Jhc2U2NCxJMFZZVkUwelZRb2pSVmhVTFZndFZrVlNVMGxQVGpvekNpTkZXRlF0V0MxVVFWSkhSVlJFVlZKQlZFbFBUam8yTURBS0kwVllWQzFZTFUxRlJFbEJMVk5GVVZWRlRrTkZPakVLSTBWWVZDMVlMVkJNUVZsTVNWTlVMVlJaVUVVNlZrOUVDaU5GV0ZSSlRrWTZNVEF1TnpRMExBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0TmtOUVMwNUNTelF0T1dZeE9HSTFOamRqWWk5bWFXeGxMblowZEFvalJWaFVMVmd0UlU1RVRFbFRWQT09Igo=", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F086CPKNBK4-9f18b567cb/img_0552_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 10744, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F086CPKNBK4-9f18b567cb/img_0552_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 1920, "thumb_video_h": 1080, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F086CPKNBK4/img_0552.mov", "permalink_public": "https://slack-files.com/T033D70RR6H-F086CPKNBK4-3b1ffa42d7", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-12-25

- [1735114899.961299] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
ONO plusより請求書が届きました。
今回のフィルム到着から巻き直しまでの費用は342,150円となります。
（輸入時の関税や国内運賃も含んでおります。）
請求書等、書類を添付しておりますのでご確認お願いいたします。
お送りした書類はONO plusフォルダ - 中国製フィルムロール　納品書/請求書 - 費用　に格納しております。
よろしくお願いいたします。
  - files: [{"id": "F0874CDHV7A", "created": 1735114871, "timestamp": 1735114871, "name": "①関税.pdf", "title": "①関税.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 59372, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0874CDHV7A/_________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0874CDHV7A/download/_________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0874CDHV7A-d90934511a/__________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0874CDHV7A/_________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F0874CDHV7A-a74ad61802", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F086CNLHJTF", "created": 1735114872, "timestamp": 1735114872, "name": "③送料（桃翠園〜ONO Plus）.pdf", "title": "③送料（桃翠園〜ONO Plus）.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 425577, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F086CNLHJTF/________________________ono_plus___.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F086CNLHJTF/download/________________________ono_plus___.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F086CNLHJTF-aa85523bdd/________________________ono_plus____thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F086CNLHJTF/________________________ono_plus___.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F086CNLHJTF-10e044f1aa", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F086U8RPR2M", "created": 1735114875, "timestamp": 1735114875, "name": "④送料（桃翠園〜ONO plus）.pdf", "title": "④送料（桃翠園〜ONO plus）.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 416419, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F086U8RPR2M/________________________ono_plus___.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F086U8RPR2M/download/________________________ono_plus___.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F086U8RPR2M-d13bf97f7f/________________________ono_plus____thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F086U8RPR2M/________________________ono_plus___.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F086U8RPR2M-55b2fa959a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F086129R431", "created": 1735114877, "timestamp": 1735114877, "name": "⑤送料（静パック〜桃翠園）フィルム返品２回目.pdf", "title": "⑤送料（静パック〜桃翠園）フィルム返品２回目.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 449694, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F086129R431/_____________________________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F086129R431/download/_____________________________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F086129R431-e142eddb43/______________________________________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F086129R431/_____________________________________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F086129R431-f3b30f0686", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F086J3JQ4H2", "created": 1735114879, "timestamp": 1735114879, "name": "⑥請求書_株式会社桃翠園様_202412_6565990.pdf", "title": "⑥請求書_株式会社桃翠園様_202412_6565990.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 175898, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F086J3JQ4H2/______________________________________202412_6565990.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F086J3JQ4H2/download/______________________________________202412_6565990.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F086J3JQ4H2-d4ad98714a/______________________________________202412_6565990_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1286, "thumb_pdf_h": 909, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F086J3JQ4H2/______________________________________202412_6565990.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F086J3JQ4H2-64ebc0a2f0", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0868V1G1AA", "created": 1735114881, "timestamp": 1735114881, "name": "中国製フィルム　巻き直し費用.pdf", "title": "中国製フィルム　巻き直し費用.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 81638, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0868V1G1AA/__________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0868V1G1AA/download/__________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0868V1G1AA-96baa2250c/___________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1286, "thumb_pdf_h": 909, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0868V1G1AA/__________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F0868V1G1AA-53faaef882", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F086CNLU66R", "created": 1735114884, "timestamp": 1735114884, "name": "②送料（静パック〜桃翠園）フィルム返送１回目.pdf", "title": "②送料（静パック〜桃翠園）フィルム返送１回目.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 12708, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F086CNLU66R/_____________________________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F086CNLU66R/download/_____________________________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F086CNLU66R-f5205bbb28/______________________________________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 644, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F086CNLU66R/_____________________________________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F086CNLU66R-ff56f0bbc3", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1735120189.132889] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本件、明日出荷ですが新包材となった「BIO Matcha 60g」のラベルフォーマットは入手できそうでしょうか。
集荷便が何時に来るのかわからない為、明日8時までに届かなかった場合は、旧デザインのラベルにて作成・貼付して出荷してもよろしいでしょうか。
ご確認よろしくお願いいたします。
- [1735120314.259619] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
遅くなりました！取り急ぎ！
  - files: [{"id": "F086J8RE3E0", "created": 1735120301, "timestamp": 1735120301, "name": "101 Pure Matcha.pdf", "title": "101 Pure Matcha.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 2115265, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F086J8RE3E0/101_pure_matcha.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F086J8RE3E0/download/101_pure_matcha.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F086J8RE3E0-7be8090c32/101_pure_matcha_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 641, "thumb_pdf_h": 910, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F086J8RE3E0/101_pure_matcha.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F086J8RE3E0-b6533eb20f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1735137340.010739] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
12/26の集荷情報です。
===
会社名　　エムシード
車番　　　和泉130い9700
乗務員　　木村　忠雄
携帯番号　<tel:09092761215|090-9276-1215>
引取り時間 13:00～14:00
===
- [1735139491.924629] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
すみません、別スレッド立ってたか記憶にないのですが、これって進捗及びスケジュールどうなってましたっけ？
静パックでテスト依頼していましたでしょうか？
- [1735154127.798809] <@U0331FZS7JT>: <@U041RJKV5JA>
メモ
12月27日発送

*【Chocolate Coconut Matcha】*
チョコレート：キタマ15%
ココナッツ：キタマ15%
B2抹茶：70%
*▼表ラベル*
Chocolate Coconut Matcha
SAMPLE
50g
TOUSUIEN CO.,LTD.
*▼裏面直接表記*
2024.12/27
B2 Matcha 70%
Chocolate flav. 15%
Coconut flav. 15%


*【Apple Cinnamon Matcha】*
アップルフレーバー：曽田香料20%
シナモン（カシア）：キタマ12%
B2抹茶：68%
*▼表ラベル*
Apple Cinnamon Matcha
SAMPLE
50g
TOUSUIEN CO.,LTD.
*▼裏面直接表記*
2024.12/27
B2 Matcha 68%
Apple flav. 20%
Cinnamon Nat. 12%

*【Raspberry Coconut Matcha】*
ラズベリー：高砂10%
ココナッツ：キタマ20%
B2抹茶：70%
*▼表ラベル*
Raspberry Coconut Matcha
SAMPLE
50g
TOUSUIEN CO.,LTD.
*▼裏面直接表記*
2024.12/27
B2 Matcha 70%
Raspberry flav. 10%
Coconut flav. 12%


※•⁠ ⁠⁠turmeric coconut (with very little black pepper, ginger, cassia cinnamon, cardamom and cloves)
•Pumpkin Spice Matchaは来年発送
- [1735167214.891259] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
静パックにテスト依頼をしておりますが、工場が非常に立て込んでおり、
スケジュール確認後テスト可能日を連絡いただくことになっております。
- [1735180911.964709] <@U041RJKV5JA>: <@U0331FZS7JT>
本件、出荷先はアメリカでよろしいでしょうか。
- [1735187762.220669] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本日、先方手配の運送便にて出荷しました。
【出荷貨物インボイス番号】
TSE-MTL-013-24-1A　（16cartons）
TSE-MTL-013-24-2B
TSE-MTL-013-24-3
よろしくお願いたします。
  - files: [{"id": "F08765J0QD6", "created": 1735187753, "timestamp": 1735187753, "name": "13676_0.jpg", "title": "13676_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 153763, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08765J0QD6/13676_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08765J0QD6/download/13676_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08765J0QD6-854a161986/13676_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08765J0QD6-854a161986/13676_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08765J0QD6-854a161986/13676_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08765J0QD6-854a161986/13676_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08765J0QD6-854a161986/13676_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08765J0QD6-854a161986/13676_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08765J0QD6-854a161986/13676_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08765J0QD6-854a161986/13676_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08765J0QD6-854a161986/13676_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADBpjFNMZxU+aO3SoLKbqRTkj7nmpXAPY0AVSJYoFT2/3wPXNRVJFkHI6jOKZI4quKhf73FPJJHWmbcnrSZSHxcZpMjd0Oc0L8oNA3E8DPNIZLnk1ESV57DmpM89hVediuADyaaQmSUqLuPNNp8XU0IbBsL0A/GhicDmlk6U1vuiqIEzTJeV/Gn0yX7n4igD/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08765J0QD6/13676_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08765J0QD6-b89c7904b5", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1735188514.305839] <@U0331FZS7JT>: <@U041RJKV5JA>
送り先ですが、スイスとのことです。
--
MatchaLand
Am Schanzengraben 25
8002 Zurich
---
よろしくお願いします！

## 2024-12-26

- [1735280535.177109] <@U041RJKV5JA>: <@U0331FZS7JT> <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本日、DHLにて出荷しました。
AWB NO. 8228988456
よろしくお願いいたします。

## 2025-01-03

- [1735903019.447629] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
:flag-ch:Sebastyan
1月末注文・出荷　予定内容
- [1735903104.112689] <@U0331FWGQRM>: 60g bags
シナモン　2000bgas
Pure matcha　4000bags

1月末出荷可否確認お願いします！
（その他フレーバー確認中）

## 2025-01-04

- [1735992143.749029] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
最新のデザインを認識したいので、入荷したパッケージをこの感じで写真撮って保存しておいてもらえますか？:sweat_drops:
（おそらくPure抹茶のみ変わってるかと思いますが）
  - files: [{"id": "F0872T63U06", "created": 1735992075, "timestamp": 1735992075, "name": "New bag_20240902.jpg", "title": "New bag_20240902.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 433499, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0872T63U06/new_bag_20240902.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0872T63U06/download/new_bag_20240902.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0872T63U06-56bc8551b7/new_bag_20240902_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0872T63U06-56bc8551b7/new_bag_20240902_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0872T63U06-56bc8551b7/new_bag_20240902_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0872T63U06-56bc8551b7/new_bag_20240902_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0872T63U06-56bc8551b7/new_bag_20240902_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0872T63U06-56bc8551b7/new_bag_20240902_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0872T63U06-56bc8551b7/new_bag_20240902_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0872T63U06-56bc8551b7/new_bag_20240902_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0872T63U06-56bc8551b7/new_bag_20240902_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADBEgLKDuAB6UGBueRgHGSanhAMKewpX9Bj7xqUDZVMTgkcce9IImZsEgcZzVlsEvxnp/Kkxh8AZ+T+tOw76EJtyCvzA7jjikaEqu7IP0qywAZSPU/ypso/dnpR1AjSMlFIXOfepNgCnjPPrUaSKAODkCpBNHtIbuSelJjEMYy2Ae3ANJsUjJyePWgypluwOAKTz0UgA9qBMCinbgEdcjNI2PLJwQfQ0rTKXX6EUkrq6YB5+lUthIgzQSaKQ1JQhJpMnNBpO9Ah1KKSlFMD/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0872T63U06/new_bag_20240902.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0872T63U06-c16e004081", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-01-05

- [1736150268.770029] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本日出荷予定の「TSE-MTL-013-24-1B」ですが、集荷が来ておりません。
出荷日の変更がありましたでしょうか。

## 2025-01-06

- [1736228792.138699] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
【TSE-MTL-013-24-1B】
本日、先方手配の運送便にて出荷しました。
よろしくお願いたします。

## 2025-01-08

- [1736355332.979539] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
TSE-SPL-MTL-001-25
サンプル依頼：レモンフレーバーの抹茶
1/14の週に発送
- [1736355624.433639] <@U0331FZS7JT>: メモ
先方希望
商品と2024年11月14日に送ったサンプルの間のクエン酸含有量を希望
ステビア：0.5-1%でブレンドして欲しい

各クエン酸含有量
▼ジンジャーレモン
製品：15%
11月サンプル：10%

▼パイナップルレモン
製品：15%
11月サンプル：10%

▼ピーチレモン
製品：15%
11月サンプル：10%

▼ストロベリーレモン
製品：13%
11月サンプル：9%
- [1736363160.492669] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
本件、テストはどうでしょうか？？？

  - files: [{"id": "F087DR7L99D", "created": 1736363149, "timestamp": 1736363149, "name": "IMG_7146.png", "title": "IMG_7146", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 3977386, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F087DR7L99D/img_7146.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F087DR7L99D/download/img_7146.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F087DR7L99D-4428046b74/img_7146_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F087DR7L99D-4428046b74/img_7146_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F087DR7L99D-4428046b74/img_7146_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F087DR7L99D-4428046b74/img_7146_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 221, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F087DR7L99D-4428046b74/img_7146_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F087DR7L99D-4428046b74/img_7146_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 332, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F087DR7L99D-4428046b74/img_7146_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1734, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F087DR7L99D-4428046b74/img_7146_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 443, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F087DR7L99D-4428046b74/img_7146_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 472, "thumb_1024_h": 1024, "original_w": 1290, "original_h": 2796, "thumb_tiny": "AwAwABbNorXMUH/PJPyqMxw84jT8qAMyitNIou8a/iKd5UP/ADyT8qAEUq0Yy4XPPWnsUYffHrxVXzCseB+FO8xiGC5yTx7VAyd+xGMEU3P0oG5vvZPoPSjb7UwKrSIBwwNKsig/eFVKXFOwi+s6EffA/Gl85P8AnoPzrOopgf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F087DR7L99D/img_7146.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F087DR7L99D-3d9a33415f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1736379530.641269] <@U0331FWGQRM>: メモ
2024年12月4日(水) 14:06 望月育代様のメール抜粋
&gt; ③追加9種類の製造スケジュール
&gt; 追加で９種類:heavy_multiplication_x:10,000本〜15,000本の製造予約をお願いいたします。
&gt; ⇒　2/3（月）～2/13（木）　9日間で製造致します。
&gt; ※原料は1月31日までに送付をお願い致します。

- [1736379634.977909] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
フィルムの確認してから、
フィルムの再製造が行われます。

よって、1/31までにフィルムが静パックに間に合わないと、また同じことが起こる可能性があります。

## 2025-01-10

- [1736498970.676229] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
フィルムテストについて静パック 望月様に急いでいる旨、先程電話にてお伝えしました。
製造現場からの返答がなく未だテスト可能日が確定しておらず、お待ちくださいとのことです。
直ぐにでも現場に確認していただくよう依頼しました。
連絡があり次第ご報告いたします。
- [1736570561.362389] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
どうでしょうか？フィルムメーカーから猛プッシュされてます:sweat_drops:w
- [1736571335.139619] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
昨日電話での依頼後、連絡はありませんでした。
本日も電話を掛けましたが休業日でした。
再度メールをお送りしておりますので、1/14（火）に確認をいたします。

## 2025-01-13

- [1736829358.219109] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
静パックより連絡がございました。
フィルムテスト日：１/１８（土）
よろしくお願いいたします。

## 2025-01-15

- [1736950878.672059] <@U0331FZS7JT>: <@U041RJKV5JA>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
明日のサンプル出荷（US・ロス向け/各50g × 2 pacs）よろしくお願いします。
下記比率を裏面記載をお願いします。
<@U0331FWGQRM>
Quotation_tousuien_20250115_B2 matcha_flavored matcha_discount(60g 8%, sachet 10%)レモン抹茶+ステビア
に価格を記載しています！

▼Ginger Lemon Matcha_1
B2 Matcha：58%
Lemon flav.：22%
Ginger nat.：7%
Citric acid：12.5%
Stevia：0.5%

▼Ginger Lemon Matcha_2
B2 Matcha：57.5%
Lemon flav.：22%
Ginger nat.：7%
Citric acid：12.5%
Stevia：1%

▼Pineapple Lemon Matcha_1
B2 Matcha：60%
Lemon flav.：11%
Pineapple flav.：16%
Citric acid：12.5%
Stevia：0.5%

▼Pineapple Lemon Matcha_2
B2 Matcha：59.5%
Lemon flav.：11%
Pineapple flav.：16%
Citric acid：12.5%
Stevia：1%

▼Peach Lemon Matcha_1
B2 Matcha：61%
Lemon flav.：8%
Peach flav.：18%
Citric acid：12.5%
Stevia：0.5%

▼Peach Lemon Matcha_2
B2 Matcha：60.5%
Lemon flav.：8%
Peach flav.：18%
Citric acid：12.5%
Stevia：1%

▼Strawberry Lemon Matcha_1
B2 Matcha：63.5%
Lemon flav.：9%
Strawberry flav.：16%
Citric acid：11%
Stevia：0.5%

▼Strawberry Lemon Matcha_2
B2 Matcha：63%
Lemon flav.：9%
Strawberry flav.：16%
Citric acid：11%
Stevia：1%
- [1736990984.745029] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
Sebastyanから重金属の検査結果として、アルミも知りたいと連絡が来ました。
抹茶1種類で検査した場合、
かかる日数と費用を確認してもらえますか?
宜しくお願い致します。:sweat_drops:

## 2025-01-16

- [1737015610.805449] <@U041RJKV5JA>: <@U0331FZS7JT> <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本日、DHLにて出荷しました。
AWB NO. 8229012525
よろしくお願いいたします。
- [1737075306.198599] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
以前にもありましたが、
Chai matcha60g用の袋を旧サプライヤーに送る必要があります。
Chai matchaの袋*１ケースだけ*、下記住所に送って頂けますでしょうか。

592-8344
大阪府堺市西区浜寺南町１丁2番地１
ダイケンヒルズ　M号室
松井幸史朗
<tel:08085309618|080-8530-9618>

前回同様、
出雲から送ると、新サプライヤーが桃翠園だとバレる可能性が高いと思いますので、
私から、旧サプライヤーの元へ匿名で送るようにします。
（送り主欄に“同上“と記入して発送します）
- [1737077339.779699] <@U033G4KN4TD>: <@U0331FWGQRM>
本日発送いたします。

## 2025-01-17

- [1737109254.683429] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
ビューローベリタスに見積もりを依頼しました。
・検査費用：6,000円
・所要日数：7営業日
・英文報告書：1,100円
　＊日本語報告書が不要な場合で、英文報告書のみ発行の場合は無料
ご確認お願いいたします。
  - files: [{"id": "F088XEXUURL", "created": 1737109042, "timestamp": 1737109042, "name": "20250117 アルミニウム分析 お見積書.pdf", "title": "20250117 アルミニウム分析 お見積書.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 56023, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F088XEXUURL/20250117______________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F088XEXUURL/download/20250117______________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F088XEXUURL-7d2fd1ff6f/20250117_______________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F088XEXUURL/20250117______________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F088XEXUURL-2298f13290", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1737118881.529719] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
ありがとうございます。
受ける場合は英文報告書のみでOKです。
~先方に確認します。~
→試験を受けてくださいとのことです。宜しくお願いします。
資料名はmatchaでお願いします。

## 2025-01-22

- [1737563819.872419] <@U0331FWGQRM>: <@U0331FZS7JT> <@U03BLQ65GK0> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
Sebastyanから下記問い合わせです。
代替品を使用していることが何か関係しているのか、
それともどの抹茶にもありうることなのか、どうでしょうか？
ーーーーーーーー
B2に藻のような風味が少し感じられるという報告が寄せられることは非常にまれですが、これは何が原因なのでしょうか。
また、これを防ぐことはできるのでしょうか。
ーーーーーーーー
- [1737592087.972329] <@U0331FZS7JT>: <@U0331FWGQRM>
<@U03BLQ65GK0> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>

藻のような風味について、肥料会社の方に肥料、気候、環境など何か考えられることは無いか、確認しました。
---
・被覆した抹茶ではどの抹茶でもあり得る
・出雲の気候からよりそれが明確？かも。
---

抹茶の覆い香（成分：ジメチルスルフィド）が関係しているのでは無いか、ということでした。
何軒かの取引先でもあった話とのことで、高品質な抹茶を出荷した先の海外のお客様から、海藻を入れてんの？といった問い合わせがあるとのことです（品評会では強い方が良いとされる）。
山肌（日陰が多い地域）のお茶に特によくみられるとのことです。
→つまり出雲精茶のお茶の比率減らす、無くしたら解決する？

<@U03BLQ65GK0>
代替品と出雲精茶のRを改めてその香りの違いをフォーカスして確認しましょう。

## 2025-01-24

- [1737779128.364539] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
アルミニウム検査の結果が届きました。
・検体：碧翆園　国産有機抹茶10500
・アルミニウム含有量：68mg/100g
検査結果は下記フォルダに格納しております。
・共有フォルダ – 検査結果　– アルミニウム検査 - 2501-10920 株式会社桃翠園 様 matcha 検査報告書
・B-ビューローベリタスエフイーエーシー – アルミニウム検査 - 2501-10920 株式会社桃翠園 様 matcha 検査報告書
ご確認お願いいたします。
  - files: [{"id": "F08AXN9NGTA", "created": 1737778613, "timestamp": 1737778613, "name": "2501-10920 株式会社桃翠園 様 matcha 検査報告書.pdf", "title": "2501-10920 株式会社桃翠園 様 matcha 検査報告書.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 94704, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08AXN9NGTA/2501-10920___________________________matcha________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08AXN9NGTA/download/2501-10920___________________________matcha________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08AXN9NGTA-c94430a6fd/2501-10920___________________________matcha_________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08AXN9NGTA/2501-10920___________________________matcha________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08AXN9NGTA-ab22d15d7e", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-01-25

- [1737844435.872139] <@U0331FWGQRM>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0> 
情報共有

抹茶に含まれるアルミニウムの量である60mg/100gの評価は、以下の観点で判断できます。

1. 食品安全基準との比較
	•	アルミニウムは一般的に食品に含まれる微量元素ですが、摂取量が過剰になると健康リスクがあるため、各国で基準値が設けられています。
	•	欧州食品安全機関（EFSA）は、アルミニウムの耐容一日摂取量（TDI）を1mg/kg体重/日としています。これは体重50kgの成人で1日50mgのアルミニウム摂取を許容範囲とすることを意味します。
	•	抹茶は非常に濃縮された形で摂取されることが多いとはいえ、1回の摂取量は通常1～2g程度です。この場合、アルミニウム摂取量は0.6～1.2mg程度となり、TDIを大きく超えることはありません。

1. 他の食品との比較
	•	緑茶や抹茶に含まれるアルミニウム量は土壌や栽培環境に左右されますが、一般的に抹茶のアルミニウム含有量は30～100mg/100gの範囲とされることがあります。
	•	60mg/100gは、この範囲内に収まっており、抹茶として特に高い値ではないと言えます。

1. マーケットの基準
	•	輸出先であるアメリカやヨーロッパでは、抹茶やお茶製品に対する明確なアルミニウム基準は設けられていませんが、総摂取量が問題とされるため、消費者向けには「土壌由来の自然発生的な成分である」と説明することが有効です。

1. 消費者へのアピールポイント
	•	アルミニウム含有量が土壌や自然由来であり、製造工程中に人工的に加えられたものではないことを明確にすることで、消費者や取引先に安心感を与えられます。
	•	また、検査結果を適切に表示・説明することで、輸出先での信頼性向上につながります。

総評

60mg/100gのアルミニウム含有量は、一般的な抹茶の範囲内にあり、過剰摂取のリスクは低いと言えます。ただし、各国の規制や顧客の関心に合わせて適切な説明と検査データの提示を行うことが重要です。必要であれば、土壌管理やアルミニウムの低減技術を導入することも検討できます。

## 2025-01-31

- [1738317838.128199] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
Sebastyan手配のフィルムでステイック製造テスト
- [1738317872.917729] <@U041RJKV5JA>: 
  - files: [{"id": "F08B5L9J29H", "created": 1738317857, "timestamp": 1738317857, "name": "KIMG0784.JPG", "title": "KIMG0784.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 3574172, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08B5L9J29H/kimg0784.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08B5L9J29H/download/kimg0784.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08B5L9J29H-7416902662/kimg0784_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08B5L9J29H-7416902662/kimg0784_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08B5L9J29H-7416902662/kimg0784_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08B5L9J29H-7416902662/kimg0784_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08B5L9J29H-7416902662/kimg0784_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08B5L9J29H-7416902662/kimg0784_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08B5L9J29H-7416902662/kimg0784_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08B5L9J29H-7416902662/kimg0784_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08B5L9J29H-7416902662/kimg0784_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 2448, "original_h": 3264, "thumb_tiny": "AwAwACRgWkyQfuMamApCpxx1rNsojUsTyhApxWnqp4zTsU0xEG2jbUu2jbQA4UuOpoFKDw2OopMBqnLYzz6VJgU0HJHSlNNbAGBRgUlJmgAFNA5bgfN3oU0m2Qnhxj6UmA9U2tnPBpxqMLJkZcEemKeTQr9QEopCaTNMD//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08B5L9J29H/kimg0784.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08B5L9J29H-3e479b9e79", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08B88Z1G68", "created": 1738317865, "timestamp": 1738317865, "name": "unnamed.jpg", "title": "unnamed.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 219013, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08B88Z1G68/unnamed.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08B88Z1G68/download/unnamed.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08B88Z1G68-11efe9cbc3/unnamed_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08B88Z1G68-11efe9cbc3/unnamed_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08B88Z1G68-11efe9cbc3/unnamed_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08B88Z1G68-11efe9cbc3/unnamed_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08B88Z1G68-11efe9cbc3/unnamed_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08B88Z1G68-11efe9cbc3/unnamed_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08B88Z1G68-11efe9cbc3/unnamed_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 600, "thumb_800_h": 800, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08B88Z1G68-11efe9cbc3/unnamed_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "original_w": 739, "original_h": 985, "thumb_tiny": "AwAwACS2zbRk5/CmeaP7r/lTmOBmq5lKuQG3E9vSk2OxJ9pT0NPRw65FRM+Odo2jqakjYMMjoaExWJKKSjFMBH6VRX5pXPtV5+hqkI9oJyD15qXuMWbDOi5wD1JqxGTt561WkRjJnBCgcGp0Jxz1oQMnopM0ZqhBLnHyjJqsS+MbD+dWHNMpWAbge9KO9LSE0JDH5ozTAaXNMR//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08B88Z1G68/unnamed.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08B88Z1G68-9282964eea", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-02-07

- [1738998850.583279] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
Sebastyan向け次回のスティック製造スケジュール（静パック）の確認よろしくお願いします。
- [1738998931.139929] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
Sebastyan 3月末出荷希望（予定）の商品は下記です。
- [1738999072.213619] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
~4000 pure matcha~
~4000 vanilla,~
~2000 cinnamon.~

5000 pure matcha 60g→内
50 pure matcha 200g
3000 vanilla,
2000 cinnamon.

※3月末出荷ということは、2月末頃に注文が来ると思います。
※数量、種類は増えると思いますが、上記は確実なので、進めてもらっていいかなと思います。
※袋が少なくなっているものがあれば教えてください。

## 2025-02-09

- [1739145208.216419] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
上記は毎月一回あると認識した上で在庫準備願います。

ーーーーー
先方からは1.5ヶ月から2ヶ月に一回と言われていますが、1ヶ月に一回と考えてもらって大丈夫です。余ったとしても、注文スパンが少し伸びるだけなので、不良在庫にはならないかと思います。（ブレンド比率が徐々に固定してきていますし）

## 2025-02-10

- [1739188862.781279] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
Sebastyanの資材について、
2月20日出荷完了後の資材在庫数量（正確でなくてok、数十枚の誤差はok）を教えてもらえますか？


## 2025-02-13

- [1739452392.505689] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
こちらいかがでしょうか？
- [1739498685.189909] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
加工が大変混みあっており、スケジュールの調整中と連絡が入りました。
製造日確定次第ご連絡いたします。

## 2025-02-21

- [1740152311.278549] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
こちらどうでしょうか？？:sweat_drops:

## 2025-02-22

- [1740216942.511749] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> 
資材在庫数量によっては、追加で製造をする必要があるとのことで、在庫数量の連絡を待たれております。
宜しくお願いします。

12日経ってるので、確認お願いします。

## 2025-02-24

- [1740448313.765889] <@U033G4KN4TD>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
資材の残数報告いたします。
Ginger Lemon Matcha_5466枚
Mango Matcha_7095枚
Vanilla Matcha_9463枚
Cinnamon Matcha‗9938枚
Strawberry Lemon Matcha_10735枚
Pure Matcha_7984枚
Chai Matcha_5416枚
Peach Lemon Matcha_5416枚
Pineapple Lemon Matcha_12441枚

メモ
2月出荷分でVanilla Matchaの袋の不良(印刷不良)が57枚アリ
→毎回、50枚程度は不良が発生するかもしれません。
- [1740448664.148579] <@U033G4KN4TD>: 
  - files: [{"id": "F08EVRU3N10", "created": 1740448650, "timestamp": 1740448650, "name": "S__242868226_0.jpg", "title": "S__242868226_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 210743, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08EVRU3N10/s__242868226_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08EVRU3N10/download/s__242868226_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08EVRU3N10-a2b2780e9e/s__242868226_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08EVRU3N10-a2b2780e9e/s__242868226_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08EVRU3N10-a2b2780e9e/s__242868226_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08EVRU3N10-a2b2780e9e/s__242868226_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08EVRU3N10-a2b2780e9e/s__242868226_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08EVRU3N10-a2b2780e9e/s__242868226_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08EVRU3N10-a2b2780e9e/s__242868226_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08EVRU3N10-a2b2780e9e/s__242868226_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08EVRU3N10-a2b2780e9e/s__242868226_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACSMAngAk+1P8t/7h/Kn23+tH0NTyS7CAADx60NhYq7HP8B/I00hh95SPqKtLcZIG3qfWku8YT60gsFvJtjwT3qXzR6iqOaXPvVAOtv9Z+FSyqGZcpu445xTLfhyT2FNJ864ABbaOTUsCRogQCi4b3NJPu8tS+M57VMVBqO4H7oexoArUUuKMVQFiEDLZHalXK5wg5OTzUbttHynBqJpX/vmkwLW5/7o/OhwWiORg1UWV88ufzqyHyOtJICLbRtqXcKNwqgP/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08EVRU3N10/s__242868226_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08EVRU3N10-e0e6a6ef6a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08EV9ERC9H", "created": 1740448656, "timestamp": 1740448656, "name": "S__242868228_0.jpg", "title": "S__242868228_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 212657, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08EV9ERC9H/s__242868228_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08EV9ERC9H/download/s__242868228_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08EV9ERC9H-dcf4b677e5/s__242868228_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08EV9ERC9H-dcf4b677e5/s__242868228_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08EV9ERC9H-dcf4b677e5/s__242868228_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08EV9ERC9H-dcf4b677e5/s__242868228_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08EV9ERC9H-dcf4b677e5/s__242868228_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08EV9ERC9H-dcf4b677e5/s__242868228_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08EV9ERC9H-dcf4b677e5/s__242868228_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08EV9ERC9H-dcf4b677e5/s__242868228_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08EV9ERC9H-dcf4b677e5/s__242868228_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACRiqzHCjJp4gl7r/Kltj+9H0NTyzFMYUHNDC1yDyJP7v8qRoZFBOOB71ILkk8qPzqUvugJIwStILFOikzRmqAfb/wCt/A1NMAQu5Swz2qOAfvPwpLiRgwVWGT+lSwH+UrJwpB9CaWMSBdrABcetOAOAC2SOpp6DseaYFGlpSOaMUwJ0XDfhUYjRZSzMDjoKTzwrZOSPaj7Qn9w0mBOHXOMinI6scA5quLkf3P1qQT/7P60rDBo/mNJ5dBkyc0m+qEf/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08EV9ERC9H/s__242868228_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08EV9ERC9H-6f33939775", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-02-26

- [1740629128.421439] <@U041RJKV5JA>: <@U0331FWGQRM> <@U03BLQ65GK0>
 <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
静パックよりスティック製造スケジュールの連絡がありました。
・製造スケジュール：4/8（火）～4/18（金）
・種類：9種類
・本数：各１万本
原料の送付は2種類ずつ送って欲しいとのことです。
フィルムについて従来通りなのかオリジナルを使用するのか確認されましたが、
テスト加工いただいたフィルムの確認後連絡すると伝えてあります。
このスケジュールで製造できるよう、原料準備を進めてもよろしいでしょうか。

## 2025-02-27

- [1740645196.325589] <@U0331FWGQRM>: 2025/02/28
Sebastyan 袋在庫・注文状況（セバスチャン→中国）について。
- [1740645214.073839] <@U0331FWGQRM>: 2025/02/25時点
Ginger Lemon Matcha_5466枚
Mango Matcha_7095枚
Vanilla Matcha_9463枚
Cinnamon Matcha‗9938枚
Strawberry Lemon Matcha_10735枚
Pure Matcha_7984枚
Chai Matcha_5416枚
Peach Lemon Matcha_5416枚
Pineapple Lemon Matcha_12441枚
- [1740645250.660449] <@U0331FWGQRM>: 2025/02/28
注文　Sebastyan→中国サプライヤ
15,000 Pure
15,000 Vanilla
10,000 Chai
5,000 Cinnamon
5,000 Coconut Raspberry
- [1740645385.352109] <@U0331FWGQRM>: 2025/02/27
静パックSachet製造スケジュール
- [1740645396.709179] <@U0331FWGQRM>: &gt; ご連絡頂いておりますスティック充填につきまして
&gt; 製造スケジュールの調整を致しましたので連絡致します。
&gt; ・原料：フレーバー抹茶
&gt; ・種類：9種類
&gt; ・本数：各１万本
&gt; 
&gt; *製造スケジュール：4/8（火）～4/18（金）*
&gt; 日産の製造数が約15,000包になります。
&gt; 原料の送付を2種類ずつの送付を要望致します。
&gt; 
&gt; また、フィルムはオリジナルフィルムでしょうか？
&gt; 加工の詳細・ご注文書を事前にご連絡いただければ幸いです。


## 2025-03-03

- [1741050947.051699] <@U08FZUNPSQ3>: <@U08FZUNPSQ3>さんがチャンネルに参加しました

## 2025-03-11

- [1741756243.454109] <@U0331FWGQRM>: 静パック製造スケジュール
- [1741756248.121919] <@U0331FWGQRM>: 4月　4/8（火）～4/18（金）

5月　4/28（月)～5/12(月）　9営業日（gw含む為）
※ゴールデンウィークの為、送付等に遅延が発生する場合がある。

## 2025-03-26

- [1743034369.628059] <@U0331FWGQRM>: Chaiのブレンドテストについて
- [1743037656.144839] <@U0331FWGQRM>: 試験環境
・100ml Water, 200ml milk, sugar
・2.5g of powder
・Cold

## 2025-03-30

- [1743397762.277149] <@U0331FWGQRM>: 2025年4月15日入荷予定60g袋について。
- [1743397905.015119] <@U0331FWGQRM>: 4/15に船便で袋を入荷する予定です。
  - files: [{"id": "F08KTN8BLNS", "created": 1743397882, "timestamp": 1743397882, "name": "WhatsApp Image 2025-03-25 at 15.54.14 (1).jpeg", "title": "WhatsApp Image 2025-03-25 at 15.54.14 (1).jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 37158, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08KTN8BLNS/whatsapp_image_2025-03-25_at_15.54.14__1_.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08KTN8BLNS/download/whatsapp_image_2025-03-25_at_15.54.14__1_.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08KTN8BLNS-508d6a0b3c/whatsapp_image_2025-03-25_at_15.54.14__1__64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08KTN8BLNS-508d6a0b3c/whatsapp_image_2025-03-25_at_15.54.14__1__80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08KTN8BLNS-508d6a0b3c/whatsapp_image_2025-03-25_at_15.54.14__1__360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 171, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08KTN8BLNS-508d6a0b3c/whatsapp_image_2025-03-25_at_15.54.14__1__480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 229, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08KTN8BLNS-508d6a0b3c/whatsapp_image_2025-03-25_at_15.54.14__1__160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 569, "original_h": 271, "thumb_tiny": "AwAWADDSJxTN+eDwPUGlbp3/AApvPv8ArQA7b7n86TacnO7H1pw7UuT6frQAwMwwMZ/GnZOegxik/ipe34UAHHvSDGe/50tNH3jQA7pSk8U00HpQAbvmpc/ypv8AFR/hQB//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08KTN8BLNS/whatsapp_image_2025-03-25_at_15.54.14__1_.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08KTN8BLNS-b58dbef44f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1743398087.708489] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
通関時に食品輸入証明書を要求される可能性があります。
下記どちらかで対応お願いします。
・海外へ販売するから不要
・対応して、許可書を入手してみる（時間的に余裕があれば）

もし税関から連絡があれば教えてください。
宜しくお願いします。

## 2025-03-31

- [1743469444.869749] <@U08L89G6JSG>: <@U08L89G6JSG>さんがチャンネルに参加しました

## 2025-04-01

- [1743490935.825129] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
上記、通関時に食品輸入証明書の電話がかかってくると思いますので、対応お願いします！

## 2025-04-02

- [1743657197.997179] <@U0331FWGQRM>: 支払いサイトについて
- [1743657319.530399] <@U0331FWGQRM>: <@U0331FZTHEK>
従来
30%　前払い
70%　出荷後45日以内
↓
2025年夏（6月頃以降）から
40%　前払い
60%　出荷後60日以内

## 2025-04-13

- [1744592905.454559] <@U08N3SKSL75>: <@U08N3SKSL75>さんがチャンネルに参加しました

## 2025-04-16

- [1744871115.859239] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
60g bagは現在日本国内を輸送中とのこと。
西濃運輸追跡番号：0414824859
- [1744871509.943849] <@U0331FWGQRM>: 2025年4月17日入荷予定のsachet用のフィルムについて
- [1744871537.547029] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
4月18日or 21日
入荷予定です！

## 2025-04-18

- [1744961342.330669] <@U033G4KN4TD>: <@U0331FWGQRM> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本日、60ｇの袋が届きました。
数量下記報告いたします。
・ココナッツラズベリー：6700枚
・チャイ：12900枚
・ピュア：16000枚
・バニラ：16300枚
・シナモン：7600枚

これまでの袋と色味や言語が違うため先方に確認をお願いいたします。
※画像左側が旧袋、右側が新袋
  - files: [{"id": "F08NAB1RRRV", "created": 1744961171, "timestamp": 1744961171, "name": "S__248922114_0.jpg", "title": "S__248922114_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 213648, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08NAB1RRRV/s__248922114_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08NAB1RRRV/download/s__248922114_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1RRRV-508a34c221/s__248922114_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1RRRV-508a34c221/s__248922114_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1RRRV-508a34c221/s__248922114_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1RRRV-508a34c221/s__248922114_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1RRRV-508a34c221/s__248922114_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1RRRV-508a34c221/s__248922114_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1RRRV-508a34c221/s__248922114_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1RRRV-508a34c221/s__248922114_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1RRRV-508a34c221/s__248922114_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1478, "original_h": 1108, "thumb_tiny": "AwAjADC1IWVcqAT6E1H5kv8AzzX/AL6qR+1ViGaQ7XHXpmk2FiUSS5H7tcf71IZ5AxHkkgHrSRMclWJzmnS/dODjmlcLDfPk/wCeJqWJjImWXac9Kr4ZQG3ZGfWrMTbgcU0wsJMwUZNQxbmBZj16cVLIpYkYP5ZpuH9T/wB80mA4ZHeo7h9vCnk+1PUNnnJ/CnMhJzQA0A4GWOfWnp1puxvX9KcisDzzQA+iiiqAKKKKACiiigD/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08NAB1RRRV/s__248922114_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08NAB1RRRV-d4e795b43e", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08NH355JJ2", "created": 1744961183, "timestamp": 1744961183, "name": "S__248922116_0.jpg", "title": "S__248922116_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 329968, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08NH355JJ2/s__248922116_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08NH355JJ2/download/s__248922116_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH355JJ2-b27460a6a7/s__248922116_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH355JJ2-b27460a6a7/s__248922116_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH355JJ2-b27460a6a7/s__248922116_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH355JJ2-b27460a6a7/s__248922116_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH355JJ2-b27460a6a7/s__248922116_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH355JJ2-b27460a6a7/s__248922116_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH355JJ2-b27460a6a7/s__248922116_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH355JJ2-b27460a6a7/s__248922116_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH355JJ2-b27460a6a7/s__248922116_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1478, "original_h": 1108, "thumb_tiny": "AwAjADCxI7Ljau7Pvimea/8Azy/8ep0uMjNNx7VLYWHLIxYAxkZ75pn2kf8APNqeo+Ynmmkc9TRcLCfal/uNUsbCRNwBH1qPHHU1LH92mmAyT71M/E1Ltz1BpNpwcfhxU2GIn1pD1p6qQOefwpNv1/KiwDOfU/nUsXSoyDjgc+9PjznmmhElFFFUAUUUUAFFFFAH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08NH355JJ2/s__248922116_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08NH355JJ2-9bdc8c21a6", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08NAB1PGBZ", "created": 1744961180, "timestamp": 1744961180, "name": "S__248922117_0.jpg", "title": "S__248922117_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 237930, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08NAB1PGBZ/s__248922117_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08NAB1PGBZ/download/s__248922117_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1PGBZ-83ecdcfde3/s__248922117_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1PGBZ-83ecdcfde3/s__248922117_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1PGBZ-83ecdcfde3/s__248922117_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1PGBZ-83ecdcfde3/s__248922117_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1PGBZ-83ecdcfde3/s__248922117_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1PGBZ-83ecdcfde3/s__248922117_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1PGBZ-83ecdcfde3/s__248922117_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1PGBZ-83ecdcfde3/s__248922117_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1PGBZ-83ecdcfde3/s__248922117_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1478, "original_h": 1108, "thumb_tiny": "AwAjADC0+4L8uM+9MzN6R/rUrVUmJaTavzH0HakJk26b+6n5mo/MuM/cBqSENs+YY9qSU4jJyB9aAGebP/zyqaJmdMuu0+lV4iS3Q4Pc1aTpQCFaqbBo3YnIOcggVcYE9Kbsb+8aGMbExdMn+WKjnUsgxzg5xUwVgepNIUb3FAFZJcMF7duOatpTPLbOc/pTkBB5oAfRRRTAKKKKACiiigD/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08NAB1PGBZ/s__248922117_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08NAB1PGBZ-cced358d6a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08NAB1GYR5", "created": 1744961177, "timestamp": 1744961177, "name": "S__248922118_0.jpg", "title": "S__248922118_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 318708, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08NAB1GYR5/s__248922118_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08NAB1GYR5/download/s__248922118_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1GYR5-a9e97a5a3a/s__248922118_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1GYR5-a9e97a5a3a/s__248922118_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1GYR5-a9e97a5a3a/s__248922118_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1GYR5-a9e97a5a3a/s__248922118_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1GYR5-a9e97a5a3a/s__248922118_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1GYR5-a9e97a5a3a/s__248922118_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1GYR5-a9e97a5a3a/s__248922118_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1GYR5-a9e97a5a3a/s__248922118_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08NAB1GYR5-a9e97a5a3a/s__248922118_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1478, "original_h": 1108, "thumb_tiny": "AwAjADCy5YL8oBPoTUe+X/nkP++qkf7tMoEJ5kneI/gaRrkKxBRuKeMlhzx3FI33utIBv2pe6NUkUiyglQRj1pn40+LOOTmmAsnSo8nscVKwzTcc+opDEXOeT+tNkznjH505d+fmC49qUjmgCLLf5NSRE55/nQRRHu3cgCgCWiiimAUUUUAFFFFAH//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08NAB1GYR5/s__248922118_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08NAB1GYR5-8da5daeb30", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08NVBH9FNY", "created": 1744961174, "timestamp": 1744961174, "name": "S__248922119_0.jpg", "title": "S__248922119_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 221291, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08NVBH9FNY/s__248922119_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08NVBH9FNY/download/s__248922119_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08NVBH9FNY-22d731411f/s__248922119_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08NVBH9FNY-22d731411f/s__248922119_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08NVBH9FNY-22d731411f/s__248922119_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08NVBH9FNY-22d731411f/s__248922119_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08NVBH9FNY-22d731411f/s__248922119_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08NVBH9FNY-22d731411f/s__248922119_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08NVBH9FNY-22d731411f/s__248922119_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08NVBH9FNY-22d731411f/s__248922119_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08NVBH9FNY-22d731411f/s__248922119_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1478, "original_h": 1108, "thumb_tiny": "AwAjADCxMXGNjY/DNR7pf76/lUkp+YVXccFmb9Kht3GopkoaXcMspHfim+dP/wA8xSxNux/PHWkkJxgHHrQpMOUXz5v+eX61NGxdAxGCe1VA2xsZ3Z7AVbiPy00xWsMk5Y1WYM7Z2nbVpo2Jzn9aTym9f1qbMobF24xTZOFzUqRsDzzSGJieuPxoSYXKyIQ24qatxdTTPKb+8fzp8aMp5qkJj6WkoqhC0UlLQAUUUUAf/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08NVBH9FNY/s__248922119_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08NVBH9FNY-c5e6b22597", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08NH357D8W", "created": 1744961186, "timestamp": 1744961186, "name": "S__248922120_0.jpg", "title": "S__248922120_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 326543, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08NH357D8W/s__248922120_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08NH357D8W/download/s__248922120_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH357D8W-cb1ccec975/s__248922120_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH357D8W-cb1ccec975/s__248922120_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH357D8W-cb1ccec975/s__248922120_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH357D8W-cb1ccec975/s__248922120_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH357D8W-cb1ccec975/s__248922120_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH357D8W-cb1ccec975/s__248922120_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH357D8W-cb1ccec975/s__248922120_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH357D8W-cb1ccec975/s__248922120_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08NH357D8W-cb1ccec975/s__248922120_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1478, "original_h": 1108, "thumb_tiny": "AwAjADCzK5RRtxnPeo/Ok/2P1p0/ao8VDbuOw9ZZCwGEx3603z5f+eY/OlUDd2zSEDNCbCwefL/zyH51NExeMMy4PpUJA9Kmh+7immKxHNy2KjxUzISxOAfrSeW2c8D2qWirjU+8KRutPWEqc/1p3l+wP407Bchx7/pUsHGRSeW3PNOjQqeTmmkK4+iiiqEFFFFABRRRQB//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08NH357D8W/s__248922120_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08NH357D8W-550d122dd3", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1744962481.865879] <@U033G4KN4TD>: メモ
・バニラ抹茶　旧袋：3400枚　新袋：1600枚
・ピュア抹茶　旧袋：3400枚　新袋：1600枚
・ココナッツラズベリー抹茶　新袋のみ1500枚
上記数量外注へ発送済(4/18時点)

・チャイ抹茶　旧袋：7000枚　在庫あり
- [1744992918.685119] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> 
袋は旧も新もミックスしていいとのことです！（ほんまか！？？）

というわけで、混ぜていいと思うのですが、
このお客様は考えが二転三転するので、
念の為に新袋のケース番号と旧袋のケース番号は把握（メモ）しておいてください。宜しくお願いします

## 2025-04-20

- [1745195461.289349] <@U08NVD403GV>: <@U08NVD403GV>さんがチャンネルに参加しました

## 2025-04-21

- [1745228403.575969] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
明日4/22の早朝には出雲にあるそうです。
その後の配達になるので、何時頃になるかは現時点では不明。
出雲配達点の電話番号：<tel:0853213721|0853-21-3721>

西濃運輸
<https://track.seino.co.jp/kamotsu/GempyoNoShokai.do#shousai0>

追跡番号
5835088291
  - attachments: [{"from_url": "https://track.seino.co.jp/kamotsu/GempyoNoShokai.do#shousai0", "service_icon": "https://track.seino.co.jp/favicon.ico", "id": 1, "original_url": "https://track.seino.co.jp/kamotsu/GempyoNoShokai.do#shousai0", "fallback": "西濃運輸｜お届け状況確認", "text": "西濃運輸の公式ホームページ。 お届け状況確認では、お客様の商品の情報（位置や状況）を、ご確認いただけるサービスです。", "title": "西濃運輸｜お届け状況確認", "title_link": "https://track.seino.co.jp/kamotsu/GempyoNoShokai.do#shousai0", "service_name": "track.seino.co.jp"}]
- [1745277800.916079] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本日（4/22）10時までに配達いただくことになりました。
検品後、報告いたします。
- [1745291152.378729] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
フィルムロールが入荷しましたので、確認しました。
若干の不良箇所はありますが、ロールの蛇行や臭いも無く製造可能と思います。
今回製造するアイテム分については、本日出荷いたします。
【入荷数】
・バニラ抹茶　6ロール
・ジンジャーレモン抹茶　6ロール
・パイナップルレモン抹茶　6ロール
・ピーチレモン抹茶　6ロール
・ストロベリーレモン抹茶　6ロール
・シナモン抹茶　6ロール
・ココナッツラズベリー抹茶　6ロール
・マンゴー抹茶　6ロール
・チャイ抹茶　6ロール
・ピュア抹茶　5ロール
【不良ロール】
＜不良内容＞
最初の２〜3巻がロールよりズレ、折れていますが、ズレの部分をカットすれば使用可能です
・ストリベリー抹茶　２ロール
・マンゴー抹茶　１ロール
・ジンジャーレモン抹茶　１ロール
・バニラ抹茶　１ロール
・パイナップルレモン抹茶　１ロール
 ＜不良内容＞
ロールが若干蛇行している
・チャイ抹茶　１ロール
  - files: [{"id": "F08P738MQQ4", "created": 1745291138, "timestamp": 1745291138, "name": "チャイ抹茶　若干の蛇行.jpg", "title": "チャイ抹茶　若干の蛇行.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 386375, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08P738MQQ4/_________________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08P738MQQ4/download/_________________________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738MQQ4-526ee00260/__________________________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738MQQ4-526ee00260/__________________________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738MQQ4-526ee00260/__________________________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738MQQ4-526ee00260/__________________________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738MQQ4-526ee00260/__________________________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738MQQ4-526ee00260/__________________________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738MQQ4-526ee00260/__________________________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738MQQ4-526ee00260/__________________________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738MQQ4-526ee00260/__________________________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACS1vHXpUbYJ9/aod3YUKQTyTSGSB8Nip1OAKasaOASOR3pGzHyW3D19KTQXJQaM0wHI4ozSGUt24ZAwDSEhFLHpSIQVBHTFOYBl2kZBqhEkV0GUhT0HSnbzxkHnpnvVeKNFcKPlBPJJ7VoysBCenPAoEU/MKHbR5xqvO2ZTjtUeT60DLEq7DkfdpoOelXTAGGTjmo/sS9nZfpQBCqdzT9rYGAcGnx2hViZHLDPAz2qcpuceg60xEUcHyDOM077OPb8qlNHHvSGf/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08P738MQQ4/_________________________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08P738MQQ4-be8765dc63", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08P738L7EG", "created": 1745291142, "timestamp": 1745291142, "name": "ロールズレ.jpg", "title": "ロールズレ.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 418914, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08P738L7EG/__________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08P738L7EG/download/__________________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738L7EG-372fc54583/___________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738L7EG-372fc54583/___________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738L7EG-372fc54583/___________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738L7EG-372fc54583/___________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738L7EG-372fc54583/___________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738L7EG-372fc54583/___________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738L7EG-372fc54583/___________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738L7EG-372fc54583/___________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08P738L7EG-372fc54583/___________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACRaCcfWkZvmx09acrgdBipSuU2LHxkkH64p1SxNwSeKa7qTkdaOUOYjwaMGnD5uRS4qRlItyeSee9OjJ2uR94DikkQpKynqDn8KlhTb857VoQJbzCUEZ5HWoDKQ3Bq/DErKHkYEHoo/rVW9iRJdyEDd/D6UkrDbI/PYUfaGp8NsJIw7NjPSn/Yl/vmmInniEjKc7SOM0yQOse3yzn1HOanHy5NQzyEkA0gK0Uk8asNh59R0pPL43yHOe3rT0i+c9hikKMBuJz7elDYJCmRz0OB6Um9/7xpuaM0ij//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08P738L7EG/__________________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08P738L7EG-f94e5660c8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08P739T3UL", "created": 1745291144, "timestamp": 1745291144, "name": "完品.jpg", "title": "完品.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 441535, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08P739T3UL/______.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08P739T3UL/download/______.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08P739T3UL-e01e76df31/_______64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08P739T3UL-e01e76df31/_______80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08P739T3UL-e01e76df31/_______360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08P739T3UL-e01e76df31/_______480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08P739T3UL-e01e76df31/_______160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08P739T3UL-e01e76df31/_______720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08P739T3UL-e01e76df31/_______800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08P739T3UL-e01e76df31/_______960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08P739T3UL-e01e76df31/_______1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACRAFboSKPLPYioHZidqdSakTzBgbsk9qQxxWRe3FNC7jjYQfapCs6jJDACmmWRBnjHc0wF+zHu4Htij7P8A9NB+VIH3DOaXPvSAIEXaWPVqkwifOScLzTIjmNfpSthlZWzhhjimIcLoT5QADIpAhPamW1psk3b846cYqzjFAEaQcckDnineQP7wp27BIx0o3D0/SkBF5JjX5TkCmDmrSMcZ65prxAgleCKYDY+KfJIqRl3OMfrUAWYddoH0pjW7yMC5z/SlcLEsLNLGHx1p+1qSKExoBup+0/3j+dAz/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08P739T3UL/______.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08P739T3UL-7558e65162", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1745292037.407219] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
確認ありがとうございます！
・全種類サンプルとして、一部（50cmくらい）カットして保管しておいてください。
・今回の梱包と前回の梱包の違いはありましたか？芯が潰れない何か工夫はしてありましたか？
（知見を貯めるという観点で、確認願います）
・印字場所を確認するために、すべてのフィルムを写真撮って共有願います。
（カットしたものを机に広げて撮影してください）
※その写真上に絵を描く形で、印字位置を確認したいと思います。

## 2025-04-22

- [1745314874.997799] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
ご依頼内容につきまして、下記対応いたしました。
_*・全種類サンプルとして、一部（50cmくらい）カットして保管しておいてください。*_
　L 承知しました。
_*・今回の梱包と前回の梱包の違いはありましたか？芯が潰れない何か工夫はしてありましたか？*_
_*（知見を貯めるという観点で、確認願います）*_
　L前回は小口荷物で入荷。輸送時の取り扱いが悪かった様で箱がボコボコで届き、フィルムも衝撃のためか断面が均一では無く、ズレが生じていた。
　今回はパレット積みでの輸送だったため、断面のズレはほとんどなく、綺麗な状態で届きました。
　芯の潰れについては、前回のクレーム後にお送りいただいた時と同様、芯が潰れない様に補強部材が付いており、
　全てのロールで芯へのダメージはありませんでした。
_*・印字場所を確認するために、すべてのフィルムを写真撮って共有願います。*_
　Lセバスチャンフォルダ　-　フィルムロールフォルダ　–　フィルム画像フォルダに入れております。
      入荷時の梱包画像もフィルムフォルダに入れておきます。
ご確認お願いいたします。

## 2025-05-06

- [1746589948.866309] <@U08RVRNBY00>: <@U08RVRNBY00>さんがチャンネルに参加しました

## 2025-05-10

- [1746882610.262719] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
60g bagの熱シールについて
- [1746882620.588389] <@U0331FWGQRM>: 切り取り線でカットしても熱シールをしていて開封できなかったとのこと。
→切り取り線よりも上で熱シールしてください（といういう意味かと思います）
　袋破棄していいので、どの辺で熱シールするのかベストかテストしてみてください。
  - files: [{"id": "F08RQC3QQQ5", "created": 1746882616, "timestamp": 1746882616, "name": "（新）Vanilla Matcha 60g_表.jpg", "title": "（新）Vanilla Matcha 60g_表.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 245101, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08RQC3QQQ5/_________vanilla_matcha___60g____.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08RQC3QQQ5/download/_________vanilla_matcha___60g____.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08RQC3QQQ5-78ebac150b/_________vanilla_matcha___60g_____64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08RQC3QQQ5-78ebac150b/_________vanilla_matcha___60g_____80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08RQC3QQQ5-78ebac150b/_________vanilla_matcha___60g_____360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08RQC3QQQ5-78ebac150b/_________vanilla_matcha___60g_____480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08RQC3QQQ5-78ebac150b/_________vanilla_matcha___60g_____160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08RQC3QQQ5-78ebac150b/_________vanilla_matcha___60g_____720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08RQC3QQQ5-78ebac150b/_________vanilla_matcha___60g_____800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08RQC3QQQ5-78ebac150b/_________vanilla_matcha___60g_____960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08RQC3QQQ5-78ebac150b/_________vanilla_matcha___60g_____1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACS0fc4pNw/vD86JF3xsvqKp+QB1lAz7VLGmXNygffH50oOehz+NUxb56Sg/hU9tF5QbJzk+lCHzMnozRRVEiEcGqUwDAcgc9xmrRkIqo5YzBVJHPJxUsYBTGyN94Z7CrsXK5xjJqJQc8GpkOFFCBjsUYo3UbqoREcHrURQFs5NPNJSGCqB3P51IDxTRS5osA7NGaTNGaBH/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08RQC3QQQ5/_________vanilla_matcha___60g____.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08RQC3QQQ5-327d3962ef", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1746882639.271109] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
カートンラベルについて
- [1746882689.951759] <@U0331FWGQRM>: 全ての側面にラベルを貼り付けてくださいとのこと。そこは不要、と言っています。天面は確認中。
  - files: [{"id": "F08RLBEASHL", "created": 1746882656, "timestamp": 1746882656, "name": "WhatsApp Image 2025-05-06 at 20.36.58.jpeg", "title": "WhatsApp Image 2025-05-06 at 20.36.58.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 248397, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08RLBEASHL/whatsapp_image_2025-05-06_at_20.36.58.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08RLBEASHL/download/whatsapp_image_2025-05-06_at_20.36.58.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08RLBEASHL-5517d4cf69/whatsapp_image_2025-05-06_at_20.36.58_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08RLBEASHL-5517d4cf69/whatsapp_image_2025-05-06_at_20.36.58_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08RLBEASHL-5517d4cf69/whatsapp_image_2025-05-06_at_20.36.58_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 203, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08RLBEASHL-5517d4cf69/whatsapp_image_2025-05-06_at_20.36.58_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 270, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08RLBEASHL-5517d4cf69/whatsapp_image_2025-05-06_at_20.36.58_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08RLBEASHL-5517d4cf69/whatsapp_image_2025-05-06_at_20.36.58_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 405, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08RLBEASHL-5517d4cf69/whatsapp_image_2025-05-06_at_20.36.58_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1422, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08RLBEASHL-5517d4cf69/whatsapp_image_2025-05-06_at_20.36.58_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 540, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08RLBEASHL-5517d4cf69/whatsapp_image_2025-05-06_at_20.36.58_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 576, "thumb_1024_h": 1024, "original_w": 1152, "original_h": 2048, "thumb_tiny": "AwAwABtkz/vSSfbFIGc/dY/hRcrmQ7eeabEjq4OB170kM0oIgqbnQBqpnrV0zLtbJ55qmSM9aYhsgOcHG4YzTUUsKfNxKCO4FOgH7v8AE1Iw2cVBsySfc1bJwKqhsDFMAkmEzAgHIGDU1v8A6v6E1QjJ3H3q9bHKE+9AD5OEJPPFVKsXDfIR61VJFAH/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08RLBEASHL/whatsapp_image_2025-05-06_at_20.36.58.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08RLBEASHL-95c91d33b2", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-05-12

- [1747043183.176909] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
改めて、コメントきました。
Oh no　言うてます。。。
  - files: [{"id": "F08RW0S9Z2P", "created": 1747043131, "timestamp": 1747043131, "name": "WhatsApp Video 2025-05-12 at 18.39.57.mp4", "title": "WhatsApp Video 2025-05-12 at 18.39.57.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 2414194, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "complete", "locale": "en-US", "preview": {"content": "最初あのちょっと", "has_more": false}}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F08RW0S9Z2P-09e19ab435/whatsapp_video_2025-05-12_at_18.39.57.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F08RW0S9Z2P-09e19ab435/whatsapp_video_2025-05-12_at_18.39.57.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08RW0S9Z2P/download/whatsapp_video_2025-05-12_at_18.39.57.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "vtt": "https://files.slack.com/files-tmb/T033D70RR6H-F08RW0S9Z2P-09e19ab435/file.vtt?_xcb=6304c&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F08RW0S9Z2P-09e19ab435/file.m3u8?_xcb=6304c&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTM1NTI1MixBVkVSQUdFLUJBTkRXSURUSD0xMjc3MTIyLENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTYxMngxMDgwLEZSQU1FLVJBVEU9MjkuOTcwLFNVQlRJVExFUz0ic3VicyIKZGF0YTphcHBsaWNhdGlvbi92bmQuYXBwbGUubXBlZ3VybDtiYXNlNjQsSTBWWVZFMHpWUW9qUlZoVUxWZ3RWa1ZTVTBsUFRqb3pDaU5GV0ZRdFdDMVVRVkpIUlZSRVZWSkJWRWxQVGpvM0NpTkZXRlF0V0MxTlJVUkpRUzFUUlZGVlJVNURSVG94Q2lORldGUXRXQzFRVEVGWlRFbFRWQzFVV1ZCRk9sWlBSQW9qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0VWxjd1V6bGFNbEF0TURsbE1UbGhZalF6TlM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFVsY3dVemxhTWxBdE1EbGxNVGxoWWpRek5TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TWk1MGN3b2pSVmhVU1U1R09qSXVNelk1TEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRVbGN3VXpsYU1sQXRNRGxsTVRsaFlqUXpOUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd015NTBjd29qUlZoVUxWZ3RSVTVFVEVsVFZBbz0KI0VYVC1YLU1FRElBOlRZUEU9U1VCVElUTEVTLEdST1VQLUlEPSJzdWJzIixOQU1FPSJFbmdsaXNoIixERUZBVUxUPVlFUyxBVVRPU0VMRUNUPVlFUyxGT1JDRUQ9Tk8sTEFOR1VBR0U9ImVuZyIsVVJJPSJkYXRhOmFwcGxpY2F0aW9uL3ZuZC5hcHBsZS5tcGVndXJsO2Jhc2U2NCxJMFZZVkUwelZRb2pSVmhVTFZndFZrVlNVMGxQVGpvekNpTkZXRlF0V0MxVVFWSkhSVlJFVlZKQlZFbFBUam8yTURBS0kwVllWQzFZTFUxRlJFbEJMVk5GVVZWRlRrTkZPakVLSTBWWVZDMVlMVkJNUVZsTVNWTlVMVlJaVUVVNlZrOUVDaU5GV0ZSSlRrWTZNVFF1TXpneExBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0VWxjd1V6bGFNbEF0TURsbE1UbGhZalF6TlM5bWFXeGxMblowZEFvalJWaFVMVmd0UlU1RVRFbFRWQT09Igo=", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F08RW0S9Z2P-09e19ab435/whatsapp_video_2025-05-12_at_18.39.57_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 14381, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F08RW0S9Z2P-09e19ab435/whatsapp_video_2025-05-12_at_18.39.57_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 480, "thumb_video_h": 848, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08RW0S9Z2P/whatsapp_video_2025-05-12_at_18.39.57.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F08RW0S9Z2P-c9818a6b7f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1747046861.268039] <@U033G4KN4TD>: <@U0331FWGQRM> <@U0331FZS7JT> <@U0840UVFVA8>
大変申し訳ございません。
至近全量外注で小分けを行っているため、改めて外注先へ伝えます。
梱包時もシール面確認を行い梱包いたします。
- [1747054665.716429] <@U0331FWGQRM>: <@U033G4KN4TD> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
チェック項目多すぎても業務が増えすぎるので、熱シール時に注意すればそれでいいかと思います。

ちなみにTSE-MTL-008(ドイツ向け）もこれが含まれている可能性はありますか？
と、確認されておりますがどうでしょうか？
- [1747105653.030719] <@U033G4KN4TD>: <@U0331FWGQRM>
本日梱包しておりますが、切り取り線より下でシールされているものは無いとの事です。

## 2025-05-13

- [1747194487.379469] <@U0331FWGQRM>: 
  - files: [{"id": "F0752ANSYF7", "created": 1716701076, "timestamp": 1716701076, "name": "__________________", "title": "タイトル未定", "mimetype": "application/vnd.slack-docs", "filetype": "quip", "pretty_type": "Canvas", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": true, "size": 497, "mode": "quip", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0752ANSYF7/canvas?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0752ANSYF7/download/canvas?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "permalink": "https://grp-ssm9297.slack.com/docs/T033D70RR6H/F0752ANSYF7", "permalink_public": "https://slack-files.com/T033D70RR6H-F0752ANSYF7-6bb3487758", "url_static_preview": "https://grp-ssm9297.slack.com/docs/T033D70RR6H/F0752ANSYF7/mobile", "quip_thread_id": "CNV9AAg2X9k", "updated": 1727857203, "update_notification": 1716701107, "canvas_readtime": 0.062625451625853, "is_starred": false, "skipped_shares": true, "teams_shared_with": [], "is_restricted_sharing_enabled": true, "has_rich_preview": false, "file_access": "visible", "access": "owner", "org_or_workspace_access": "none", "title_blocks": [{"type": "rich_text", "block_id": "DOYmi", "elements": [{"type": "rich_text_section", "elements": [{"type": "text", "text": "Untitled"}]}]}], "canvas_creator_id": "U0331FZS7JT", "team_pref_version_history_enabled": true, "canvas_printing_enabled": true, "is_ai_suggested": false}]

## 2025-05-22

- [1747915495.061529] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
2025年の目標らしいです。
Pureとバニラが毎月各1万袋らしいです。
ーーー
弊社の発注見通しについて最新情報をお伝えさせていただきます。
 来年の今頃までに、ピュアとバニラの発注量を倍増させることを目標としております。
 具体的には、スイスとドイツを合わせて、それぞれ月に10,000ユニットを予定しております。
ーーー
- [1747915520.779919] <@U0331FWGQRM>: <@U0331FZS7JT> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
なので、原料の準備についてまた相談させてください。

## 2025-05-28

- [1748485110.797339] <@U08U8MMTH43>: <@U08U8MMTH43>さんがチャンネルに参加しました

## 2025-05-29

- [1748506449.250529] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U0331FZS7JT>
＜情報共有＞
レモン味の商品は予想より売れていないため、当面は再注文の必要はありません。
・Ginger Lemon
・Pineapple Lemon
・Peach Lemon
・Strawberry Lemon

ココナッツラズベリーは大変人気がある。
マンゴーとストロベリーも同様の売れ行きを期待している。
これらの味はレモン味と異なり、ミルクと混ぜられるため、とのこと。
- [1748509294.946229] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U0331FZS7JT>
:star:️*2025年注文予定数量*
- [1748509300.452139] <@U0331FWGQRM>: Monthly Product Quantities
-June
Pure: 5,000 bags
Vanilla: 5,000 bags
Cinnamon: 1,500 bags
Coconut Raspberry: 1,500 bags
200g Bags: 500 bags

-July
Pure: 4,000–5,000 bags
Vanilla: 4,000–5,000 bags
Cinnamon: 1,500 bags
Coconut Raspberry: 1,500 bags

-August
Pure: 10,000 bags
Vanilla: 10,000 bags
~Pure: 5,000 bags~
~Vanilla: 5,000 bags~
Cinnamon: 1,500 bags
Coconut Raspberry: 1,500 bags

-September
Pure: 5,000 bags
Vanilla: 5,000 bags
Cinnamon: 1,500 bags
Coconut Raspberry: 1,500 bags

-October
Pure: 10,000 bags
Vanilla: 10,000 bags
~Pure: 5,000 bags~
~Vanilla: 5,000 bags~
Cinnamon: 1,500 bags
Coconut Raspberry: 1,500 bags

-November (Black Friday Season)
Pure: 10,000 bags
Vanilla: 10,000 bags
Cinnamon: 1,500 bags
Coconut Raspberry: 1,500 bags

-December
Pure: 5,000 bags
Vanilla: 5,000 bags
Cinnamon: 1,500 bags
Coconut Raspberry: 1,500 bags
- [1748509322.267909] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U0331FZS7JT>
Mango, Chai, Strawberryは試作中。
1000bags/月程度を予想。
- [1748569598.370019] <@U033G4KN4TD>: <@U03BLQ65GK0>
CC <@U041RJKV5JA>
6月Sebastyan必要原料下記となります。

・Pure: 5,000 bags　→61ｇ×5000＝305㎏
　*R-mixS：305㎏*

・Vanilla: 5,000 bags　→61ｇ×5000＝305㎏
　*R-mixS：244㎏*　
　*バニラパウダー：61㎏*(現在庫出精に70㎏あり）

・Cinnamon: 1,500 bags　→61ｇ×1500＝91.5㎏
　92㎏で計算　
　*R-mixS：73.6㎏*　
　*シナモン(カシア)：18.4㎏*(再粉砕済は200ｇ程度桃にアリ　未粉砕出精在庫30㎏あり)

・Coconut Raspberry: 1,500 bags　→61ｇ×1500＝91.5㎏
　92㎏で計算
　*R-mixS：64.4㎏*　
　*ココナッツパウダー：18.4㎏*(出精在庫22㎏あり)　
　*ラズベリーミクロン：9.2㎏*(出精在庫14㎏あり）

・200g Bags: 500 bags　→201ｇ×500＝100.5㎏
　*R-mixS：100.5㎏*

合計：*R-mixS：787.5㎏*必要となります。

フレーバーについては、管理表上の数字となるので小村さん再度見ていただきます。
 <@U041RJKV5JA> 7月分の必要発注量をまた言います！

よろしくお願いいたします。

## 2025-06-02

- [1748855627.226419] <@U0331FWGQRM>: <@U0331FZS7JT>
2025年の商品原価についてメモ
- [1748856109.260419] <@U0331FWGQRM>: <@U0331FZS7JT>
抹茶の原料原価が1.5-1.8倍になる見込みです。
香料については価格の上昇はありません。
従いまして、商品価格としては26%-40%ほど上昇する見込み
正確な抹茶原料の価格は6月半ばにわかりますので、現時点では正確な商品価格は未定です。
つきましては、今回送付させていただくquotationの価格は2024年の抹茶価格で見積もりしております。

全ての上昇価格を貴社に負担いただくつもりはありませんので、原価上昇26%-40%のうち、10%-15%は弊社で負担できるように努めたいと考えております。
quotationの価格から、15%-25%ほど上昇した価格が最終売価になるとと思いますので、ご参考によろしくお願いします。
- [1748856846.790349] <@U0331FZS7JT>: メモ
抹茶使用量
Pure 5000bags：305kg
Vanilla 5000bags：244kg
Cinnamon1,500 bags：74kg
Coconut Raspberry1,500 bags：65kg
200g 500 bags：100kg

▼June-Oct + Dec
月間：788kg
合計：4,328kg

▼Nov
月間：1,237kg

6-12月
合計：5,565kg
※但し、別途の注文やMango, Chaiは加味していない。
- [1748908658.534719] <@U0331FWGQRM>: <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
各香料の原料確保は大丈夫ですか？
（数量把握＆購入スケジュールは立てていますか？）
- [1748914893.704939] <@U08V56G9U92>: <@U08V56G9U92>さんがチャンネルに参加しました

## 2025-06-03

- [1748942767.619029] <@U041RJKV5JA>: <@U0331FWGQRM>
 <@U0331FZS7JT> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
香料の原料確保については、5月中にメーカーへ下記の数量にて試算のうえ、確保を依頼しております。
• 各フレーバーにつき、4回分（2.5g Sachet：各15,000本 × 4回、60g bag：各2,000袋 × 4回〈バニラのみ5,000袋 × 4回〉）
• 上記に加え、ドイツ向け出荷を想定した数量
今回ご連絡いただいた数量に関しては、バニラを除くフレーバーについては12月分まで、すでに確保依頼済みの数量で対応可能です。
 バニラについては、追加での確保が可能とのことですので、他案件での使用分も含め、適宜確保を依頼いたします。
よろしくお願いいたします。
- [1748952422.663639] <@U0331FWGQRM>: <@U041RJKV5JA> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
在庫確保ありがとうござます。
12月までの分となると、残り6ヶ月分となります。
製造リードタイムによっては数ヶ月後に発注をかけなければいけません。
（例えば香料の製造リードタイムが2ヶ月だとしたら、10月に追加発注が必要）
リードタイムを確認した上で、12月以降の分のスケジュールも視野に入れて在庫管理を宜しくお願い致します。

## 2025-06-09

- [1749485869.784609] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
添付のラベルを印刷して、テストサンプルを作成し写真＆動画撮影して欲しいです。
（中身はなんでも良いです。ティッシュでも良いです）
Silver zipper bag with label

※元々、クラフト11560の商品
→銀色チャックへ変更 清和10329
  - files: [{"id": "F09105ADA6M", "created": 1749485726, "timestamp": 1749485726, "name": "Matcha Bag 200g.pdf", "title": "Matcha Bag 200g.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 36350, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09105ADA6M/matcha_bag_200g.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09105ADA6M/download/matcha_bag_200g.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09105ADA6M-ba787f3076/matcha_bag_200g_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 238, "thumb_pdf_h": 368, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09105ADA6M/matcha_bag_200g.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09105ADA6M-2532858e7c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-06-10

- [1749617141.831989] <@U08U8MMTH43>: <@U0331FWGQRM>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
テストサンプル、写真と動画の撮影をいたしました。
ご確認お願いいたします。
  - files: [{"id": "F090V6L9J4V", "created": 1749617071, "timestamp": 1749617071, "name": "正面画像.jpg", "title": "正面画像.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U08U8MMTH43", "user_team": "T033D70RR6H", "editable": false, "size": 228006, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F090V6L9J4V/____________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F090V6L9J4V/download/____________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6L9J4V-4de096f426/_____________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6L9J4V-4de096f426/_____________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6L9J4V-4de096f426/_____________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6L9J4V-4de096f426/_____________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6L9J4V-4de096f426/_____________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6L9J4V-4de096f426/_____________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6L9J4V-4de096f426/_____________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6L9J4V-4de096f426/_____________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6L9J4V-4de096f426/_____________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACRqx7vuqDTvIb+6Pzp0LhG578VOzewpJAVvJb+6PzoMRUZKjFWAT1wPypszARle56UWAg2j0FG0egooxUjEcfKamjfemT1AqM0kXGc9CKaYEodTkg5xUTdck5P6U/5QDjGcetMIptiQUtJ+Bo/A1AyQmmgVLgUED0oKIsUmcGpdooIHpRcQzJpcmlxRikM//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F090V6L9J4V/____________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F090V6L9J4V-705da24971", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F090V6LSE21", "created": 1749617081, "timestamp": 1749617081, "name": "側面画像.jpg", "title": "側面画像.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U08U8MMTH43", "user_team": "T033D70RR6H", "editable": false, "size": 431860, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F090V6LSE21/____________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F090V6LSE21/download/____________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6LSE21-27f693c3bf/_____________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6LSE21-27f693c3bf/_____________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6LSE21-27f693c3bf/_____________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6LSE21-27f693c3bf/_____________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6LSE21-27f693c3bf/_____________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6LSE21-27f693c3bf/_____________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6LSE21-27f693c3bf/_____________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6LSE21-27f693c3bf/_____________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F090V6LSE21-27f693c3bf/_____________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACR9OpBSigQ2kpe1FACUUtFAC8+hpOgPFP3H1pGY7SKQ7CDpRQrFdtSE0BYioqTNGaAsJigpkUop2aBkQUntwKfSlqTNACUUlFAH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F090V6LSE21/____________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F090V6LSE21-d96ad33a35", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F090XUAACG4", "created": 1749617093, "timestamp": 1749617093, "name": "動画.mp4", "title": "動画.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U08U8MMTH43", "user_team": "T033D70RR6H", "editable": false, "size": 2245558, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F090XUAACG4-2379c893be/______.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F090XUAACG4-2379c893be/______.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F090XUAACG4/download/______.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F090XUAACG4-2379c893be/file.m3u8?_xcb=a86bf&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTQ4NjcyMSxBVkVSQUdFLUJBTkRXSURUSD0xNDg2NzIxLENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTYwOHgxMDgwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNU1GaFZRVUZEUnpRdE1qTTNPV000T1ROaVpTOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TVM1MGN3b2pSVmhVU1U1R09qSXVPREF6TEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTVNRmhWUVVGRFJ6UXRNak0zT1dNNE9UTmlaUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01pNTBjd29qUlZoVUxWZ3RSVTVFVEVsVFZBbz0K", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F090XUAACG4-2379c893be/_______trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 8808, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F090XUAACG4-2379c893be/_______thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F090XUAACG4/______.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F090XUAACG4-8cd99c6178", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-06-13

- [1749829150.614759] <@U0331FWGQRM>: <@U041RJKV5JA> <@U08U8MMTH43>
お客様からラベルを大きくして欲しいと依頼ありました。
大きいラベルversionで再度撮影願います。よろしくお願いします。
- [1749834843.718379] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
Sebastyanの袋とsachetのフィルムロールの在庫管理ってどこでしてますか？
在庫を聞かれております。宜しくお願い致します。

## 2025-06-16

- [1750067318.141199] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
Sebastyanフォルダにエクセルデータを格納しました。（ファイル名：Sebastyan 資材在庫）
ご確認お願いいたします。

## 2025-06-17

- [1750144305.684799] <@U041RJKV5JA>: <@U0331FWGQRM>
 <@U08U8MMTH43>
ラベルサイズを大きくして、再度撮影しました。
ご確認お願いいたします。
  - files: [{"id": "F091KRPTPKM", "created": 1750144290, "timestamp": 1750144290, "name": "label_1.jpg", "title": "label_1.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 333527, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F091KRPTPKM/label_1.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F091KRPTPKM/download/label_1.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F091KRPTPKM-bcd02a4922/label_1_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F091KRPTPKM-bcd02a4922/label_1_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F091KRPTPKM-bcd02a4922/label_1_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F091KRPTPKM-bcd02a4922/label_1_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F091KRPTPKM-bcd02a4922/label_1_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F091KRPTPKM-bcd02a4922/label_1_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F091KRPTPKM-bcd02a4922/label_1_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F091KRPTPKM-bcd02a4922/label_1_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F091KRPTPKM-bcd02a4922/label_1_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACSZULDOQKCuO9CnBxTsEn736UAN2+9Ls9xTwjd2/ShgAMs36UARUUuKTFACkcigH5CeuKazjHDD86VcMhBGRnpQAqSFmxz+VD5LfjihUXcCFHHtQ7KGUZxg85oAcF96Xb7imiVB/Ev50vmp/eH50AUOetPV8DaeRnNNzSdTxxUlEytyDgcc9aRjuPNNUNjoMetLwB1obFYMUYoz7mjP1pDP/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F091KRPTPKM/label_1.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F091KRPTPKM-f6dfdfff26", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F092F39AREU", "created": 1750144293, "timestamp": 1750144293, "name": "label_2.jpg", "title": "label_2.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 359574, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F092F39AREU/label_2.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F092F39AREU/download/label_2.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F092F39AREU-96575ff987/label_2_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F092F39AREU-96575ff987/label_2_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F092F39AREU-96575ff987/label_2_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F092F39AREU-96575ff987/label_2_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F092F39AREU-96575ff987/label_2_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F092F39AREU-96575ff987/label_2_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F092F39AREU-96575ff987/label_2_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F092F39AREU-96575ff987/label_2_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F092F39AREU-96575ff987/label_2_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACScLnPOKUpgdaax2kUuCRwxxQACPvup3l/7QpArDuaCxUHJzQAhGDikp2KMUAJKPkz6UxmCp1HXjNK8sZUjd1HpTI3yvUD60gBZPnG7aBntmpXHA9SaQMT3ppkHmDJwBQBNijFNE0f94UedH/eFO4FPmkBx2/OlwaTBBqCh4YH+EcUd+aQE0cntRcLDsUYpMGjmgZ//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F092F39AREU/label_2.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F092F39AREU-8ba14f1a75", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0925867F33", "created": 1750144296, "timestamp": 1750144296, "name": "label_3.jpg", "title": "label_3.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 356036, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0925867F33/label_3.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0925867F33/download/label_3.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0925867F33-271326460d/label_3_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0925867F33-271326460d/label_3_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0925867F33-271326460d/label_3_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0925867F33-271326460d/label_3_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0925867F33-271326460d/label_3_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0925867F33-271326460d/label_3_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0925867F33-271326460d/label_3_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0925867F33-271326460d/label_3_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0925867F33-271326460d/label_3_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACSzig8UhO0j3pSCf/1UAIF7dadtPtSAEen5UFsDmgApKXFGKAEl4UH0NMZwEHK59zilkdGjYBhnFMU7kU4B/CkAK+XG4IBn+8alfqPc4pvB/hH5Ubx5uCQAB3NAEuKMUgkT+8v50eYn95fzpgUTmgNjA54PajmkGc1BRIGzwGYUHliT3pgPtTifai4WFxRik59KMn0oGf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0925867F33/label_3.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0925867F33-b50087a884", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1750165977.394729] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
TSE-MTL-010-25注文分を引いた後の在庫数ですか？
- [1750204152.121659] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
まだ製造に取り掛かっておりませんので、010-25分は引いておりません。
作業後、ロス分も含めて反映します。

## 2025-06-18

- [1750230158.772249] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
2番のラベルがいいとのことです。
よろしくお願いします！！

## 2025-06-21

- [1750524000.883159] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
sebastyanの60g商品について、
前回のようなzipper bagがvノッチ部分にも熱シールしないように注意してください。とのことです。
問題ないか厳重な品質確認お願いします。

## 2025-06-22

- [1750635094.708469] <@U033G4KN4TD>: <@U0331FWGQRM>
 <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
先方支給の袋に不良が見受けられましたので、ご報告いたします。
 添付画像のような不良が確認されております。
 お手数ですが、先方へ本品の使用可否についてご確認いただけますでしょうか。
  - files: [{"id": "F092JUVKRLL", "created": 1750634488, "timestamp": 1750634488, "name": "不良　PDF.pdf", "title": "不良　PDF.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 1750043, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F092JUVKRLL/_________pdf.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F092JUVKRLL/download/_________pdf.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F092JUVKRLL-38f22353ac/_________pdf_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F092JUVKRLL/_________pdf.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F092JUVKRLL-fbf8dedb9a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-06-30

- [1751298192.167859] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0> <@U0331FZS7JT>
製造キャパシティについて、相談させてください。
水曜日に時間もらえたらと思います。
セバスチャンから下記メッセージが来ています。
ーーーー
現在の製造キャパシティがどのような状況か、教えていただけますでしょうか？
例えば、8月からピュア10,000個とバニラ10,000個を毎月製造することは可能でしょうか？
 あるいは、2026年1月から毎月20,000個の製造は可能でしょうか？（←おそらくpure, vanilla 各20000）
1ヶ月あたりに対応可能な最大製造量はどのくらいでしょうか？
ドイツ市場に非常に大きな可能性を感じており、まずは御社の製造能力を把握させていただければと思っております。
ーーーー
- [1751303211.157619] <@U0331FZS7JT>: メモ
pure 10,000袋：600kg
バニラ 10,000袋：480kg(バニラ120kg)
1,080kg/月
8月-12月 5.4t + α（他のフレーバー抹茶）
1月-6 月 10.8t + α（他のフレーバー抹茶）
- [1751335108.990789] <@U0331FWGQRM>: <@U033G4KN4TD> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
報告ありがとうございます。
現時点では全量確認してないと思うので、
現時点での不良品が約90袋程度ということですね。

お客様に伝える際に、
例えば、5000袋中の何袋が不良品だったのかを連絡しなければ、
お客様側で状況判断できないので、またわかり次第教えてください。
- [1751338215.143909] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> 
破棄してくださいと連絡が来ました。
（が、90袋が不良品と伝えているので、その判断をされたと思います。）

なので、全量不良品数カウントが終わるまで保管しておいてください。

## 2025-07-11

- [1752225772.763589] <@U0331FZS7JT>: <@U05KGS6HN9H> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
セバスチャンサンプル発送
----
ATTN：MatchaLand
Sebastyan Meixger
ADRESS：703 Am Schanzengraben 25, 8002 Zurich, Switzerland
Postal code : 8002
Phone：<tel:+41794059719|+41-794059719>
-----
- [1752295986.609899] <@U08U8MMTH43>: <@U0331FZS7JT>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
本日、DHLにて出荷しました。
AWB No.　7007198995
よろしくお願いいたします。
＜メモ＞
・Chai Matcha 1
Matcha B2（出雲抹茶R(B2））：88％
Ginger （有機ジンジャー）：3％
Cinnamon（シナモン(カシア)）：6％
Clove（クローブ）：3％

・Chai Matcha 2
Matcha B2W（出雲抹茶W(B2W））：88％
Ginger （有機ジンジャー）：3％
Cinnamon（シナモン(カシア)）：6％
Clove（クローブ）：3％

・Mango Matcha 1
Matcha B2（出雲抹茶R(B2））：92％
Mango flav（マンゴー(大阪香料））：8％

・Mango Matcha 2
Matcha B2（出雲抹茶R(B2））：91.5％
Stevia（ステビア）：0.5％
Mango flav（マンゴー(大阪香料））：8％

・Mango Matcha 3
Matcha B2N（出雲抹茶N(B2N））：92％
Mango flav（マンゴー(大阪香料））：8％

・Mango Matcha 4
Matcha B2N（出雲抹茶N(B2N））：91%
Stevia（ステビア）1％
Mango flav（マンゴー(大阪香料））：8％

## 2025-07-13

- [1752450155.806389] <@U0331FZS7JT>: <@U05KGS6HN9H> <@U08U8MMTH43>
先週は失礼しました。
送り先を修正したインボイスを格納しています。
よろしくお願いします。
- [1752475114.919319] <@U095LLEH09G>: <@U095LLEH09G>さんがチャンネルに参加しました
- [1752475512.992819] <@U08U8MMTH43>: <@U0331FZS7JT>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
本日、DHLにて出荷しました。
AWB No.7007199290
よろしくお願いいたします。

## 2025-07-14

- [1752562625.440529] <@U0331FWGQRM>: <@U0331FZS7JT>
新商品依頼
• *ウーロン茶*
•  ・年間推定販売量：18,200個
•  ・重量：1個あたり約50〜100g（ご使用の缶のサイズに応じて、50g、80g、100gの見積もりを作成可能）
•  ・パッケージ：オリジナルラベル付きのアルミ缶に入ったリーフタイプのウーロン茶
•  ・特徴表示：オーガニック、中国産（福建省・湖北省・広東省などの伝統的なウーロン茶産地）
•  ・外観：伝統的な球状に丸められた茶葉
•  ・香り・味わい：花や果実を思わせる香り、非常に少ない渋み
- [1752562746.627299] <@U0331FWGQRM>: *<@U0331FZS7JT>* 
新商品依頼
*中グレードのセレモニアル抹茶（当社のB2よりやや低品質）*
•  ・年間推定販売量：27,300個
•  ・重量：1個あたり30g
•  ・パッケージ：オリジナルラベル付きのアルミ缶に入った抹茶パウダー（例：Oakberryのようなスタイル）
•  ・特徴表示：オーガニック、日本産、セレモニアルグレード
•  ・外観：濃い緑色のきめ細かいパウダー、点てると明るい緑色
•  ・香り・味わい：典型的なフレッシュで濃厚な抹茶の香り、やや青っぽさあり


## 2025-07-15

- [1752563060.035659] <@U0331FWGQRM>: サンプル候補
水宗園4200　供給可能料1.2t（鹿児島Cの代替品）
水宗園3400　供給可能料10t
- [1752563249.240339] <@U0331FWGQRM>: ひかわに確認
三井農林
Alibaba
- [1752647489.477629] <@U0331FZS7JT>: メモ
ひかわ（日野執行役）・三井農林(企業HP)：2025年7月16日確認の連絡送信/返信待ち

## 2025-07-19

- [1752910903.148359] <@U0331FWGQRM>: Slovakia向けについて（matcha protein bar用）
- [1752910911.033619] <@U0331FWGQRM>: ・商品には賞味期限のみでOK（2年）
・COA添付が必要
・COAには賞味期限とLot番号が必要

原料
出雲抹茶N（Non-organic matcha middle grade-2）

## 2025-07-21

- [1753094680.300169] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
8月中旬出荷希望の内容は下記になりそうです。
更新があれば改めて連絡します。
60g
•⁠  ⁠10,000bags Pure matcha
•⁠  ⁠⁠10,000bags Vanilla
~•⁠  ⁠6000bags Pure matcha~
~•⁠  ⁠⁠6000bags Vanilla~

200g
•⁠  ⁠200bags Pure matcha

## 2025-07-22

- [1753197450.915929] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
上記訂正です。
8月中頃の出荷分については各10,000とのことです。
- [1753197688.709589] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
さらに、
10月中頃出荷分も各10,000袋の予定です。
フレーバーは合計10000袋の予定なので、
総量で30000袋程度とのことですので、製造スケジュールと人員を確保願います。

## 2025-07-23

- [1753326155.771709] <@U033G4KN4TD>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
資材の入荷予定はありますでしょうか？
ご確認お願いいたします。
  - files: [{"id": "F096SSNUHP1", "created": 1753326102, "timestamp": 1753326102, "name": "Sebastyan資材在庫.pdf", "title": "Sebastyan資材在庫.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 396752, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F096SSNUHP1/sebastyan____________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F096SSNUHP1/download/sebastyan____________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F096SSNUHP1-2a8a511c32/sebastyan_____________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F096SSNUHP1/sebastyan____________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F096SSNUHP1-5289bfba9d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1753326306.236749] <@U0331FWGQRM>: <@U033G4KN4TD> 
あります！
船便で8月12日着予定でしたが、エアーに変更して早めてもらってます。

数量など詳細内容は不明ですが、
取り急ぎpureとvanillaはそれぞれ8000と3000だけ早くくれとは言っております！

- [1753326775.960699] <@U08L89G6JSG>: <@U0331FWGQRM>
ご報告が遅くなりました。
先日出雲に来られた際に一緒に確認していただいたレベルで
Pureのストックから3000枚チェックしましたがNGは無しでした。

&gt; 破棄してくださいと連絡が来ました。
&gt; （が、90袋が不良品と伝えているので、その判断をされたと思います。）
　→　こちらも再度確認しOKレベルのものはストックに追加しようと思います。（Pure　OK47枚　NG2枚）

## 2025-07-25

- [1753444666.304859] <@U0331FWGQRM>: <@U033G4KN4TD> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
8/4着予定らしいですが、今までの傾向で行くと3,4日遅くなる可能性があります。

## 2025-07-29

- [1753833290.516769] <@U0331FWGQRM>: <@U0840UVFVA8> <@U0331FZS7JT> cc <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
20250730 from Sebastyan
現在の販売状況に基づき、ブラックフライデーまでの各フレーバーごとの月間販売数量を以下のように予想しています。
（プロテインバーを除く）

ピュア 5,000
バニラ 5,000
チャイ 1,000
マンゴー 750
シナモン 750
ココナッツラズベリー 1,000
200g ピュア 175

サシェ（全フレーバー）：4,000/月

スイス向け：今後6～9ヶ月以内に、この数量が少なくとも50%増加すると予想しています。

ドイツ向けには、2026年6月までにこの量の50%を供給予定です。

ブラックフライデー向けには、この量の2倍（ピュア/バニラ 10,000、チャイ/シナモン/マンゴー/ココナッツ 2,000～3,000）を注文予定
- [1753833458.575609] <@U0331FWGQRM>: <@U0840UVFVA8> <@U0331FZS7JT> cc <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
下記問い合わせが来ています。
1茶の売れ残り、有機モガ、2茶、秋碾茶、慣行品の農薬未検出品、中国産抹茶、
などの可能性、を探り、改めて下記問い合わせについてどこまで対応できるか返答が必要です。相談させてください。宜しくお願い致します。

&lt;&lt;重要な質問&gt;&gt;
生産能力についてご説明ください。
2026年1月に純粋/バニラで1万個は可能とおっしゃいましたが、2万個は無理とのことでした。2025年6月（2026年6月のこと？）までに、この2つのフレーバーで月間2万個は可能でしょうか？2026年1月は？
抹茶の調達能力はありますか？

ドイツへの進出と、スイスでのスーパーマーケット展開を計画しているため、何が可能かを確認する必要があります。
- [1753833662.393549] <@U0331FWGQRM>: <@U0331FZS7JT>
大麦若葉はひかわから調達可能ですか？
混ぜるわけではなく、お客様への提案方法として、
抹茶と1:1でブレンドした商品の提案はできないか？と思った次第です。選択肢の１つになりうるかな？と思った次第です。
確認、宜しくお願い致します。:sweat_drops:
- [1753839565.178339] <@U0331FZS7JT>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
CC：<@U0331FWGQRM> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
*メモ（ブラックフライデーまで）*
*全種類出雲R使用*
*▼60g bag*
ピュア 5,000：300kg
バニラ 5,000：240kg
チャイ 1,000：52.8kg
マンゴー 750：41.4kg
シナモン 750：36kg
ココナッツラズベリー 1,000：42kg
200g ピュア 175：35kg
*合計：747.2kg/月*

*▼サシェ（全フレーバー/11種）：4,000/月*
ピュア：8kg
バニラ：8kg
ジンジャーレモン：5.6kg
パイナップルレモン：5.8kg
ピーチレモン：5.9kg
ストロベリーレモン：6.2kg
シナモン：8kg
マンゴー：9.2kg
チャイ：8.8kg
ストロベリー：7kg
*合計：72.7kg/月*

*袋+サシェ：819.9kg/月(747.2kg+72.7kg)*

*抹茶のGradeを分けた場合(要品質確認)*
*▼60g bag*
(R)ピュア 5,000：300kg
(T)バニラ 5,000：(R)204kg(A)36kg
(W)チャイ 1,000：(R)21.12kg(A)31.68kg
(T)マンゴー 750：(R)35.19kg(A)6.21kg
(W)シナモン 750：(R)14.4kg(A)21.6kg
*出雲R：574.71kg/月*
*出雲A：172.49kg/月*

*▼サシェ（全フレーバー/11種）：4,000/月*
(R)ピュア：8kg
(T)バニラ： (R)6.8kg(A)1.2kg
(T)ジンジャーレモン：(R)4.76kg(A)0.84kg
(T)パイナップルレモン：(R)4.93kg(A)0.87kg
(T)ピーチレモン：(R)5.015kg(A)0.885kg
(T)ストロベリーレモン：(R)5.27kg(A)0.93kg
(W)シナモン：(R)3.2kg(A)4.8kg
(T)マンゴー：(R)7.82kg(A)1.38kg
(W)チャイ：(R)3.52kg(A)5.28kg
(T)ストロベリー：(R)5.95(A)1.05kg
*出雲R：55.265kg/月*
*出雲A：17.435kg/月*

*(R)袋+サシェ：629.975kg/月(574.71kg+55.265kg)*
*(A)袋+サシェ：189.925kg/月(172.49kg+17.435kg)*

## 2025-07-30

- [1753861711.585179] <@U033G4KN4TD>: <@U0331FWGQRM> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
 <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
```8月中頃の出荷分については各10,000```
上記については、新しく受注スレッドを立てられますでしょうか？
出荷可能日の連絡を一旦こちらに報告いたします。
出荷可能日：8月23日

## 2025-08-04

- [1754352920.272569] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
2025年8月入荷予定60g袋について。
- [1754352977.918979] <@U0331FWGQRM>: 8/4頃着予定
・PURER BIO MATCHA 60g　   9000
・Vanilla Matcha 60g　　　　　3000

UPS追跡番号
1ZX2W3290494917964
  - files: [{"id": "F098UHJ0886", "created": 1754352972, "timestamp": 1754352972, "name": "スクリーンショット 2025-08-05 9.06.16.png", "title": "スクリーンショット 2025-08-05 9.06.16.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 82451, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F098UHJ0886/____________________________2025-08-05_9.06.16.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F098UHJ0886/download/____________________________2025-08-05_9.06.16.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F098UHJ0886-16b3a86c07/____________________________2025-08-05_9.06.16_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F098UHJ0886-16b3a86c07/____________________________2025-08-05_9.06.16_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F098UHJ0886-16b3a86c07/____________________________2025-08-05_9.06.16_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 325, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F098UHJ0886-16b3a86c07/____________________________2025-08-05_9.06.16_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 433, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F098UHJ0886-16b3a86c07/____________________________2025-08-05_9.06.16_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F098UHJ0886-16b3a86c07/____________________________2025-08-05_9.06.16_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 650, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F098UHJ0886-16b3a86c07/____________________________2025-08-05_9.06.16_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 886, "original_w": 816, "original_h": 904, "thumb_tiny": "AwAwACzRwwB7nsCf/rU4Zyc/hTASS4OThgBj6CnDJGG/McUALRQPpRQAUUUUAMBC+Yc456n6CkDM3RlOBkgD/wCvQSU3ttzyO+PSnqwYdRnvg5oABznkEUc56jH0paKAAZ7kUUUUAN4Xcx4GckmlAXbgAYNBzg469s0o6c0AAAHSiiigAooooA//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F098UHJ0886/____________________________2025-08-05_9.06.16.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F098UHJ0886-460c5d3283", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1754353038.789329] <@U0331FWGQRM>: 8/20頃着予定
・PURER BIO MATCHA 60g	50,000
・Vanilla Matcha 60g	　　　　40,000
・Strawberry Matcha 60g	　　20,000
・Coconut Raspberry 60g	　　20,000
・Cinnamon Matcha 60g	　　10,000

## 2025-08-05

- [1754457461.831219] <@U033G4KN4TD>: メモ
PURER BIO MATCHA 60g
デザインが古くなって入荷(日本地図マーク無)
8/20頃着分も旧デザインにて入荷予定。(袋製造会社ミス)

*TSE-MTL-014-25*：旧デザイン(日本地図マーク無)6390枚使用予定
　　　　　　　　　新デザイン3610枚使用予定
*TSE-MTL-013-25*：旧デザインのみで出荷予定
  - files: [{"id": "F0991NSCG9Z", "created": 1754457057, "timestamp": 1754457057, "name": "S__259948562_0.jpg", "title": "S__259948562_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 295386, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0991NSCG9Z/s__259948562_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0991NSCG9Z/download/s__259948562_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NSCG9Z-8c12db4894/s__259948562_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NSCG9Z-8c12db4894/s__259948562_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NSCG9Z-8c12db4894/s__259948562_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NSCG9Z-8c12db4894/s__259948562_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NSCG9Z-8c12db4894/s__259948562_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NSCG9Z-8c12db4894/s__259948562_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NSCG9Z-8c12db4894/s__259948562_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NSCG9Z-8c12db4894/s__259948562_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NSCG9Z-8c12db4894/s__259948562_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1478, "original_h": 1108, "thumb_tiny": "AwAkADBgDkgBzz7CpRDLtIO8k+6/4UQjMq5qW4ZgQN20H060CZWaKYdS/wCQP9KVIZWGdzfkKtRZZV5Py+p6/WpGyq5Vcn06UBYqCCT+LP5CoJbdlAyMZ9atxSESbSc57E5/X/PSi7/g/GgEJCuHz6CmyOPOLdSMYB/WpIg3zZBB7Z4oZN4IZQD6g0DFjlDqWAxzTLiVjDlO/celKq7eAoA9femoSIl4z8o4oAIpQuECZOcggdqdPltv41GYlD5CEj0zwakkYBQT60kBj5PqaMn1NJRTAUMQcgkGkoooAVWZTlSQfY1Ojs6fMxOD3NV6mh+7+NDBH//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0991NSCG9Z/s__259948562_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0991NSCG9Z-70c4caf437", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0991NQH1RR", "created": 1754457061, "timestamp": 1754457061, "name": "S__259948560_0.jpg", "title": "S__259948560_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 353835, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0991NQH1RR/s__259948560_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0991NQH1RR/download/s__259948560_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NQH1RR-e0635b11c6/s__259948560_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NQH1RR-e0635b11c6/s__259948560_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NQH1RR-e0635b11c6/s__259948560_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NQH1RR-e0635b11c6/s__259948560_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NQH1RR-e0635b11c6/s__259948560_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NQH1RR-e0635b11c6/s__259948560_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NQH1RR-e0635b11c6/s__259948560_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NQH1RR-e0635b11c6/s__259948560_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0991NQH1RR-e0635b11c6/s__259948560_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1478, "original_h": 1108, "thumb_tiny": "AwAkADBmPQZNLscDOx89xsp0Y/eL9RVzcDkZwRQJopCNmb7jDPXjFCwyEBhHke5q2dx+UNg+uKQDK4yQMnOD70BYrGCUniMD2BprRumN64z05q6GwcE49M1BcliF3Yzz0/CgAiAEgNSkk8/MvtxzUEJzJz2FTlsDNAxrsfR/wIpgJwCWwoJzzjvSsx3gbOD3zSJyv4n+dAD/ADCVyGB464/+vTJRmMex9MUFUOeDxz3odgEwARzQBk7j6mje/wDeb86SigB3mOP42/Ol82T++350yigB/nS/89G/OlE8pwC5I96joHUUAf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0991NQH1RR/s__259948560_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0991NQH1RR-7c446e4bf2", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-08-06

- [1754488692.383449] <@U0331FWGQRM>: <@U033G4KN4TD>
連絡ありがとうございます！
今回、旧デザインで袋を製造してしまったらしく、Sebastyanも理解しておりました。
そして、下記について念のためにSebastyanに連絡はしておきました。
&gt; *TSE-MTL-014-25*：旧デザイン(日本地図マーク無)6390枚使用予定
&gt; 　　　　　　　　　新デザイン3610枚使用予定
&gt; *TSE-MTL-013-25*：旧デザインのみで出荷予定
Sebastyanからは、改めて熱シール部分について注意してくださいとアナウンスがありましたので、
念のために共有させていただきます。

## 2025-08-20

- [1755742156.826649] <@U033G4KN4TD>: <@U0331FWGQRM>
8/20頃着予定
・PURER BIO MATCHA 60g	50,000
・Vanilla Matcha 60g	 40,000
・Strawberry Matcha 60g	 20,000
・Coconut Raspberry 60g	 20,000
・Cinnamon Matcha 60g	 10,000

追跡番号が分かれば共有お願いいたします！

## 2025-08-21

- [1755833126.166619] <@U0331FWGQRM>: <@U033G4KN4TD>
追跡番号はわからないのですが、
現在通関中で来週到着するそうです。:sweat_drops:

製造上問題ありそうですか？
- [1755833278.124489] <@U0331FWGQRM>: <@U033G4KN4TD>
上記（8/20頃着予定）以外に
追加で45500のPure matchaの製造が完了したと連絡が来て、
これは9月10日頃着でも問題なさそうです？急ぎならAIRの選択も可能です。
- [1755836843.793279] <@U033G4KN4TD>: <@U0331FWGQRM>
承知いたしました！
TSE-MTL-015-25のバニラの製造を8/25から予定していた為、確認でした。
出荷日に影響はありませんので大丈夫です！

&gt; 追加で45500のPure matchaの製造が完了したと連絡が来て、
&gt; これは9月10日頃着でも問題なさそうです？急ぎならAIRの選択も可能です。
→9月10日頃着で問題ありません！よろしくお願いいたします。

メモ
Pure matchaの袋在庫
8/22時点：1,610
8/20頃着予定：50,000
＝合計51,610
MTL015で3,000袋使用
MTL017で15,000袋使用
51,610-18,000＝33,610

## 2025-08-25

- [1756116553.157169] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
追跡番号入手しました。
宜しくお願い致します。
<https://track.seino.co.jp/kamotsu/GempyoNoShokai.do>
追跡番号：0414824992

## 2025-08-28

- [1756365085.911779] <@U08L89G6JSG>: <@U0331FWGQRM>
下記8/27に入荷しましたがPureの50,000袋が未着です。
32ケース届いているので出荷漏れかと思いますが
ご確認いただけますでしょうか:woman-bowing:
&gt; 8/20頃着予定
&gt; ・PURER BIO MATCHA 60g	50,000
&gt; ・Vanilla Matcha 60g	 40,000
&gt; ・Strawberry Matcha 60g	 20,000
&gt; ・Coconut Raspberry 60g	 20,000
  - files: [{"id": "F09C19R7B1D", "created": 1756365070, "timestamp": 1756365070, "name": "IMG_0800.jpg", "title": "IMG_0800", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U08L89G6JSG", "user_team": "T033D70RR6H", "editable": false, "size": 1082558, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09C19R7B1D/img_0800.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09C19R7B1D/download/img_0800.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09C19R7B1D-122a12092a/img_0800_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09C19R7B1D-122a12092a/img_0800_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09C19R7B1D-122a12092a/img_0800_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09C19R7B1D-122a12092a/img_0800_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09C19R7B1D-122a12092a/img_0800_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09C19R7B1D-122a12092a/img_0800_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09C19R7B1D-122a12092a/img_0800_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09C19R7B1D-122a12092a/img_0800_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09C19R7B1D-122a12092a/img_0800_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACSS2iGPMb8BRcyGOPcuAScdKdG4S3XcQMnHJx3pTJERguh+pFIaepDazSSPtfpjOcYNWGiz71HthYArjPrGM4/KpFDLncxbpjimgk03oRmMZ5zSeWvvT3Ybjmm7h6ikIkbcq4UA49TimjzT1VP++j/hUhOAOM/TtTGYgjAGO5JxTsA5Y8YJCgjsP05/OhQ235v5U3ewbsVx+NKCTjIHvSAZImWzTNlTODmm4NIY5unJqF8epUZ9aiFyrAHcPxpwnQn7y/nVCH7RvGWPPQDiplx25qNW45H604P6Y/OkA9utJQZEHBYZpPMT+8KQz//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09C19R7B1D/img_0800.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F09C19R7B1D-7ee6382ac7", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1756370425.165959] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
8/27入荷分のpacking listです。
  - files: [{"id": "F09CK13FN4U", "created": 1756370397, "timestamp": 1756370397, "name": "スクリーンショット 2025-08-28 17.39.37.png", "title": "スクリーンショット 2025-08-28 17.39.37.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 70012, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09CK13FN4U/____________________________2025-08-28_17.39.37.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09CK13FN4U/download/____________________________2025-08-28_17.39.37.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09CK13FN4U-3241f0ec02/____________________________2025-08-28_17.39.37_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09CK13FN4U-3241f0ec02/____________________________2025-08-28_17.39.37_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09CK13FN4U-3241f0ec02/____________________________2025-08-28_17.39.37_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 249, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09CK13FN4U-3241f0ec02/____________________________2025-08-28_17.39.37_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 331, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09CK13FN4U-3241f0ec02/____________________________2025-08-28_17.39.37_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09CK13FN4U-3241f0ec02/____________________________2025-08-28_17.39.37_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 497, "original_w": 743, "original_h": 513, "thumb_tiny": "AwAiADDQO/Jwi4/3j/hR+8/uJ/30f8KdnnHOevSmkYJ+ZgW9BnFAWG7ZdwPGPTd/9anfvP7if99H/Cn45zSMSBx+eM4oFYb+8/uJ/wB9H/ClXdn5lUD2Of6VGS+VPmYGeQIzyP8AOalxyDk/SgY0xKSSVXn/AGaQxIMZVfThaGmjGR5iAjsWApBPEQp81B7bhQFhfKTH3V/75FHlJn7qY/3aPPh/56p/30KTzo9+fOTH+8KAsMVAZ2Xam0KDgp7n/AVMsaqSQAPoMVWWdPtLEyLggDO73b/63+PrZSRHJCurHrgEGgB1FFFABRRRQAUUUUAf/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09CK13FN4U/____________________________2025-08-28_17.39.37.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F09CK13FN4U-99f8eeaec0", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1756370657.789809] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
9月10日に船便で着予定です。
よろしくお願いします！
ーーーーーー
8/8受信
Good day,the production of PURE matcha bags has been completed, totaling 45,500. can we send them to you by sea?expected delivery on September 10.
ーーーーーー

## 2025-09-01

- [1756788858.879439] <@U09DF1SDTQR>: <@U09DF1SDTQR>さんがチャンネルに参加しました

## 2025-09-11

- [1757577651.185079] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
:flag-ch:Matchaland_Sebastyan様から注文ですが、
　出荷予定日によってどのinvoiceに結合するか検討するとのこと。
&gt; 60bag x 1kg bags of B2 matcha
この商品の出荷可能日を教えてもらえますか？
- [1757599844.950219] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
袋はシルバーのスタンドバッグでラベルはこちらです！
  - files: [{"id": "F09ERKB6QAW", "created": 1757599816, "timestamp": 1757599816, "name": "Matcha Bag 1kg.pdf", "title": "Matcha Bag 1kg.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 35935, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09ERKB6QAW/matcha_bag_1kg.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09ERKB6QAW/download/matcha_bag_1kg.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09ERKB6QAW-d2d1264995/matcha_bag_1kg_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 238, "thumb_pdf_h": 368, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09ERKB6QAW/matcha_bag_1kg.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09ERKB6QAW-17035785fb", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-09-12

- [1757682300.928939] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
Pure matchaの袋が日本に届いたようです。
数日中に届くようです。（13ケース）
<https://track.seino.co.jp/cgi-bin/gnpquery.pgm>
追跡番号：0414825013
  - attachments: [{"from_url": "https://track.seino.co.jp/cgi-bin/gnpquery.pgm", "service_icon": "https://track.seino.co.jp/favicon.ico", "id": 1, "original_url": "https://track.seino.co.jp/cgi-bin/gnpquery.pgm", "fallback": "西濃運輸｜お届け状況確認", "text": "西濃運輸の公式ホームページ。 お届け状況確認では、お客様の商品の情報（位置や状況）を、ご確認いただけるサービスです。", "title": "西濃運輸｜お届け状況確認", "title_link": "https://track.seino.co.jp/cgi-bin/gnpquery.pgm", "service_name": "track.seino.co.jp"}]

## 2025-09-15

- [1758004290.934229] <@U033G4KN4TD>: <@U0331FWGQRM> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
 <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
出荷可能日：9月26日
よろしくお願いいたします。

## 2025-09-17

- [1758129053.689899] <@U0331FWGQRM>: <@U0331FZS7JT>
セバスチャンより、下記メッセージで、
調達的には問題なかったでしたっけ？？？
ーーーー
マンゴー、ラズベリーココナッツ、ストロベリーのフルーツフレーバーについて質問があります。
 法的またはマーケティング上の目的で、パウダーに実際の原料を0.1％加えることは可能でしょうか？
 例えば、0.1％のマンゴーパウダー、0.1％のラズベリー／ココナッツパウダー、0.1％のストロベリーパウダーです。
風味付けのためではなく、原材料欄に記載するためだけに加えるのです。
 また、0.1％というごくわずかな量であれば、パウダーに影響はありませんよね？
ーーーー
- [1758151442.860219] <@U0331FZS7JT>: <@U0331FWGQRM>
マンゴー、ラズベリーについては確認の必要がありますが、多分問題ないと思います。
早速確認の連絡をします:saluting_face:
- [1758151568.513559] <@U0331FWGQRM>: <@U0331FZS7JT> 
バニラも宜しくお願いします！
- [1758151581.631869] <@U0331FZS7JT>: <@U0331FWGQRM>
了解です！

## 2025-09-23

- [1758676555.044459] <@U033G4KN4TD>: <@U0331FWGQRM> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本件、進展はございますでしょうか？
 <@U041RJKV5JA> 小分けの指示書をお願いいたします。
今週小分け作業予定です。
- [1758697115.709159] <@U08L89G6JSG>: <@U0331FWGQRM>
Pure matchaの袋13ケース
入荷確認しました:raised_hands:

## 2025-09-24

- [1758734928.528409] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
こちら、MTL-016-25に含めることになりました！
スレッドに追記しますのでそちらを確認願います。
- [1758736112.649639] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> cc <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
セバスチャンと共有しているスプレッドシートです。
注文内容や、支払い、資材の残りの記録を共有するものです。
<https://docs.google.com/spreadsheets/d/1sZCSfcIeMJfzuNXdkB0buBA-Y5Zc1yuZ6dp-w5WHjDk/edit?usp=sharing>

M列に残りの資材を追記するようにお願いできますか？
- [1758736218.496749] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
私がスレッドを立てていない、
セバスチャンの注文予定の内容も、セバスチャンが追記して行っております。
（例えば019,020,021など）
ご確認ください。
- [1758736489.432379] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
<連絡>
今後はsachetの注文は単品ではなくなり、
（例えば、chai 10000本みたいな注文ではなく、）

7種類※で１セットのOPP袋での注文になるとのこと。
（※Pure, vanilla, strawberry, chai, cinnamon, coconut, mango）

（雑な連絡ですみませんが取り急ぎ）

## 2025-09-30

- [1759247745.914179] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
invoice未作成なのですが、
TSE-MTL-021-25の注文が12月15日出荷希望であります。
Sachet OPP袋 20000袋の注文があるので、
静パックのスケジュールを押さえておいていただけますか？
（11月中旬から末頃製造ですかね？）
宜しくお願いします。

※種類は017と同じ7種類の予定です

## 2025-10-15

- [1760537310.725299] <@U0331FWGQRM>: <@U0331FZS7JT>
この件、どんな感じでしょうか？
フォローアップしてくれときました:raised_hands:
- [1760543908.974559] <@U0331FZS7JT>: <@U0331FWGQRM>
すみません、連絡遅くなりました:pray::sweat_drops:
全て対応可能です！
届いたサンプルを確認したところ、パウダーへの影響も無いです！

