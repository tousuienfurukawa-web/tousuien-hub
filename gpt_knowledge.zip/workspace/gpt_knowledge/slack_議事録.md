# Slack channel: 議事録

## 2022-07-04

- [1656927676.080839] <@U0331FWGQRM>: <@U0331FWGQRM>さんがチャンネルに参加しました
- [1656927678.879319] <@U0331FZS7JT>: <@U0331FZS7JT>さんがチャンネルに参加しました
- [1656927678.939729] <@U0331FZTHEK>: <@U0331FZTHEK>さんがチャンネルに参加しました
- [1656927679.014749] <@U033G4KN4TD>: <@U033G4KN4TD>さんがチャンネルに参加しました
- [1656927679.064009] <@U03BLQ65GK0>: <@U03BLQ65GK0>さんがチャンネルに参加しました
- [1656927685.301599] <@U0331FWGQRM>: 2022.07.04 MTG

＜片寄さん＞

山内さんの穴埋め

受注処理
荷受け
電話対応
初めてのお客様の対応が難しかった。

―――
＜魯さん＞
Alibaba
HPの画像を統一したい
RFQ
カテゴリ分けした

Indonesia（andres）
サンプル発送済み（7/4）
粉末：抹茶、ほうじ茶、玄米茶
EMS

Canada
サンプルは未発送
フルーツ抹茶
3%, 5%
出雲抹茶H
有機抹茶1C
※MOQ：20kgチェリー、スイカ、マンゴー
	MOQ：200cans（40g）
※MOQ：100kgレモン、ストロベリー（1kg）
	MOQ ：1000cans（40g）

Teavoya
5g stick
デザイン待ち

海外HP翻訳

―――
＜松井＞
自社商品作成
・製菓用として100g用抹茶がいい？
・スティックサンプルがいい？
名刺
・皆さんの分を新デザインで作成
タイ出張
・現地での営業方法を確立
―――
＜社長＞
カンボジア イオンopen 2023秋頃
サウジアラビア

## 2022-08-07

- [1659922187.595809] <@U03SGRNND5L>: <@U03SGRNND5L>さんがチャンネルに参加しました

## 2022-09-11

- [1662964610.393239] <@U041RJKV5JA>: <@U041RJKV5JA>さんがチャンネルに参加しました

## 2023-02-05

- [1675645597.107409] <@U03SGRNND5L>: <@U0331FZS7JT>社長
 <!channel>
前回の海外ミーティングの議事録です。
宜しくお願い致します。

〈片寄さん〉
・月単月と2-12月累計の収支報告。
・海外全受注案件の受注・売上・回収処理の報告。
・EU圏内への輸出の際のEPA適用方法

〈魯さん〉
・チリへの輸出とEPAの適用について。　
 ・アメリカのお客様への提案商品のリスト化。

〈平川部長〉
・冊子、カタログ見積り。
・残留農薬分析・重金属分析・放射能検査の準備。
・各段ボールに何が何個入るのか　商品重量はどれくらいかをリスト化。
・これまで使ったＨＳコードのまとめ。

〈松井執行役〉
・受注関係…継続商談。
	アメリカ（Neels様, Marcus Fisher様）
サウジアラビア（NQ様）
・Alibabaライブ配信予定。
・invoice, packing list を海外事業部メンバーで作成できるようにする。

〈岡社長〉
・チリ, イギリスの新規見込み客への引き続き、アプローチしていく。
・フィリピンの出荷が予定通りできなかった。（担当：尾林）
　→　片寄さんより入金時、担当者に出荷日等の確認をする。
 タイムツリー
・invoice, packing listの修正を担当者が行う
　→修正箇所を報告する。
- [1675648489.217509] <@U0331FZS7JT>: 追記
インボイス・パッキングリスト用のサインは
エクセルにまとめて誰でも使えるようにする。
海外→管理→サイン・署名→各者サイン（エクセル）

メンションは全員なので、私の個別メンションは不要です。
よろしくお願いします。
- [1675648667.110479] <@U0331FZS7JT>: <@U041RJKV5JA> 部長

議事録を元に
何ができて何ができていないか、の
進捗管理をお願いします。
それを次の会議の際に、担当者と話し
どうなっているか、いつまでにできるかも含め
報告をお願いします。
- [1675648737.433239] <@U03SGRNND5L>: <@U0331FZS7JT> 社長

追記、ありがとうございます。

メンションのこともよくわかっておらず
申し訳ございませんでした。
- [1675649929.520219] <@U0331FZS7JT>: <@U03SGRNND5L> さん
※怒ってるとか、叱っているとかではなくて
私の感想です。

議事録含めですが・・・
誰にとって必要な情報で、
誰に何をしたら作業や業務が円滑に進むかを
考えながら業務に当たった方が良いと思います。
よく分かってないなら調べるなり聞くなりされたらいかがでしょうか。
それが無くて、会議の際に質問や議題が無い、というのはちょっと違うかなと思います。
チームなので助け合ったり、高め合う必要はあると思います。
周囲のテンションを下げさせないのも大事なポイントでは無いでしょうか。

今やっていただいているインボイスやパッキングリスト、原産地証明の取得、発送業務は手続きが分かれば極論、誰でもできます。作業なので。
一旦私の社長という肩書きを無視して言わせていただくと
ポイントは何をこれまでと変えて、結果どう良くなるかを考えながらやっていただけると助かります。
これまでの知見もおありでしょうから、うまく取り込み共有していただけると助かります。

<@U041RJKV5JA> 部長
サポートをお願いします。
尾林さんが議事録を作成されていたのは、あの場で私が指示していたのでご存知のはずですので。
会議やっただけ、では意味がないと思うのですがいかがでしょうか。
仮に指示を出して、共有ファイルに議事録入れただけでは、誰も存在は分かりません。
入れてもその情報の共有をお願いします。
※今後はスラックでの共有をお願いします。
多分、こういう細かいことを１つずつしっかりやらないと５億は届かないと思います。

以上、よろしくお願いします。

## 2023-02-07

- [1675813765.061999] <@U03SGRNND5L>: <!channel>
お疲れ様です。
2/6（月）の海外ミーティングの議事録です。
宜しくお願い致します。

■海外ミーティング議事録（2/6　16：00～）
【参加者】
	社長 　　　岡　祐太
	執行役 　　松井　幸史朗
	営業部長　平川　雅志
　　　　　　　 片寄　光信
	　　　　　魯杰
 　　　　　　　尾林　宗由

〈片寄さん〉
・1月単月と年間（2-1月）累計収支報告
　 1月単月：事業損益　281千円
　　 収入計 1,046千円
　　 支出計 765千円
 　　件数 16件
・年間（2-1月）
 　　事業損益　▲1,460千円
　　 収入計 7,872千円
 　　支出計 9,332千円
 　　件数 139件　内訳：Groene Company 42件　59,655千円
　　　　　　　　　　 ：それ以外    97件　6,882千円

　・今後は補助金の申請を松井執行役がしていたが、今後は海外事業部でする。

〈魯さん〉
　・アメリカのお客様のサンプル依頼中。
　・アリババのRFQの運用方法を平川部長、尾林と共有。
　・台湾の恩実様から連絡をくる予定。（サンプル発送済）
　・台湾・錦茂行様へのサンプル（みかん茶）は感触良い。　
　　 5月に来日予定　
　 松井執行役のお客様（アメリカ）も来日予定（出雲か鹿児島を訪問希望）。

〈尾林〉
　・3件の出荷（国内2件、海外1件）。
　・魯さんからアリババ・RFQの運用方法を共有。
 　　今週から平川部長と魯さん、尾林の3人で日替わりでRFQに提案していく。
　・スウェーデン、大野様のエクセルデータのインボイスを消してしまった。
 　　　原因に追究し、今後は起こさない。
 　　　原因の可能性：他のフォルダに移動していないか？
 　　　　　　　　　　ごみ箱にないか？　⇒　無。
 　　　対策 ：エクセルのインボイスをコピーし、作業する。
　・國次郎の店頭対応を3件
 　　　バーコードが無いものがあり、お会計に手間取ることがあった。
 　　　バーコードがついていない（つけれない）商品のバーコードリストの作成。
　・海外のお客様で、国内発送する場合、インボイスは箱に貼り付ける。
　
〈平川部長〉
　・出荷用の各段ボールに20g～1kg袋がいくつ入るのかを引き続き、調べる。
　・これまで使ったHSコードのまとめ。
　・アリババ RFQの運用を魯さんと共有（2週間で20件の提案を目標に当番制でする）
　・松井執行役から引き継いだ香港のお客様（モデル事務所）は
	　サンプル準備はできており、入金待ちの状況
	　
〈松井執行役〉
・Alibabaの運用について（見るポイント、進め方）
	RFQ…「green tea」,「matcha」をキーワードに検索。
	Last 7Days　で条件を絞ったりする。
	サウジアラビアのお客様は最近登録の方が多い？
	⇒経験が浅いので購入に繋がりにくい？
	サウジアラビアでは国全体が新しいものを取り入れようと
	しているという話もあるので、とにかくアプローチしよう。
 ・Gmailの運用について（誰の名前でするのか）
	松井執行役の名前で統一して返信する。
	誰が対応しているのか関係なく、週末や深夜に気づいた人が早く返信するようにする。
 ・invoiceのケースに同梱するか箱に貼り付けるかについて（ケーススタディ：Nadhaya様）
　　箱に貼り付ける　で統一

〈岡社長〉
・議事録はスラックにあげて共有。
・各担当者の進捗状況を平川部長が確認する。

## 2023-02-09

- [1675945298.888139] <@U0331FWGQRM>: ※念の為にコメントしておきますが、

RFQ…「green tea」,「matcha」をキーワードに検索。

については、上記２つのキーワードに限定する必要はありません。私がそうしていただけで、
言いたかったのは、検索条件を記憶させる機能がありますよ、と言いたかっただけです。
毎回毎回RFQを検索するたびに条件を打ち直す必要はないですよ、という意味です。

## 2023-02-16

- [1676541177.853119] <@U03SGRNND5L>: <!channel>
お疲れ様です。
2/14（火）の海外ミーティングの議事録です。
宜しくお願い致します。

■海外ミーティング議事録（2/14　16：00～）
【参加者】
	社長 岡　祐太
	執行役 松井　幸史朗
	営業部長　平川　雅志
　　　　　　　 片寄　光信
　　　　　　　 尾林　宗由

〈片寄さん〉
・海外案件の受注処理等の対応。
・海外案件の経費支出は【海外営業】フォルダ→【海外営業部収支】→【支出関係】→【2023】の各項目に各自で入れる。

〈尾林〉
・海外案件　出荷1件　準備中4件。　 
・RFQ　3件　内1件…見積送信済　
　＊RFQのお客様へは
	はやく返信する。
　　 桃翠園のロゴデータを使って返信する。
　　 Eメールアドレスがわかれば、メールする。
 　　やるべき国を考えてアプローチする。（平川部長と相談する。）
・國次郎の商品にバーコードがついてない時の対応⇒バーコード一覧表作成（ﾗﾐﾈｰﾄ加工）

〈平川部長〉
・出荷用の各段ボールに20g～1kgがいくつ入るか調べる
・缶や段ボールの仕入先がわかるようにする。
・新しくできる段ボールの規格書を調べる。
・RFQ…香港、フランス、ベナン（アフリカ）のお客様に対応中。
　　RFQは曜日担当に限らず、誰でもとにかく提案する。
　    RFQで、提案したお客様を【営業進捗管理表】にて管理
・残留農薬検査等の準備
・魯さんのアリババレクチャー　2/16（木）15：00～

〈松井執行役〉
・お客様へのレスポンスをはやくする為に
 抹茶や缶の写真、データを色、グレード別につくる。（スケジュール化）
	原価の記載。
	パワポ等で雛形を作る。
	画像に関しては、同条件で撮影が必要→プロに撮ってもらうのもあり。
・写真データの拡張子をJPGにする。
 ・Neels 様メモ　サンプル進捗確認…来週にはサンプルを発送する予定
 Neels 様は発送先と請求先の住所が異なる。
	アリババから仕入れた品を明日（2/15）営業会議前に共有
	仕入先をアイテム別、国別で整理できると良い

 〈海外チームで行う〉
・日々の業務でのフォルダの見直し…会議で見直し報告。
 【海外営業】→【管理（送料・資材・その他）】→【仕入】フォルダを没にした。

## 2023-02-21

- [1677043590.620479] <@U03SGRNND5L>: <!channel>
お疲れ様です。
2/21（火）の海外ミーティングの議事録です。
宜しくお願い致します。

■海外ミーティング議事録（2/21　16：00～）
【参加者】
	社長 　　　岡　祐太
	執行役　　 松井　幸史朗
	営業部長　平川　雅志
　　　　　　　 片寄　光信
	　　　　　 魯杰
　　　　　　　 尾林　宗由

〈片寄さん〉
・2月売上報告　1,162千円（2/21現在）
・支払い期限条件内の未入金あり
・貿易証明　商工会議所へ提出（2年更新）

〈魯さん〉
・RFQの見積り、問合せ対応（アリババ9件、全て返事待ち）
・台湾のお客様へサンプル発送　⇒　フィードバック待ち
・詐欺的な案件かも？ ⇒ 岡社長,平川部長に相談　

〈尾林〉
・海外案件　出荷5件　準備中2件　
 ・RFQ　1件サンプル希望　入金待ち
・HSコードの確認

〈平川部長〉
・各種検体の手配
・ケースの入り数・HSコード確認 ⇒　ほぼ完成
	●【海外営業】→【管理（送料・資材・その他）】→●ダンボール入り数
	●【海外営業】→【管理（送料・資材・その他）】→●HSコード　
	
〈松井執行役〉
・出荷時のミス予防策　
	請求用INVOICE No, ⇒　赤文字
	発送用INVOICE No, ⇒  黒文字
・全員がランダムにRFQやる意図を再確認 ⇒ 当番制に戻す
・情報伝達のタイミング
　　 送信予約やスタンプの利用

〈岡社長〉
・イギリス、ドイツへ700kg(年間)決まりそう
　　 理由：取引先を変えようと考えている。
　　 （現状の取引先から入荷無（5月から））
・ライブストリームをする。（2/23（金）、/24（土）） 30～60分の予定

＊次の海外ミーティングからグーグルのスプレッドシートで議事録作成

## 2023-07-31

- [1690796789.415309] <@U05KGS6HN9H>: <@U05KGS6HN9H>さんがチャンネルに参加しました

## 2023-08-28

- [1693290782.945699] <@U0331FZS7JT>: <@U0331FWGQRM>

さっきはありがとう！
議事録！

<https://youtu.be/WStPeWa3Fgk>
グロービッツ（種々アメリカ対応会社）<https://globizz.net>
MTG議事録

①食品の規制対応(FDA施設登録（査察対応やアドバイス含む）・PNC)-USD 1,400/2年
　L自社小売の時にお願いするのが良さそう
②USA会社設立代行（USD4,000/登記費用別途）
　Lこの先あるかも
　L LA場所貸しの場合：USD300-500/月
③アメリカ進出のコンサル
・スーパーなどの実店舗への販路開拓
    EX）USD1,000/月でディストリビューターなどを探す（メーカーがプレゼン資料作成）
　　　　Lプロジェクトを決めてそれに則って動くイメージ
・展示会出展代行
・現地での電話対応（代行）

・EC販売支援
　　Lグロービッツで対応が可能(SEO・マーケティングなど)
倉庫借りるなど、自社で対応不可能なものはグロービッツ紹介してくれる

その他：最近日本の工場監査多い
　　　　L物量・金額の多寡に関わらずランダムで選ばれる

PDFパスワード：globizz
  - attachments: [{"from_url": "https://youtu.be/WStPeWa3Fgk", "service_icon": "https://a.slack-edge.com/80588/img/unfurl_icons/youtube.png", "thumb_url": "https://i.ytimg.com/vi/WStPeWa3Fgk/hqdefault.jpg", "thumb_width": 480, "thumb_height": 360, "video_html": "<iframe width=\"400\" height=\"225\" src=\"https://www.youtube.com/embed/WStPeWa3Fgk?feature=oembed&autoplay=1&iv_load_policy=3\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" allowfullscreen title=\"グロービッツMTG   SD 480p\"></iframe>", "video_html_width": 400, "video_html_height": 225, "id": 1, "original_url": "https://youtu.be/WStPeWa3Fgk", "fallback": "YouTube Video: グロービッツMTG   SD 480p", "title": "グロービッツMTG   SD 480p", "title_link": "https://youtu.be/WStPeWa3Fgk", "author_name": "岡祐太", "author_link": "https://www.youtube.com/@user-to3ef4be4l", "service_name": "YouTube", "service_url": "https://www.youtube.com/"}, {"from_url": "https://globizz.net/", "service_icon": "https://globizz.net/favicon.ico", "id": 2, "original_url": "https://globizz.net", "fallback": "FDA申請、米国進出のコンサルタント GLOBIZZ", "text": "FDA申請代行、FDA 510(k)コンサルティング、米国EPA、プロポジション65対応、米国市場調査・米国進出のお手伝い、経営・販売戦略など、ロサンゼルスより日本人スタッフが対応。結果にこだわり他に類のない高いレベルのサービスを提供致します。", "title": "FDA申請、米国進出のコンサルタント GLOBIZZ", "title_link": "https://globizz.net/", "service_name": "globizz.net"}]
  - files: [{"id": "F05QBKJ0ERX", "created": 1693290751, "timestamp": 1693290751, "name": "食品_グロービッツ会社案内_2023.pdf", "title": "食品_グロービッツ会社案内_2023.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 2210658, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05QBKJ0ERX/____________________________________________2023.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05QBKJ0ERX/download/____________________________________________2023.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05QBKJ0ERX/____________________________________________2023.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F05QBKJ0ERX-3b1db2ac44", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-10-06

- [1696616195.019049] <@U0606SPN4BW>: <@U0606SPN4BW>さんがチャンネルに参加しました

## 2023-11-21

- [1700559311.506169] <@U066P20UQH1>: <@U066P20UQH1>さんがチャンネルに参加しました

## 2024-01-04

- [1704433611.625359] <@U0331FWGQRM>: <!channel>
1/9 mtg 10:00-
昨年末のmtgについて、延期していただきありがとうございました。
もし何か議題があれば事前にスレッドにて共有よろしくお願いします。
- [1704433885.996539] <@U0331FWGQRM>: ・来年度目標について（問題・課題）

・検査名について
先日の検査結果（重金属、菌検査）の
資料名について、IZUMOCHAにしている理由は何かありますか？

・フォルダ管理について、
桃翠園共有フォルダの中の検査結果を桃翠園のベース資料として、
そこから、各フォルダへコピペする。という形がいいかと思います。
資料の検査結果の整理
ファイル名の付け方
について相談したい。

・有機の取り扱いについて（Ossu teaなど）
進捗あれば共有してほしい。

・缶の巻締機の購入について。
Xtime_Ray
・缶の底蓋について
Hongxu Packaging_Erato

・Genuine
白印字対応について。キーエンス？中国？

## 2024-01-08

- [1704764649.198629] <@U0331FWGQRM>: <@U0331FZS7JT>
ミーティングURLってTimetreeのやつで合ってます？

## 2024-03-15

- [1710516550.422239] <@U0331FWGQRM>: <@U041RJKV5JA>
次回営業会議いつでしたっけ？

## 2024-03-17

- [1710717851.064469] <@U041RJKV5JA>: 4月15日（月）15時からになります。
よろしくお願いします。

## 2024-05-23

- [1716530707.174329] <@U0331FWGQRM>: <@U0331FZS7JT> <@U03BLQ65GK0>
本日15:20
MTG URL
<https://meet.google.com/itv-xafx-vbw>
  - attachments: [{"from_url": "https://meet.google.com/itv-xafx-vbw", "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "id": 1, "original_url": "https://meet.google.com/itv-xafx-vbw", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/itv-xafx-vbw", "service_name": "meet.google.com"}]

## 2024-05-24

- [1716536324.427679] <@U0331FZS7JT>: <@U0331FWGQRM> <@U03BLQ65GK0>
福井さん会長がいない状態だと現場回らない
　L機械をパートさんに使えるようにする
　L1人が複数の仕事をする（専門性を付き詰めるよりも、他の人もできる様にする）
　L今のうちにローテーションする？
　L１人増やす（タイミングはセバスチャンまたは大きな売上が継続的に見えた際に募集開始）
　L調達・商品開発
　LCOA（などの書類）
　L購買部署
　L社内の情報（書類等）をまとめる/松井
----------------
　
COA：ロット毎検査
L毎回：水分・菌・官能
L桃翠園水分値計測機購入

ほうじ場：ゆくゆく出雲精茶に移動する
  Lプレハブ→同じ広さ必要？➡︎高さ不要
↓
*セミオート機械を4台買って茶詰め場に置く（仕切る）*
　L中国出張（松井・祐太・大樹・足立・福井・林）
       ６or 7月

補助金進める/６月
- [1716546497.679369] <@U0331FZS7JT>: <@U0331FWGQRM> <@U03BLQ65GK0>
5/24 水分値計購入
5/24 家庭用ミル（水分値計用）購入

## 2024-08-02

- [1722585203.880829] <@U0331FWGQRM>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
*8/7 13:00 JONA　仲様*
*MTG時に質問する内容メモ*

## 2024-08-06

- [1722993790.382079] <@U03BLQ65GK0>: メモ
・外国格付表事業者の運用ルールの確認（外国格付のJASマーク本当に不要？外国の有機マークも不要？＝認証マークは貼らなくても出荷できるの？）
・JONAで外国の認証取得ができる→取得した場合の運用ルールの確認と同等性利用しての輸出時との違い（運用の行いやすさ＝海外認証を運用した場合のデメリットは何？）

## 2024-10-09

- [1728538820.870729] <@U0331FWGQRM>: <@U0331FZS7JT> <@U03BLQ65GK0> <@U041RJKV5JA> <@U033G4KN4TD>
明日（10/11）14:00-の営業会議ですが、
直前のMTGが万が一伸びた場合は
15:00開始に変更させてください。
- [1728538869.763869] <@U0331FWGQRM>: メモ
・茶詰場の人員管理について。

## 2024-10-16

- [1729127666.651429] <@U0331FWGQRM>: <@U0331FZTHEK> <@U0331FZS7JT>
<https://meet.google.com/efz-prxm-dhn>
  - attachments: [{"from_url": "https://meet.google.com/efz-prxm-dhn", "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "id": 1, "original_url": "https://meet.google.com/efz-prxm-dhn", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/efz-prxm-dhn", "service_name": "meet.google.com"}]

## 2024-12-01

- [1733104651.061839] <@U082RF7UF1V>: <@U082RF7UF1V>さんがチャンネルに参加しました

## 2024-12-05

- [1733469344.336979] <@U0840UVFVA8>: <@U0840UVFVA8>さんがチャンネルに参加しました

## 2025-03-03

- [1741050946.936919] <@U08FZUNPSQ3>: <@U08FZUNPSQ3>さんがチャンネルに参加しました

## 2025-03-31

- [1743469444.787719] <@U08L89G6JSG>: <@U08L89G6JSG>さんがチャンネルに参加しました

## 2025-04-13

- [1744592905.343949] <@U08N3SKSL75>: <@U08N3SKSL75>さんがチャンネルに参加しました

## 2025-04-20

- [1745195461.043909] <@U08NVD403GV>: <@U08NVD403GV>さんがチャンネルに参加しました

## 2025-05-06

- [1746589948.773529] <@U08RVRNBY00>: <@U08RVRNBY00>さんがチャンネルに参加しました

## 2025-05-14

- [1747255333.181269] <@U0331FWGQRM>: 
  - files: [{"id": "F081HR2G0TA", "created": 1731579847, "timestamp": 1731579847, "name": "無題", "title": "無題", "mimetype": "application/vnd.slack-docs", "filetype": "quip", "pretty_type": "Canvas", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": true, "size": 0, "mode": "quip", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F081HR2G0TA/canvas?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F081HR2G0TA/download/canvas?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "permalink": "https://grp-ssm9297.slack.com/docs/T033D70RR6H/F081HR2G0TA", "permalink_public": "https://slack-files.com/T033D70RR6H-F081HR2G0TA-39a4bf61bc", "url_static_preview": "https://grp-ssm9297.slack.com/docs/T033D70RR6H/F081HR2G0TA/mobile", "quip_thread_id": "QIJ9AAjBGnQ", "update_notification": null, "is_starred": false, "skipped_shares": true, "teams_shared_with": [], "is_restricted_sharing_enabled": true, "has_rich_preview": false, "file_access": "visible", "access": "owner", "org_or_workspace_access": "none", "canvas_creator_id": "U0331FZS7JT", "team_pref_version_history_enabled": true, "canvas_printing_enabled": true, "is_ai_suggested": false}]

## 2025-05-28

- [1748485110.714339] <@U08U8MMTH43>: <@U08U8MMTH43>さんがチャンネルに参加しました

## 2025-06-02

- [1748914893.618129] <@U08V56G9U92>: <@U08V56G9U92>さんがチャンネルに参加しました

## 2025-07-13

- [1752475114.867009] <@U095LLEH09G>: <@U095LLEH09G>さんがチャンネルに参加しました

## 2025-09-01

- [1756788858.822489] <@U09DF1SDTQR>: <@U09DF1SDTQR>さんがチャンネルに参加しました

