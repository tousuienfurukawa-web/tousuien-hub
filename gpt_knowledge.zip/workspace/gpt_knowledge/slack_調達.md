# Slack channel: 調達

## 2025-01-19

- [1737357872.824519] <@U0331FZS7JT>: <@U0331FZS7JT>さんがチャンネルに参加しました
- [1737358053.507379] <@U03BLQ65GK0>: <@U03BLQ65GK0>さんがチャンネルに参加しました
- [1737358053.600229] <@U0331FWGQRM>: <@U0331FWGQRM>さんがチャンネルに参加しました
- [1737358053.678709] <@U041RJKV5JA>: <@U041RJKV5JA>さんがチャンネルに参加しました
- [1737358053.751629] <@U05KGS6HN9H>: <@U05KGS6HN9H>さんがチャンネルに参加しました
- [1737358053.822859] <@U066P20UQH1>: <@U066P20UQH1>さんがチャンネルに参加しました
- [1737358053.896329] <@U0840UVFVA8>: <@U0840UVFVA8>さんがチャンネルに参加しました
- [1737358053.978489] <@U0331FZTHEK>: <@U0331FZTHEK>さんがチャンネルに参加しました
- [1737358054.050119] <@U033G4KN4TD>: <@U033G4KN4TD>さんがチャンネルに参加しました
- [1737358054.122039] <@U0606SPN4BW>: <@U0606SPN4BW>さんがチャンネルに参加しました
- [1737358054.194229] <@U082RF7UF1V>: <@U082RF7UF1V>さんがチャンネルに参加しました
- [1737358094.425359] <@U0331FZS7JT>: 2025. 1.20 MTG メモ
毎月通常何kg頼むか→過去の内容読み込む
・主要なお客様の製品の数字出し
・毎月ごとの実績
・＋αを発注できるように

お客の上位20%分
３、４ヶ月（12,1,2,3月）分の量を購入しておく
　Lキャッシュとの相談
→上記以外の月は毎月ごとで定量を発注
※上記の定量の数量は貯蔵分も確保する
※碾茶で購入できるものがあれば、抹茶と半々の割合で購入・在庫

よく動く高い抹茶について先んじて在庫を確保する

▼次回MTG
~2025.1/29 15時〜~
執行役が出社したタイミングでスケジュール決めて行う。

## 2025-01-20

- [1737360933.358239] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <@U03BLQ65GK0> <@U0331FZTHEK> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
*中国製缶仕入れについて*
*（2025年1月発注分）*
- [1737361228.622659] <@U0331FWGQRM>: 60x60Hmm　：
Silver　現在庫560
White　現在庫379
Black　現在庫800

60x60Hmm　：
Silver　現在庫1000
White　現在庫1000
Black　現在庫1000
- [1737361238.866099] <@U0331FWGQRM>: ~注文数量~
~60x60Hmm　：~
~4000pcs white　*ship by AIR~
~3000pcs black　*ship by SEA~
~5000pcs silver　*ship by AIR~

~60x68Hmm　：~
~2000pcs white　*ship by SEA~
~1000pcs black　*ship by SEA~
~5000pcs silver　*ship by AIR~

## 2025-01-29

- [1738206665.697569] <@U0331FZS7JT>: 香岳園メモ(2024.1.30)
全般的に値上がりはするだろうが、今のところはまだ見えていない
手摘み抹茶の仕入れは今のところ例年通りの予定
希望がある場合はそれを伝えたらその分購入は可能

【品種】
さみどり：¥25,000
  L品質重視で手摘みでなくとも同じようなものが無いかは探してもらう

ごこう、あさひについてはあまり量は出回らないが、抑えることは可能
あさひは¥30,000以上

うじひかり・つゆひかり・さえみどりは碾茶で納品

きらり31：最大で200kgぐらいは抑えられそう（24年は50kgの購入）
さえみどり：最大で200kgぐらいは抑えられそう（24年は40kgの購入）
つゆひかり：最大で700kgぐらいは抑えられそう（24年は120kgの購入）
うじひかり：未定(24年は90kgの購入)


その他
おくみどり(K9000)や、やぶきた（K6000）は例年になく今年は多く仕入れる予定で動いている
→おくみどり4tぐらいは桃翠園への提案可能

ダイナミック・ミルを導入
１時間10kgの生産能力
高額な抹茶も石臼並に綺麗に粉砕することができる
２台据付を行った

緒方さんの先の予定
2028年（3年後）の半ば(65歳)までは香岳園に勤める（調達・営業）
65歳以降は仕入れのみを行い、営業は小林さんという37歳の方に変わる

## 2025-02-06

- [1738853690.710879] <@U08BA1AGC0H>: <@U08BA1AGC0H>さんがチャンネルに参加しました
- [1738892624.657159] <@U0331FZS7JT>: <!channel>
*【香岳園：宇治抹茶K12000（つゆひかり）の代替品】*
*茗広茶業：宇治抹茶おくみどり/価格：¥11,000/kg*
*※香岳園：K9000おくみどり（香岳園在庫切）の上位品（宇治抹茶おくみどり単一品種）としても提案可能です。*
代替品としてOK：Nadhaya様（タイ）
代替品としてOKか確認していただく：Tachu様
10kg（1kg×10袋）が本日在庫分として届きます。
5月頭まで50kgを調達し順次使用していく予定。
さらに増やせそうな場合は別途営業チームに共有します。
※多分大丈夫そう（３月中に100kgの在庫確保を見込む）
〈画像〉
１枚目： 左：つゆひかり 右：茗広おくみどり
２枚目： 左：K9000おく 右：茗広おくみどり
  - files: [{"id": "F08C09R2YES", "created": 1738890518, "timestamp": 1738890518, "name": "IMG_4118.JPG", "title": "IMG_4118.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 231194, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08C09R2YES/img_4118.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08C09R2YES/download/img_4118.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08C09R2YES-33ffef4916/img_4118_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08C09R2YES-33ffef4916/img_4118_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08C09R2YES-33ffef4916/img_4118_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08C09R2YES-33ffef4916/img_4118_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08C09R2YES-33ffef4916/img_4118_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08C09R2YES-33ffef4916/img_4118_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08C09R2YES-33ffef4916/img_4118_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08C09R2YES-33ffef4916/img_4118_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08C09R2YES-33ffef4916/img_4118_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1477, "original_h": 1108, "thumb_tiny": "AwAkADCmVx1peCMVfltCy8YFQLbKn3359qAKuKVRk1Ymg2jcOV9RUccLPlhgKO5pAKFzTxGakjh7hgasCFsUAMikLws3XFQbs9aLaYKSrcBqka3bPyEY96UrgJAdzlD91gc1HLw+wfdTgU6VltY2+YGVhgAdqbFi5QFSPMAwwPf3pWdgERyjAirkzGNMg4B4qCO2beC+MDt6028nV2Eanocn604gVSeKb5jgYDsB7GnN0qI1QCHnk0gJByCQfUUppKAJTPKy4MjEfWmUlFAH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08C09R2YES/img_4118.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08C09R2YES-7a310959f7", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08C0CQ4UJ2", "created": 1738892347, "timestamp": 1738892347, "name": "IMG_4127.JPG", "title": "IMG_4127.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 247249, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08C0CQ4UJ2/img_4127.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08C0CQ4UJ2/download/img_4127.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08C0CQ4UJ2-d6f45ab3b1/img_4127_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08C0CQ4UJ2-d6f45ab3b1/img_4127_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08C0CQ4UJ2-d6f45ab3b1/img_4127_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 212, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08C0CQ4UJ2-d6f45ab3b1/img_4127_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 283, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08C0CQ4UJ2-d6f45ab3b1/img_4127_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08C0CQ4UJ2-d6f45ab3b1/img_4127_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 424, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08C0CQ4UJ2-d6f45ab3b1/img_4127_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 472, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08C0CQ4UJ2-d6f45ab3b1/img_4127_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 566, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08C0CQ4UJ2-d6f45ab3b1/img_4127_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 604, "original_w": 1666, "original_h": 982, "thumb_tiny": "AwAcADCJYixwtPMMa8NLz7CnxjbbFh1Y4zUOwGk2A5ocDcrBl9RSLEW5yAB1JpYflkA6q3BFEwKkRjov86VwFEMTcCbn6UySFojzyPUUm2rEP72FkbntQmAloyyRNCTg9VoaJlOCpqmCQcjrUn2+4UY3g/UUNXAsbRCplk4A6A9zTIz9ojDjl14Yf1qnLLJK2ZGLGmxyPG+5GKkdxT5dALwRicAGrBAtrdmb7x6D3qouoz7OQhPrioWmkmfMjZpKNgP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08C0CQ4UJ2/img_4127.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08C0CQ4UJ2-b47c386eab", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-02-14

- [1739542785.599589] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0331FZS7JT>
発注します！（230万）

## 2025-02-15

- [1739644191.708289] <@U0331FWGQRM>: <@U0331FZS7JT>
Nutty toneの抹茶はありましたでしょうか？？（Nadhayaから依頼があった、ナッツ風味の抹茶の件）

また、添付の八女抹茶（八女の露〜あじさいまで）について、
Nadhayaに改めて提案しても大丈夫でしょうか。
（過去にquotationを提出済みですが、
すでに供給不可、もしくは厳しいのものがあれば事前に教えていただけますと助かります。）
  - files: [{"id": "F08DVPXENGH", "created": 1739644183, "timestamp": 1739644183, "name": "スクリーンショット 2025-02-16 3.28.56.png", "title": "スクリーンショット 2025-02-16 3.28.56.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 193047, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08DVPXENGH/____________________________2025-02-16_3.28.56.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08DVPXENGH/download/____________________________2025-02-16_3.28.56.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08DVPXENGH-821c48bdcb/____________________________2025-02-16_3.28.56_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08DVPXENGH-821c48bdcb/____________________________2025-02-16_3.28.56_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08DVPXENGH-821c48bdcb/____________________________2025-02-16_3.28.56_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 197, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08DVPXENGH-821c48bdcb/____________________________2025-02-16_3.28.56_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 263, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08DVPXENGH-821c48bdcb/____________________________2025-02-16_3.28.56_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08DVPXENGH-821c48bdcb/____________________________2025-02-16_3.28.56_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 395, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08DVPXENGH-821c48bdcb/____________________________2025-02-16_3.28.56_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 439, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08DVPXENGH-821c48bdcb/____________________________2025-02-16_3.28.56_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 526, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08DVPXENGH-821c48bdcb/____________________________2025-02-16_3.28.56_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 561, "original_w": 1288, "original_h": 706, "thumb_tiny": "AwAaADC3tUk5jf8AOmyOsWDtkTP41ZHHamyIr4DqGxSsCtfUrC6QcEOfegXaf3WqfyIv+eYoFvFj/VrRqXeBAbteMBqcl0GYLg8nFS/Z4s/6taaIo1bIjAIPWpk2g90P3uT/AKz9KUFwed/TvipqY/aqsQGT60qk45plApgOJO4c0zJ34zS96TAqZK4H/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08DVPXENGH/____________________________2025-02-16_3.28.56.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F08DVPXENGH-b27c55845f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-02-16

- [1739767972.935679] <@U0331FZS7JT>: <@U0331FWGQRM>
CC：<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U03BLQ65GK0>
すみません、連絡遅くなりました:pray::sweat_drops:

*八女抹茶について*
八女の露：Tachu用に毎月9kg製造
→こちらTachuからの注文内容に応じてNadhaya様にご提案可能です！
八女の華〜あじさい：提案可能です

量的に少ないのは「八女の華」です。
八女の華：代替品在庫13kg＋毎月オリジナル2.5kgの供給数量（毎月5kg購入するが、八女の露 代替品製造に毎月2.5kg使用）
なので、５月末までの３ヶ月でトータル20kgあるので、他社との兼ね合いで月当たり4kgぐらいであれば対応可能かと！

八女の華 以下のグレード（もくれん、やまぶき、こでまり、あじさい）は代替品を各100kgを
3月7日〜順次製造しますので問題ないです！

*Nutty Toneの抹茶について*
「西尾の抹茶NA」がDRで対応可能です！
※味確認したのはNAのDRですが、品質的には八女抹茶の「やまぶき」でした:sweat_drops:
色はやまぶきよりかなり良いけど、旨味弱ッ（やまぶき代替品ぐらい）で、この下のNBとNCは碾茶購入してDRすることを考えると、ある程度品質が担保できてすぐに提案できそうなのはNAのDRかな、と思っています。
NA在庫：43kg(内DR済み20kg)
追加発注：50kg（メモ：3月納品）
5月末までトータル90kgぐらいは対応が可能です！
- [1739773624.613549] <@U066P20UQH1>: <@U0331FZS7JT>
:flag-th:のKIT様より、*うじひかりの単一品種を1.5kg*供給できないか、と問い合わせがありました。
うじひかりは2/17時点で7kg在庫があるとExcelで見かけましたが、これは供給可能な7kgでしょうか？:sweat_drops:
ご確認よろしくお願いいたします:woman-bowing:
- [1739776696.060389] <@U0331FZS7JT>: <@U066P20UQH1>
<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
供給不可でお願いします。（Tachu・Nadhaya用に残しています！）
今回1.5kg納品しても、もしすぐに次の希望があった場合に出せないなど、次の出荷までかなり時間が空くことも想定されるので
この方に限らず新規のお客様には５月末まで待っていただきますよう、宜しくお願いします:man-bowing:。

## 2025-02-17

- [1739829129.374529] <@U066P20UQH1>: <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
「真」茶筅の在庫状況について
*ノーマルの竹と黒竹の両方について在庫状況を共有いただけますか？*:woman-bowing:
:us:HAN様からどちらか1本を購入したいと依頼を受けております。
- [1739836721.653249] <@U0331FZS7JT>: <@U066P20UQH1> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
通常：３本
黒竹：10本
です！
宜しくお願いします。
※通常の少ないですが、提案してもらって問題ありません。
- [1739851292.245529] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
中国製の缶（白色）が赤っぽいという件について、他のサイズも全て赤っぽいんでしたっけ？？？:sweat_drops:

<https://grp-ssm9297.slack.com/archives/C05G1KRTDF1/p1737629373054009?thread_ts=1737539727.900899&amp;channel=C05G1KRTDF1&amp;message_ts=1737629373.054009|https://grp-ssm9297.slack.com/archives/C05G1KRTDF1/p1737629373054009?thread_ts=1737539727.900899&amp;channel=C05G1KRTDF1&amp;message_ts=1737629373.054009>
  - attachments: [{"from_url": "https://grp-ssm9297.slack.com/archives/C05G1KRTDF1/p1737629373054009?thread_ts=1737539727.900899&amp;channel=C05G1KRTDF1&amp;message_ts=1737629373.054009", "ts": "1737629373.054009", "author_id": "U0331FWGQRM", "channel_id": "C05G1KRTDF1", "channel_team": "T033D70RR6H", "is_msg_unfurl": true, "is_reply_unfurl": true, "message_blocks": [{"team": "T033D70RR6H", "channel": "C05G1KRTDF1", "ts": "1737629373.054009", "message": {"blocks": [{"type": "rich_text", "block_id": "Gb4lT", "elements": [{"type": "rich_text_section", "elements": [{"type": "user", "user_id": "U066P20UQH1"}, {"type": "text", "text": " cc "}, {"type": "user", "user_id": "U05KGS6HN9H"}, {"type": "text", "text": "\n40g缶（白）のサンプルについてですが、\n中国製の缶を送る予定です。\nただ、色が少しいつもと違います。\n（若干赤っぽい。。なんでやねん）\nとりあえず、サンプルなのでこれを送って、\n色については、本注文まで言及しない。\n次回の缶製造ロット（中国製）のものが間に合えばそれを使用する、でいいかと思います。（3月頭納品）\nまた相談させてください。取り急ぎ報告。"}, {"type": "text", "text": "\n\n※缶底の巻じめ部分が変なのはちゃんとしたやつを送るので大丈夫です！"}]}]}]}}], "files": [{"id": "F089Y1BM7CK", "created": 1737629211, "timestamp": 1737629211, "name": "IMG_7215.MOV", "title": "IMG_7215", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 2771903, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "complete", "locale": "en-US"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F089Y1BM7CK-ea42e385be/img_7215.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F089Y1BM7CK-ea42e385be/img_7215.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F089Y1BM7CK/download/img_7215.mov?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "vtt": "https://files.slack.com/files-tmb/T033D70RR6H-F089Y1BM7CK-ea42e385be/file.vtt?_xcb=36d7a&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F089Y1BM7CK-ea42e385be/file.m3u8?_xcb=36d7a&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTMxMjQzMSxBVkVSQUdFLUJBTkRXSURUSD0xMzEyNDMxLENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTgxMHgxMDgwLEZSQU1FLVJBVEU9MjkuOTcwLFNVQlRJVExFUz0ic3VicyIKZGF0YTphcHBsaWNhdGlvbi92bmQuYXBwbGUubXBlZ3VybDtiYXNlNjQsSTBWWVZFMHpWUW9qUlZoVUxWZ3RWa1ZTVTBsUFRqb3pDaU5GV0ZRdFdDMVVRVkpIUlZSRVZWSkJWRWxQVGpvM0NpTkZXRlF0V0MxTlJVUkpRUzFUUlZGVlJVNURSVG94Q2lORldGUXRXQzFRVEVGWlRFbFRWQzFVV1ZCRk9sWlBSQW9qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0T1ZreFFrMDNRMHN0WldFME1tVXpPRFZpWlM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNUzUwY3dvalJWaFVTVTVHT2pBdU1UTXpMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNE9Wa3hRazAzUTBzdFpXRTBNbVV6T0RWaVpTOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TWk1MGN3b2pSVmhVTFZndFJVNUVURWxUVkFvPQojRVhULVgtTUVESUE6VFlQRT1TVUJUSVRMRVMsR1JPVVAtSUQ9InN1YnMiLE5BTUU9IkVuZ2xpc2giLERFRkFVTFQ9WUVTLEFVVE9TRUxFQ1Q9WUVTLEZPUkNFRD1OTyxMQU5HVUFHRT0iZW5nIixVUkk9ImRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzJNREFLSTBWWVZDMVlMVTFGUkVsQkxWTkZVVlZGVGtORk9qRUtJMFZZVkMxWUxWQk1RVmxNU1ZOVUxWUlpVRVU2Vms5RUNpTkZXRlJKVGtZNk5pNHhNemtzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EZzVXVEZDVFRkRFN5MWxZVFF5WlRNNE5XSmxMMlpwYkdVdWRuUjBDaU5GV0ZRdFdDMUZUa1JNU1ZOVSIK", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F089Y1BM7CK-ea42e385be/img_7215_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 6139, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F089Y1BM7CK-ea42e385be/img_7215_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 960, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F089Y1BM7CK/img_7215.mov", "permalink_public": "https://slack-files.com/T033D70RR6H-F089Y1BM7CK-ecddcf070c", "comments_count": 0, "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08AAQEC5A5", "created": 1737629211, "timestamp": 1737629211, "name": "IMG_7212.jpg", "title": "IMG_7212", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 632658, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08AAQEC5A5/img_7212.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08AAQEC5A5/download/img_7212.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08AAQEC5A5-154d1b21d5/img_7212_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08AAQEC5A5-154d1b21d5/img_7212_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08AAQEC5A5-154d1b21d5/img_7212_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08AAQEC5A5-154d1b21d5/img_7212_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08AAQEC5A5-154d1b21d5/img_7212_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08AAQEC5A5-154d1b21d5/img_7212_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08AAQEC5A5-154d1b21d5/img_7212_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08AAQEC5A5-154d1b21d5/img_7212_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08AAQEC5A5-154d1b21d5/img_7212_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 4032, "original_h": 3024, "thumb_tiny": "AwAkADC01winuT2xUF426RQOwpm1Q42jJ9SangRZNzOoLA4pIbRnHOaaBngVpyxREY2L+AptkoCtgc7sZpiKJikUbtjAeuKFlYDBJxjFazE+tZMifvG+poAmiJ3ZzV23GE/GqaptOScVLGJGOVJUUrjaJpeCahszxJ7OaV4HYf6w596g+yzIco4/A4piLkh5NUXGXb60GG5zlsn8aArj7yt+VAE0fzS8+lW1GBVSL/XH6VbFSNjqKKSmIQ01qdTWoA//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08AAQEC5A5/img_7212.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08AAQEC5A5-241fad72dd", "comments_count": 0, "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}], "id": 1, "original_url": "https://grp-ssm9297.slack.com/archives/C05G1KRTDF1/p1737629373054009?thread_ts=1737539727.900899&amp;channel=C05G1KRTDF1&amp;message_ts=1737629373.054009", "fallback": "[January 23rd, 2025 2:49 AM] tousuien.matsui: <@U066P20UQH1> cc <@U05KGS6HN9H>\n40g缶（白）のサンプルについてですが、\n中国製の缶を送る予定です。\nただ、色が少しいつもと違います。\n（若干赤っぽい。。なんでやねん）\nとりあえず、サンプルなのでこれを送って、\n色については、本注文まで言及しない。\n次回の缶製造ロット（中国製）のものが間に合えばそれを使用する、でいいかと思います。（3月頭納品）\nまた相談させてください。取り急ぎ報告。\n\n※缶底の巻じめ部分が変なのはちゃんとしたやつを送るので大丈夫です！", "text": "<@U066P20UQH1> cc <@U05KGS6HN9H>\n40g缶（白）のサンプルについてですが、\n中国製の缶を送る予定です。\nただ、色が少しいつもと違います。\n（若干赤っぽい。。なんでやねん）\nとりあえず、サンプルなのでこれを送って、\n色については、本注文まで言及しない。\n次回の缶製造ロット（中国製）のものが間に合えばそれを使用する、でいいかと思います。（3月頭納品）\nまた相談させてください。取り急ぎ報告。\n\n※缶底の巻じめ部分が変なのはちゃんとしたやつを送るので大丈夫です！", "author_name": "matsui", "author_link": "https://grp-ssm9297.slack.com/team/U0331FWGQRM", "author_icon": "https://secure.gravatar.com/avatar/f9d05f2cae161f657bb1248fc85b5235.jpg?s=48&d=https%3A%2F%2Fa.slack-edge.com%2Fdf10d%2Fimg%2Favatars%2Fava_0008-48.png", "author_subname": "matsui", "mrkdwn_in": ["text"], "footer": "Slack の会話内のスレッド"}]
- [1739855227.236809] <@U066P20UQH1>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U0331FZS7JT>
黒竹1本:us:HAN様向けで確保をお願いします。
後ほど注文スレッド立てます。

## 2025-02-18

- [1739926402.081829] <@U0331FWGQRM>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
提案する茶筅の種類について
・80・100本立て→基本は100本立てを提案
・種類→ノーマルor真
・産地→中国 or 日本 or Korea

提案する商品一覧
~100本立て中国製：原価490円（USD3.25）~
100本立て韓国製：原価1430円
100本立て日本製：原価2300円
真（白）日本製：原価1700円
真（黒）日本製：原価2100円

ーメモー
・100本立ては韓国製と日本製がある。
・真は全て日本製
・韓国製と日本製の品質差は素人には分からない。
・中国製も仕入れ可能。だが品質は悪い。
- [1739930465.915199] <@U0331FWGQRM>: メモ
Cheng yee様（今度注文するかも）
100本立て日本製：原価2300円　10個/order

## 2025-02-26

- [1740586407.414739] <@U0331FWGQRM>: <@U0331FZS7JT>
静岡の抹茶って杉本以外からも仕入れられたりしますか？
有機or農薬対応したもの。
原料確保の観点で、静岡（と三重）の抹茶が少ないのかなーとか思いまして。

## 2025-03-01

- [1740823337.621049] <@U0331FWGQRM>: 出荷方法変更
*-First- (20days)　→3/12出荷、3/19頃に桃翠園着予定*
*60x60Hmm　：*
*2000pcs white　*ship by AIR*
*2000pcs silver　*ship by AIR*

-Second-(25days)
60x60Hmm　：
2000pcs white　*ship by AIR
3000pcs black　*ship by SEA
3000pcs silver　*ship by AIR

60x68Hmm　：
2000pcs white　*ship by SEA
1000pcs black　*ship by SEA
5000pcs silver　*ship by AIR
- [1740824090.139889] <@U0331FWGQRM>: <@U0331FZTHEK>
invoiceはこちらになりました。

・USD4580（USD2290（Paypal）x2回）
・USD11063（会社カード）
  - files: [{"id": "F08FPNYRG1Y", "created": 1740823381, "timestamp": 1740823381, "name": "Invoice for 20000pcs tins (1).pdf", "title": "Invoice for 20000pcs tins (1).pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 135600, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08FPNYRG1Y/invoice_for_20000pcs_tins__1_.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08FPNYRG1Y/download/invoice_for_20000pcs_tins__1_.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08FPNYRG1Y-845164cd52/invoice_for_20000pcs_tins__1__thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08FPNYRG1Y/invoice_for_20000pcs_tins__1_.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08FPNYRG1Y-d532cfd654", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08FLLSBYSH", "created": 1740823969, "timestamp": 1740823969, "name": "USD4580_receipt-18868213501033174.pdf", "title": "USD4580_receipt-18868213501033174.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 476505, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08FLLSBYSH/usd4580_receipt-18868213501033174.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08FLLSBYSH/download/usd4580_receipt-18868213501033174.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08FLLSBYSH-a6e813757d/usd4580_receipt-18868213501033174_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08FLLSBYSH/usd4580_receipt-18868213501033174.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08FLLSBYSH-bece323a4f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08FZTCKJ3B", "created": 1740823972, "timestamp": 1740823972, "name": "USD11063_receipt-19521205001033174.pdf", "title": "USD11063_receipt-19521205001033174.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 810856, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08FZTCKJ3B/usd11063_receipt-19521205001033174.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08FZTCKJ3B/download/usd11063_receipt-19521205001033174.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08FZTCKJ3B-efee6b935f/usd11063_receipt-19521205001033174_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08FZTCKJ3B/usd11063_receipt-19521205001033174.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08FZTCKJ3B-719e1bc020", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-03-04

- [1741131786.144769] <@U0331FWGQRM>: *-First- (20days)　→3/12出荷、3/17-19頃に桃翠園着予定*
*60x60Hmm　：*
*2000pcs white　*ship by AIR*
*2000pcs silver　*ship by AIR*

## 2025-03-11

- [1741737158.557189] <@U0331FZS7JT>: <@U041RJKV5JA> <@U05KGS6HN9H>
香岳園K2500について追加で50kgの発注をお願いします。
よろしくお願いします。

## 2025-03-13

- [1741909759.287339] <@U0331FZS7JT>: <@U041RJKV5JA> <@U05KGS6HN9H>
CC：<@U0331FWGQRM>
まるゑいに
有機抹茶ME上(5500)を100kgの発注書の送付をお願いします。
※納期は最短で4月10日or11日に発送とのことです。
→TSE013-25(:flag-ca: カナダTeangle用/3/14連絡)

## 2025-03-16

- [1742126686.121529] <@U0331FZS7JT>: <!channel>
茗広茶業から連絡があり、
宇治抹茶やぶきた（慣行品）
¥9,000/kg
の供給が可能とのこと。
サンプル届き次第、品質・供給量確認します。

## 2025-03-17

- [1742262796.889849] <@U066P20UQH1>: <@U0331FZS7JT> <@U03BLQ65GK0>
アメリカのSOT様が、出雲抹茶Nを年間200kg（おくみどり指定）を予約したいとのことですが、可能でしょうか・・？
必要なら、デポジットも支払うと言っています。。ご確認よろしくお願いいたします。:woman-bowing:
- [1742267780.095459] <@U03BLQ65GK0>: <@U066P20UQH1>
問題有りません:+1:️
一点確認ですが、「出雲」の指定ですか？（Nランクであれば産地問わないということではなく）
- [1742278556.592319] <@U066P20UQH1>: <@U03BLQ65GK0>
出雲＋おくみどり　で指定されております！対応可能でしょうか・・？

## 2025-03-18

- [1742286564.208669] <@U03BLQ65GK0>: <@U066P20UQH1>
了解です、問題有りませんので進めて下さい！
- [1742286709.130509] <@U03BLQ65GK0>: <@U066P20UQH1>
ただお願いがあって、受注があった際（特に最初の受注時）にこれは「出雲+おく」ですという一文を入れてもらえるとありがたいです:bow:

## 2025-03-21

- [1742554781.256239] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
3/15 出荷（下記の一部。白缶が一部別送）
60x60Hmm　：
4000pcs white　*ship by AIR
5000pcs silver　*ship by AIR
60x68Hmm：
5000pcs silver　*ship by AIR


追跡番号　SF3147623830702
<https://www.sf-international.com/jp/ja/support/querySupport/waybill>
  - attachments: [{"from_url": "https://www.sf-international.com/jp/ja/support/querySupport/waybill", "service_icon": "https://www.sf-international.com/nuxt/_nuxt/icons/icon_512x512.cc1525.png", "id": 1, "original_url": "https://www.sf-international.com/jp/ja/support/querySupport/waybill", "fallback": "顺丰国际官网", "text": "顺丰国际", "title": "顺丰国际官网", "title_link": "https://www.sf-international.com/jp/ja/support/querySupport/waybill", "service_name": "sf-international.com"}]

## 2025-03-23

- [1742724281.859339] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <@U03BLQ65GK0>
3/24（月）に到着しそうですね。
58ケース
60x60Hmm　1440(/4000) pcs white
60x60Hmm　5000pcs silver
60x68Hmm　5000pcs silver

遅れて（一部別送分）3/25に下記着の予定
11ケース
60x60Hmm　2580(/4000) pcs white
- [1742724358.998159] <@U0331FWGQRM>: 2025/03/23 19:00時点
  - files: [{"id": "F08JR0BGZ7G", "created": 1742724331, "timestamp": 1742724331, "name": "スクリーンショット 2025-03-23 19.05.28.png", "title": "スクリーンショット 2025-03-23 19.05.28.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 346649, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08JR0BGZ7G/____________________________2025-03-23_19.05.28.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08JR0BGZ7G/download/____________________________2025-03-23_19.05.28.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08JR0BGZ7G-749b3ee5a7/____________________________2025-03-23_19.05.28_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08JR0BGZ7G-749b3ee5a7/____________________________2025-03-23_19.05.28_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08JR0BGZ7G-749b3ee5a7/____________________________2025-03-23_19.05.28_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 346, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08JR0BGZ7G-749b3ee5a7/____________________________2025-03-23_19.05.28_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 462, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08JR0BGZ7G-749b3ee5a7/____________________________2025-03-23_19.05.28_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08JR0BGZ7G-749b3ee5a7/____________________________2025-03-23_19.05.28_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 693, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08JR0BGZ7G-749b3ee5a7/____________________________2025-03-23_19.05.28_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 770, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08JR0BGZ7G-749b3ee5a7/____________________________2025-03-23_19.05.28_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 924, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08JR0BGZ7G-749b3ee5a7/____________________________2025-03-23_19.05.28_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 985, "original_w": 1696, "original_h": 1632, "thumb_tiny": "AwAuADCmbd/LGIpN3f5TTfs8vP7qT2+U1vlV3BiozjGaAV6gUAYH2eX/AJ5S/wDfFH2ebP8AqpP++TXQAg0tAHPrbybvmilx7Kaf9m/6Zz/98Vu80UDTGselLSMOAaXvQITpS5pPSl20ALRSYpfxoAa3QfWlpG6D60GgANFHpRmgBfxozz1pKdz60Af/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08JR0BGZ7G/____________________________2025-03-23_19.05.28.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F08JR0BGZ7G-09834d4ba3", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08K8P0FFGR", "created": 1742724341, "timestamp": 1742724341, "name": "スクリーンショット 2025-03-23 19.05.39.png", "title": "スクリーンショット 2025-03-23 19.05.39.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 261449, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08K8P0FFGR/____________________________2025-03-23_19.05.39.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08K8P0FFGR/download/____________________________2025-03-23_19.05.39.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08K8P0FFGR-33e9c6a3de/____________________________2025-03-23_19.05.39_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08K8P0FFGR-33e9c6a3de/____________________________2025-03-23_19.05.39_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08K8P0FFGR-33e9c6a3de/____________________________2025-03-23_19.05.39_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 324, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08K8P0FFGR-33e9c6a3de/____________________________2025-03-23_19.05.39_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 432, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08K8P0FFGR-33e9c6a3de/____________________________2025-03-23_19.05.39_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08K8P0FFGR-33e9c6a3de/____________________________2025-03-23_19.05.39_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 648, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08K8P0FFGR-33e9c6a3de/____________________________2025-03-23_19.05.39_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 720, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08K8P0FFGR-33e9c6a3de/____________________________2025-03-23_19.05.39_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 864, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08K8P0FFGR-33e9c6a3de/____________________________2025-03-23_19.05.39_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 922, "original_w": 1864, "original_h": 1678, "thumb_tiny": "AwArADC+o2M5Lk7jnHpT/wAaTAzyB9aXap7D8qAD8aWkCgdABS0AFFFFADfwpRnHSkIyRyRTqACiiigAooooAaTg0obNGBRQAbh7fnRkUUUAG4e350ZoooA//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08K8P0FFGR/____________________________2025-03-23_19.05.39.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F08K8P0FFGR-ecdc0fd5b2", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-03-24

- [1742871962.665799] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
納期遅れました！:sweat_drops:
3/26（水）AMで確定しました。
58ケース
60x60Hmm　1440(/4000) pcs white
60x60Hmm　5000pcs silver
60x68Hmm　5000pcs silver

こちらは3/25に到着予定です。
11ケース
60x60Hmm　2580(/4000) pcs white

## 2025-03-25

- [1742895065.135119] <@U05KGS6HN9H>: <!channel>
碧翠園より、カレンダーと合わせて、抹茶納期に時間を要する旨
連絡が入っておりますので共有申し上げます。
  - files: [{"id": "F08K4G61CJZ", "created": 1742895013, "timestamp": 1742895013, "name": "20250325碧翠園連絡.pdf", "title": "20250325碧翠園連絡.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 316374, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08K4G61CJZ/20250325_______________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08K4G61CJZ/download/20250325_______________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08K4G61CJZ-8b5fa1e949/20250325________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08K4G61CJZ/20250325_______________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08K4G61CJZ-dd96469532", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-03-27

- [1743139730.446389] <@U08FZUNPSQ3>: <@U08FZUNPSQ3>さんがチャンネルに参加しました
- [1743143567.155319] <@U08FZUNPSQ3>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> cc <@U0331FZS7JT>
下記ファイルの原料登録単価を追記しました。
```海外営業&gt;●管理（送料・資材・その他）&gt;●原料仕入（発注書）
202xxxxx【 御中】発注書.xlsx```
ご利用下さい。
よろしくお願いいたします。

## 2025-03-28

- [1743157145.164949] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U08FZUNPSQ3> <@U0331FZTHEK>
CC：<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
<@U08FZUNPSQ3>
データのまとめ、ありがとうございました。
フォルダを移動しました。

●桃翠園共有フォルダ→●調達→「202xxxxx【 御中】発注書」

こちらで入力の上、発注の際はメールまたはFaxにてお願いします。
エクセルのトップタブにサプライヤー各社のリンクを貼り付けているので、そこから各社の発注書に飛んで入力してもらうと楽かと思います。

発注後、各年のサプライヤーのフォルダに格納をお願いします。
順次各サプライヤーの発注書の中身を厚くしていこうと思います。

もし価格改定等ありましたら<@U08FZUNPSQ3> <@U0331FZTHEK> 確認の上、反映をお願いします。
反映後はスレッドに記載をお願いします。
よろしくお願いします。
- [1743212415.435679] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U08FZUNPSQ3> <@U0331FZTHEK>
TOUSUIENの海外出荷向けダンボール用デザインテープを発注しました（前回同様200巻）。
6月12日発送とのこと。
<https://www.notosiki.co.jp/mypage/>
ログインアドレス：<mailto:oka-is@hit-5.net|oka-is@hit-5.net>
パスワード：tousuien10
注文履歴から同じものが購入できますので、今後必要な場合は発注をお願いします。

よろしくお願いします。
  - attachments: [{"image_url": "https://www.notosiki.co.jp/parts/img/home/slide_00.png", "image_width": 2400, "image_height": 1260, "image_bytes": 134973, "from_url": "https://www.notosiki.co.jp/mypage/", "service_icon": "https://www.notosiki.co.jp/favicon.ico", "id": 1, "original_url": "https://www.notosiki.co.jp/mypage/", "fallback": "ダンボールの販売・通販【ダンボールワン】: ログイン | ダンボール通販No.1【ダンボールワン】", "text": "段ボール・梱包資材の通販サイト「ダンボールワン」のログインページです。既製品ダンボール、オーダーメイドダンボールをWEBでカンタン注文！日本全国の工場ネットワークで安心の国産品質、大量生産で業界最安値に挑戦しています！全国送料無料（一部除く）。", "title": "ログイン | ダンボール通販No.1【ダンボールワン】", "title_link": "https://www.notosiki.co.jp/mypage/", "service_name": "ダンボールの販売・通販【ダンボールワン】"}]

## 2025-03-30

- [1743377922.399549] <@U0331FWGQRM>: <!channel>
タマヤ製の黒缶について
在庫
2025
3/30時点　200缶
4/9入荷 　7000缶
5月GW明け入荷　5500缶

## 2025-03-31

- [1743469445.022189] <@U0331FZS7JT>: <!channel>
メモ兼ねて
サプライヤー：まるゑい
非有機の抹茶をサンプル依頼

¥10,000/kg
¥5,000/kg
¥4,000/kg

品質・種々の情報確認中
- [1743469792.543229] <@U08L89G6JSG>: <@U08L89G6JSG>さんがチャンネルに参加しました

## 2025-04-04

- [1743817030.220039] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> cc <@U0331FZS7JT> <@U03BLQ65GK0>
> ①黒缶
> ・白缶に移行するまでには5000缶程度の注文をする予定
> ・HABITについては今後も黒缶を使用
> ②白缶
> ・初回の注文は5000缶程度を予定
> ・白缶に移行するタイミングは夏頃

・黒缶については、追加で1000缶, 3000缶, 5000缶、
発注した場合の納期をそれぞれ確認お願いします。

・白缶については、
5000缶, 10000缶, 20000缶注文した場合の納期と見積りを確認願います。
その上で5000缶は必ず必要なので発注願います。

## 2025-04-13

- [1744593613.963359] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> cc : <@U0331FZS7JT> <@U03BLQ65GK0>
納期についてご連絡いたします。
①黒缶
納期：受注後３週間以内に出荷（1000缶でも5000缶でも同じ）
　　　今回入荷が遅れているのは、当社の発注量が通常時よりも多く、蓋の在庫がなくなり製造が必要となったため。
　　　今後も在庫切れの場合は、1カ月～1カ月半かかります。
②白缶
納期：受注後３週間以内に出荷（1000缶でも5000缶でも同じ）
　　　＊コンスタントに発注が可能となった場合、製造スケジュールに組み込んでいただいた場合の納期となります。
　　　蓋・胴の在庫が共にない場合は、1ヶ月以上掛かるとのこと。
　　　今回発注分の5000缶の納期は確認中です。
価格：169円/缶（3000缶以上同単価）
見積書を添付いたします。
早めの発注を行い、常に1案件分の在庫を持つようにいたします。
ご確認よろしくお願いいたします。
  - files: [{"id": "F08MKKE7PJT", "created": 1744593309, "timestamp": 1744593309, "name": "＃17150ミニトップ缶ﾎﾜｲﾄ R7.4.11.pdf", "title": "＃17150ミニトップ缶ﾎﾜｲﾄ R7.4.11.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 133675, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08MKKE7PJT/___17150__________________________________r7.4.11.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08MKKE7PJT/download/___17150__________________________________r7.4.11.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08MKKE7PJT-e882ec19c0/___17150__________________________________r7.4.11_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08MKKE7PJT/___17150__________________________________r7.4.11.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08MKKE7PJT-8d4a6c91a7", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-04-14

- [1744677081.722489] <@U0840UVFVA8>: <!channel>
下記発注をお願いします！

碧水園
・国産有機抹茶10500　100kg
（OST用在庫　約２回分）

よろしくお願いします！
- [1744690094.235569] <@U0331FZS7JT>: <@U041RJKV5JA>
注文されたようですね？
発注後何かしらスタンプ押していただると助かります。

宜しくお願いします。

## 2025-04-15

- [1744702924.705039] <@U041RJKV5JA>: <@U0331FZS7JT> <@U0840UVFVA8>
納期：5月中旬〜下旬（確定次第連絡をいただきます。）
現状、在庫が全くないとのことです。
碾茶での納品可否も確認しましたが、合組も出来ていないため難しいとのことでした。
よろしくお願いいたします。
- [1744760999.694689] <@U0840UVFVA8>: <!channel>
下記発注をお願いいたします。

水宗園
・有機抹茶＠9000  100kg
（現在庫：約50kg）

よろしくお願いします
- [1744766752.405229] <@U041RJKV5JA>: <@U0331FZS7JT> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
4/18（金）に水宗園より「有機抹茶34号」が819.2kg入荷します。
 先方の手違いにより製品名が「有機抹茶A-1、有機抹茶A-2」の2銘柄にて入荷します。
 ＊どちらも同じ製品となります。
 ケースへの製品ラベル貼付けの際には「有機抹茶34号」にてご対応をお願いします。
 よろしくお願いいたします。
- [1744783427.475339] <@U041RJKV5JA>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
OSSU TEA(003-25）不足ラベルは4/24（木）に到着します。
よろしくお願いいたします。

## 2025-04-16

- [1744845932.515209] <@U041RJKV5JA>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
有機ココナッツパウダー納品日
・4月21日（月）
よろしくお願いいたします。
- [1744852087.655009] <@U041RJKV5JA>: <@U0331FZS7JT> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
【納品予定日】
・4/30 20kg
・5/9 80kg
- [1744858082.302439] <@U041RJKV5JA>: <@U0331FZS7JT> CC <@U03BLQ65GK0>
水宗園　1茶八女産碾茶 焙煎B 300kg発注しました。
よろしくお願いいたします。

## 2025-04-23

- [1745461414.666439] <@U0840UVFVA8>: <!channel>
下記原料発注をお願いします。

・水宗園 有機抹茶7400　100kg
　（現在庫：約40kg）

・まるゑい 有機抹茶8000（ほぼ大野様用？）
　数量はお任せします！
　（現在庫：約5kg）

よろしくお願いします！
- [1745473467.230489] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
・まるゑい 有機抹茶8000：100kg
*6月12日(木)納品*
- [1745473476.952469] <@U08NVD403GV>: <@U08NVD403GV>さんがチャンネルに参加しました

## 2025-04-25

- [1745646484.658669] <@U0840UVFVA8>: <!channel>
下記原料発注をお願いします。

・鹿児島製茶 有機煎茶1A
　TSE024-25で50kg使用
　（現在庫：約1kg）

よろしくお願いします。

## 2025-04-26

- [1745653866.260839] <@U0331FZS7JT>: メモ
有機煎茶1B：60kg送付で鹿児島製茶在庫無し
有機煎茶1A：200kg注文（鹿児島製茶在庫129kg）

有機煎茶１B及び１A代替品
・まるゑい確認中
・ひかわ：有機ほうじ茶の原料でできるか要確認
- [1745654014.089829] <@U0331FZS7JT>: <@U041RJKV5JA>
まるゑいに１Aと１Bの見本を各50g送っていただけますか？
これで対応可能か探ってもらいます。
よろしくお願いします。

## 2025-04-27

- [1745805255.741359] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S08NN8M4LAZ|@katayose-kamiya>
抹茶44(和香園)
478kg(1kg × 478本)発注済み（発注書は別途送付します）
GW明けに桃翠園に届く予定。

追加分（現時点予定/納期等確認中）：約2200kg
　L納期：5月中旬-下旬

有機煎茶1A・1B（鹿児島製茶）代替品について
ひかわ：有機ほうじ茶の荒茶を確認したいと先方に打診中
和香園：確認中
まるゑい：在庫なし
茗広茶業：在庫なし
- [1745821435.008959] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S08NN8M4LAZ|@katayose-kamiya> <@U03BLQ65GK0>

有機煎茶1A・1B（鹿児島製茶）代替品について
ひかわ：有機ほうじ茶の荒茶を確認したいと先方に打診中

▼品質確認(ひかわで仕上げたものが来た/価格確認中)
１B代替品として問題なし
　L若干赤棒を抜く必要あり。

１A代替品として
水色：問題なし
形状：四角い部分と赤帽を抜いたらOK
※葉色良いとこはほぼ同じ
滋味：赤棒と四角い形状を抜いたらほとんど同じになると予想。
もし多少異なるとしたら少し火入れしたら問題なさそう
→ひかわの原料単体で上記の製造を行ったら良い
　または、合組でOK。

<@U03BLQ65GK0> <@U0840UVFVA8>
まだ１Aも１Bも在庫あるので、
６月末辺りにテスト製造をお願いします。
よろしくお願いします。

## 2025-04-29

- [1745975426.904719] <@U066P20UQH1>: <@U03BLQ65GK0> <@U0331FZS7JT>
<https://grp-ssm9297.slack.com/archives/C089D005K0S/p1742262796889849>
3月18日時点で年間200kg確保したいと言っていたお客様ですが、すでに170kg注文されており、追加で来年の春頃まで分として150kg追加で確保して欲しいと依頼がありました。（このペースだと、追加150kgでは済まないのでは、、と思っております。。）
質問は、
①出雲＋おくみどり指定ですが、大丈夫でしょうか？
②リミットがあれば大体でも構いませんので教えていただけますか？

よろしくお願いいたします:woman-bowing:
  - attachments: [{"from_url": "https://grp-ssm9297.slack.com/archives/C089D005K0S/p1742262796889849", "ts": "1742262796.889849", "author_id": "U066P20UQH1", "channel_id": "C089D005K0S", "channel_team": "T033D70RR6H", "is_msg_unfurl": true, "message_blocks": [{"team": "T033D70RR6H", "channel": "C089D005K0S", "ts": "1742262796.889849", "message": {"blocks": [{"type": "rich_text", "block_id": "ycJfr", "elements": [{"type": "rich_text_section", "elements": [{"type": "user", "user_id": "U0331FZS7JT"}, {"type": "text", "text": " "}, {"type": "user", "user_id": "U03BLQ65GK0"}, {"type": "text", "text": "\nアメリカのSOT様が、出雲抹茶Nを年間200kg（おくみどり指定）を予約したいとのことですが、可能でしょうか・・？\n必要なら、デポジットも支払うと言っています。。ご確認よろしくお願いいたします。"}, {"type": "emoji", "name": "woman-bowing", "unicode": "1f647-200d-2640-fe0f"}]}]}]}}], "id": 1, "original_url": "https://grp-ssm9297.slack.com/archives/C089D005K0S/p1742262796889849", "fallback": "[March 17th, 2025 6:53 PM] haru.nboc: <@U0331FZS7JT> <@U03BLQ65GK0>\nアメリカのSOT様が、出雲抹茶Nを年間200kg（おくみどり指定）を予約したいとのことですが、可能でしょうか・・？\n必要なら、デポジットも支払うと言っています。。ご確認よろしくお願いいたします。:woman-bowing:", "text": "<@U0331FZS7JT> <@U03BLQ65GK0>\nアメリカのSOT様が、出雲抹茶Nを年間200kg（おくみどり指定）を予約したいとのことですが、可能でしょうか・・？\n必要なら、デポジットも支払うと言っています。。ご確認よろしくお願いいたします。:woman-bowing:", "author_name": "Haruka Hayashi", "author_link": "https://grp-ssm9297.slack.com/team/U066P20UQH1", "author_icon": "https://avatars.slack-edge.com/2024-04-12/6955353714228_179323cb3551f7c8ecfe_48.png", "author_subname": "Haruka Hayashi", "mrkdwn_in": ["text"], "footer": "Slack の会話"}]
- [1745977953.768449] <@U03BLQ65GK0>: <@U066P20UQH1>
①問題有りません
②量のリミットですよね？他のお客さんのことも考えると500kgが上限ですね。
ただ、500kg使い切った＝もう出せない　が確定になるわけではない（在庫状況によっては調整できるかもしれない）ので一旦の目安として500kgとしておいて下さい。

以上よろしくお願いします！
- [1745978332.050409] <@U066P20UQH1>: <@U03BLQ65GK0>  cc<@U0331FZS7JT>
ありがとうございます！
追加150kg確保は問題ないので増えそうな場合は早めに教えてくださいとお客さんに伝えました。
念の為、ご認識をお願いいたします！（どこかに書いておいた方がよければご指示ください:woman-bowing:）

## 2025-05-09

- [1746836478.966839] <@U05KGS6HN9H>: <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S08NN8M4LAZ|@katayose-kamiya>
国産有機ほうじ茶パウダー（ひかわ）
在庫用300kg　5/8発注済み
《5/10ひかわより分納回答》
6月末　100kg
7月末　100kg
8月末　100kg

## 2025-05-11

- [1747026289.321609] <@U041RJKV5JA>: <@U0331FZS7JT> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
＜水宗園＞
4/24発注分
有機抹茶@7400 - 100kg
先方出荷日：5/16（金）
- [1747029566.140439] <@U041RJKV5JA>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
＜キタマ＞
バニラパウダー　1kg×50袋
入荷日：5月15日（木）（出雲精茶へ納品）

## 2025-05-12

- [1747116679.586719] <@U041RJKV5JA>: <@U033G4KN4TD>
＜むそう＞
有機JASてんさい糖 25kg
納品日：5月19日（月）
- [1747119264.946309] <@U041RJKV5JA>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
＜キタマ＞
バニラパウダー　1kg×70袋（セバスチャン用先行確保分）
入荷日：5月16日（金）
　　　　＊ヤマナ茶業へ納品

## 2025-05-13

- [1747121109.516359] <@U0331FZS7JT>: <!channel>
宇治抹茶 情報共有
From 水宗園(直掛け・機械摘み/仕上げ碾茶価格)
うじひかり：¥25,000/kg（香岳園からは昨年碾茶で¥15,000/kg）
つゆひかり：¥23,000/kg(香岳園からは昨年碾茶で¥12,000/kg)
さえみどり：¥23,000/kg(香岳園からは昨年碾茶で¥10,000/kg)
明日３回目の入札が行われる
上記の価格からは少し下がるのではないか、という予測。
・ごこう
・あさひ
・うじみどり
などの品種はもう少し後で市場に出てくる予定
京都府産に限らず、三重奈良滋賀のお茶も確認を依頼しています。
※奈良が品質高めで安いらしい。。

宇治抹茶メインサプライヤーの香岳園からの連絡は
折り返しがまだなため
随時価格の確認を共有しながら調達を進めていきます。
- [1747191933.942889] <@U05KGS6HN9H>: <@U0331FZS7JT>
Chaseki様用と思いますが、4/11発中分の碧翠園缶製品
納期回答が有りました。
5/15（木）納品予定です。
  - files: [{"id": "F08SXFCGRR6", "created": 1747191920, "timestamp": 1747191920, "name": "碧翠園_缶製品.pdf", "title": "碧翠園_缶製品.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 354411, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08SXFCGRR6/___________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08SXFCGRR6/download/___________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08SXFCGRR6-d62cd0acf1/____________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08SXFCGRR6/___________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08SXFCGRR6-57acdd39df", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1747196321.848199] <@U041RJKV5JA>: <@U0331FZS7JT> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
＜水宗園＞
5/9発注分納期
・有機抹茶9000 100kg　5/30（金）着
・有機抹茶7400 300kg　6/10（火）着

## 2025-05-14

- [1747208304.919359] <@U0840UVFVA8>: <@U041RJKV5JA> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
原料発注をお願いいたします。
＜キタマ＞
・チョコレートパウダーB3663 10kg
よろしくお願いします。
- [1747285549.020789] <@U041RJKV5JA>: <!channel>
＜タマヤ＞
プルトップスクリュー缶 100g 白　720缶
納品日：5月26日（月）
- [1747289996.828989] <@U041RJKV5JA>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
＜キタマ＞
チョコレートパウダー　1kg×10袋
納品日：5月19日（月）

## 2025-05-19

- [1747640051.321669] <@U041RJKV5JA>: <@U0331FZS7JT>
 <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S08NN8M4LAZ|@katayose-kamiya> <@U03BLQ65GK0>
抹茶44の納期をご連絡いたします。
・960kg…6/2日納品
・117kg…6/3日納品
・923kg…6/9日納品
・558kg…6/10日納品
合計納品数量：2,558kg
＊今回納品分より納品単価3,500円/kgとなります。
- [1747701181.550859] <@U041RJKV5JA>: <@U0331FZS7JT> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
＜碧翆園＞
国産有機抹茶10500 100kg
納品日：5月27日（火）
- [1747714285.188229] <@U041RJKV5JA>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
＜高砂香料＞
マンゴーミクロン ZH-1561 8kg
納品日：5月30日（金）

## 2025-05-20

- [1747790806.335879] <@U041RJKV5JA>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
＜小川香料＞
ユズフレーバー　9kg
納品日：~5月27日（火）~　5月23日（金）

## 2025-05-22

- [1747906585.452219] <@U033G4KN4TD>: <@U03BLQ65GK0>
5月19日に入荷した抹茶R-mixS　(537.5㎏)
(Sebastyan用)
来週使用し、残り25㎏くらいになる予定です。
次回分粉砕予定をよろしくお願いいたします。

## 2025-05-24

- [1748151948.843259] <@U0331FZS7JT>: <@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
宇治抹茶(碾茶シングルオリジン)確保量
サプライヤー：利招園茶舗
▼さみどり
碾茶数量：317.5kg
碾茶原価：32,869/kg

▼うじひかり
数量：99.1kg
碾茶原価：31,595/kg

▼ごこう
数量：184.1kg
碾茶原価：20,930/kg

▼やぶきた
数量：258.3kg
碾茶原価：¥9,953/kg
  - files: [{"id": "F08U8V7KN1X", "created": 1748151620, "timestamp": 1748151620, "name": "宇治抹茶(シングル)利招園茶舗.xlsx", "title": "宇治抹茶(シングル)利招園茶舗.xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 14904, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08U8V7KN1X/____________________________________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08U8V7KN1X/download/____________________________________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08U8V7KN1X-c4552520da/_____________________________________________converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08U8V7KN1X-c4552520da/_____________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08U8V7KN1X/____________________________________________.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F08U8V7KN1X-4d92ba7191", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-05-25

- [1748225658.036839] <@U05KGS6HN9H>: 《5/26 ひかわ納期回答》
　発注残（在庫用）70kg
　上記6月末予定分から　30kg
---------------------------------------
　合計100kg　→5/28入荷

## 2025-05-26

- [1748263846.549519] <@U0331FWGQRM>: <@U0331FZS7JT> <@U03BLQ65GK0>
今年の星野製茶の星峰、池の白、星の露の
入手性（数量＆価格）について情報はありますでしょうか？？？
- [1748310184.448639] <@U0331FZS7JT>: <@U05KGS6HN9H>
<!channel>
【葵製茶/西尾抹茶】
2025年産価格：今週中に連絡が来る予定
価格は1.5倍程度になるとのこと。
※碾茶は２倍の価格になっているがそのまま反映はしない方針。

本年産製品納期：7月初旬
NA,NB,NC何れも１番茶を使用しているため
今年の１茶碾茶を仕上げ・合組・粉砕に要する時間が上記の通り（昨年の１茶原料は在庫0）。
※昨日<@U05KGS6HN9H> から発注している分については生かしで進めているので、
改めて納期連絡が来る予定です。

情報来たら改めて共有します。
よろしくお願いします。
- [1748313950.235509] <@U0331FZS7JT>: <@U0331FWGQRM>
CC：<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0>

７月1日からの価格と今年の購入可能数量予定は下記の通り(昨年価格)(昨年購入数量)です！
【星峰】¥37,500/kg(¥31,400)：3kg(1kg)
【池の白】¥28,500/kg(¥26,000)：10kg(8kg)
【星の露】¥22,500/kg(¥20,600)：18kg(15kg)
【八女の露】¥17,500/kg(¥15,200)：57kg(47kg)
【八女の華】¥14,500/kg(¥12,500)：175kg(144kg)
【もくれん】¥12,000/kg(¥10,000)：185kg(154kg)
【やまぶき】¥10,000/kg(¥8,000)：35kg(28kg)
【こでまり】¥8,000/kg(¥6,000)：310kg(258kg)
【あじさい】¥5,000/kg(¥4,000)：50kg(32kg)

星野から言われている桃翠園への対応数量は昨年購入量のMAX 1.2倍です。
その上で原料の品質調整含めて上記希望数量を先方に伝え
６月半ばに最終的に桃翠園にそれぞれ何kg対応可能か確定します。
※もくれん〜こでまりが結構数量厳しそうとのこと。

併せて水宗園にも八女抹茶の手配は依頼しています。
水宗園から碾茶見本はまだ届いていないですが、品質的にはおそらく「八女の露」〜「こでまり」のものとなりそうで水宗園で確保できる最大の1t-2t依頼しています。

ご確認、よろしくお願いします:man-bowing:
  - files: [{"id": "F08TW8M12G6", "created": 1748305963, "timestamp": 1748305963, "name": "2025星野製茶園抹茶価格.pdf", "title": "2025星野製茶園抹茶価格.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 51434, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08TW8M12G6/2025___________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08TW8M12G6/download/2025___________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08TW8M12G6-d0fb1375b0/2025____________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08TW8M12G6/2025___________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F08TW8M12G6-4e95d0e7e5", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1748314466.162149] <@U08N3SKSL75>: <@U08N3SKSL75>さんがチャンネルに参加しました
- [1748314466.456789] <@U08RVRNBY00>: <@U08RVRNBY00>さんがチャンネルに参加しました

## 2025-06-02

- [1748912207.893659] <@U05KGS6HN9H>: <@U0331FZS7JT> <!channel>
丸久小山園より価格改定の案内が届きましたので情報共有致します。
・発送日ベースで2025/7/1より改定実施予定
・抹茶は概ね現行価格の150～160％程度値上げ見込み
添付ご確認のほどお願い致します。
  - files: [{"id": "F0901HCGYHX", "created": 1748912199, "timestamp": 1748912199, "name": "丸久小山園_価格改定案内20250603.pdf", "title": "丸久小山園_価格改定案内20250603.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 273416, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0901HCGYHX/__________________________________20250603.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0901HCGYHX/download/__________________________________20250603.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0901HCGYHX-c6d14109de/__________________________________20250603_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0901HCGYHX/__________________________________20250603.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F0901HCGYHX-68057c9d4d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1748912378.007649] <@U0331FWGQRM>: <@U05KGS6HN9H> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
連絡ありがとうございます。
150%値上げは
1.5倍ではなく、2.5倍という認識ですが、
あっていますか？
念の為に確認してもらえますか？
- [1748914164.732099] <@U05KGS6HN9H>: <@U0331FWGQRM>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
電話にて問合せ致しました。
現行の1.5倍～1.6倍という意味です。
（仮：100円→150～160円）

## 2025-06-04

- [1749020632.910649] <@U041RJKV5JA>: ＜メモ＞
高砂香料　各種原料リードタイム：2ヶ月

## 2025-06-05

- [1749174348.269199] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
中国製缶について（Ossu teaのスレッドをこちらに転記します。）
下記について、進捗Updateお願いします。
- [1749174352.159649] <@U0331FWGQRM>: <https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1748587498905939?thread_ts=1747126757.485039&amp;cid=C03C62NBSDP>
  - attachments: [{"from_url": "https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1748587498905939?thread_ts=1747126757.485039&amp;cid=C03C62NBSDP", "ts": "1748587498.905939", "author_id": "U033G4KN4TD", "channel_id": "C03C62NBSDP", "channel_team": "T033D70RR6H", "is_msg_unfurl": true, "is_reply_unfurl": true, "message_blocks": [{"team": "T033D70RR6H", "channel": "C03C62NBSDP", "ts": "1748587498.905939", "message": {"blocks": [{"type": "rich_text", "block_id": "9muI2", "elements": [{"type": "rich_text_section", "elements": [{"type": "user", "user_id": "U0331FWGQRM"}, {"type": "text", "text": "\n申し訳ございません。\nよろしくお願いいたします。\n\nプルトップスクリュー缶60×68銀　\nプルトップスクリュー缶60×60銀　(残1580)\nプルトップスクリュー缶60×60白\n感覚ですが上記はよく動いていると思います。\n\n缶在庫全て確認し報告いたします。"}]}]}]}}], "id": 1, "original_url": "https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1748587498905939?thread_ts=1747126757.485039&amp;cid=C03C62NBSDP", "fallback": "[May 29th, 2025 11:44 PM] tousuien04: <@U0331FWGQRM>\n申し訳ございません。\nよろしくお願いいたします。\n\nプルトップスクリュー缶60×68銀　\nプルトップスクリュー缶60×60銀　(残1580)\nプルトップスクリュー缶60×60白\n感覚ですが上記はよく動いていると思います。\n\n缶在庫全て確認し報告いたします。", "text": "<@U0331FWGQRM>\n申し訳ございません。\nよろしくお願いいたします。\n\nプルトップスクリュー缶60×68銀　\nプルトップスクリュー缶60×60銀　(残1580)\nプルトップスクリュー缶60×60白\n感覚ですが上記はよく動いていると思います。\n\n缶在庫全て確認し報告いたします。", "author_name": "Fukui", "author_link": "https://grp-ssm9297.slack.com/team/U033G4KN4TD", "author_icon": "https://avatars.slack-edge.com/2022-02-16/3118194883458_b87877677a672efe50f6_48.png", "author_subname": "Fukui", "mrkdwn_in": ["text"], "footer": "Slack の会話内のスレッド"}]

## 2025-06-08

- [1749448058.047919] <@U082RF7UF1V>: <@U0331FWGQRM> <@U033G4KN4TD>

松井さん
中国缶在庫についてですが、不明な点が多く、福井さんへ確認が必要となりました。
申し訳ありませんが、福井さんが出社されてから連絡をさせてください。
ご迷惑をおかけし、申し訳ありません。

## 2025-06-09

- [1749518562.048999] <@U0331FZS7JT>: <!channel>
まるゑい有機抹茶価格改定（本日注文分より）
  - files: [{"id": "F090R58V892", "created": 1749518523, "timestamp": 1749518523, "name": "御見積り書【有機製品】2025.6.pdf", "title": "御見積り書【有機製品】2025.6.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 118214, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F090R58V892/_________________________________2025.6.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F090R58V892/download/_________________________________2025.6.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F090R58V892-f2c055337c/_________________________________2025.6_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F090R58V892/_________________________________2025.6.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F090R58V892-24d90ae7bd", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-06-10

- [1749547771.228609] <@U041RJKV5JA>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
下記原料が出雲精茶へ納品されますので、ご連絡いたします。
＜6/18入荷＞
・ストロベリーミクロンZH-2930 8kg×2
・ラズベリーミクロン　MQ-16867 8kg×2
・バニラパウダー 70kg
・シナモンパウダー（カシア）20kg
・ココナッツパウダー 20kg
- [1749559629.142889] <@U0331FZS7JT>: <!channel>
八女１茶抹茶（碾茶）From 水宗園
価格確認中
納品日：6月17日
納品先：出雲精茶(10kg/袋)
※ものによっては真空唐箕を必要とする
  - files: [{"id": "F090KQATRD1", "created": 1749559547, "timestamp": 1749559547, "name": "水宗園（八女1茶碾茶_2026）.xlsx", "title": "水宗園（八女1茶碾茶_2026）.xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 10090, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F090KQATRD1/__________________1__________2026___.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F090KQATRD1/download/__________________1__________2026___.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F090KQATRD1-115f08157d/__________________1__________2026____converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F090KQATRD1-115f08157d/__________________1__________2026____thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F090KQATRD1/__________________1__________2026___.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F090KQATRD1-f084d2ffbb", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1749619972.631949] <@U041RJKV5JA>: <!channel>
Genuine Tea用ミニトップ缶（黒）20,000缶の納品予定
・6月11日（水）　3,000缶
~・6月下旬　9,000缶~
~・7月上旬　8,000缶~
```●6月中納品数量　9000缶
6/19出荷、6/23着　3000缶
6/20出荷、6/23着　3000缶
6/23出荷、6/25着　3000缶
●7月頭納品数量　8000缶　
7/1出荷、7/3着　3000缶
7/2出荷、7/4着　3000缶
7/3出荷、7/7着　2000缶　```


## 2025-06-11

- [1749685462.221489] <@U05KGS6HN9H>: <@U0331FZS7JT> *@channel*
6/11丸久小山園からの連絡内容を共有致します。
①6月の注文受付を一旦停止（7月再開見込み）
②7月から1.7倍の価格見込み（別途通知予定）
※6/3に当社へ入荷した製品までが現時点で最終で、以下の在庫状況です。
青嵐	50
五十鈴	40
千木の白　12
幽玄	12
和光	12
金輪	12

## 2025-06-12

- [1749792197.705599] <@U041RJKV5JA>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
日本粉末薬品　ジンジャーパウダー　2kg
納品日：6月17日
- [1749792211.086359] <@U08V56G9U92>: <@U08V56G9U92>さんがチャンネルに参加しました

## 2025-06-15

- [1750016503.852089] <@U0331FZS7JT>: <!channel>
*2025年 価格改定まとめ*
このスレッドに2025年の価格改定があったものをまとめ、随時更新します。
- [1750016613.095889] <@U0331FZS7JT>: *まるゑい*
2025年6月〜
  - files: [{"id": "F091BM4TJPM", "created": 1750016570, "timestamp": 1750016570, "name": "御見積り書【有機製品】2025.6.pdf", "title": "御見積り書【有機製品】2025.6.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 118214, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F091BM4TJPM/_________________________________2025.6.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F091BM4TJPM/download/_________________________________2025.6.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F091BM4TJPM-20b32fd1d6/_________________________________2025.6_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F091BM4TJPM/_________________________________2025.6.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F091BM4TJPM-2cde0f6f9d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1750016785.413979] <@U0331FZS7JT>: *丸久小山園*（価格改定案内）
2025年7月〜
確定後別途アップロード
  - files: [{"id": "F092789KV0Q", "created": 1750016779, "timestamp": 1750016779, "name": "丸久小山園_価格改定案内20250603.pdf", "title": "丸久小山園_価格改定案内20250603.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 273416, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F092789KV0Q/__________________________________20250603.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F092789KV0Q/download/__________________________________20250603.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F092789KV0Q-7570ffa64a/__________________________________20250603_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F092789KV0Q/__________________________________20250603.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F092789KV0Q-cef2aedeb9", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1750016930.887509] <@U0331FZS7JT>: *星野製茶園*
2025年６月〜
  - files: [{"id": "F091BMC2KDZ", "created": 1750016927, "timestamp": 1750016927, "name": "2025星野製茶園抹茶価格.pdf", "title": "2025星野製茶園抹茶価格.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 51434, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F091BMC2KDZ/2025___________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F091BMC2KDZ/download/2025___________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F091BMC2KDZ-233aa19a14/2025____________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F091BMC2KDZ/2025___________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F091BMC2KDZ-729bc6fe1a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1750017458.676919] <@U0331FWGQRM>: <@U0331FZS7JT> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
メモ
KATO SUMMER（和香園 抹茶44）は年間7トン予定
- [1750017474.038879] <@U08U8MMTH43>: <@U08U8MMTH43>さんがチャンネルに参加しました
- [1750017861.673199] <@U0331FWGQRM>: 和香園
<https://grp-ssm9297.slack.com/archives/C089D005K0S/p1747640051321669?thread_ts=1745805255.741359&amp;cid=C089D005K0S>
  - attachments: [{"from_url": "https://grp-ssm9297.slack.com/archives/C089D005K0S/p1747640051321669?thread_ts=1745805255.741359&amp;cid=C089D005K0S", "ts": "1747640051.321669", "author_id": "U041RJKV5JA", "channel_id": "C089D005K0S", "channel_team": "T033D70RR6H", "is_msg_unfurl": true, "is_reply_unfurl": true, "message_blocks": [{"team": "T033D70RR6H", "channel": "C089D005K0S", "ts": "1747640051.321669", "message": {"blocks": [{"type": "rich_text", "block_id": "DDsB/", "elements": [{"type": "rich_text_section", "elements": [{"type": "user", "user_id": "U0331FZS7JT"}, {"type": "text", "text": "\n "}, {"type": "usergroup", "usergroup_id": "S088LEJ1U5T"}, {"type": "text", "text": " "}, {"type": "usergroup", "usergroup_id": "S073HEMKWV7"}, {"type": "text", "text": " "}, {"type": "usergroup", "usergroup_id": "S08NN8M4LAZ"}, {"type": "text", "text": " "}, {"type": "user", "user_id": "U03BLQ65GK0"}, {"type": "text", "text": "\n抹茶44の納期をご連絡いたします。\n・960kg…6/2日納品\n・117kg…6/3日納品\n・923kg…6/9日納品\n・558kg…6/10日納品\n合計納品数量：2,558kg\n＊今回納品分より納品単価3,500円/kgとなります。"}]}]}]}}], "id": 1, "original_url": "https://grp-ssm9297.slack.com/archives/C089D005K0S/p1747640051321669?thread_ts=1745805255.741359&amp;cid=C089D005K0S", "fallback": "[May 19th, 2025 12:34 AM] tousuien.s006: <@U0331FZS7JT>\n <!subteam^S088LEJ1U5T> <!subteam^S073HEMKWV7> <!subteam^S08NN8M4LAZ> <@U03BLQ65GK0>\n抹茶44の納期をご連絡いたします。\n・960kg…6/2日納品\n・117kg…6/3日納品\n・923kg…6/9日納品\n・558kg…6/10日納品\n合計納品数量：2,558kg\n＊今回納品分より納品単価3,500円/kgとなります。", "text": "<@U0331FZS7JT>\n <!subteam^S088LEJ1U5T> <!subteam^S073HEMKWV7> <!subteam^S08NN8M4LAZ> <@U03BLQ65GK0>\n抹茶44の納期をご連絡いたします。\n・960kg…6/2日納品\n・117kg…6/3日納品\n・923kg…6/9日納品\n・558kg…6/10日納品\n合計納品数量：2,558kg\n＊今回納品分より納品単価3,500円/kgとなります。", "author_name": "Hirakawa", "author_link": "https://grp-ssm9297.slack.com/team/U041RJKV5JA", "author_icon": "https://avatars.slack-edge.com/2022-09-11/4078874890257_aed9eafd9eee277ba076_48.png", "author_subname": "Hirakawa", "mrkdwn_in": ["text"], "footer": "Slack の会話内のスレッド"}]
- [1750038521.970969] <@U041RJKV5JA>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
＜明石屋＞
ビートグラニュー糖BGF 20kg×6袋
入荷日：6月16日（月）

## 2025-06-16

- [1750060325.466769] <@U041RJKV5JA>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
＜清和＞
・No. 240
入荷日：6月18日（静岡倉庫出荷分）
　　　　6月19日（埼玉倉庫出荷分）

## 2025-06-17

- [1750152023.704979] <@U05KGS6HN9H>: <@U0331FZS7JT> *<!channel>*
碧翠園より販売休止の案内が届きましたので情報共有致します。
海外向け出荷実績では、CHS（Chaseki/タイ）に関係する内容です。
  - files: [{"id": "F091TLURN5A", "created": 1750152013, "timestamp": 1750152013, "name": "20250617_碧翠園案内.pdf", "title": "20250617_碧翠園案内.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 349832, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F091TLURN5A/20250617________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F091TLURN5A/download/20250617________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F091TLURN5A-f0b231ccea/20250617_________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F091TLURN5A/20250617________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F091TLURN5A-32e186061e", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-06-18

- [1750246568.686919] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0331FZS7JT> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
*鹿児島製茶*
価格確認中（6/18現在未定）
分かり次第共有願います。
- [1750246609.829519] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0331FZS7JT> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
*碧翠園*
価格確認中（6/18現在未定）
分かり次第共有願います。
- [1750247410.041889] <@U0331FWGQRM>: ~<@U03BLQ65GK0>~ ~<@U0331FZS7JT> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>~
~*葵製茶*~
~価格確認中（6/18現在未定）~
~分かり次第共有願います。~
- [1750247426.903719] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0331FZS7JT> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
*香岳園*
価格確認中（6/18現在未定）
分かり次第共有願います。

香岳園1700→2,200
香岳園4500→6,000
香岳園2500→4,000
香岳園6000→？？？
ーーーー
ほうじ茶原料　K1400→2000
- [1750247456.748549] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0331FZS7JT> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
*和香園*
価格確認中~（6/18現在未定）~
分かり次第共有願います。

ーーーーーーーーーーーー
2025/06/30
抹茶44　
1㎏×25個以上                 6,240円
20㎏バルク            6,100円

抹茶1B
1㎏×25個以上                 11,500円
20㎏バルク            11,100円
ーーーーーーーーーーーー
- [1750247553.761869] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0331FZS7JT> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
*水宗園*
価格確認中（6/18現在未定）
分かり次第共有願います。
- [1750247585.173719] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0331FZS7JT> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
*大石製茶*
価格確認中（6/18現在未定）
分かり次第共有願います。
- [1750313483.224159] <@U03BLQ65GK0>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
一旦現時点で分かっている情報共有します。
*鹿児島製茶*
種類：碾茶
品名：碾茶桃25（EU・US）
単価：6,500
数量：3,530kg
- [1750314457.261579] <@U0331FZS7JT>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U03BLQ65GK0>
*葵製茶（基本は碾茶で購入）*
▼碾茶
NA：16,000/kg
NB：14,000/kg
NC：11,000/kg

▼抹茶
NA：18,000/kg
NB：16,000/kg
NC：13,000/kg

供給可能量：確認中
  - files: [{"id": "F091Z0N8A30", "created": 1750314270, "timestamp": 1750314270, "name": "桃翠園様　西尾抹茶　御見積書.pdf", "title": "桃翠園様　西尾抹茶　御見積書.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 305104, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F091Z0N8A30/__________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F091Z0N8A30/download/__________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F091Z0N8A30-c9c3a7e142/___________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1286, "thumb_pdf_h": 910, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F091Z0N8A30/__________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F091Z0N8A30-8a1b958566", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F092J0X3909", "created": 1750314272, "timestamp": 1750314272, "name": "桃翠園様　西尾碾茶　御見積書.pdf", "title": "桃翠園様　西尾碾茶　御見積書.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 295483, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F092J0X3909/__________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F092J0X3909/download/__________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F092J0X3909-4f8d835af7/___________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1286, "thumb_pdf_h": 910, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F092J0X3909/__________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F092J0X3909-f763c0fb0e", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1750316037.788359] <@U0331FZS7JT>: <@U03BLQ65GK0> <@U0840UVFVA8>
出雲抹茶Rについて
※内容確定後、調達の価格改定まとめに反映

## 2025-06-19

- [1750318581.454079] <@U0331FZS7JT>: <@U03BLQ65GK0> <@U0840UVFVA8>

農薬海外対応
出雲精茶産
原価：￥6,869/kg
数量：◯◯kg
（品種内訳）

海外非対応
原料：◯◯
原価：￥◯◯/kg
数量：◯◯kg

最終確定させる際の反映内容
・モガの割合
・他産地碾茶の比率

R用に混ぜる原料
▼海外向け
・出雲
・鹿児島製茶
・JA鹿児島
・水宗園

▼国内向け
・出雲
・モガ（中島製茶、茗広、JA鹿児島？）

<https://docs.google.com/spreadsheets/d/18MEmTbufMzD7xGD8-J8NyjvnoymQARiG4o7T1taPGfY/edit?gid=1241715023#gid=1241715023>

## 2025-06-22

- [1750638732.606769] <@U041RJKV5JA>: <!channel>
香岳園より「ほうじ茶原料　K1400」の価格改訂の連絡がございました。
旧価格：1400円→新価格：2000円
改訂価格適用日：6月23日
取扱商品一覧表に反映いたします。
- [1750639914.765149] <@U05KGS6HN9H>: 《6/23ひかわ納期回答》
　　6月末予定残　70kg
　　7月末予定分　20kg
　-----------------------------
　　合計90kg　→6/25入荷
- [1750640215.652929] <@U041RJKV5JA>: <!channel>
星野製茶より本年の供給可能量の連絡がございました。
・星峰 0kg
・池の白 10kg
・星の露 18kg
・八女の露 55kg
・八女の華 150kg
・もくれん 170kg
・やまぶき 30kg
・こでまり 250kg
・さざんか 50kg
・あじさい 0kg
「あじさい」につきましては、原料が揃わないため本年は製造できないとのことです。
そのため、１つ上のグレードの「さざんか」を供給いただけるよう依頼しました。
秋口までの状況を見て、さらに供給が可能となった場合には、追加でのご提供もお願いできる見込みです。

## 2025-06-23

- [1750734964.536199] <@U0331FWGQRM>: *星野製茶*
供給可能量
・星峰 0kg
・池の白 10kg
・星の露 18kg
・八女の露 55kg
・八女の華 150kg
・もくれん 170kg
・やまぶき 30kg
・こでまり 250kg
・さざんか 50kg
・あじさい 0kg

## 2025-06-24

- [1750815328.704699] <@U041RJKV5JA>: <@U0331FZS7JT> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
和香園　抹茶44 1200kg出荷予定日
・600kg：7月10日出荷予定
・600kg：7月23日出荷予定

## 2025-06-25

- [1750904276.109689] <@U0331FZS7JT>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> 
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 
碧翠園
有機碾茶サンプル(碧翠園過年度在庫)
碧翠園国産有機抹茶12000のと同等のものができそうとのこと。
サンプル依頼済み
※合計40kg弱

## 2025-06-26

- [1750923917.404179] <@U041RJKV5JA>: <!channel>
【価格改定】
福田龍
有機ペパーミント（エジプト産）
旧価格：2000円→新価格：2700円
- [1750984187.491689] <@U041RJKV5JA>: <!channel>
丸久小山園より価格改定の連絡がありました。
改定日：2025年7月1日
  - files: [{"id": "F092W7661SB", "created": 1750984173, "timestamp": 1750984173, "name": "丸久小山園価格改定（2025.07.01〜）.pdf", "title": "丸久小山園価格改定（2025.07.01〜）.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 3058576, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F092W7661SB/______________________________2025.07.01______.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F092W7661SB/download/______________________________2025.07.01______.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F092W7661SB-3d42ec4ff7/______________________________2025.07.01_______thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1287, "thumb_pdf_h": 910, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F092W7661SB/______________________________2025.07.01______.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F092W7661SB-9acaf09a7b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-07-01

- [1751435726.400129] <@U0331FZS7JT>: <@U0331FWGQRM> <@U08L89G6JSG>
このURLです

## 2025-07-02

- [1751522808.029249] <@U0331FZS7JT>: <@U08RVRNBY00>
林さんの画面に映っているスプレッドシートです
<https://docs.google.com/spreadsheets/d/18MEmTbufMzD7xGD8-J8NyjvnoymQARiG4o7T1taPGfY/edit?gid=1241715023#gid=1241715023>

## 2025-07-03

- [1751588386.555379] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0331FZS7JT> <@U0840UVFVA8> cc <!channel>
最近、資材や抹茶の原料などの品質問題がかなりあります。
注文数が増えているので、自ずと不良品も増えるのは理解できますが、
見過ごすわけにはいかないので、品質管理体制を整える必要があります。

碾茶、抹茶、資材など、（ほとんど）すべての取り扱うものについて、
入荷した時点で品質確認を行う体制を組みたいと思います。
※ほとんど、と言ったのは、既成商品（ALの袋やダンボールなど）は不要という意味。

調達チームを作って（2人くらい）調達と品質管理の業務をしたいと思います。
・在庫管理と発注
・入荷時期のスケジューリング
・品質管理のスケジューリング

採用計画含めてまた相談させてください。
- [1751589458.828679] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <@U03BLQ65GK0>
*香岳園*
からラインナップの全リストが届きましたので共有します。
※昨年まで単一品種で購入していた下記の製品は、単一品種ではなく品種ブレンドのものになりました。
理由は抹茶の調達量が足らず、ブレンドして製品化しなければ価格に見合った製品を供給できないためとのことです。
・うじひかり
・つゆひかり
・さえみどり

<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
仕入れの際に商品名はそのままですが、価格が異なるので
ご注意下さい。
例：（商品名）香岳園K50000→(価格)¥70000

<@U08RVRNBY00>
原料登録への反映をお願い致します。
不明な点があればご連絡下さい。

よろしくお願いします。
  - files: [{"id": "F0946U2UEEA", "created": 1751588908, "timestamp": 1751588908, "name": "2025香岳園.pdf", "title": "2025香岳園.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 539394, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0946U2UEEA/2025_________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0946U2UEEA/download/2025_________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0946U2UEEA-295e3760bc/2025__________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1576, "thumb_pdf_h": 1114, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0946U2UEEA/2025_________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F0946U2UEEA-1a39894ebf", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1751593076.452099] <@U0331FWGQRM>: <@U066P20UQH1> <@U08RVRNBY00> cc <!channel>
（桃翠園フォルダ＞価格関係　の中にあります。）
コロコロ変わってすみません。
出雲抹茶の価格はこれでお願いします！:sweat_drops:
  - files: [{"id": "F094D232HU4", "mode": "tombstone"}]
- [1751593214.112359] <@U0331FWGQRM>: 
  - files: [{"id": "F094Q8PNDED", "created": 1751593208, "timestamp": 1751593208, "name": "・出雲抹茶価格（20250704）.xlsx", "title": "・出雲抹茶価格（20250704）.xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 42255, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F094Q8PNDED/________________________20250704___.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F094Q8PNDED/download/________________________20250704___.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F094Q8PNDED-a9d6fd111c/________________________20250704____converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F094Q8PNDED-a9d6fd111c/________________________20250704____thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1113, "thumb_pdf_h": 788, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F094Q8PNDED/________________________20250704___.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F094Q8PNDED-ad59083b3f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-07-06

- [1751853837.057239] <@U0331FWGQRM>: メモ
ーーー
（旧）
Top-1　碧翠園16000京都
*Top-2　碧翠園12000京都*
*Upp-1　鹿児島A　水宗園9000*
Upp-2　鹿児島1A（鹿児島A：鹿児島B＝1：1）

（新）
Top-1　供給不可。ない（9月まで不明）
*Top-2　鹿児島A　水宗園13000（300kg）*
*Upp-1　（鹿児島A　水宗園13000）＋何かを混ぜる？*
Upp-2　鹿児島1A（鹿児島A：鹿児島B）
ーーー
7/9（水）水宗園13000（旧9000）100kg入荷
→元々、鹿児島製茶　有機抹茶A（=Top-2）

7/末に鹿児島A碾茶着→１週間後粉砕完了。品質確認
鹿児島Bは在庫を使用（870kg）2025年度分は9月の下旬着。

※碧翠園　京都12000がわずかに在庫あり（10kg）

※碧翠園10500
→水宗園13000 (鹿児島A)+鹿児島B

## 2025-07-07

- [1751944348.459539] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
福田龍の桃翠園担当の方が
司馬様→吉田様
に変わりました。
電話：<tel:0663645861|06-6364-5861>
mail：<mailto:yoshida@fukudaryu.co.jp|yoshida@fukudaryu.co.jp>

顧客管理表の「原料登録」その他（AO列）と
Excelの「取り扱い一覧」に上記連絡先記載しています。
よろしくお願いします。

## 2025-07-09

- [1752116314.771099] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
*中国製缶仕入れについて*
*（2025年6月発注分）*
- [1752116358.612039] <@U0331FWGQRM>: 6/30入荷
　60×68　銀　5000pcs（200入×25箱）
　60×60　銀　5040pcs（240入×21箱）
　底ふた（4箱）

7/11入荷（予定）
　60×60　白　5000pcs
　60×68　白　5000pcs

<https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1751269699176119?thread_ts=1747126757.485039&amp;cid=C03C62NBSDP>
  - attachments: [{"from_url": "https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1751269699176119?thread_ts=1747126757.485039&amp;cid=C03C62NBSDP", "ts": "1751269699.176119", "author_id": "U05KGS6HN9H", "channel_id": "C03C62NBSDP", "channel_team": "T033D70RR6H", "is_msg_unfurl": true, "is_reply_unfurl": true, "message_blocks": [{"team": "T033D70RR6H", "channel": "C03C62NBSDP", "ts": "1751269699.176119", "message": {"blocks": [{"type": "rich_text", "block_id": "48yMY", "elements": [{"type": "rich_text_section", "elements": [{"type": "user", "user_id": "U0331FWGQRM"}, {"type": "text", "text": "\n"}, {"type": "usergroup", "usergroup_id": "S088LEJ1U5T"}, {"type": "text", "text": " "}, {"type": "usergroup", "usergroup_id": "S073HEMKWV7"}, {"type": "text", "text": "\n本日、中国からプルトップスクリュー缶が入荷しましたが、INVOICEと相違があります。\n・INVOICE\n　60×60　白　5000pcs\n　60×60　銀　5000pcs\n・現物\n　60×68　銀　5000pcs（200入×25箱）\n　60×60　銀　5040pcs（240入×21箱）\n　底ふた（4箱）\n白に変えて、OST-004で使用する60×68銀を出荷いただいたという\n認識でOKでしょうか？"}]}]}]}}], "id": 1, "original_url": "https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1751269699176119?thread_ts=1747126757.485039&amp;cid=C03C62NBSDP", "fallback": "[June 30th, 2025 12:48 AM] tousuien05: <@U0331FWGQRM>\n<!subteam^S088LEJ1U5T> <!subteam^S073HEMKWV7>\n本日、中国からプルトップスクリュー缶が入荷しましたが、INVOICEと相違があります。\n・INVOICE\n　60×60　白　5000pcs\n　60×60　銀　5000pcs\n・現物\n　60×68　銀　5000pcs（200入×25箱）\n　60×60　銀　5040pcs（240入×21箱）\n　底ふた（4箱）\n白に変えて、OST-004で使用する60×68銀を出荷いただいたという\n認識でOKでしょうか？", "text": "<@U0331FWGQRM>\n<!subteam^S088LEJ1U5T> <!subteam^S073HEMKWV7>\n本日、中国からプルトップスクリュー缶が入荷しましたが、INVOICEと相違があります。\n・INVOICE\n　60×60　白　5000pcs\n　60×60　銀　5000pcs\n・現物\n　60×68　銀　5000pcs（200入×25箱）\n　60×60　銀　5040pcs（240入×21箱）\n　底ふた（4箱）\n白に変えて、OST-004で使用する60×68銀を出荷いただいたという\n認識でOKでしょうか？", "author_name": "Adachi", "author_link": "https://grp-ssm9297.slack.com/team/U05KGS6HN9H", "author_icon": "https://secure.gravatar.com/avatar/c4e7258333f2958f831d063db85b4542.jpg?s=48&d=https%3A%2F%2Fa.slack-edge.com%2Fdf10d%2Fimg%2Favatars%2Fava_0005-48.png", "author_subname": "Adachi", "mrkdwn_in": ["text"], "footer": "Slack の会話内のスレッド"}]

## 2025-07-12

- [1752308513.082989] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
＜和香園　抹茶1B＞
・1kg×175本　7月26日（土）出荷、7月28日（月）着予定
・1kg×150本　8月中（作業スケジュール調整中）
- [1752313887.005359] <@U0331FZS7JT>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U03BLQ65GK0> <!subteam^S08NN8M4LAZ|@katayose-kamiya>
宇治抹茶（単一品種）の価格表を出雲抹茶同様、
（桃翠園フォルダ＞価格関係）にまとめます。
ファイル名：宇治抹茶単一品種価格（20250711）
現在途中ですが、週明けまでに届いている品種は確定できます。
来週のところで未記載の品種も確定する予定です。
確定後お知らせします。
※八女抹茶も同様。

よろしくお願いします！
  - files: [{"id": "F0965GFJ3EC", "created": 1752313880, "timestamp": 1752313880, "name": "・宇治抹茶単一品種価格（20250711).xlsx", "title": "・宇治抹茶単一品種価格（20250711).xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 40332, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0965GFJ3EC/____________________________________20250711_.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0965GFJ3EC/download/____________________________________20250711_.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0965GFJ3EC-52b00dafb5/____________________________________20250711__converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0965GFJ3EC-52b00dafb5/____________________________________20250711__thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1113, "thumb_pdf_h": 788, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0965GFJ3EC/____________________________________20250711_.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F0965GFJ3EC-67189dd484", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-07-14

- [1752541743.065879] <@U05KGS6HN9H>: <@U0331FZS7JT>
<!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
《共有》
7/23（水）入荷予定
香岳園/宇治抹茶2200（従来のK1700相当）　20kg bulk
香岳園/宇治抹茶4000（従来のK2500相当）　20kg bulk
香岳園/宇治抹茶7500（従来のK4500相当）　10kg bulk

## 2025-07-16

- [1752722484.170709] <@U03BLQ65GK0>: <@U0331FZS7JT> cc <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
星野製茶の抹茶代替品について
●経緯　※cc入れてる人にも伝えるため書きます
水宗園の碾茶を使用することが決定している
↓
吉田園の2025年産八女150号も使えるかどうかを確認

●検証方法
使用が決定している水宗園の碾茶と比較して判断する。
→水宗園の碾茶は9種あり、その内の上位グレードと比較する。
※<@U0331FZS7JT> 下のランクと比較すると電話では言っていましたが、
茶葉の外観が明らかに上位グレードレベルでしたので比較対象と比較方法を変更しました

●結果
比較対象：9810
【外観】
粉体の色9810に対して明るく、鮮やか
【水色】
9810の方が深い緑で150号は明るく鮮やかな緑（若干黄色っぽい）
【内質】
基本的な旨味は同程度だが、150号の方が火香が強く、その為旨味をより濃く感じる。
香りは抹茶としての風味は近く、大きな欠点はない。
【150号の特徴】
・風味はしっかりと火香があるためDRは不要と判断（色を残す意味でも）
・仕上不要

●結論
代替品として成立する。
→単価が15,000円と水宗園のものより約2,000円低く、値落とし材として使用できるのはもちろんのこと、
質としては水宗園の上位のものと変わらないので、全体的な引き上げ役としても使用できる。
ただし火香が強いためか水色が若干黄色っぽいので、他のお茶をDRしたものとの比較検討が再度必要。
  - files: [{"id": "F09688HMZ7E", "created": 1752721977, "timestamp": 1752721977, "name": "IMG_0931.jpg", "title": "IMG_0931.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 1763143, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09688HMZ7E/img_0931.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09688HMZ7E/download/img_0931.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09688HMZ7E-4ffec110d6/img_0931_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09688HMZ7E-4ffec110d6/img_0931_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09688HMZ7E-4ffec110d6/img_0931_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09688HMZ7E-4ffec110d6/img_0931_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09688HMZ7E-4ffec110d6/img_0931_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09688HMZ7E-4ffec110d6/img_0931_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09688HMZ7E-4ffec110d6/img_0931_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09688HMZ7E-4ffec110d6/img_0931_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09688HMZ7E-4ffec110d6/img_0931_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 4032, "original_h": 3024, "thumb_tiny": "AwAkADCvHHuOADTzbEH7ygHtVoosCEjnPpURaMEne/P+z/8AXoYhhh2/T1ppTnAGT7VMjjIALMHPOeKdJhG2IcMR1xz9KLhchFs56lV+p/wqJkkjA8wYJ9KkOVPWrEREyFH5pJhcbG/nwFQfnXoKquT0IxTFkaM7lYg1L9tVv9ZCrH1BxQ1cAhHzbmO1F5Jp7SNMizAjd0bb2NVpbhpBt4Vf7q8A02KZoWJU8HqD0NFtAJsmrdoMbnPAx3qsLqAgkwkHtg9aHu2lXYo2LjBAPWkohYqtTTTm6009asYUlLSUALQKKKAP/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09688HMZ7E/img_0931.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F09688HMZ7E-4667a69471", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0963BSHFPG", "created": 1752721984, "timestamp": 1752721984, "name": "IMG_0930.jpg", "title": "IMG_0930.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U03BLQ65GK0", "user_team": "T033D70RR6H", "editable": false, "size": 2560902, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0963BSHFPG/img_0930.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0963BSHFPG/download/img_0930.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0963BSHFPG-41e2201452/img_0930_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0963BSHFPG-41e2201452/img_0930_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0963BSHFPG-41e2201452/img_0930_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0963BSHFPG-41e2201452/img_0930_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0963BSHFPG-41e2201452/img_0930_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0963BSHFPG-41e2201452/img_0930_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0963BSHFPG-41e2201452/img_0930_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0963BSHFPG-41e2201452/img_0930_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0963BSHFPG-41e2201452/img_0930_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 4032, "original_h": 3024, "thumb_tiny": "AwAkADC/mmu7hGKIWYdBnGaSdtsLEHBxVLzZWAcuR9KluwF9GLIpIwSMkZzilYkKSo3EDgZ61FbSGWLJ6jikuJdmEQ/OT6dqdwFEsvmBWhwpON27Pb+VTVTFy6kbjuB9R/hVpGDqGXoaE7gISCMHpVN08veAAFxx39asE1DMpIY/7OBz9aTAnhHlRhe/f60y6AaIttyy80801vmQj1GKYFZ8PsCqcseD/OrcbCNEQ9cVUV8iPDdwPzGDzVrJ3DnvUoBnekcbmQHpn+ho70p/1ifX+hqgHmm9qcab2oArP8sYx2f/ABqyPXvVaX/Vf8D/AMatD+tJAf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0963BSHFPG/img_0930.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0963BSHFPG-be11537391", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1752722571.174009] <@U0331FZS7JT>: <@U03BLQ65GK0> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
確認ありがとうございます！
では<@U041RJKV5JA>全量購入でお願いします！

## 2025-07-20

- [1752996237.705969] <@U0331FZS7JT>: メモ
9803（水宗園八女オクミドリの一番良い）と同じ品質か確認

## 2025-07-21

- [1753145961.228189] <@U033G4KN4TD>: <@U041RJKV5JA> <@U0840UVFVA8>
CC:<@U03BLQ65GK0> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
Sebastyan必要原料数量のご報告
*TSE-MTL-013-25・８月中旬出荷分*
```抹茶R-mixS：873.18㎏
バニラパウダーB7355：89㎏（在庫69.2㎏）
シナモン(カシア)パウダー：8.4㎏（在庫20㎏）
ココナッツパウダーB7664：4.68㎏（在庫6.2㎏）
ラズベリーミクロンMQ16867：2.34㎏（在庫12.1㎏）```
抹茶の準備、バニラパウダーの発注をお願いします。
- [1753159991.470769] <@U0331FZS7JT>: 吉田園150号（碾茶¥15,000/kg）
150kg

## 2025-07-22

- [1753169599.115229] <@U041RJKV5JA>: <@U033G4KN4TD>
香岳園　K9000おくみどり
納品日：7月25日（金）
- [1753170462.941599] <@U041RJKV5JA>: <@U0331FZS7JT>
 <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
＜和香園　抹茶44＞
・納品数量：
　1kg×1200袋
　20kg×80袋
・納品日：7月25日（金）
- [1753230753.283749] <@U041RJKV5JA>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
キタマ　バニラパウダー
・1kg×30袋（RSD用）　7月24日着　＠出雲精茶
・1kg×90袋（MTL用）　7月28日着　＠出雲精茶

## 2025-07-23

- [1753326115.580249] <@U041RJKV5JA>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
キタマ　バニラパウダー
・1kg×50袋（MTL用）　7月30日着　＠出雲精茶
- [1753328841.722839] <@U033G4KN4TD>: <!channel>
缶在庫のお知らせ
```アメリカ MIA-ZACHARY SARDINIAアリババ)様から注文予定を頂きました。
イスラエル向け案件
TSE-MIA-005-25```
上記案件で60×100の缶（色は確認中）
3000缶注文の可能性あり（確定？）→不足となる見込み

```TSE-OST-001-25
OSSU tea様```
OSSU TEA様60×68シルバー　900缶注文あり
在庫1,555缶
  - files: [{"id": "F0979AD9RK6", "created": 1753328495, "timestamp": 1753328495, "name": "20250724.pdf", "title": "20250724.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 786044, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0979AD9RK6/20250724.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0979AD9RK6/download/20250724.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0979AD9RK6-e3c3b02680/20250724_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1286, "thumb_pdf_h": 910, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0979AD9RK6/20250724.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F0979AD9RK6-1e87533350", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1753328863.317559] <@U05KGS6HN9H>: 《7/24ひかわ納期回答》
　7月末予定残　80kg
　8月末予定分　70kg
----------------------------
　合計150kg　→7/25入荷

## 2025-07-24

- [1753343677.447779] <@U0331FWGQRM>: <@U08N3SKSL75>
```アメリカ MIA-ZACHARY SARDINIAアリババ)様から注文予定を頂きました。
イスラエル向け案件
TSE-MIA-005-25```
この案件用の缶を準備する必要がありますが、色って事前にわかりますか？？？？
60×100の缶（色不明）
- [1753406678.841419] <@U041RJKV5JA>: <!channel>
＜明石屋＞
ビートグラニュー糖 BGF 20kg について
 製造メーカーの都合により、8月中旬から11月上旬までの期間、内容量が30kgに変更になるとの連絡がありました。
ただし、具体的に8月の何日から変更となるかは不明とのことですので、発注の際には事前の確認をお願いいたします。

## 2025-07-29

- [1753840450.095219] <@U041RJKV5JA>: <@U0331FZS7JT>
 <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
＜神戸スパイス＞
クローブパウダー　20kg×3袋
納品日：8月1日午前中
＊「クローブパウダー20㎏は原材料として直輸入しておりますので、 まれに夾雑物が混ざる場合がございます。」とのことですので、篩作業が必要となります。
　確認したところ、篩では除去が難しいほど細かい夾雑物が含まれている可能性はほぼないとのことです。

## 2025-07-30

- [1753922237.582499] <@U033G4KN4TD>: <!channel>
オーガニックシナモンスティック10㎏が届いております。
発注者が分かりませんので、皆様にご連絡いたします。
ご確認お願いいたします。
  - files: [{"id": "F09855RPPFV", "created": 1753921839, "timestamp": 1753921839, "name": "S__259194889.jpg", "title": "S__259194889.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 438435, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09855RPPFV/s__259194889.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09855RPPFV/download/s__259194889.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09855RPPFV-cd29655422/s__259194889_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09855RPPFV-cd29655422/s__259194889_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09855RPPFV-cd29655422/s__259194889_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 203, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09855RPPFV-cd29655422/s__259194889_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 270, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09855RPPFV-cd29655422/s__259194889_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09855RPPFV-cd29655422/s__259194889_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 405, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09855RPPFV-cd29655422/s__259194889_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 450, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09855RPPFV-cd29655422/s__259194889_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 540, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09855RPPFV-cd29655422/s__259194889_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 576, "original_w": 1706, "original_h": 960, "thumb_tiny": "AwAcADCWIjYSQDzUvH8IBqukgQYIzk8YNKbj0Uj6n/69NLQlk52jqAOaRGIJB29AflFMjm8xwAMCpM4GWwPWmIRS2759vsBVTcauAg8iqOaljQ88DPoaYzs3HTNPUbwQ3SlMS+pqovQb3GwsFck5IxzVlpkXGSTk44HTHWoY0CuO46c81OqKFAAwPY0MQHnkcj61Sq7gKAB0HAqhk1LGj//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09855RPPFV/s__259194889.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F09855RPPFV-6b5e44a307", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1753922515.427979] <@U0331FZS7JT>: <@U03BLQ65GK0> 
前に頼んでませんでしたっけ？
一緒です？
- [1753923373.608759] <@U0331FZS7JT>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <@U03BLQ65GK0>
製品到着後、まとめて篩をお願いします。
篩後のものでいつでも使えるように準備をお願いします。
- [1753924365.438089] <@U03BLQ65GK0>: <@U0331FZS7JT>
私はこれは全くのノータッチですよ。
（これを使った製品製造とかは関わってるかもしれませんが）
- [1753924693.605079] <@U0331FZS7JT>: <@U03BLQ65GK0>
そうでしたっけ。
以前、シナモンスティックを国内のどっかから頼まれて代わりに準備する、
的な内容を聞いたような記憶があったので:sweat_drops:
了解です。
- [1753924934.628979] <@U03BLQ65GK0>: <@U0331FZS7JT>
いやぁ…記憶にないですね。
他の誰かだと思いますよ...
何か委託加工でも受けてたっけと思って調べてみましたがそういうのもないですし。
<@U033G4KN4TD> <@U0840UVFVA8>
直近でシナモンを使った何かの加工の予定って無いんですか？
- [1753926201.264979] <@U033G4KN4TD>: <@U03BLQ65GK0>
海外案件で使用予定はありません。

以前もありましたが、その時は(株)大和様
依頼分でした。
<https://grp-ssm9297.slack.com/archives/C033G42K9DG/p1738771889965649?thread_ts=1738745698.323819&amp;cid=C033G42K9DG>
  - attachments: [{"from_url": "https://grp-ssm9297.slack.com/archives/C033G42K9DG/p1738771889965649?thread_ts=1738745698.323819&amp;cid=C033G42K9DG", "ts": "1738771889.965649", "author_id": "U0331FZS7JT", "channel_id": "C033G42K9DG", "channel_team": "T033D70RR6H", "is_msg_unfurl": true, "is_reply_unfurl": true, "message_blocks": [{"team": "T033D70RR6H", "channel": "C033G42K9DG", "ts": "1738771889.965649", "message": {"blocks": [{"type": "rich_text", "block_id": "JdX0T", "elements": [{"type": "rich_text_section", "elements": [{"type": "usergroup", "usergroup_id": "S073HEMKWV7"}, {"type": "text", "text": " "}, {"type": "usergroup", "usergroup_id": "S072Q871SF9"}, {"type": "text", "text": "\n株式会社大和 様　依頼分とあります。\n"}, {"type": "user", "user_id": "U03BLQ65GK0"}, {"type": "text", "text": " ですか？\n"}]}]}]}}], "files": [{"id": "F08CL406UUQ", "created": 1738771692, "timestamp": 1738771692, "name": "IMG_4112.jpg", "title": "IMG_4112", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 1131136, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08CL406UUQ/img_4112.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08CL406UUQ/download/img_4112.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08CL406UUQ-199237c862/img_4112_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08CL406UUQ-199237c862/img_4112_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08CL406UUQ-199237c862/img_4112_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08CL406UUQ-199237c862/img_4112_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08CL406UUQ-199237c862/img_4112_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08CL406UUQ-199237c862/img_4112_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08CL406UUQ-199237c862/img_4112_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08CL406UUQ-199237c862/img_4112_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08CL406UUQ-199237c862/img_4112_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACR2CQMcUqj3psIYrk4x2qXBxnj86AEA96XHfj8qXDdKMN9fyoEQMPmNJQTkk0magsfFzGvFSgHA24zVeAnYPTPNWOCAOfwqiSZenTmkc4UkDpURZl6KPzpHkPlvnA49aAK1LmmZozUlEayMvANPEz+o/KoOhI9KXNMRYE7+o/KmtIzdTx6YqLNGaAH5pN1MJpN1Az//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08CL406UUQ/img_4112.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F08CL406UUQ-e11dafe1eb", "comments_count": 0, "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}], "id": 1, "original_url": "https://grp-ssm9297.slack.com/archives/C033G42K9DG/p1738771889965649?thread_ts=1738745698.323819&amp;cid=C033G42K9DG", "fallback": "[February 5th, 2025 8:11 AM] yuta.oka.0915: <!subteam^S073HEMKWV7> <!subteam^S072Q871SF9>\n株式会社大和 様　依頼分とあります。\n<@U03BLQ65GK0> ですか？", "text": "<!subteam^S073HEMKWV7> <!subteam^S072Q871SF9>\n株式会社大和 様　依頼分とあります。\n<@U03BLQ65GK0> ですか？", "author_name": "Yuta Oka", "author_link": "https://grp-ssm9297.slack.com/team/U0331FZS7JT", "author_icon": "https://avatars.slack-edge.com/2022-02-16/3118160981555_2c9de1514f262063f72d_48.png", "author_subname": "Yuta Oka", "mrkdwn_in": ["text"], "footer": "Slack の会話内のスレッド"}]
- [1753926463.266749] <@U03BLQ65GK0>: <@U033G4KN4TD>
そうなんですね。。
加工の依頼は受けていないので、ちょっと確認します。
ありがとうございました！

## 2025-08-03

- [1754269793.615739] <@U041RJKV5JA>: <@U033G4KN4TD>
＜鹿児島製茶＞
有機碾茶A 200kg
・納品日：8月7日（木）
・納品場所：出雲精茶
- [1754278037.157239] <@U041RJKV5JA>: <@U033G4KN4TD>
＜鹿児島製茶＞
有機碾茶B 300kg
・納品日：8月7日（木）
・納品場所：出雲精茶

## 2025-08-04

- [1754357328.291559] <@U041RJKV5JA>: <!channel>
【星野製茶園】
・納品日：8月22日（金）
・納品アイテム
　池の白　2kg
　星の露　5kg
　八女の露　23kg
　やまぶき　10kg
　さざんか　20kg
- [1754375296.557009] <@U08U8MMTH43>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
以下、中田喜造商店の茶筅商品の納期についての情報共有です。

80本/100本立て：納期リードタイムは不明
　　　　　　　　１回の注文で3～5本までしか発注不可
真茶筅（白、黒）：各毎月10本ずつ定期で発注可能とのこと

よろしくお願いいたします。

## 2025-08-05

- [1754383847.154229] <@U095LLEH09G>: <@U095LLEH09G>さんがチャンネルに参加しました
- [1754449342.616739] <@U08RVRNBY00>: <@U08U8MMTH43>
<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
8月８日に入庫する茶筌があると伺いました。

:black_small_square:*現時点、出荷可能数お教えいただけますでしょうか？*

→CHS様より入荷次第、注文希望あり。
入荷したら全て欲しい。（可能なら合計　月25本定期購入希望であるほどのため）

## 2025-08-06

- [1754469197.756519] <@U08U8MMTH43>: <@U08RVRNBY00>
<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
> :black_small_square:*現時点、出荷可能数お教えいただけますでしょうか？*
80本立て：5本
100本立て：5本
真茶筅、黒：10本

以上が現時点の出荷可能数です。

> （可能なら合計　月25本定期購入希望であるほどのため）
真茶筅、黒：10本
真茶筅、白：5本（10本入荷予定ですが、残り5本はお店の方で在庫確保されるためです）

以上が、毎月入荷予定で海外営業で確保できる数量です。
CHS以外のお客様の注文の兼ね合いはございませんでしたでしょうか？:sweat_drops:
ご確認よろしくお願いいたします。
- [1754516548.767349] <@U08RVRNBY00>: <@U08U8MMTH43> 
cc <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> 

本件ご確認ありがとうございます。
いただいた内容ふまえ、海外営業のみなさんとお客様に確認し、発注いたします。

## 2025-08-07

- [1754613340.941119] <@U0331FWGQRM>: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U03BLQ65GK0>
香岳園の商品名が商品名が価格と紐付いております。
そのため、年度が変わるたびに、認識を誤る可能性がありますので、
商品名を品質に紐付けるように変更しました。
例）
もくれんは毎年もくれんの品質で提供され、
価格が都度変動するイメージ。

なので、香岳園の商品名を添付の通り変更しましたので、
こちらを使用するよう宜しくお願い致します。
  - files: [{"id": "F099BGLUW03", "created": 1754613277, "timestamp": 1754613277, "name": "2025香岳園_商品名追記.pdf", "title": "2025香岳園_商品名追記.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 918981, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F099BGLUW03/2025_________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F099BGLUW03/download/2025_________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F099BGLUW03-cf35080a44/2025__________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1576, "thumb_pdf_h": 1114, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F099BGLUW03/2025_________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F099BGLUW03-e335860210", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1754618817.608059] <@U033G4KN4TD>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
追記
従来：宇治抹茶K9000やぶきた
変更後：宇治抹茶K-JY
従来：宇治抹茶K9000おくみどり
変更後：宇治抹茶K-JO
- [1754620848.834499] <@U0331FWGQRM>: <@U033G4KN4TD> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
相談

宇治抹茶K-J おくみどり
宇治抹茶K-J やぶきた

にします？？
- [1754621936.046889] <@U033G4KN4TD>: <@U0331FWGQRM> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
同じアルファベットがあると、間違いの元なる可能性があるため
~宇治抹茶K-Rで行きたいです。~
金額順でアルファベットを付けているので
ずらした方がよろしいでしょうか？
- [1754621979.118659] <@U08U8MMTH43>: <@U08RVRNBY00>
<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
本日、中田喜造商店様から茶筅の納品ありました。
しかし、納品数ですが聞いていた数と実際に納品された数に相違がありました。

以下、情報共有いたします。
80本立て：5本
100本立て：5本
真茶筅、黒：5本
真茶筅、白：5本

（中田喜造商店に確認とったところ、商品が準備できなかったため5本しか納品できなかった、追加での納品も不可とのことです。）
数量、変更になってしまい申し訳ございません:sweat_drops:
よろしくお願いいたします。
- [1754622219.545539] <@U0331FWGQRM>: <@U033G4KN4TD> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
宇治抹茶K9000おくみどり
宇治抹茶K9000やぶきた
で今まで来ていたので問題ないかと思いましたが、
今までそれに対して扱いずらさを感じていたのであればこれを機に変えた方がいいかもですね。

アルファベット（J）が品質（グレード）を意味しているので、
アルファベットをずらすと、品質の優劣がつくので、
品種違いなだけであれば、
宇治抹茶K-JO：くみどり
宇治抹茶K-JY ：やぶきた

にしますか？
- [1754622267.935329] <@U08RVRNBY00>: <@U08U8MMTH43> CC <@U0331FZS7JT>
ありがとうございます！
別メッセージの通り以下にて進めさせていただけれ幸いです。

```80本立て：5本→CHS-008-25用
100本立て：5本→CHS-008-25用
真茶筅、白：5本→CHS-008-25用
真茶筅、黒：5本→国内（社長より：国内確保）```

- [1754625733.693859] <@U033G4KN4TD>: <@U0331FWGQRM> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
宇治抹茶K-JO：おくみどり
宇治抹茶K-JY ：やぶきた
良いと思います！そうします！

## 2025-08-11

- [1754959621.992229] <@U033G4KN4TD>: メモ
再粉砕必要
- [1754975843.052789] <@U033G4KN4TD>: メモ
60×68シルバー
OST006で600缶使用予定
RBB004で20缶使用予定

*使用後残：852缶予定*

## 2025-08-22

- [1755848787.771749] <@U041RJKV5JA>: <@U0331FZS7JT>
碾茶うじみどり（宇治産）
・納品日：8月29日（金）
・納品場所：出雲精茶

## 2025-08-24

- [1756094146.750509] <@U0331FZS7JT>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U03BLQ65GK0> <!subteam^S08NN8M4LAZ|@katayose-kamiya>
<https://grp-ssm9297.slack.com/archives/C089D005K0S/p1752313887005359?thread_ts=1750016503.852089&amp;cid=C089D005K0S>
価格関係フォルダにある
・宇治抹茶単一品種価格
について更新（品種追加）しましたので、情報共有します。

追加品種：うじみどり
産地：宇治
農薬：慣行
サプライヤー：水宗園（碾茶仕入れ・出雲精茶で粉砕）
製品原価/kg：¥32,107
製品量：427kg

品質
味：旨味かなり強い
パウダー：濃緑色
水色：濃緑色
香り：焙煎結構強め（甘い香り強い）

品種好きなお客様に新規で提案できます（農薬の関係上基本的にアジアや中東）ので、タイミングで提案してみてください。

ご確認、よろしくお願いします。
  - attachments: [{"from_url": "https://grp-ssm9297.slack.com/archives/C089D005K0S/p1752313887005359?thread_ts=1750016503.852089&amp;cid=C089D005K0S", "ts": "1752313887.005359", "author_id": "U0331FZS7JT", "channel_id": "C089D005K0S", "channel_team": "T033D70RR6H", "is_msg_unfurl": true, "is_reply_unfurl": true, "message_blocks": [{"team": "T033D70RR6H", "channel": "C089D005K0S", "ts": "1752313887.005359", "message": {"blocks": [{"type": "rich_text", "block_id": "/c01P", "elements": [{"type": "rich_text_section", "elements": [{"type": "usergroup", "usergroup_id": "S072Q871SF9"}, {"type": "text", "text": " "}, {"type": "usergroup", "usergroup_id": "S088LEJ1U5T"}, {"type": "text", "text": " "}, {"type": "usergroup", "usergroup_id": "S073HEMKWV7"}, {"type": "text", "text": " "}, {"type": "user", "user_id": "U03BLQ65GK0"}, {"type": "text", "text": " "}, {"type": "usergroup", "usergroup_id": "S08NN8M4LAZ"}, {"type": "text", "text": "\n宇治抹茶（単一品種）の価格表を出雲抹茶同様、\n（桃翠園フォルダ＞価格関係）にまとめます。\nファイル名：宇治抹茶単一品種価格（20250711）\n現在途中ですが、週明けまでに届いている品種は確定できます。\n来週のところで未記載の品種も確定する予定です。\n確定後お知らせします。\n※八女抹茶も同様。\n\nよろしくお願いします！"}]}]}]}}], "files": [{"id": "F0965GFJ3EC", "created": 1752313880, "timestamp": 1752313880, "name": "・宇治抹茶単一品種価格（20250711).xlsx", "title": "・宇治抹茶単一品種価格（20250711).xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 40332, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0965GFJ3EC/____________________________________20250711_.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0965GFJ3EC/download/____________________________________20250711_.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0965GFJ3EC-52b00dafb5/____________________________________20250711__converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0965GFJ3EC-52b00dafb5/____________________________________20250711__thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1113, "thumb_pdf_h": 788, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0965GFJ3EC/____________________________________20250711_.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F0965GFJ3EC-67189dd484", "comments_count": 0, "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}], "id": 1, "original_url": "https://grp-ssm9297.slack.com/archives/C089D005K0S/p1752313887005359?thread_ts=1750016503.852089&amp;cid=C089D005K0S", "fallback": "[July 12th, 2025 2:51 AM] yuta.oka.0915: <!subteam^S072Q871SF9> <!subteam^S088LEJ1U5T> <!subteam^S073HEMKWV7> <@U03BLQ65GK0> <!subteam^S08NN8M4LAZ>\n宇治抹茶（単一品種）の価格表を出雲抹茶同様、\n（桃翠園フォルダ＞価格関係）にまとめます。\nファイル名：宇治抹茶単一品種価格（20250711）\n現在途中ですが、週明けまでに届いている品種は確定できます。\n来週のところで未記載の品種も確定する予定です。\n確定後お知らせします。\n※八女抹茶も同様。\n\nよろしくお願いします！", "text": "<!subteam^S072Q871SF9> <!subteam^S088LEJ1U5T> <!subteam^S073HEMKWV7> <@U03BLQ65GK0> <!subteam^S08NN8M4LAZ>\n宇治抹茶（単一品種）の価格表を出雲抹茶同様、\n（桃翠園フォルダ＞価格関係）にまとめます。\nファイル名：宇治抹茶単一品種価格（20250711）\n現在途中ですが、週明けまでに届いている品種は確定できます。\n来週のところで未記載の品種も確定する予定です。\n確定後お知らせします。\n※八女抹茶も同様。\n\nよろしくお願いします！", "author_name": "Yuta Oka", "author_link": "https://grp-ssm9297.slack.com/team/U0331FZS7JT", "author_icon": "https://avatars.slack-edge.com/2022-02-16/3118160981555_2c9de1514f262063f72d_48.png", "author_subname": "Yuta Oka", "mrkdwn_in": ["text"], "footer": "Slack の会話内のスレッド"}]
- [1756096923.849209] <@U041RJKV5JA>: <!channel>
鹿児島製茶より、2025年産 有機碾茶Bの納品価格について連絡がありました。
・原価：9,800円/kg
・確保量：1,500kg
・出荷可能日：9月1日より
なお、2024年産の在庫数量は以下の通りです。
・鹿児島製茶取り置き分：470kg
・出雲精茶粉砕済み（有機抹茶B）：282kg

## 2025-08-25

- [1756165125.399619] <@U033G4KN4TD>: <@U0331FWGQRM>
中国缶の発注はされていますでしょうか？
60×68シルバー
在庫729缶となっております。

## 2025-08-27

- [1756337361.485089] <@U033G4KN4TD>: <@U041RJKV5JA>
有機碾茶A　200㎏発注お願いいたします。
- [1756341531.291409] <@U041RJKV5JA>: <@U033G4KN4TD>
納品日：9月2日（火）出雲精茶着
- [1756353693.247769] <@U08RVRNBY00>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
:black_small_square:*9月の茶筌入荷予定について*
情報がございましたら、ぜひ頂戴したく存じます。

:flag-th:CHSーThomas様より入庫あれば、発注希望いただいております。

## 2025-08-28

- [1756431662.508499] <@U08U8MMTH43>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
小山園から価格改定の案内が来ております。
情報共有いたします。
改定日：2025年11月１日
  - files: [{"id": "F09DDLE0YEL", "created": 1756431455, "timestamp": 1756431455, "name": "小山園、価格改定表.pdf", "title": "小山園、価格改定表.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U08U8MMTH43", "user_team": "T033D70RR6H", "editable": false, "size": 3757092, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09DDLE0YEL/___________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09DDLE0YEL/download/___________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09DDLE0YEL-8b4fc55476/____________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09DDLE0YEL/___________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09DDLE0YEL-77596775bd", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1756441925.945169] <@U05KGS6HN9H>: <@U08RVRNBY00>
<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
海外で使用可能予定となる中田喜造商店（9月）の茶筌入荷ですが、
9/8～13の入荷予定で
・真茶筅（白）10本くらい
・真茶筅（黒）10本くらい
となります。
- [1756449758.648389] <@U0331FZS7JT>: <@U041RJKV5JA> 有機玄米サプライヤー
下記宛にサンプル100g送付願いします。
----
(株)安永商会
〒860-0812
熊本県熊本市中央区南熊本5丁目10−10番8号
<tel:0963641151|096-364-1151>
安永様宛
▼ラベル
有機玄米
100g
株式会社 桃翠園
-----
サンプルを送って製造可能か確認
（製造可能な場合）供給可能量：300kg/月

よろしくお願いします。
<https://ys-cha.com>

## 2025-08-31

- [1756699772.815089] <@U05KGS6HN9H>: <!channel>
香岳園からの宇治抹茶仕入に関しまして、今年はこちらから都度の
発注が無くても、年間供給可能量が入荷する流れとなっております。
添付入荷予定ご参照をお願い致します。
※宇治抹茶K14000＝ブレンド
　注：基本全てブレンド（単一品種なし）
※No.8 K12000、No.16 K20000は、ひかわ様（タイ向け）用
※概要予定の為、香岳園出荷日（＝入荷日）は前後する可能性があります。
  - files: [{"id": "F09DA3EU60H", "created": 1756699749, "timestamp": 1756699749, "name": "20250901_宇治抹茶_香岳園入荷予定.pdf", "title": "20250901_宇治抹茶_香岳園入荷予定.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 345247, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09DA3EU60H/20250901___________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09DA3EU60H/download/20250901___________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09DA3EU60H-2e605b2700/20250901____________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09DA3EU60H/20250901___________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09DA3EU60H-830d0e4cbf", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1756702790.137179] <@U08N3SKSL75>: <@U0331FWGQRM>
イスラエル向け案件、60×100の缶（色不明）の件、一旦キャンセル扱いでお願いします。

## 2025-09-01

- [1756721605.396769] <@U0331FWGQRM>: *中国製缶仕入れについて*
*（2025年8月発注分）*
- [1756721897.032429] <@U0331FWGQRM>: AIR Shipment:
　60×60Hmm: 5,000 pcs – Silver
　60×68Hmm: 10,000 pcs – Silver
　60×85Hmm: 1,000 pcs – White

SEA Shipment:
　60×60Hmm: 5,000 pcs – Silver
　60×68Hmm: 10,000 pcs – Silver

ーーーーーーーーーー
国内用
60x68Hmm
3000pcs green matte（pantone 3305）
3000pcs cream matte （pantone 7499）
ーーーーーーーーーー
- [1756722581.832009] <@U0331FWGQRM>: <@U033G4KN4TD>
はい、発注していて、ほぼ製造は完了してます！
いつまでにいるとかありますか？？？
- [1756768689.719189] <@U033G4KN4TD>: <@U0331FWGQRM>
ありがとうございます！
OSSU TEAの注文前に届くと助かります :pray:
- [1756791311.669239] <@U041RJKV5JA>: 【安永商会】
・有機玄米
　年間供給可能量：300kg

## 2025-09-09

- [1757468068.499149] <@U08L89G6JSG>: 本日入荷しました！
入庫処理が必要なものでしたら仮入庫の入力お願いします:woman-bowing:
  - files: [{"id": "F09F7NV4VFS", "created": 1757468019, "timestamp": 1757468019, "name": "IMG_0988.jpg", "title": "IMG_0988", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U08L89G6JSG", "user_team": "T033D70RR6H", "editable": false, "size": 933133, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09F7NV4VFS/img_0988.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09F7NV4VFS/download/img_0988.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09F7NV4VFS-a44e44f21d/img_0988_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09F7NV4VFS-a44e44f21d/img_0988_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09F7NV4VFS-a44e44f21d/img_0988_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09F7NV4VFS-a44e44f21d/img_0988_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09F7NV4VFS-a44e44f21d/img_0988_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09F7NV4VFS-a44e44f21d/img_0988_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09F7NV4VFS-a44e44f21d/img_0988_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09F7NV4VFS-a44e44f21d/img_0988_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09F7NV4VFS-a44e44f21d/img_0988_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 4032, "original_h": 3024, "thumb_tiny": "AwAkADC4vKjjtSggjI5BowAe2aRVCqBnOKADb0xRt56fjSk+9Ju5oAbvTjDZz6UqsGfAHrjPfHWhsnABxQOh4BOMc96AHE1G7jj29DTZH98VFnmgCQyn0Jpd4ZfmH4Go80bqAJVZewxTg1QBvmAJ5NSKf84oArOSWoB5of71A60DF9OvHvTlQHkjJ9xTakXpQIFQKfl4z6AU2VvJwVAy3XipB1qK66J+NAH/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09F7NV4VFS/img_0988.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F09F7NV4VFS-fa7ab8bc93", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1757468887.575849] <@U03BLQ65GK0>: <@U08L89G6JSG>
ひかわへ右から左で納品する製品ですので入庫不要です。
ひかわへの納品日は山内さんに確認をお願いします。

## 2025-09-10

- [1757488804.806889] <@U041RJKV5JA>: <@U0331FZS7JT>
大阪香料より、ストロベリーパウダー（NO.2686）の見積もりが届きました。
 併せて、ラズベリーパウダー（NO.1435、NO.1436）についても記載されています。
 ご確認のほど、よろしくお願いいたします。
  - files: [{"id": "F09EG4C5HT4", "created": 1757488799, "timestamp": 1757488799, "name": "ｽﾄﾛﾍﾞﾘｰFP2686.ﾗｽﾞﾍﾞﾘｰFP1435.1436お見積書.pdf", "title": "ｽﾄﾛﾍﾞﾘｰFP2686.ﾗｽﾞﾍﾞﾘｰFP1435.1436お見積書.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 211382, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09EG4C5HT4/_____________________fp2686._____________________fp1435.1436____________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09EG4C5HT4/download/_____________________fp2686._____________________fp1435.1436____________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09EG4C5HT4-cd392286d1/_____________________fp2686._____________________fp1435.1436_____________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09EG4C5HT4/_____________________fp2686._____________________fp1435.1436____________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09EG4C5HT4-a484d5752f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1757489885.630989] <@U0331FWGQRM>: <@U0840UVFVA8> <@U03BLQ65GK0> <@U041RJKV5JA> <@U066P20UQH1> <@U0331FZS7JT>
お疲れ様です。
明日9/11 14:00から
原料在庫の状況の情報共有についてのMTGをしますので、
下記URLより宜しくお願い致します。
<https://meet.google.com/fks-zrnv-xec>
  - attachments: [{"from_url": "https://meet.google.com/fks-zrnv-xec", "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "id": 1, "original_url": "https://meet.google.com/fks-zrnv-xec", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/fks-zrnv-xec", "service_name": "meet.google.com"}]
- [1757566834.740939] <@U0331FWGQRM>: <@U0840UVFVA8> <@U03BLQ65GK0> <@U041RJKV5JA> <@U066P20UQH1> <@U0331FZS7JT>
14:10からでよろしくお願いします。
- [1757571030.372679] <@U0331FWGQRM>: <@U0840UVFVA8> <@U03BLQ65GK0> <@U041RJKV5JA> <@U066P20UQH1> <@U0331FZS7JT>
<https://meet.google.com/btz-azoq-tob>
  - attachments: [{"from_url": "https://meet.google.com/btz-azoq-tob", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "id": 1, "original_url": "https://meet.google.com/btz-azoq-tob", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/btz-azoq-tob", "service_name": "meet.google.com"}]

## 2025-09-11

- [1757587651.559599] <@U033G4KN4TD>: <!channel>
納品書が届いております。
仮入庫がされていないため、入庫処理が必要か判断できません。
ご確認お願いいたします。
  - files: [{"id": "F09EQDRQAT0", "created": 1757587563, "timestamp": 1757587563, "name": "S__263250045_0.jpg", "title": "S__263250045_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 245057, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09EQDRQAT0/s__263250045_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09EQDRQAT0/download/s__263250045_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQDRQAT0-4a77b62fce/s__263250045_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQDRQAT0-4a77b62fce/s__263250045_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQDRQAT0-4a77b62fce/s__263250045_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQDRQAT0-4a77b62fce/s__263250045_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQDRQAT0-4a77b62fce/s__263250045_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQDRQAT0-4a77b62fce/s__263250045_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQDRQAT0-4a77b62fce/s__263250045_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQDRQAT0-4a77b62fce/s__263250045_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQDRQAT0-4a77b62fce/s__263250045_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1478, "original_h": 1108, "thumb_tiny": "AwAkADBy2kQHK559TS/ZIf7gqVCdi5P8Pelzz2oAg+xw/wB2kFnEexx/n2qzjnPekIbsR+VAFY2kQIG1vrxRJbJHGWXORVgnkfNg9cGkkXMLZOeM0AKqlVAJ6DFGMDHagmm5wMUAKScdaMn1ppNJmgB+T60MCUI9jTQaUE0ABGaNoIweR70pooAY4CxsR2FUWu3VsbV/X/Gr83+qf6Vkv980AT/bZP7ifr/jR9uk/up+R/xqtRQB/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09EQDRQAT0/s__263250045_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F09EQDRQAT0-d2fb7d7d26", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09EQEBBT26", "created": 1757587567, "timestamp": 1757587567, "name": "S__263250044_0.jpg", "title": "S__263250044_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 286700, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09EQEBBT26/s__263250044_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09EQEBBT26/download/s__263250044_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEBBT26-1421e4dd29/s__263250044_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEBBT26-1421e4dd29/s__263250044_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEBBT26-1421e4dd29/s__263250044_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEBBT26-1421e4dd29/s__263250044_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEBBT26-1421e4dd29/s__263250044_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEBBT26-1421e4dd29/s__263250044_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEBBT26-1421e4dd29/s__263250044_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEBBT26-1421e4dd29/s__263250044_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEBBT26-1421e4dd29/s__263250044_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1478, "original_h": 1108, "thumb_tiny": "AwAkADBFhdlBVcg+9L9nl/u/qKsQECFc/wCeak3D1oApfZ5f7v6ij7PL/d/UVd3DuRTFWNW3ADP1oAq/Z5f7v6igwSAEleB71bL+mPzprnKN9D/FQAgUFVwSOB3NIY1PXJ/E0If3a/QUFqBWQ0wx+n603yI/Q/nTs4pN1AWQojjHRR+NL5akfdUU0MaXd+dA7EIncKAAOBTJbuRAMBefam1FP0FAEn2yT0Q/hQbxj/yzj/X/ABqvSUAWPtkn91B+FIbyUdNv5VBSHrQB/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09EQEBBT26/s__263250044_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F09EQEBBT26-0ef40f7fa5", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09EQEB6GAW", "created": 1757587570, "timestamp": 1757587570, "name": "S__263250043_0.jpg", "title": "S__263250043_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 288809, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09EQEB6GAW/s__263250043_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09EQEB6GAW/download/s__263250043_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEB6GAW-995a0c6176/s__263250043_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEB6GAW-995a0c6176/s__263250043_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEB6GAW-995a0c6176/s__263250043_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEB6GAW-995a0c6176/s__263250043_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEB6GAW-995a0c6176/s__263250043_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEB6GAW-995a0c6176/s__263250043_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEB6GAW-995a0c6176/s__263250043_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEB6GAW-995a0c6176/s__263250043_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09EQEB6GAW-995a0c6176/s__263250043_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 1478, "original_h": 1108, "thumb_tiny": "AwAkADAEMhAIXg+9HkS/3f1FW0IEajODgUbge9AFPyJf7v6ij7PL/d/UVcJUggkYNMEcQOQBn60C1K/2eX+7+oo+zy/3P1FW9w578etBIYj5enqaBjDGCerf99GmeX7n8zUh9aTqc0CsQmBCDuycd80eRH6H9akHU0H2oCyGiFf/ANYFO8tf7q/lRmnA0DsHejAopaAGSfJGWA5qqbhgOi/rVqf/AFJqg33aANCONXhDkEE+hpjk4OOPpU0H/HqtQP0NAH//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09EQEB6GAW/s__263250043_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F09EQEB6GAW-8afc9bbefc", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09EMBRP12R", "created": 1757587573, "timestamp": 1757587573, "name": "S__263250041_0.jpg", "title": "S__263250041_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 223781, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09EMBRP12R/s__263250041_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09EMBRP12R/download/s__263250041_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09EMBRP12R-7b433c6b4b/s__263250041_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09EMBRP12R-7b433c6b4b/s__263250041_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09EMBRP12R-7b433c6b4b/s__263250041_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 230, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09EMBRP12R-7b433c6b4b/s__263250041_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 307, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09EMBRP12R-7b433c6b4b/s__263250041_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09EMBRP12R-7b433c6b4b/s__263250041_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 460, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09EMBRP12R-7b433c6b4b/s__263250041_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 512, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09EMBRP12R-7b433c6b4b/s__263250041_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 614, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09EMBRP12R-7b433c6b4b/s__263250041_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 655, "original_w": 1462, "original_h": 935, "thumb_tiny": "AwAfADByQO6ggjn60otnIyGQj2NTQnbAMnGM0LgA/dP0FAEP2ST1X86Psknqv61PuIGAcVHJLIFIVSTjjpQBH9lf1X9aGtXVSxK4Az1pQzZ+7IOevFPyRFtGemOn4UAPi5iBFLz3wPxqmJ2VQABx0PekNy391T35oAtkDOcDNIM45wD7GqhunIxhfwzTRO4+6cfiT/OgC0rqTjI3emRUqrjp61Q8+T+8PyFPFxL/AHv0FAH/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09EMBRP12R/s__263250041_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F09EMBRP12R-79271e0ed7", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1757659134.329409] <@U03BLQ65GK0>: <@U033G4KN4TD>
A-16については既に入庫済みです。
中島製茶の分については入庫しておきますので残りについては発注された方対応をお願いします。

## 2025-09-12

- [1757739506.498169] <@U05KGS6HN9H>: <@U0331FWGQRM>
<!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
AIRと思いますが、ヤマト運輸納品での中国缶は、
保管スペースの兼ね合いで9/16に受入を行うように
調整致しました。
◆荷受にあたりまして、PackingListがあれば助かります。
- [1757739523.628239] <@U09DF1SDTQR>: <@U09DF1SDTQR>さんがチャンネルに参加しました

## 2025-09-19

- [1758342419.279659] <@U08U8MMTH43>: <@U0331FWGQRM>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
先日荷受けした貨物と一緒にこちらの缶が、小さいケースに入っていました。
おそらくpanton3305.7499のものだと思いますが、各３個ずつあります。
（各色一個ずつは蓋裏PVCなし、円形白いPVC？別途４枚あり）
ご確認のほどよろしくお願いいたします。
  - files: [{"id": "F09GD4D85U4", "created": 1758342202, "timestamp": 1758342202, "name": "S__160776197_0.jpg", "title": "S__160776197_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U08U8MMTH43", "user_team": "T033D70RR6H", "editable": false, "size": 298122, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09GD4D85U4/s__160776197_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09GD4D85U4/download/s__160776197_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09GD4D85U4-aa795a96a0/s__160776197_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09GD4D85U4-aa795a96a0/s__160776197_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09GD4D85U4-aa795a96a0/s__160776197_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 288, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09GD4D85U4-aa795a96a0/s__160776197_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 384, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09GD4D85U4-aa795a96a0/s__160776197_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09GD4D85U4-aa795a96a0/s__160776197_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 576, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09GD4D85U4-aa795a96a0/s__160776197_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1000, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09GD4D85U4-aa795a96a0/s__160776197_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 768, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09GD4D85U4-aa795a96a0/s__160776197_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 819, "thumb_1024_h": 1024, "original_w": 1144, "original_h": 1430, "thumb_tiny": "AwAwACewtNa4jXuT9KSbPktt64qmBnpyfSkgbsW/tUfo35VIkiSfdOT6VQxzSpkOpweDmnYnmL4B+tLzS0vFIsrliVK+oxWe2R3rQAFUZB8x+tJCY1SSe35CrcC/OO2OarIOauQkDOaoXUsA0bv84ppI64oyPQ0ihCnrUE9sG+ZDhvT1q4fpTDzSAppbuDyRirCqF4A57n1p1H0p3FYUCl4pOO4xS4X2pDP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09GD4D85U4/s__160776197_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F09GD4D85U4-b121dcaf1e", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09G6636KJR", "created": 1758342206, "timestamp": 1758342206, "name": "S__160776199_0.jpg", "title": "S__160776199_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U08U8MMTH43", "user_team": "T033D70RR6H", "editable": false, "size": 234192, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09G6636KJR/s__160776199_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09G6636KJR/download/s__160776199_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09G6636KJR-cc53c4533d/s__160776199_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09G6636KJR-cc53c4533d/s__160776199_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09G6636KJR-cc53c4533d/s__160776199_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09G6636KJR-cc53c4533d/s__160776199_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09G6636KJR-cc53c4533d/s__160776199_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09G6636KJR-cc53c4533d/s__160776199_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09G6636KJR-cc53c4533d/s__160776199_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09G6636KJR-cc53c4533d/s__160776199_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09G6636KJR-cc53c4533d/s__160776199_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACWHyXx2pPJYelWEjmY43L+VWVhUD5vmPrS5kFjO8t/b86QIwYZA4rT8pP7tQy25A3Rke4NHMgsVw0x7IaXdL/dSnqhA5PPtS7fc/nUaFkqHDdak31EMZ6040kJj/MFIz5BxTKG6UANo/Cj8TR+JpFDlUmlVg65FNTgioMkNwTTEWcU0nLYB6VGXc4+Y8HNIOOlAEw/Cjn2puaOPekM//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09G6636KJR/s__160776199_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F09G6636KJR-fb39f04266", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09G87ECB6W", "created": 1758342212, "timestamp": 1758342212, "name": "S__160776200_0.jpg", "title": "S__160776200_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U08U8MMTH43", "user_team": "T033D70RR6H", "editable": false, "size": 429718, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09G87ECB6W/s__160776200_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09G87ECB6W/download/s__160776200_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09G87ECB6W-272509cec7/s__160776200_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09G87ECB6W-272509cec7/s__160776200_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09G87ECB6W-272509cec7/s__160776200_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09G87ECB6W-272509cec7/s__160776200_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09G87ECB6W-272509cec7/s__160776200_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09G87ECB6W-272509cec7/s__160776200_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09G87ECB6W-272509cec7/s__160776200_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09G87ECB6W-272509cec7/s__160776200_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09G87ECB6W-272509cec7/s__160776200_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACVo7cUooGcZx8vrTtp2huMdakYgFBwKcCMH26+1NOZGKoMkckDtQAwmkzQQVPIxSZ+tAFkTN5JBQnAxg96iRiVBCHjnO79aCSSCpAIx8uRk/hSeZnkL09uKYie2m2owKk45yB1/+vVW3kKO6BSyE5zkDFPilaPAI4J4qKJzvkUqxySx2jp1oAc+7cd4ww6ikp33mJxjtg0baBj/ACh5gfc3Y9O9Sq21FAIzjkAfp0pBRnn2oCxG8W4jmnR/uy27J3HPHrTqMc0ANbls0nHr+lPo5pAf/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09G87ECB6W/s__160776200_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F09G87ECB6W-00ee9c7bb0", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09GN1B5HJM", "created": 1758342215, "timestamp": 1758342215, "name": "S__160776203_0.jpg", "title": "S__160776203_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U08U8MMTH43", "user_team": "T033D70RR6H", "editable": false, "size": 384517, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09GN1B5HJM/s__160776203_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09GN1B5HJM/download/s__160776203_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09GN1B5HJM-f18fe5a36f/s__160776203_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09GN1B5HJM-f18fe5a36f/s__160776203_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09GN1B5HJM-f18fe5a36f/s__160776203_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09GN1B5HJM-f18fe5a36f/s__160776203_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09GN1B5HJM-f18fe5a36f/s__160776203_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09GN1B5HJM-f18fe5a36f/s__160776203_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09GN1B5HJM-f18fe5a36f/s__160776203_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09GN1B5HJM-f18fe5a36f/s__160776203_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09GN1B5HJM-f18fe5a36f/s__160776203_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACVuMUmBg7ifwGaf3/KnRRGQbiDzzzUjZHhQuQ3fuMUhA465PpV0Wo2kNg5qmqsHIPVDge+O9MCysII4JGOPlpfIH99/zpysAMjJUnIIGaXePRv++TTEVMZyKel1sO2QHPqATmm+pp25YztUAkdTSQ2Oe6HKrnP0xiqvm+XwRx29qseYjvtYD5u4FQlG3bSnQ+1DAatyxyUiznvtpftMv/PL/wAdq2ronCoeOCSKd53/AEz/AEosBX3EYOaZNGyneoyrDPFOPT1pgkWBsFmdu6qcAfjQA2MMWDYOByM96sKdy5B5UgmojicHYSrY+6efyNRDcMFGwy96QFyILkllDZA5bnn8qk/d/wDPNPyP+FUwynqCp9AMil3R+r/98j/GncR//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09GN1B5HJM/s__160776203_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F09GN1B5HJM-a608d84373", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09H1L3G9FA", "created": 1758342239, "timestamp": 1758342239, "name": "S__160776202.jpg", "title": "S__160776202.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U08U8MMTH43", "user_team": "T033D70RR6H", "editable": false, "size": 353118, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09H1L3G9FA/s__160776202.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09H1L3G9FA/download/s__160776202.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09H1L3G9FA-3ecdcd9394/s__160776202_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09H1L3G9FA-3ecdcd9394/s__160776202_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09H1L3G9FA-3ecdcd9394/s__160776202_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09H1L3G9FA-3ecdcd9394/s__160776202_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09H1L3G9FA-3ecdcd9394/s__160776202_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09H1L3G9FA-3ecdcd9394/s__160776202_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09H1L3G9FA-3ecdcd9394/s__160776202_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09H1L3G9FA-3ecdcd9394/s__160776202_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09H1L3G9FA-3ecdcd9394/s__160776202_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACVg60tJ2zjJ7CrEdpjDSMxPoOBSGV+KaQScAEmpLmM27buqMfyqK33SyOcbunAAoC5M0G3G4kH6E/0pPKH95v8Avk/4U4ylAPUjJ570n2g/5JpiI1YqAw6qc/WtFZAy7lOQehrOzjj1p8SIrffYZ64OAaQE186+Vs4LHsf51nwymCUOOvQj1qxLEIxu3FgepPWq4jM0oVeKYEslyJWLAkexFN80f3v0NTbLZBt2uSOp3UYt/wC4/wD33QBGpy6+mcUElTg8GmgcdM+1So7JuWR9x+mcH8xSGJK5MJBH3qjhydxHU4FOlVuJCwKnuO3tUCylHJ2gqeoNMRY3bQCQDmjzB/dH6/40iTryTKVz22Zp/wBoT/nuf+/dAH//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09H1L3G9FA/s__160776202.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F09H1L3G9FA-b1ad17761f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09G3DUE5BM", "created": 1758342246, "timestamp": 1758342246, "name": "S__160776204_0.jpg", "title": "S__160776204_0.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U08U8MMTH43", "user_team": "T033D70RR6H", "editable": false, "size": 367753, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09G3DUE5BM/s__160776204_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09G3DUE5BM/download/s__160776204_0.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09G3DUE5BM-6d81f0c20a/s__160776204_0_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09G3DUE5BM-6d81f0c20a/s__160776204_0_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09G3DUE5BM-6d81f0c20a/s__160776204_0_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09G3DUE5BM-6d81f0c20a/s__160776204_0_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09G3DUE5BM-6d81f0c20a/s__160776204_0_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09G3DUE5BM-6d81f0c20a/s__160776204_0_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09G3DUE5BM-6d81f0c20a/s__160776204_0_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09G3DUE5BM-6d81f0c20a/s__160776204_0_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09G3DUE5BM-6d81f0c20a/s__160776204_0_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACVwFLjilXtjrUpiI6sM/SpGQHg03I4zUmxmYgDkd6SSJlUkEEY5pWGR8euKOP71NbIpMn0NAFmM7WB9KsEgjOarwgMTkdKmZQw5FUhMiV181ucbsYzT5GCLuPSoYo/MJLdBxillgUISnGOTQBVLe1Jn2pGB7UmG96kZaVyhyPy9ae0zFcKMe+ai7GlzxRcB0MoQkN0JzmpJJlK7V5J/SqwNOHWncLBtB7CjaPQU7GRRtPvSA//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09G3DUE5BM/s__160776204_0.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F09G3DUE5BM-d8467647f3", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-09-22

- [1758595264.093079] <@U0331FWGQRM>: <@U0331FZS7JT> 
すみませんが、これ大阪に来られる際持ってきてもらえますか？？
- [1758595264.601959] <@U0331FWGQRM>: <@U0331FZS7JT> 
すみませんが、これ大阪に来られる際持ってきてもらえますか？？

## 2025-09-23

- [1758682789.119529] <@U08RVRNBY00>: <@U05KGS6HN9H>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
:black_small_square:*茶筌についてー情報更新ありましたらお教えいただきたくお願いします。*

*１）中田喜造商店*
*お伺い：１０月の入荷時期目処お分かりになりましたら情報お願いします。*
```（メモ：9/18情報）
１０月からの出荷可能予測数（下方修正ありで理解）
１）TEA WEAR Shin (Black) 真(黒竹)　×５本
２）TEA WEAR Shin (White) 真(白)　×５本```
*２）久保透商店*
*お伺い：昨年発注分含め、入荷予定の更新情報ありましたらお願いします。*
```（メモ：8/2情報）
昨年8月の発注残28本が現在に至っても入荷せず。
毎回発注しても長期待ちが当然というスタンス。```
*３）翠華園*
*お伺い：昨年発注分含め、入荷予定の情報ありましたらお願いします。*
```（メモ：8/2情報）
昨年発注した茶筌等の未納品多数。
物があれば優先的に出荷いただける。しかし、長期待ち定着。
昨年12月頃発注止めていただきたい旨、連絡あり新発注せず。```

## 2025-09-24

- [1758758572.670219] <@U08RVRNBY00>: <@U05KGS6HN9H>
CC <@U0331FZS7JT>
:black_small_square:*香岳園抹茶のブレンドについて質問*です。
`下部スレッド内容に質問まとめました。（9/27)`

~１）9/9の入荷分から　全ての商品ブレンド（単一なし）であっておりますでしょうか？~

~２）基本全ての商品がブレンドとなるが、以前までの単一品種がメイン品種と言って良いでしょうか？~
~*→メイン品種については、８０％以上はメイン品種で占められているか？*（追加質問）~

~３）きらり３１については、ブレンドでなく単一でしょうか？~
→きらりは社長より単一の旨回答いただきました。

お忙しいところ恐れ入りますが、ご確認のほどお願い申し上げます。
- [1758777024.282229] <@U08RVRNBY00>: <@U05KGS6HN9H>
CC　<@U0331FZS7JT>
五月雨式にご質問失礼いたします。

:black_small_square:*香岳園抹茶のブレンドの品種について*
 「宇治抹茶 K-F」「宇治抹茶 K-G」「宇治抹茶 K-I」のように、
 `メイン品種＋サブ品種1つの組み合わせ`で、
品種情報をご共有いただくことは可能でしょうか？

よろしくお願いします。:woman-bowing:

## 2025-09-25

- [1758784911.548009] <@U05KGS6HN9H>: <@U0331FWGQRM>
<!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
SEA Shipment分と思いますが、本日入荷しました。
60×60Hmm: 5,040 pcs（240入×21箱） – Silver
60×68Hmm: 10,000 pcs （200入×50箱）– Silver
台帳に入庫入力済みです。
- [1758866785.844889] <@U041RJKV5JA>: <!channel>
和香園
11月入荷分より下記原料の納品価格が変更となります。
下記金額はkg単価です。
【抹茶44】　　　  旧価格　  新価格
・1kg詰めの場合   3,500円→6,200円
・バルクの場合　 3,300円→5,900円

【抹茶１B】　　　 旧価格　  新価格
・1kg詰めの場合   4,580円→10,900円
・バルクの場合　 4,580円→10,500円
※旧価格は、1kg詰め・バルク共に同価格でした。

＜バルク入り数について＞
・和香園で粉砕した場合：25kg
・外部委託で粉砕した場合：20kg

## 2025-09-26

- [1758892792.278559] <@U0331FWGQRM>: <@U041RJKV5JA>
記載方法として、何円から何円になったと書いていただけると助かります。
あと、見積書はどこ（フォルダ名）にありますか？
- [1758932134.206069] <@U041RJKV5JA>: <@U0331FWGQRM>
旧価格を追記しました。
価格の連絡はLINEにていただきましたので、スクショをお送りいたします。
和香園フォルダに「抹茶44・抹茶1B価格改訂_2025.11入荷分より」のファイル名にて格納しておきます。
よろしくお願いいたします。
  - files: [{"id": "F09HA31N319", "created": 1758932110, "timestamp": 1758932110, "name": "抹茶44・抹茶1B価格改訂_2025.11入荷分より.png", "title": "抹茶44・抹茶1B価格改訂_2025.11入荷分より.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 19162, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09HA31N319/______44_________1b_____________2025.11_______________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09HA31N319/download/______44_________1b_____________2025.11_______________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09HA31N319-95dff1bcda/______44_________1b_____________2025.11________________64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09HA31N319-95dff1bcda/______44_________1b_____________2025.11________________80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09HA31N319-95dff1bcda/______44_________1b_____________2025.11________________360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 268, "thumb_360_h": 208, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09HA31N319-95dff1bcda/______44_________1b_____________2025.11________________160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 268, "original_h": 208, "thumb_tiny": "AwAmADDQLkE+gpWcKcGnYFMZcsDkjHYd6ADzV3be/wBKUMCOKaUz/Ew+h96Nv+0evrQA/NGabj3NKOtADqimMYYeYcHnHP51LTWAJ5FADFZWB2nPNJtVAA3A6DBNSUmDg89entQBCzIV+Zl2t65qZTkA8fgc0mGzy2R9KVARjJz+FAD6RlDAg9DS0UAM8paUIB/OnUUANEYGMduKXFLRQB//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09HA31N319/______44_________1b_____________2025.11_______________.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F09HA31N319-8e8705a06b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-09-27

- [1758957903.444289] <@U08RVRNBY00>: <@U05KGS6HN9H>
CC　<@U0331FZS7JT>

:black_small_square:*香岳園抹茶のブレンドの品種について*
こちらの件、お調べいただきありがとうございます。
追加で質問もあるため、*質問３点*まとめております↓

ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー
*1）`9/9入荷分から。　全ての商品ブレンド（単一なし）であっておりますか？`*
全ての単一商品でしょうか？基本ということなので例外（きらり以外）はありますでしょうか？

*2） `メイン品種＋サブ品種1つの組み合わせ`*
「宇治抹茶 K-F」「宇治抹茶 K-G」「宇治抹茶 K-I」のように、
 メイン品種＋サブ品種1つの組み合わせで、
品種情報をご共有いただくことは可能でしょうか？

*３）`メイン品種については、８０％以上はメイン品種で占められているか？`*（追加質問）
→CHSはGokouなどで７０ー８０％未満がメイン品種であれば、注文を取りやめる話が出ているため、
お伺いしたく存じます。
ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー
＊なお、社長より*「きらり」のみ単一*で伺いました！（香岳園より碾茶で仕入れ、桃翠園で粉砕）

よろしくお願いします。:woman-bowing:

## 2025-09-28

- [1759104082.863529] <@U05KGS6HN9H>: <@U08RVRNBY00>
<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
<!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
香岳園にメイン/サブで各抹茶のおおよその品種情報を
穴埋め返信いただきました。取り急ぎご参照ください。
  - files: [{"id": "F09JE337YBS", "created": 1759104074, "timestamp": 1759104074, "name": "20250929_香岳園品種内訳情報.pdf", "title": "20250929_香岳園品種内訳情報.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 327385, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09JE337YBS/20250929____________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09JE337YBS/download/20250929____________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09JE337YBS-3bdf3e1ce1/20250929_____________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09JE337YBS/20250929____________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F09JE337YBS-021798138d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1759107968.105169] <@U08RVRNBY00>: <@U05KGS6HN9H>
<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
<!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>

お忙しい中ご確認いただきありがとうございます:woman-bowing:
 以下の点、私の理解で合っているかご確認させてください。

```１）今回の資料に記載がなかったサブ品種については、今後あらためて情報をご提供いただける予定
２）「未記入＝単一品種」という意味ではない（特に上のグレード。宇治抹茶9000以下はブレンド認識）
３）宇治抹茶12000・11000については、メイン品種が「おくみどり」→「やぶきた」へ変更された```
確認させていただいたところ、
 ・サブ品種が記載されていた部分については、7月にいただいた内容と同一でした。
 そのため、それ以外の部分についての更新・変更を差し支えなければ教えていただけますと幸いです。
もしこちらの認識に誤りがあれば、ご指摘いただけますと助かります！
- [1759112014.439969] <@U05KGS6HN9H>: <@U08RVRNBY00>
<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
<!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
香岳園/緒方部長に再度確認してみましたが、明確には分かりません。
サブ品種の空欄箇所ですが、単一という意味ではなく、ブレンドです。
但し何がどれくらい入っているかまで細かい内容は不明。
せめて他に何が入っているか？伺ってみましたが、詳細開示は勘弁して
欲しいとの平行線です。
宇治抹茶70000~30000　メイン：さみどり（ほぼ全て）
　→推測では上ランクは、ごこう・うじひかり等が少量？
宇治抹茶12000~2200　メイン：やぶきた（ほぼ全て）
　→推測では、さやまみどり等も配合？
- [1759115831.475159] <@U08RVRNBY00>: <@U05KGS6HN9H>
ありがとうございます！

*ーサブ品種未記入のグレードも、`全て「ブレンド」`で確認いたしました。*

なお、メイン品種の割合については、言及はございましたでしょうか？
（７０％くらい、８０％くらいはメインか否か、、、）
- [1759118194.513649] <@U05KGS6HN9H>: <@U08RVRNBY00>
割合も伺ってみたのですが、ほぼ全てさみどりのような回答
しか得られませんでした…:cry:

## 2025-09-29

- [1759206035.338709] <@U0331FZS7JT>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <@U03BLQ65GK0> <!subteam^S08NN8M4LAZ|@katayose-kamiya>
八女抹茶について、
単一品種の１茶碾茶仕入れが可能となったので下記２品種購入の上、
表（・八女抹茶価格（20250930)）を更新しています。
よろしくお願いします。
※何れも碾茶価格：¥20,000/kg

産地：八女
農薬：慣行
単一品種：きらり-31
サプライヤー：吉田園（碾茶仕入れ・出雲精茶で粉砕）
製品量：193kg
抹茶原価：¥20,592/kg
品質
味：旨味強い
パウダー：少し黄色味がかった濃緑色
水色：少し黄色味がかった濃緑色
香り：焙煎強め（甘い香り強い）
※パウダー、水色とも黄色味掛かっているのは焙煎によるものと思われる。

産地：八女
農薬：慣行
単一品種：せいめい
サプライヤー：吉田園（碾茶仕入れ・出雲精茶で粉砕）
製品量：80kg
抹茶原価：¥20,592/kg
品質
味：旨味そこそこ
パウダー：鮮緑色
水色：鮮緑色
香り：焙煎はかなり弱くフレッシュ感が強い
  - files: [{"id": "F09HR51583F", "created": 1759206023, "timestamp": 1759206023, "name": "・八女抹茶価格（20250930).xlsx", "title": "・八女抹茶価格（20250930).xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 122768, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09HR51583F/________________________20250930_.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09HR51583F/download/________________________20250930_.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09HR51583F-b378ec4a47/________________________20250930__converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F09HR51583F-b378ec4a47/________________________20250930__thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1113, "thumb_pdf_h": 788, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09HR51583F/________________________20250930_.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F09HR51583F-debe8fcc73", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-10-07

- [1759826421.966249] <@U0331FZS7JT>: <!channel>
有機１茶碾茶（ラインナップ外/単独提案用として購入）
仕入れ先：茗広茶業
産地：宮﨑
品種：やぶきた
碾茶数量：300kg
価格（碾茶）：¥12,500/kg
価格（抹茶）：¥13,016/kg
- [1759826569.276889] <@U0331FZS7JT>: 品質メモ（事務所の簡易石臼での確認）
外観色：緑だが、少し茶色
少し：くすんだ緑
香り：かなり甘い（火香かなり強い/八女ぐらい）
味：旨味強い。後味ちょっと苦い。

## 2025-10-09

- [1760075459.185469] <@U08U8MMTH43>: <@U08RVRNBY00>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
*中田喜造商店*
10月分の茶筅、入荷確定しましたので情報共有いたします。（入荷日は、10/11 予定です）

TEA WEAR Shin (Black) 真(黒竹)　×５本
TEA WEAR Shin (White) 真(白)　×５本
以上が出荷可能数量になります。
よろしくお願いいたします:woman-bowing:

## 2025-10-13

- [1760412255.902509] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> cc <@U0331FZS7JT> <@U08RVRNBY00>
八女抹茶の現時点での供給可能数量を確認お願いします
※元々聞いていた供給可能数量と、現時点での出庫数量を確認しましたが、
　この引き算した数量が正しい数字か確認したい意図です。
  - files: [{"id": "F09L4UGKYPM", "created": 1760412219, "timestamp": 1760412219, "name": "スクリーンショット 2025-10-14 12.20.43.png", "title": "スクリーンショット 2025-10-14 12.20.43.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 79744, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09L4UGKYPM/____________________________2025-10-14_12.20.43.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09L4UGKYPM/download/____________________________2025-10-14_12.20.43.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09L4UGKYPM-940c79ddbd/____________________________2025-10-14_12.20.43_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09L4UGKYPM-940c79ddbd/____________________________2025-10-14_12.20.43_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09L4UGKYPM-940c79ddbd/____________________________2025-10-14_12.20.43_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 104, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09L4UGKYPM-940c79ddbd/____________________________2025-10-14_12.20.43_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 138, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09L4UGKYPM-940c79ddbd/____________________________2025-10-14_12.20.43_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09L4UGKYPM-940c79ddbd/____________________________2025-10-14_12.20.43_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 207, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09L4UGKYPM-940c79ddbd/____________________________2025-10-14_12.20.43_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 230, "original_w": 946, "original_h": 272, "thumb_tiny": "AwAOADC5HOjybNjKe25cU/zI8AnGG6HFRhVjywRenYYp4K46D8qSG7X0HYQ4wo6cArRsj3Fti5PBO3rSfL6D8qMj0/SmIcw4+UAfVc1FJMsTKpRmJ/urT8j0/SmOiuwJVTj1ApMatfU//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09L4UGKYPM/____________________________2025-10-14_12.20.43.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F09L4UGKYPM-122985396f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1760424699.517179] <@U08RVRNBY00>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> cc <@U0331FZS7JT> <@U0331FWGQRM>
:black_small_square: *追加のご依頼：宇治抹茶（香岳園・単一品種）の供給可能数量について*

松井さんからのご依頼（八女抹茶）に続きまして、
 「*宇治抹茶（香岳園分および単一品種）」についても、現時点での供給可能数量のご確認*をお願いいたします。

※香岳園商品については*年間供給量が不明でした*ので、そちらもあわせてご確認いただけますと幸いです。

▶︎ 対象ファイル：
 `桃翠園フォルダ ＞ 価格関係 ＞ *宇治抹茶単一品種価格（20250825).xlsx*`
 → ファイル内「【出庫】在庫管理表」に記載の*2*025年の出庫数を入力済みです。
 差異がありましたら申し訳ありません:woman-bowing:

お手数をおかけしますが、どうぞよろしくお願いいたします！
  - files: [{"id": "F09LFM9CASY", "created": 1760424652, "timestamp": 1760424652, "name": "スクリーンショット 2025-10-14 15.36.15.png", "title": "スクリーンショット 2025-10-14 15.36.15.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U08RVRNBY00", "user_team": "T033D70RR6H", "editable": false, "size": 144582, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09LFM9CASY/____________________________2025-10-14_15.36.15.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09LFM9CASY/download/____________________________2025-10-14_15.36.15.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09LFM9CASY-23e10e602c/____________________________2025-10-14_15.36.15_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09LFM9CASY-23e10e602c/____________________________2025-10-14_15.36.15_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09LFM9CASY-23e10e602c/____________________________2025-10-14_15.36.15_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 60, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09LFM9CASY-23e10e602c/____________________________2025-10-14_15.36.15_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 79, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09LFM9CASY-23e10e602c/____________________________2025-10-14_15.36.15_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09LFM9CASY-23e10e602c/____________________________2025-10-14_15.36.15_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 119, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09LFM9CASY-23e10e602c/____________________________2025-10-14_15.36.15_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 132, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09LFM9CASY-23e10e602c/____________________________2025-10-14_15.36.15_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 159, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09LFM9CASY-23e10e602c/____________________________2025-10-14_15.36.15_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 169, "original_w": 1633, "original_h": 270, "thumb_tiny": "AwAIADCeR1EZzbg/Xafp3p4dAyusG3JA3fL3/Gopejfj/wCg0v8Ay7x/8A/mKALIPBJY5X1I5/L/APXUgGBjsPWq56Gp2+6fpQBHGTukBfOG/oKVCcZMqt9BxUEf35P97+gog/1Q+p/maAP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09LFM9CASY/____________________________2025-10-14_15.36.15.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F09LFM9CASY-73a627e03c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F09LA2Y45V4", "created": 1760424655, "timestamp": 1760424655, "name": "スクリーンショット 2025-10-14 15.36.40.png", "title": "スクリーンショット 2025-10-14 15.36.40.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U08RVRNBY00", "user_team": "T033D70RR6H", "editable": false, "size": 257861, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F09LA2Y45V4/____________________________2025-10-14_15.36.40.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F09LA2Y45V4/download/____________________________2025-10-14_15.36.40.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F09LA2Y45V4-258d31cb89/____________________________2025-10-14_15.36.40_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F09LA2Y45V4-258d31cb89/____________________________2025-10-14_15.36.40_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F09LA2Y45V4-258d31cb89/____________________________2025-10-14_15.36.40_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 217, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F09LA2Y45V4-258d31cb89/____________________________2025-10-14_15.36.40_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 289, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F09LA2Y45V4-258d31cb89/____________________________2025-10-14_15.36.40_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F09LA2Y45V4-258d31cb89/____________________________2025-10-14_15.36.40_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 433, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F09LA2Y45V4-258d31cb89/____________________________2025-10-14_15.36.40_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 481, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F09LA2Y45V4-258d31cb89/____________________________2025-10-14_15.36.40_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 578, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F09LA2Y45V4-258d31cb89/____________________________2025-10-14_15.36.40_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 616, "original_w": 1421, "original_h": 855, "thumb_tiny": "AwAdADC7vG/Ajk4z06fzoZwOCkhGRyKVCMngilwm3GDjgYxTAA5J+64+uKPMIPKP9eKXcOPvcnHSkwhboQSck464pDFD56qw+uKaZCB/q3P5f40mC0quC+0ds4/TFScY70XAETbyfvHrSlARgjjjvTJJfL2jGc+9K0mFzjuR+Wf8KBC7F3BscjOPx60bFyTgZJyaiknZW2qBncFyfcUW8rybt23A9BTswJTGhkEhHzAYBzTscYoopBc//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F09LA2Y45V4/____________________________2025-10-14_15.36.40.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F09LA2Y45V4-dc2cda793c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-10-14

- [1760506755.209069] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
下記２種類が明日、または明後日各10kgずつ届きます。
入庫処理よろしくお願いします。
*宇治抹茶 特：茗広茶業 宇治抹茶17000*
*宇治抹茶No.1：茗広茶業 宇治抹茶13000*

<!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
*宇治抹茶 特：茗広茶業 宇治抹茶17000*
上記については価格同じで若干品質異なる（今回の製品の方が良い）となっていて
正確には仕入れ製品名が異なりますが
同じものとして処理をお願いします。
また在庫が4.7kgあるので、あまりに品質がことある場合は手合組で良いので
合組をお願いします。
- [1760507212.704619] <@U033G4KN4TD>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
仮入庫済です

