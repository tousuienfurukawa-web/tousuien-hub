# Slack channel: hp作成-海外

## 2022-02-16

- [1645068347.588319] <@U0331FWGQRM>: <@U0331FWGQRM>さんがチャンネルに参加しました
- [1645068488.309959] <@U0331FZS7JT>: <@U0331FZS7JT>さんがチャンネルに参加しました
- [1645068717.537679] <@U0331FWGQRM>: チャンネル名を「海外展開」から「hp作成-海外」に変更しました
- [1645069693.184899] <@U033G4KN4TD>: <@U033G4KN4TD>さんがチャンネルに参加しました
- [1645071802.897349] <@U0331FWGQRM>: todo
プリズムの確認・追記

確認事項
海さんにロゴマーク依頼し忘れかも・・
どうするか含めて相談

## 2022-03-16

- [1647474956.491669] <@U0331FWGQRM>: <@U033G4KN4TD>
海さんからのスケジュール共有します
ーーー
スケジュール組んでみました。（スプレットシートご招待しましたので、ご覧ください。）
新商品開発と海外ph作成の撮影を同日に行うという前提です。
<https://docs.google.com/spreadsheets/d/1oITZYxTmvZ2RJOTE7BHk1yw0Hfc5RAOX99viGoMf3x0/edit?usp=sharing>

同日に撮影するにはいくつか条件があります。
~【新商品開発】~
• ~一ノ葉ブランドページ完成の第一希望日である5月10日に間に合わない。5月下旬完成イメージ~
• ~ブランドページの発注は合成素材で進めてもらい、最後に撮影素材と差し替えしてもらう（そもそも可能なのか？）~
【海外ph作成】
• 全体的に駆け足なスケジュールなので、Slackでの提案&amp;FBのやり取り、定例外でのmtg設定の可能性アリ
• 急ですが来週からスタートしたい
• WFが上がってくる前に概ねの撮影イメージを決定し、撮影に挑む
同日の撮影を諦める、海外hpは撮影なしで購入素材などで作成する、などでしたらもう少しゆとりのあるスケジュールが引けますので、一度ご検討頂ければ幸いです。
ご提案スケジュール通り進める場合、2月3月気合！！といった感じです。笑

## 2022-04-17

- [1650244426.256229] <@U03BLQ65GK0>: <@U03BLQ65GK0>さんがチャンネルに参加しました

## 2022-06-27

- [1656315545.719659] <@U033G4KN4TD>: <@U0331FWGQRM>
お疲れ様です。
海外HPについて
①、FAQの追加
②、お問合せ
　　whatsapp
        line
        tel
        email address
        address
③、product
        Matcha、Sencha、Hojicha、Genmaicha、それぞれの写真を載せる

上記の項目を追加する必要があるかと思っています。

よろしくお願い致します。
- [1656315943.654349] <@U033G4KN4TD>: <@U0331FWGQRM>
OEMについて
「小袋詰め、ティーバッグ、缶、スティックなどを対応します。」の右側の写真、
「パッケージ写真」に変更したら、どうかなと思っています。
※上の「桃翠園はOEM商品の提供に積極的です。」の写真と全く同じですので。
- [1656316281.085819] <@U033G4KN4TD>: <@U0331FWGQRM>
「代表あいさつ」
「品質が良いのは当たり前`。`美味しいのは当たり前`。`とした上で、お客様が望まれる形で商品を届けられるように努めております。」
&gt; `。`→`、`に変更する必要があるかと思ってます。
よろしくお願い致します。
- [1656316833.730119] <@U033G4KN4TD>: <@U0331FWGQRM>
「メールやチャットなどからお気軽にご連絡ください」って書いてありますが、
チャットのツールがないみたいです。
チャットツールの追加が必要かと思っています。
  - files: [{"id": "F03M5LFMNN9", "created": 1656316710, "timestamp": 1656316710, "name": "スクリーンショット 2022-06-27 午後4.56.52.png", "title": "スクリーンショット 2022-06-27 午後4.56.52.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 46498, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F03M5LFMNN9/____________________________2022-06-27_______4.56.52.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F03M5LFMNN9/download/____________________________2022-06-27_______4.56.52.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F03M5LFMNN9-63b983becc/____________________________2022-06-27_______4.56.52_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F03M5LFMNN9-63b983becc/____________________________2022-06-27_______4.56.52_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F03M5LFMNN9-63b983becc/____________________________2022-06-27_______4.56.52_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 124, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F03M5LFMNN9-63b983becc/____________________________2022-06-27_______4.56.52_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 165, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F03M5LFMNN9-63b983becc/____________________________2022-06-27_______4.56.52_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "image_exif_rotation": 1, "original_w": 545, "original_h": 187, "thumb_tiny": "AwAQADC+Rk580/pRt5J80/pS98c0DPv+tACdBzKf0oKkg/vD+lLk56H9aAD7/rQAgX/pqT+VL3/1n4UAEjqaAp9f1oA//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F03M5LFMNN9/____________________________2022-06-27_______4.56.52.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F03M5LFMNN9-2db05cdde5", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1656324210.145819] <@U033G4KN4TD>: <@U0331FWGQRM>
お疲れ様です。
海外HPについて、
「Home」の追加が必要があるかと思っています。
  - files: [{"id": "F03MBJ48E12", "created": 1656324195, "timestamp": 1656324195, "name": "スクリーンショット 2022-06-27 午後7.00.10.png", "title": "スクリーンショット 2022-06-27 午後7.00.10.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 30176, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F03MBJ48E12/____________________________2022-06-27_______7.00.10.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F03MBJ48E12/download/____________________________2022-06-27_______7.00.10.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F03MBJ48E12-6d1b472b56/____________________________2022-06-27_______7.00.10_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F03MBJ48E12-6d1b472b56/____________________________2022-06-27_______7.00.10_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F03MBJ48E12-6d1b472b56/____________________________2022-06-27_______7.00.10_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 19, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F03MBJ48E12-6d1b472b56/____________________________2022-06-27_______7.00.10_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 25, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F03MBJ48E12-6d1b472b56/____________________________2022-06-27_______7.00.10_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F03MBJ48E12-6d1b472b56/____________________________2022-06-27_______7.00.10_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 37, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F03MBJ48E12-6d1b472b56/____________________________2022-06-27_______7.00.10_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 41, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F03MBJ48E12-6d1b472b56/____________________________2022-06-27_______7.00.10_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 50, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F03MBJ48E12-6d1b472b56/____________________________2022-06-27_______7.00.10_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 53, "image_exif_rotation": 1, "original_w": 1624, "original_h": 84, "thumb_tiny": "AwACADC5DwDipT1NRQ96lP3jSQ3uIe1B6D60HtQeg+tMQHtR/F+NB7fSj+L8aAP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F03MBJ48E12/____________________________2022-06-27_______7.00.10.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F03MBJ48E12-d8bf39b35d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2022-06-28

- [1656416940.163469] <@U0331FWGQRM>: <@U033G4KN4TD>
中国語の翻訳ですが、
下記先のD列に中国語翻訳を入れていただけますか？
また明日説明しますね！

<https://docs.google.com/spreadsheets/d/1oBfkK4SphEfodkWaMMVK81qiE_sPjDnD/edit#gid=265775013>
- [1656417149.380199] <@U0331FWGQRM>: 明日の午前中に宜しくお願いします！
完了し次第、教えてください！
宜しくお願いします！
- [1656474299.724089] <@U033G4KN4TD>: <@U0331FWGQRM>
お疲れ様です。
「OEMについて」だけの中国語翻訳が終わっていません。
午後１４：００前に終わらせます。
よろしくお願い致します。
- [1656476293.597559] <@U033G4KN4TD>: <@U0331FWGQRM>
お疲れ様です。
翻訳完了です。
よろしくお願い致します。
- [1656476724.537329] <@U033G4KN4TD>: <@U0331FWGQRM>
追記
①それぞれのページのタイトルの翻訳について、

桃翠園について	お茶作りについて　	OEMについて	代表あいさつ	　　商品一覧	　　お問い合わせ
关于桃翠园	　　关于茶叶	　　　　　　关于OEM	　　社长致辞	　　　　　产品	　　联系我们
- [1656476957.925449] <@U033G4KN4TD>: ② 中国語に変換する時、「お茶づくりについて」のページがなくなりました。
- [1656479486.863089] <@U0331FWGQRM>: <@U033G4KN4TD>
有難う御座います:raised_hands:
助かりました！！！

## 2022-06-29

- [1656546583.974749] <@U0331FWGQRM>: <@U033G4KN4TD>
Tel : <tel:0853720039|0853-72-0039>
Adress : 1482 Kaminaoe, Hikawa-cho, Izumo, Shimane Japan
E-mail : <mailto:global-team@ml.tousuien.jp|global-team@ml.tousuien.jp>

電話番号 : <tel:0853720039|0853-72-0039>
住所 : 島根県出雲市斐川町上直江1482
E-mail : <mailto:global-team@ml.tousuien.jp|global-team@ml.tousuien.jp>

上記の中国語翻訳を教えてください
宜しくお願いします！
- [1656549998.342329] <@U033G4KN4TD>: <@U0331FWGQRM>
お疲れ様です。

电话：<tel:0853720039|0853-72-0039>
地址：岛根县出云市斐川町上直江1482
邮件： <mailto:global-team@ml.tousuien.jp|global-team@ml.tousuien.jp>

以上、中国語翻訳です。
よろしくお願い致します。
- [1656553628.964699] <@U033G4KN4TD>: <@U0331FWGQRM> <@U0331FZS7JT>
お疲れ様です。
アリババのお客さんから
【Paypalがないです、「Google Pay」ができますか】という連絡が来ました。

私が「Google Pay」を調べたら、
「申請手続も複雑ではない、
セキュリティも高いです。」とネットに書いてあります。

Google Payを申請してもいいのかと思っております。

以上ご報告です。
よろしくお願い致します。
- [1656554805.237669] <@U0331FWGQRM>: <@U033G4KN4TD> 確認します。

## 2022-07-04

- [1656924453.966989] <@U0331FWGQRM>: <!channel>
修正有無確認として、
本投稿のスレッドにどんどん入れてください！
- [1656924478.852919] <@U0331FWGQRM>: この続きに！
- [1656924556.208949] <@U0331FWGQRM>: 問い合わせに対する自動返信機能について
・送信アドレスがtousuienでないため、誰からのメールか分からない。
・文章が短い
・動画URLや資料なども添付したい

## 2022-07-19

- [1658220320.500249] <@U0331FZS7JT>: <@U0331FZTHEK> さん
お疲れ様です。
本件HPの製作費の１部の経費です。
損益計算に反映をお願いします。
  - files: [{"id": "F03Q3TE280L", "created": 1658220252, "timestamp": 1658220252, "name": "TSE-2206-002.pdf", "title": "TSE-2206-002.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 40428, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F03Q3TE280L/tse-2206-002.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F03Q3TE280L/download/tse-2206-002.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F03Q3TE280L-d229ecd17b/tse-2206-002_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F03Q3TE280L/tse-2206-002.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F03Q3TE280L-c211e4dca4", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1658220357.138009] <@U0331FZTHEK>: <@U0331FZTHEK>さんがチャンネルに参加しました

## 2022-08-07

- [1659922187.561369] <@U03SGRNND5L>: <@U03SGRNND5L>さんがチャンネルに参加しました

## 2022-09-11

- [1662964610.358349] <@U041RJKV5JA>: <@U041RJKV5JA>さんがチャンネルに参加しました

## 2023-07-31

- [1690796789.365299] <@U05KGS6HN9H>: <@U05KGS6HN9H>さんがチャンネルに参加しました

## 2023-10-06

- [1696616194.978539] <@U0606SPN4BW>: <@U0606SPN4BW>さんがチャンネルに参加しました

## 2023-11-21

- [1700559311.464849] <@U066P20UQH1>: <@U066P20UQH1>さんがチャンネルに参加しました

## 2024-12-01

- [1733104651.025649] <@U082RF7UF1V>: <@U082RF7UF1V>さんがチャンネルに参加しました

## 2024-12-05

- [1733469344.301359] <@U0840UVFVA8>: <@U0840UVFVA8>さんがチャンネルに参加しました

## 2025-03-03

- [1741050946.899199] <@U08FZUNPSQ3>: <@U08FZUNPSQ3>さんがチャンネルに参加しました

## 2025-03-31

- [1743469444.761299] <@U08L89G6JSG>: <@U08L89G6JSG>さんがチャンネルに参加しました

## 2025-04-13

- [1744592905.310529] <@U08N3SKSL75>: <@U08N3SKSL75>さんがチャンネルに参加しました

## 2025-04-20

- [1745195461.010779] <@U08NVD403GV>: <@U08NVD403GV>さんがチャンネルに参加しました

## 2025-05-06

- [1746589948.746419] <@U08RVRNBY00>: <@U08RVRNBY00>さんがチャンネルに参加しました

## 2025-05-28

- [1748485110.687809] <@U08U8MMTH43>: <@U08U8MMTH43>さんがチャンネルに参加しました

## 2025-06-02

- [1748914893.593359] <@U08V56G9U92>: <@U08V56G9U92>さんがチャンネルに参加しました

## 2025-07-13

- [1752475114.840969] <@U095LLEH09G>: <@U095LLEH09G>さんがチャンネルに参加しました

## 2025-09-01

- [1756788858.787589] <@U09DF1SDTQR>: <@U09DF1SDTQR>さんがチャンネルに参加しました

