# Slack channel: 中国サプライヤー

## 2025-07-16

- [1752651840.494129] <@U066P20UQH1>: <@U066P20UQH1>さんがチャンネルに参加しました
- [1752651865.249069] <@U0331FZS7JT>: <@U0331FZS7JT>さんがチャンネルに参加しました
- [1752651865.381929] <@U0331FWGQRM>: <@U0331FWGQRM>さんがチャンネルに参加しました
- [1752651865.484589] <@U0840UVFVA8>: <@U0840UVFVA8>さんがチャンネルに参加しました
- [1752651865.592889] <@U05KGS6HN9H>: <@U05KGS6HN9H>さんがチャンネルに参加しました
- [1752651865.683769] <@U08N3SKSL75>: <@U08N3SKSL75>さんがチャンネルに参加しました
- [1752652012.319029] <@U066P20UQH1>: <!channel>
お疲れ様です！
中国の抹茶サプライヤー開拓について出張に向けて、リサーチの現状報告と、今後のスケジュール感について皆さんに相談させていただきたく、
改めてMTGをさせていただければと思います！！
*明日7/17の朝10時〜10時半*でお時間いただければと思うんですが、ご都合いかがでしょうか？？
よろしければスタンプいただければと思います:bow:
- [1752652040.551419] <@USLACKBOT>: 
- [1752713980.814879] <@U066P20UQH1>: MTG room こちらとなります！
<https://meet.google.com/ihr-jrcm-mwm>
  - attachments: [{"from_url": "https://meet.google.com/ihr-jrcm-mwm", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "id": 1, "original_url": "https://meet.google.com/ihr-jrcm-mwm", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/ihr-jrcm-mwm", "service_name": "meet.google.com"}]
- [1752717658.818609] <@U066P20UQH1>: <https://meet.google.com/wdw-cdoo-fzf>
  - attachments: [{"from_url": "https://meet.google.com/wdw-cdoo-fzf", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "id": 1, "original_url": "https://meet.google.com/wdw-cdoo-fzf", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/wdw-cdoo-fzf", "service_name": "meet.google.com"}]

## 2025-07-21

- [1753149452.991509] <@U066P20UQH1>: <!channel>
お疲れ様です！
本日11時半〜お時間いただけますでしょうか？
中国出張のスケジュール・メンバー・アテンド依頼について相談したく、30分ほどお時間いただければと思います:bow:
<https://meet.google.com/kvr-uxfq-qim>
  - attachments: [{"from_url": "https://meet.google.com/kvr-uxfq-qim", "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "id": 1, "original_url": "https://meet.google.com/kvr-uxfq-qim", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/kvr-uxfq-qim", "service_name": "meet.google.com"}]
- [1753151336.419359] <@U0331FWGQRM>: <@U066P20UQH1> 
喘息の病院に薬取りに来てて、間も無く支払いが終わりますので終わり次第参加可能です。
（5分くらい遅れるかもです）
音だけで参加します。宜しくお願いします。
- [1753152770.099489] <@U066P20UQH1>: <!channel>
フォルダ：林作業中＞中国抹茶サプライヤー＞調査外注＞クラウドワークス荒川さん＞250721出張アテンド見積もり

## 2025-07-23

- [1753319128.709549] <@U066P20UQH1>: <@U08N3SKSL75> <@U05KGS6HN9H> cc <@U0331FZS7JT> <@U0331FWGQRM>
8/3-8/9 貴州・浙江省 出張スケジュール、予約情報他
- [1753319402.755199] <@U066P20UQH1>: *8/3 林　羽田→関空　¥13,110*(JCB4029決済)
```※オンラインチェックインの詳細はこちらからご確認ください。
<https://www.starflyer.jp/checkin/boarding/onlinecheckin/>

◆お客様
 ハヤシ ハルカ 様
◆フライト
 8月3日 SFJ021便
 東京羽田　08:45発 → 大阪関西　10:10着
 ●予約番号 [3153]
 ご利用運賃　ＳＴＡＲ３Ｂ
お座席　SFJ021便　8D

 運賃合計 13,110円
 ●確認番号 [228962680]```
  - files: [{"id": "F0978SGD8AG", "created": 1753319396, "timestamp": 1753319396, "name": "スクリーンショット 2025-07-24 10.00.40.png", "title": "スクリーンショット 2025-07-24 10.00.40.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 118008, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0978SGD8AG/____________________________2025-07-24_10.00.40.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0978SGD8AG/download/____________________________2025-07-24_10.00.40.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0978SGD8AG-d184dfe7d1/____________________________2025-07-24_10.00.40_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0978SGD8AG-d184dfe7d1/____________________________2025-07-24_10.00.40_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0978SGD8AG-d184dfe7d1/____________________________2025-07-24_10.00.40_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 355, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0978SGD8AG-d184dfe7d1/____________________________2025-07-24_10.00.40_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 474, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0978SGD8AG-d184dfe7d1/____________________________2025-07-24_10.00.40_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0978SGD8AG-d184dfe7d1/____________________________2025-07-24_10.00.40_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 711, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0978SGD8AG-d184dfe7d1/____________________________2025-07-24_10.00.40_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 811, "original_w": 826, "original_h": 837, "thumb_tiny": "AwAwADB0ummSZj5hAZi2dg7/AI5pn9kn/nqf++P/AK9aRUZOWI/4FTcJkDec+m6gDNOlEDIdj7BR/jT/AOyP+m//AI5/9etHaucZOf8AeNLsHqf++jQBm/2R/wBN/wDxz/69Oi0vy5kfzslSGxt6/rWhsHqf++jSbFznnI9zQAHJb7rfXP8A9elA47j8aaS/qOv9wmkJk7Ff++DQA/A9/wA6Wov3mc7h1/un/Gm+Wc53nOc/xY/LNAE2Pr+dLUPlknJc5zkY3Y/LNMUAyD95k7s8M38s/wD1vakMleVFYq0gU+npSjLAEOcdeAKdg7sk8dhilpiEwfWlpGYL1z+AJoDBiQM8eoIoAWoxAoYMMcdto/PpUlFAH//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0978SGD8AG/____________________________2025-07-24_10.00.40.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F0978SGD8AG-af23dd4c26", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F097W2EQRA4", "created": 1753319399, "timestamp": 1753319399, "name": "スクリーンショット 2025-07-24 9.59.47.png", "title": "スクリーンショット 2025-07-24 9.59.47.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 79622, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F097W2EQRA4/____________________________2025-07-24_9.59.47.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F097W2EQRA4/download/____________________________2025-07-24_9.59.47.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F097W2EQRA4-e54fff97e6/____________________________2025-07-24_9.59.47_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F097W2EQRA4-e54fff97e6/____________________________2025-07-24_9.59.47_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F097W2EQRA4-e54fff97e6/____________________________2025-07-24_9.59.47_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 281, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F097W2EQRA4-e54fff97e6/____________________________2025-07-24_9.59.47_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 375, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F097W2EQRA4-e54fff97e6/____________________________2025-07-24_9.59.47_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F097W2EQRA4-e54fff97e6/____________________________2025-07-24_9.59.47_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 562, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F097W2EQRA4-e54fff97e6/____________________________2025-07-24_9.59.47_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 625, "original_w": 882, "original_h": 689, "thumb_tiny": "AwAmADCa8sxczBvMK4ULjZn1qH+yP+m//jn/ANetOgZ70AZn9kf9N/8Axz/69H9kf9N//HP/AK9aRODyeKM8dRn6UroDN/sj/pv/AOOf/Xp0Wl+XKj+dnawONv8A9etA57EflS0wDvRSEE9GI+lAHuTQAEZHb8RQBgk8ZPXilqJ5wjFSkhx3VCRQBLRUYmBcpskyDjO04/Ok88eZs2SZzjOw4/OgCRt38JA+ozS0UUAFBGRg5/A0UUANC7TwTjvkk06iigD/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F097W2EQRA4/____________________________2025-07-24_9.59.47.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F097W2EQRA4-89a21ecedf", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1753319500.653909] <@U066P20UQH1>: *8/3 足立 出雲市駅→岡山→新大阪→関空 ¥14,800*(現地決済?)
  - files: [{"id": "F097M1DMU3B", "created": 1753319495, "timestamp": 1753319495, "name": "スクリーンショット 2025-07-24 9.07.05.png", "title": "スクリーンショット 2025-07-24 9.07.05.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 155754, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F097M1DMU3B/____________________________2025-07-24_9.07.05.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F097M1DMU3B/download/____________________________2025-07-24_9.07.05.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F097M1DMU3B-2236208977/____________________________2025-07-24_9.07.05_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F097M1DMU3B-2236208977/____________________________2025-07-24_9.07.05_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F097M1DMU3B-2236208977/____________________________2025-07-24_9.07.05_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 279, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F097M1DMU3B-2236208977/____________________________2025-07-24_9.07.05_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 372, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F097M1DMU3B-2236208977/____________________________2025-07-24_9.07.05_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F097M1DMU3B-2236208977/____________________________2025-07-24_9.07.05_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 558, "thumb_720_h": 720, "original_w": 606, "original_h": 782, "thumb_tiny": "AwAwACa40ZaQkOOOoKg5/r/+qngNnd5hZccAfzp+cduppuXK5ABI/Wi4WF5zjn6004YgN+GaePcc0wvxnaf0ouFhyBQPlxj2p1IOaWgBOoIPSkUKRwB798UgK7sZO7rjNOBJHIxQAAAZIUZopc1GUQ4BUe3FAEgopExjA4A9qWgBvYjPrx3pApxw7D8jQQcHaMEnrigoN2fm/M4oAcoI6sW+uKTacDk9aQIQB838/wDGl2cdec+9ACgYHJz70tAGKKAP/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F097M1DMU3B/____________________________2025-07-24_9.07.05.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F097M1DMU3B-4c835b1cfa", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1753319963.654129] <@U0331FZS7JT>: <@U05KGS6HN9H>
もし車で駅まで向かわれるなら、乗車は宍道駅からでも良いかも知れません。
足立さんのご自宅から近いので！
駅の自動発券所で新幹線のチケットもまとめて購入可能です。
ヤクモ：全席指定なので、宍道からでも問題なく乗れます！
以上、情報共有でした。

## 2025-07-25

- [1753437759.608119] <@U066P20UQH1>: *8/3-8/4 広州宿 ¥12,033* (JCB4029決済)
```柏高酒店（广州北站花城路地铁站店）Paco Hotel
广州花都区站前路21号```
Amap
<https://ditu.amap.com/place/B0LAF7RSUW>
```予約番号：1688891287538235
確認キー：4177```
<https://jp.trip.com/hotels/detail/?hotelId=1328559&checkIn=2025-08-03&checkOut=2025-08-04&locale=ja-JP>
- [1753437961.146969] <@U066P20UQH1>: *8/4 広州北→銅仁　高速鉄道　¥29,655* (JCB4029決済)
*09:18*
*広州北(广州北)*
```列車番号: G2138
改札口: 3检票口,西检票口2```
↓
*14:53*
*銅仁(铜仁)*

*HAYASHI HARUKA*
```大人発券済み
二等: 06車、席番12A```
*KIMURA YUKA*
```大人発券済み
二等: 06車、席番12C```
*ADACHI TAKASHI*
```大人発券済み
二等: 06車、席番12D```
- [1753438474.477129] <@U066P20UQH1>: *8/4-5-6-7 (3泊) 貴茶付近ホテル　¥25,650*(JCB4029決済)
```星玥.Enjoy Nature高空プール設計師美宿（梵淨山公園）
XIN GYUE HOTEL
江口双江街道小磨王c1门面```
A map
<https://ditu.amap.com/place/B0KUJ5MC07>
```予約番号：1688891287020335
確認キー：8993```
<https://jp.trip.com/hotels/detail/?hotelId=122019688&checkIn=2025-08-04&checkOut=2025-08-06&locale=ja-JP>

## 2025-07-28

- [1753705563.782439] <@U0331FWGQRM>: <@U05KGS6HN9H> <@U066P20UQH1> cc <@U0331FZS7JT> <@U0840UVFVA8>
情報共有
Chama tea の投稿です。
これ普通？
生葉どんなけ一気に刈ってんねん！笑

  - files: [{"id": "F097PEA6HK8", "created": 1753705540, "timestamp": 1753705540, "name": "IMG_8749.png", "title": "IMG_8749", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 3829749, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F097PEA6HK8/img_8749.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F097PEA6HK8/download/img_8749.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F097PEA6HK8-0c864b7c45/img_8749_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F097PEA6HK8-0c864b7c45/img_8749_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F097PEA6HK8-0c864b7c45/img_8749_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F097PEA6HK8-0c864b7c45/img_8749_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 221, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F097PEA6HK8-0c864b7c45/img_8749_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F097PEA6HK8-0c864b7c45/img_8749_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 332, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F097PEA6HK8-0c864b7c45/img_8749_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1734, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F097PEA6HK8-0c864b7c45/img_8749_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 443, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F097PEA6HK8-0c864b7c45/img_8749_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 472, "thumb_1024_h": 1024, "original_w": 1290, "original_h": 2796, "thumb_tiny": "AwAwABfRw28kEYIxjBpecdRn6VhFAF++rZ6gDkUzvgdKAOgCgMTzk+5pawRnHYfUUfN/eH5UASoNqqUPXpzz0/xz+VCMoU7UyR/F6D6VqiGMZ/dpjPGFpTDEesaH/gIpWAw8888jsDS7h/dFbXkRf88k/wC+RR5EP/PJP++RTAUSbmIBXAJByec/5zR5gBO/Cj1JH+e1NEcalnYYwSSSePXPX/OKb9ogLnMkWABhtw/z6U9AJty5xuGfTNLTU34UsACR82PXinUgP//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F097PEA6HK8/img_8749.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F097PEA6HK8-05577793fb", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F097B1PT9AT", "created": 1753705540, "timestamp": 1753705540, "name": "IMG_8750.png", "title": "IMG_8750", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 4749719, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F097B1PT9AT/img_8750.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F097B1PT9AT/download/img_8750.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F097B1PT9AT-f2d05ce0e2/img_8750_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F097B1PT9AT-f2d05ce0e2/img_8750_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F097B1PT9AT-f2d05ce0e2/img_8750_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F097B1PT9AT-f2d05ce0e2/img_8750_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 221, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F097B1PT9AT-f2d05ce0e2/img_8750_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F097B1PT9AT-f2d05ce0e2/img_8750_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 332, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F097B1PT9AT-f2d05ce0e2/img_8750_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1734, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F097B1PT9AT-f2d05ce0e2/img_8750_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 443, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F097B1PT9AT-f2d05ce0e2/img_8750_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 472, "thumb_1024_h": 1024, "original_w": 1290, "original_h": 2796, "thumb_tiny": "AwAwABfRw28kEYIxjBpecdRn6VlvbyoMMBzTRG0bh0xwR/ED2oA1goDE85PuaWsuIt5jFjtwcZAJ9an3f9Nf/IZpXHYjnmErjDEID07Z/wA4qIAfLl+ozzx+vvWkIIucxR4P+yKd5cZGCi4PtRYRlh03qBhsjJ3DvT8x/wByP/vkf4VoeTHnPlp7/KKPJi/55p/3yKYAJNzEArgEg5POf85o8wAnfhR6kj/PamiONSzsMYJJJPHrnr/nFN+0QFzmSLAAw24f59KegE25c43DPpmlpqb8KWABI+bHrxTqQH//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F097B1PT9AT/img_8750.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F097B1PT9AT-cecca7faed", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F098EQT0P24", "created": 1753705540, "timestamp": 1753705540, "name": "IMG_8751.png", "title": "IMG_8751", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 4718864, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F098EQT0P24/img_8751.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F098EQT0P24/download/img_8751.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F098EQT0P24-16229f0c3e/img_8751_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F098EQT0P24-16229f0c3e/img_8751_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F098EQT0P24-16229f0c3e/img_8751_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F098EQT0P24-16229f0c3e/img_8751_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 221, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F098EQT0P24-16229f0c3e/img_8751_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F098EQT0P24-16229f0c3e/img_8751_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 332, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F098EQT0P24-16229f0c3e/img_8751_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1734, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F098EQT0P24-16229f0c3e/img_8751_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 443, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F098EQT0P24-16229f0c3e/img_8751_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 472, "thumb_1024_h": 1024, "original_w": 1290, "original_h": 2796, "thumb_tiny": "AwAwABdwtG55H5UG0Ix849PxqJoHiIIkAzwCKGeUP8krHH+2TQBKbV+AccewpPsretQox80s7c57mp/MX+//AJ/KlcdiOWfc+VbgdAOaZxu+ZhwecnFaeOnIxS4H979KLCMsSASLjJwOT71J5w9/zNXyB2OaSmAjbypMZU4I5OOMdRTgHP3lX6jvUpIUEkgAckmovtMH/PaP/vsUALtPpRtPpUlFAH//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F098EQT0P24/img_8751.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F098EQT0P24-1f34d34a1a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-07-29

- [1753773330.614449] <@U0331FZS7JT>: <@U0331FWGQRM>
CC：<@U05KGS6HN9H> <@U066P20UQH1> <@U0840UVFVA8>
量的には出雲精茶とのコンテナに入る量と同じぐらいかもね！
この程度の送風で生葉焼けしないなら結構涼しいんかな:thinking_face:？
出雲精茶でこれやったら萎凋すると思う！w

## 2025-08-05

- [1754411447.986579] <@U066P20UQH1>: <!channel>
お疲れ様です！夜分にすみません。

本日無事に貴茶の視察が終わりました。
貴州省までの道のりは2日がかりで大変でしたが、なかなか濃い日々を過ごしております。

今日は朝9時から茶畑、碾茶工場、オフィス、抹茶仕上げ工場の見学をし夜ごはんまで海外営業のrenaさんにご案内いただきました。
renaさんは日本語も堪能でとても良い方でした。
仕上げ工場だけは撮影NGだったので写真がないのですが、そのほかの様子をフォルダに格納しておきます。
<@U05KGS6HN9H> <@U08N3SKSL75>
撮影した分お手隙で格納お願いします:bow:
`林作業中&gt;中国サプライヤー&gt;出張&gt;写真&gt;250805貴茶`

貴茶でも、日本と同じように引き合いの量がすごくて、相当忙しいようです。
規模としては年間抹茶生産量2000トン、有機は3割程度、残りはEU対応の非有機抹茶だそうで、有機の引き合いが強く、有機の原料確保は難しいかもしれません。（付き合いのある既存のお客さん優先で予約が埋まっていくみたいです。今年の有機抹茶は、、後少しならあるかも。。という様子でした）
非有機に関しては、1トン〜10トンは（おそらくそれ以上も）大丈夫そうでした。
日本からの引き合いも去年の秋ごろから増えているそうです。
また帰国後に、もう一社の視察の分と合わせて、詳細の情報も共有したいと思います。

明日も貴陽に滞在しますが、残念ながら貴茶も相当忙しいようで明日は案内が難しいみたいなので、ホテルかカフェで仕事して、明後日杭州に移動します。

暑い日々が続きそうなので、体調に気をつけて残りも引き続き頑張ります！
  - files: [{"id": "F098Y592DS7", "created": 1754409846, "timestamp": 1754409846, "name": "696bfb9dafc1609e5a051265b15920f9.jpg", "title": "696bfb9dafc1609e5a051265b15920f9", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 241762, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "subtype": "slack_image", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F098Y592DS7/696bfb9dafc1609e5a051265b15920f9.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F098Y592DS7/download/696bfb9dafc1609e5a051265b15920f9.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F098Y592DS7-cdad296b70/696bfb9dafc1609e5a051265b15920f9_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F098Y592DS7-cdad296b70/696bfb9dafc1609e5a051265b15920f9_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F098Y592DS7-cdad296b70/696bfb9dafc1609e5a051265b15920f9_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 294, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F098Y592DS7-cdad296b70/696bfb9dafc1609e5a051265b15920f9_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 392, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F098Y592DS7-cdad296b70/696bfb9dafc1609e5a051265b15920f9_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F098Y592DS7-cdad296b70/696bfb9dafc1609e5a051265b15920f9_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 589, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F098Y592DS7-cdad296b70/696bfb9dafc1609e5a051265b15920f9_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 654, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F098Y592DS7-cdad296b70/696bfb9dafc1609e5a051265b15920f9_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 785, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F098Y592DS7-cdad296b70/696bfb9dafc1609e5a051265b15920f9_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 837, "original_w": 1566, "original_h": 1280, "thumb_tiny": "AwAoADBsKKXwwJGPWpxCn93FMthmT8KnwD6Vki2RmBCeMj6Uv2dfVqk3AA4IbHGBUcpVYwzAjP6UxIQ2yHuab9mTOOakRAMk5/EU8KCT/KgGVoTiT8KsCSJ3wrZbjiqoOw7hnj071UhJEqlTgg1SjYXNc0pY1jQ5GE4PHr/kCq9zI6Ku0sq9DSTSsSCPl5LcHvUTsRGCRuA6Z7UIRetizRBnHzZOT605QA7t6kZqpA7eUPmPfvUm5v7x/OnyiuDI/wDcJ/EVWhifcDsOMVo1HB/qhRcLFd0Z0JVD9D9ab9nkaLbjBJ79qvUUrjKsELiJeP1qXyW9qfB/qV+lSU7isf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F098Y592DS7/696bfb9dafc1609e5a051265b15920f9.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F098Y592DS7-beb7e7a8cb", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-08-09

- [1754732534.744729] <@U0606SPN4BW>: <@U0606SPN4BW>さんがチャンネルに参加しました

