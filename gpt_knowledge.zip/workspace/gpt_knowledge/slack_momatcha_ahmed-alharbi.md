# Slack channel: momatcha_ahmed-alharbi

## 2024-07-14

- [1720992358.826059] <@U0331FWGQRM>: <@U0331FWGQRM>さんがチャンネルに参加しました
- [1720992361.311099] <@U0331FZS7JT>: <@U0331FZS7JT>さんがチャンネルに参加しました
- [1720992361.380859] <@U0331FZTHEK>: <@U0331FZTHEK>さんがチャンネルに参加しました
- [1720992361.440689] <@U033G4KN4TD>: <@U033G4KN4TD>さんがチャンネルに参加しました
- [1720992361.686489] <@U03BLQ65GK0>: <@U03BLQ65GK0>さんがチャンネルに参加しました
- [1720992361.761429] <@U041RJKV5JA>: <@U041RJKV5JA>さんがチャンネルに参加しました
- [1720992361.838699] <@U05KGS6HN9H>: <@U05KGS6HN9H>さんがチャンネルに参加しました
- [1720992361.912779] <@U0606SPN4BW>: <@U0606SPN4BW>さんがチャンネルに参加しました
- [1720992362.013079] <@U066P20UQH1>: <@U066P20UQH1>さんがチャンネルに参加しました
- [1720992425.689199] <@U0331FWGQRM>: *Sachet*
(/10g)
Matcha　40%
Beet sugar　50%
Wasanbon　10%
- [1720992596.502119] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
ブレンド比率（上記）は未定ですが、おそらくこのぐらいの比率になります。
Sachetのダイライン（デザインのフォーマット）を入手するために、
Sachetのサイズを確定する必要があります。
原料サンプルを吉村に送って、sachetのサイズを決めてもらえますか？
Momatchaは添付のsachetをイメージしていたので、この感じをベースにしてもらえますか？

※添付画像は、形状を参考にしてくださいという意味であって、
　寸法はこちらで設定してOKです。（むしろ提案してくださいとのことです）
  - files: [{"id": "F07CD3L2H26", "created": 1720992567, "timestamp": 1720992567, "name": "45B7378CE32E7722BE074744C174392F (1).jpg", "title": "45B7378CE32E7722BE074744C174392F (1).jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 95773, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07CD3L2H26/45b7378ce32e7722be074744c174392f__1_.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07CD3L2H26/download/45b7378ce32e7722be074744c174392f__1_.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07CD3L2H26-9574f8c6f4/45b7378ce32e7722be074744c174392f__1__64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07CD3L2H26-9574f8c6f4/45b7378ce32e7722be074744c174392f__1__80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07CD3L2H26-9574f8c6f4/45b7378ce32e7722be074744c174392f__1__360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 289, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07CD3L2H26-9574f8c6f4/45b7378ce32e7722be074744c174392f__1__480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 385, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07CD3L2H26-9574f8c6f4/45b7378ce32e7722be074744c174392f__1__160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07CD3L2H26-9574f8c6f4/45b7378ce32e7722be074744c174392f__1__720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 577, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07CD3L2H26-9574f8c6f4/45b7378ce32e7722be074744c174392f__1__800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 641, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07CD3L2H26-9574f8c6f4/45b7378ce32e7722be074744c174392f__1__960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 770, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07CD3L2H26-9574f8c6f4/45b7378ce32e7722be074744c174392f__1__1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 821, "original_w": 1080, "original_h": 866, "thumb_tiny": "AwAmADDTooooAqys/msA7D2FEDM0oy7EehqG9fbOy7tuQOcUae5MrKWLADOT2qNblX0NCiiirJCiiigDPul33DAruAAOO1OsxtmKhNvBNOmdkncqARgZzS2rs7ZYYqb6l9C3RRRVEBRRRQBUmDecxGPzohz5wPH50sv+sali/wBYKm2ppbQs0UUVRmf/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07CD3L2H26/45b7378ce32e7722be074744c174392f__1_.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07CD3L2H26-a5556deb33", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07CRP29Z9P", "created": 1720992569, "timestamp": 1720992569, "name": "FE25D10346EBCBC191E2255FACC8A3D5.jpg", "title": "FE25D10346EBCBC191E2255FACC8A3D5.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 59165, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07CRP29Z9P/fe25d10346ebcbc191e2255facc8a3d5.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07CRP29Z9P/download/fe25d10346ebcbc191e2255facc8a3d5.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07CRP29Z9P-276f75e8c6/fe25d10346ebcbc191e2255facc8a3d5_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07CRP29Z9P-276f75e8c6/fe25d10346ebcbc191e2255facc8a3d5_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07CRP29Z9P-276f75e8c6/fe25d10346ebcbc191e2255facc8a3d5_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 280, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07CRP29Z9P-276f75e8c6/fe25d10346ebcbc191e2255facc8a3d5_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 373, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07CRP29Z9P-276f75e8c6/fe25d10346ebcbc191e2255facc8a3d5_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07CRP29Z9P-276f75e8c6/fe25d10346ebcbc191e2255facc8a3d5_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 560, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07CRP29Z9P-276f75e8c6/fe25d10346ebcbc191e2255facc8a3d5_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 622, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07CRP29Z9P-276f75e8c6/fe25d10346ebcbc191e2255facc8a3d5_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 747, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07CRP29Z9P-276f75e8c6/fe25d10346ebcbc191e2255facc8a3d5_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 796, "original_w": 1080, "original_h": 840, "thumb_tiny": "AwAlADDTooooAr3CAtk56etJbx4kzlunrUkvWmwsPNK46CptqVd2sT0UUVRIUUUUARTUkP3j9KjvfN2jyc5zzUdkZ/NIlB27fSpsMvUUUVQgooooAqzu3mFeMe4otyfMxgYPoKbP/rmpbf8A1oqeptyrluW6KKKoxP/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07CRP29Z9P/fe25d10346ebcbc191e2255facc8a3d5.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07CRP29Z9P-c8fd4bd5e5", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1720992763.667529] <@U0331FWGQRM>: *Ceremoanial grade KIWAMI matcha 30g pull top type tin (bag in tin)*
- [1720992852.198579] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
ラベルデザインがリニューアルされました。
とりあえず、2000枚くらい印刷を進めます。

※蓋のラベルは“変更なし” です。
引き続き同じデザインを使用します。

## 2024-07-15

- [1721090688.730259] <@U05KGS6HN9H>: <@U0331FWGQRM>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
現在注文いただいているTSE-MOM-007-24（500ocs）は
ニス有りの従来缶ラベルで宜しいですよね？

## 2024-07-16

- [1721142819.867199] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
上記について:ok:ではないそうです！！:sweat_drops:
スレッドに書きましたが、旧デザインは即終了らしいです！
新デザインが今後のメインデザインとなるそうです。
- [1721142848.141629] <@U0331FWGQRM>: *今後の予定_20240717現在*
- [1721142880.037099] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
次回のご注文に関しまして、以下の詳細をご確認ください。
1. 次回のご注文は1000缶分となります。
2. 500缶には新しいメインデザインが使用されます。
3. 残りの500缶には最新のマーケティングキャンペーン専用の新デザインが使用されます。このデザインはキャンペーン期間中のみの一時的なものです。


## 2024-07-18

- [1721298133.163949] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
吉村 日高様に確認したところ、スティックのサイズは製造工場にて決定されるとの事でしたので静パックに確認しました。
10g充填は可能だと思うとの事でしたので、本日原料をお送りしてご確認いただきます。
ただし、形状は背貼りしか出来ないとの事です。
健祥は最大2g迄しか対応できないとの事です。
丸菱 藤澤様がスティック加工先をご存じとの事ですので、画像の形状で製造可能なのか確認いただいております。
- [1721325223.264279] <@U0331FWGQRM>: <@U041RJKV5JA>
<!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
確認ありがとうございます。
必ずしも上記のような構造（背貼りではない？）でなければならないかどうかまでは、
確認取れておりませんが、かき確認お願いします。

①静パックへのサイズの確認宜しくお願いします。（背貼り）
②丸菱紹介のスティック加工業者が上記のような構造（背貼りではない？）の可否
③情報図書館とかは？（ロット数が多いんでしたっけ？:sweat_drops:）

現実的なのは①な気がしております。
サイズを確認した後、吉村へ連絡し、吉村からダイラインを入手してください。

## 2024-07-24

- [1721824314.232949] <@U041RJKV5JA>: <@U0331FWGQRM>
 <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
上記確認が取れましたのでご報告いたします。
ご確認お願いいたします。
①静パックでの充填加工は可能との事です。
　・スティックサイズ：35㎜×150Ｐ
　・スティック形状：背貼り
　見積書を静パックフォルダに格納しております。
　ファイル名：(株)桃翠園様　お見積書NO.202407050
　また、吉村よりフォーマットを入手しましたのでMomatcha様フォルダに格納しております。
　ファイル名：Momacha様スティック雛形
②丸菱の取引先では背貼り形状でしか製造できず、他社をお探しいただいておりますが、未だ見つけられていないとの事です。
　画像の形状で製造可能は工場が見つかった際はご連絡いたします。
③情報図書館での充填可能範囲は0.5g～1.5gとの回答をいただいており、本件では依頼する事が出来ませんでした。
  - files: [{"id": "F07E7ESC2N5", "created": 1721824092, "timestamp": 1721824092, "name": "(株)桃翠園様　お見積書NO.202407050.pdf", "title": "(株)桃翠園様　お見積書NO.202407050.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 174333, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07E7ESC2N5/________________________________no.202407050.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07E7ESC2N5/download/________________________________no.202407050.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07E7ESC2N5-c6423ab73e/________________________________no.202407050_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07E7ESC2N5/________________________________no.202407050.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07E7ESC2N5-c4fb530d20", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07DUMC32BD", "created": 1721824104, "timestamp": 1721824104, "name": "巻取ひな形(80×150スティック).pdf", "title": "巻取ひな形(80×150スティック).pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 142507, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07DUMC32BD/________________80__150________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07DUMC32BD/download/________________80__150________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07DUMC32BD-0956f7accc/________________80__150_________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1576, "thumb_pdf_h": 1299, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07DUMC32BD/________________80__150________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07DUMC32BD-8655eff2c7", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07DE895Y07", "created": 1721824112, "timestamp": 1721824112, "name": "入稿仕様書.pdf", "title": "入稿仕様書.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 289573, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07DE895Y07/_______________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07DE895Y07/download/_______________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F07DE895Y07-37e1963896/________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1576, "thumb_pdf_h": 1113, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07DE895Y07/_______________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F07DE895Y07-3e1b38963f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1721867023.880679] <@U0331FWGQRM>: <@U041RJKV5JA>
縦横比が全然違うので、かなり細長くなると思います。
（長細すぎません？）
例えば、4x11.5cmは可能ですか？

後でスーパーに買いに行ってきます:sweat_drops:
- [1721868689.049769] <@U041RJKV5JA>: <@U0331FWGQRM>
当社の抹茶カプチーノのスティックサイズが「約4.2（シール部）/約3.5（胴）×14㎝」です。
比較画像をお送りします。
サイズ変更可能か確認後、報告いたします。
  - files: [{"id": "F07EB99RHK3", "created": 1721868665, "timestamp": 1721868665, "name": "9460.jpg", "title": "9460.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 109613, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07EB99RHK3/9460.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07EB99RHK3/download/9460.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07EB99RHK3-68f60d82e3/9460_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07EB99RHK3-68f60d82e3/9460_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07EB99RHK3-68f60d82e3/9460_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07EB99RHK3-68f60d82e3/9460_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07EB99RHK3-68f60d82e3/9460_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07EB99RHK3-68f60d82e3/9460_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07EB99RHK3-68f60d82e3/9460_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1066, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07EB99RHK3-68f60d82e3/9460_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07EB99RHK3-68f60d82e3/9460_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1108, "original_h": 1477, "thumb_tiny": "AwAwACQ4ApMr60r/AHajyKzbsZzk0yVFDMB2NPaJQpOTwKbERuX6VKx+RvpVmhXxSYpaKQDmHyGo8c1M33DTA6luR2qJGVTcWIfMKlb7p+lRxdRUp6GtDUhxRin4oxSAYx+U1BnnrUh2f7X503KehpNXIlFskiPzCpj0NVV2g5BYVIG4+8aotDs0ZpnH940f8CNAH//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07EB99RHK3/9460.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07EB99RHK3-8a184c779a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1721869589.650449] <@U0331FWGQRM>: <@U041RJKV5JA>
一回ストップしてください:sweat_drops:
吉村にダイライン何度も作らしたら、何度手間にもなるので、

こちらでスーパーのスティックサイズを確認するのと、
そのサイズの袋に、粉が入るかをこちらで確認するのが先です。
可能であれば、桃翠園のそのスティックに今回の粉を入れたらどのような感じになるかを確かめられますか？
サイズ検討の検討材料になると思います。

今の段階は、下記の中の１です。
１、Momatcha向けの粉をどのサイズのスティックに入れるのがベストなのか、
２、そしてそのサイズが製造可能なのか（これは静パックで確認）
３、吉村でダイラインを描いてもらう
４、そのダイラインにデザインを載せる
５、入稿。印刷

宜しくお願いします。
- [1721884997.340239] <@U041RJKV5JA>: <@U0331FWGQRM>
静パックにサイズ変更について確認しました。
サイズ変更は不可との事です。
今回の原料・容量では35mm×150mmでしか製造できないとの事です。
顆粒であれば巾40mm、粉体2g程度であれば50mmで製造可能との事です。

## 2024-07-25

- [1721898527.820839] <@U0331FWGQRM>: <@U041RJKV5JA> 
上記を踏まえて、
今回の件はなぜダメなんですか？
重量によっては幅を40や50に変更できて、
10gだと細いのしかできないんですか?
- [1721963898.606999] <@U041RJKV5JA>: <@U0331FWGQRM>
静パックに確認しました。
40mm巾用の機械は抹茶の様な細かい粉体には対応していない構造なので不可。
50mm巾は充填する際にスクリューに抹茶を載せて袋に押し込むようにして入れるが、スクリューが細く2g程度しか載せることが出来ない為不可。
本件原料の粒度、容量から35mm巾の機械でしか充填出来ないとの判断となったとの事です。
- [1721971971.931839] <@U0331FWGQRM>: <@U041RJKV5JA> 
これらスティックはこのサイズです。
ブレンディ　3.5x12.5
ネスカフェ　3.5x12.0

なので、3.5cmで大丈夫そうです。
ただ、長さは13cmくらいまでが理想です。
可能そうでしょうか？:sweat_drops:
  - files: [{"id": "F07DR8PT04X", "created": 1721971739, "timestamp": 1721971739, "name": "IMG_5487.MOV", "title": "IMG_5487", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 6332939, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F07DR8PT04X-2208fc125d/img_5487.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F07DR8PT04X-2208fc125d/img_5487.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07DR8PT04X/download/img_5487.mov?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F07DR8PT04X-2208fc125d/file.m3u8?_xcb=57f79&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9Mjg1NTc0NyxBVkVSQUdFLUJBTkRXSURUSD0yODIzMzE4LENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTgxMHgxMDgwLEZSQU1FLVJBVEU9MjkuOTcwCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBM1JGSTRVRlF3TkZndE1qSXdPR1pqTVRJMVpDOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TVM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTNSRkk0VUZRd05GZ3RNakl3T0daak1USTFaQzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01pNTBjd29qUlZoVVNVNUdPakl1TURZNUxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEzUkZJNFVGUXdORmd0TWpJd09HWmpNVEkxWkM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNeTUwY3dvalJWaFVMVmd0UlU1RVRFbFRWQW89CiNFWFQtWC1TVFJFQU0tSU5GOkJBTkRXSURUSD0xNTc5NjI1LEFWRVJBR0UtQkFORFdJRFRIPTE1NjcyMzAsQ09ERUNTPSJhdmMxLjY0MDAxZixtcDRhLjQwLjUiLFJFU09MVVRJT049NTQweDcyMCxGUkFNRS1SQVRFPTI5Ljk3MApodHRwczovL2ZpbGVzLnNsYWNrLmNvbS9maWxlcy10bWIvVDAzM0Q3MFJSNkgtRjA3RFI4UFQwNFgtMjIwOGZjMTI1ZC9maWxlX0hfMjY0XzEyODB4NzIwXzM1MDBLQlBTXzdRVkJSLm0zdTgK", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F07DR8PT04X-2208fc125d/img_5487_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 14080, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F07DR8PT04X-2208fc125d/img_5487_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 960, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07DR8PT04X/img_5487.mov", "permalink_public": "https://slack-files.com/T033D70RR6H-F07DR8PT04X-07d36aff75", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07E89WP6TW", "created": 1721971738, "timestamp": 1721971738, "name": "IMG_5486.jpg", "title": "IMG_5486", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 978458, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07E89WP6TW/img_5486.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07E89WP6TW/download/img_5486.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07E89WP6TW-423697d067/img_5486_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07E89WP6TW-423697d067/img_5486_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07E89WP6TW-423697d067/img_5486_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07E89WP6TW-423697d067/img_5486_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07E89WP6TW-423697d067/img_5486_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07E89WP6TW-423697d067/img_5486_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07E89WP6TW-423697d067/img_5486_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07E89WP6TW-423697d067/img_5486_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07E89WP6TW-423697d067/img_5486_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3024, "original_h": 4032, "thumb_tiny": "AwAwACRmSYW+lMpy/wCpf6UjqwGV24/PFCdiZRuJQBzUsaqY8lCx+tMYAOcLj2pqV3YhxaVwGewpcH0pM0ZoGNQ/um+lSpFI6AgrtYY59aqo37s1dtnAthuIHOOaRp1GxfJlTng44FNcfO1TRqDPID65pkw2ysBUr4hPYiIoxSmirIK0Skq3pU9uyeWAz7TmlYryARUAVlG49KRbL29C5PJzjpTXIJ+XOPeq6zovBB/KnG4UDO00WQtR+KMVEJi3IQ4pfNb/AJ5mmKzP/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07E89WP6TW/img_5486.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07E89WP6TW-23013eda24", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1721972712.826739] <@U041RJKV5JA>: <@U0331FWGQRM>
確認しました。
150mmより低くするとシール面への嚙み込みが発生する為、不可との事でした。

## 2024-08-04

- [1722813659.126899] <@U041RJKV5JA>: <@U0331FWGQRM>
静パックより各サイズへの充填可能量の連絡がございました。
・110p→5ｇ
・120p→7ｇ
・130p→8ｇ
・140p→9ｇ
・150p→10g
白缶＋中袋が届きましたら、出荷いたします。

## 2024-08-05

- [1722849234.477369] <@U0331FWGQRM>: <@U041RJKV5JA>
お客様から、それぞれ、粉を入れた状態のサンプルを見たいと言われました。
行なってもらえるか確認してくれますか？？:sweat_drops:
最悪、有償でもいいです。

## 2024-08-07

- [1723018005.123269] <@U041RJKV5JA>: <@U0331FWGQRM>
静パックより製造不可との連絡がございました。
理由は、“手作業となり、機械で充填した時と膨らみ具合が異なり参考にならない為”との事です。
空打ちスティックと白缶を出荷いたしましょうか。

## 2024-12-01

- [1733104651.342449] <@U082RF7UF1V>: <@U082RF7UF1V>さんがチャンネルに参加しました

## 2024-12-05

- [1733469344.509839] <@U0840UVFVA8>: <@U0840UVFVA8>さんがチャンネルに参加しました

## 2025-03-03

- [1741050947.099259] <@U08FZUNPSQ3>: <@U08FZUNPSQ3>さんがチャンネルに参加しました

## 2025-03-31

- [1743469444.927929] <@U08L89G6JSG>: <@U08L89G6JSG>さんがチャンネルに参加しました

## 2025-04-13

- [1744592905.495259] <@U08N3SKSL75>: <@U08N3SKSL75>さんがチャンネルに参加しました

## 2025-04-20

- [1745195461.324909] <@U08NVD403GV>: <@U08NVD403GV>さんがチャンネルに参加しました
- [1745199345.549469] <@U0331FZS7JT>: <@U066P20UQH1>
Momatchaメモ
紅茶ラテサンプルについて

キタマ：ベルガモット依頼
ベルガモットパウダー
ベルガモット果汁パウダー
何れもナチュラル
サンプル確認後フィードバックします。

## 2025-04-23

- [1745468663.183939] <@U0331FZS7JT>: <@U066P20UQH1>
ベルガモット果汁パウダー
香りが弱いため不可

ベルガモットパウダー
香りがあるがそこそこ酸味強し
粒度がかなり荒いため粉砕のし直しが必要
L使えるか微妙

上記いずれもキタマ

大東製糖
　L砂糖にフレーバーを纏わせることが可能な会社
ここに別途確認中
おそらくここで作っているのでは？と推測
セバスチャンのマンゴーフレーバーの砂糖を作っているところ。
→最近砂糖とフレーバーの案件はロスもあるためもうやめたorz

<https://www.harunoterrace.co.jp>
ここに確認中
  - attachments: [{"from_url": "https://www.harunoterrace.co.jp/", "id": 1, "original_url": "https://www.harunoterrace.co.jp", "fallback": "はるのTERRACE", "text": "はるのTERRACEでは、南国高知で生産された野菜を使用し、独自製法にこだわりのある加工品を多数販売しております。", "title": "はるのTERRACE", "title_link": "https://www.harunoterrace.co.jp/", "service_name": "harunoterrace.co.jp"}]

## 2025-04-26

- [1745656896.308969] <@U0331FZS7JT>: テストしたが香りが弱い。
全量ベルガモットシュガーを使ったらかなりコストが上がることが予想される。
曽田香料にベルガモット香料パウダーがあるため、サンプル依頼中。
再度検討。

## 2025-05-06

- [1746589948.898659] <@U08RVRNBY00>: <@U08RVRNBY00>さんがチャンネルに参加しました

## 2025-05-08

- [1746767805.145569] <@U066P20UQH1>: メモ
土佐ベルガモット80パー　:heavy_multiplication_x: 出雲紅茶P20パー

## 2025-05-28

- [1748485110.958899] <@U08U8MMTH43>: <@U08U8MMTH43>さんがチャンネルに参加しました

## 2025-06-02

- [1748914893.735979] <@U08V56G9U92>: <@U08V56G9U92>さんがチャンネルに参加しました

## 2025-07-13

- [1752475114.934359] <@U095LLEH09G>: <@U095LLEH09G>さんがチャンネルに参加しました

## 2025-09-01

- [1756788858.895299] <@U09DF1SDTQR>: <@U09DF1SDTQR>さんがチャンネルに参加しました

