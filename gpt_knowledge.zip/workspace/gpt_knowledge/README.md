# Knowledge Base: Slack Export

This folder contains markdown summaries of Slack channels exported from your workspace.

## Files
- slack_00_なんでもok.md
- slack_01_サンプル出荷.md
- slack_02_groene-company.md
- slack_02_受注.md
- slack_03_原料仕入れ.md
- slack_04_入金確認.md
- slack_FC_F07V129KLLB_Tea_Testing_Summary.md
- slack_FC_F08ATAMUR16_プロジェクトトラッカー.md
- slack_hp作成-海外.md
- slack_momatcha_ahmed-alharbi.md
- slack_omatcha.md
- slack_sebastyan.md
- slack_アリババ.md
- slack_中国サプライヤー.md
- slack_是正処置が必要な案件.md
- slack_海外営業mtg.md
- slack_製造.md
- slack_調達.md
- slack_議事録.md
- slack_雑談.md
- slack_顧客管理表.md

Total messages summarized: 26248
