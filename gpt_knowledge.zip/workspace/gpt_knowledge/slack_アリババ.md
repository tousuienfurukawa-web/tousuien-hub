# Slack channel: アリババ

## 2022-02-16

- [1645068519.560359] <@U0331FWGQRM>: <@U0331FWGQRM>さんがチャンネルに参加しました
- [1645068551.290619] <@U0331FZS7JT>: <@U0331FZS7JT>さんがチャンネルに参加しました
- [1645069693.206379] <@U033G4KN4TD>: <@U033G4KN4TD>さんがチャンネルに参加しました
- [1645073790.990759] <@U0331FWGQRM>: 
  - files: [{"id": "F03463FFJ72", "created": 1645073785, "timestamp": 1645073785, "name": "商品検討_PRICE LIST.xlsx", "title": "商品検討_PRICE LIST.xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 23481, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F03463FFJ72/_____________price_list.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F03463FFJ72/download/_____________price_list.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F03463FFJ72-ad8d8f3fbd/_____________price_list_converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F03463FFJ72-ad8d8f3fbd/_____________price_list_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F03463FFJ72/_____________price_list.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F03463FFJ72-f49e770bda", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1645073816.735309] <@U0331FWGQRM>: 途中ですが、
作成しました。:sweat_drops:間に合わなかったです
- [1645078501.279089] <@U0331FWGQRM>: 
  - files: [{"id": "F033GH71ECS", "created": 1645078497, "timestamp": 1645078497, "name": "スクリーンショット 2022-02-17 15.14.53.png", "title": "スクリーンショット 2022-02-17 15.14.53.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 249455, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F033GH71ECS/____________________________2022-02-17_15.14.53.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F033GH71ECS/download/____________________________2022-02-17_15.14.53.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F033GH71ECS-d9ec3ef030/____________________________2022-02-17_15.14.53_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F033GH71ECS-d9ec3ef030/____________________________2022-02-17_15.14.53_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F033GH71ECS-d9ec3ef030/____________________________2022-02-17_15.14.53_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 300, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F033GH71ECS-d9ec3ef030/____________________________2022-02-17_15.14.53_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 399, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F033GH71ECS-d9ec3ef030/____________________________2022-02-17_15.14.53_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F033GH71ECS-d9ec3ef030/____________________________2022-02-17_15.14.53_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 599, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F033GH71ECS-d9ec3ef030/____________________________2022-02-17_15.14.53_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 666, "original_w": 918, "original_h": 764, "thumb_tiny": "AwAnADDQkk2HGM8Z607Jz04oZVPVQfqKM0wFoprPtHTPsKFfd2I+tIB1AOaTNKDQAhqK4dkiypAOQMkZ71Kagu/9SP8AeX+dNALsm/57D/vgVDNMYGCyT4JGeI6udhTHjDkEgH6rmkBFBIzkHfvVl3D5cd6sCogNs4AAHyHoPepRQAtMkiWVdrZx6A0+igCD7JH6v/32aPskfq//AH2anooAiS3SNtyls9OWzUoGKKKAP//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F033GH71ECS/____________________________2022-02-17_15.14.53.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F033GH71ECS-1df8ce0316", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1645078512.028889] <@U0331FWGQRM>: これがdingtalk？
- [1645078606.943139] <@U0331FZS7JT>: それです！

## 2022-02-17

- [1645089598.641879] <@U0331FWGQRM>: 
  - files: [{"id": "F033AKX9GAJ", "created": 1645089593, "timestamp": 1645089593, "name": "スクリーンショット 2022-02-17 17.15.56.png", "title": "スクリーンショット 2022-02-17 17.15.56.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 102482, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F033AKX9GAJ/____________________________2022-02-17_17.15.56.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F033AKX9GAJ/download/____________________________2022-02-17_17.15.56.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F033AKX9GAJ-217f0c4beb/____________________________2022-02-17_17.15.56_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F033AKX9GAJ-217f0c4beb/____________________________2022-02-17_17.15.56_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F033AKX9GAJ-217f0c4beb/____________________________2022-02-17_17.15.56_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 112, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F033AKX9GAJ-217f0c4beb/____________________________2022-02-17_17.15.56_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 149, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F033AKX9GAJ-217f0c4beb/____________________________2022-02-17_17.15.56_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F033AKX9GAJ-217f0c4beb/____________________________2022-02-17_17.15.56_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 223, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F033AKX9GAJ-217f0c4beb/____________________________2022-02-17_17.15.56_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 248, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F033AKX9GAJ-217f0c4beb/____________________________2022-02-17_17.15.56_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 297, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F033AKX9GAJ-217f0c4beb/____________________________2022-02-17_17.15.56_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 317, "original_w": 1740, "original_h": 539, "thumb_tiny": "AwAOADDSLY60bh60joHXB/P0pqRKq4PPuTQIfnPQik3fWjYvpTqBibv84peaKKAP/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F033AKX9GAJ/____________________________2022-02-17_17.15.56.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F033AKX9GAJ-0248227d48", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1645089637.683899] <@U0331FWGQRM>: <@U0331FZS7JT> <@U033G4KN4TD> カテゴリ分けについて、
これでどうかなと思いますがいかがでしょうか。
追記あれば宜しくお願いします！
※製品数は14個です。
- [1645113262.191259] <@U0331FWGQRM>: <@U0331FZS7JT> 押印の上スキャンして私に返信してもらえますか？宜しくお願いします。
- [1645113271.304429] <@U0331FWGQRM>: 
  - files: [{"id": "F033CQNAXK8", "created": 1645113267, "timestamp": 1645113267, "name": "DHLアカウント開設同意書.pdf", "title": "DHLアカウント開設同意書.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 377189, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F033CQNAXK8/dhl______________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F033CQNAXK8/download/dhl______________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F033CQNAXK8-ae9fd4fb99/dhl_______________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 935, "thumb_pdf_h": 1210, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F033CQNAXK8/dhl______________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F033CQNAXK8-7a036d7725", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1645140459.205529] <@U0331FZS7JT>: <@U0331FWGQRM>
了解です！
- [1645141248.627749] <@U0331FZS7JT>: 送りました！
- [1645152167.449529] <@U033G4KN4TD>: <@U0331FWGQRM> お疲れ様です。
UPSの鈴木さんからもらった資料（アカウント申請書・サービスガイド）
を共有フォルダに入れております。
- [1645152279.807309] <@U033G4KN4TD>: <@U0331FWGQRM> 私が分かる情報を入力いたしますか？
- [1645152306.631499] <@U0331FWGQRM>: <@U033G4KN4TD> 有難う御座います。お願いします！
- [1645158927.117299] <@U033G4KN4TD>: <@U0331FWGQRM>
UPSのアカウント申請書に私の分かる範囲で情報を記入いたしました、
ご確認お願い致します。

## 2022-02-18

- [1645257590.394469] <@U0331FZS7JT>: <@U0331FWGQRM> 執行役
ありがとうございます！

大枠のカテゴリ（matcha, sencha,… ）良いですね！
SALEの枠は面白い！！
実績のスピード優先で、こちら進めつつ、
後続でアジアだとオーガニックでなくても求められることもあるので
Matchaの中に、Non organic枠 があっても良いかなと思いました（出雲抹茶、宇治抹茶、八女抹茶など）！

ただ、上記の場合産地名縛りも出てきそうなので、考えるので、また週明け相談させてください！

よろしくお願いします:man-bowing:

## 2022-02-24

- [1645750015.947209] <@U0331FWGQRM>: ＜予定メモ＞
<@U033G4KN4TD>
下記件、調査願います。
期限：3/4

whatsapp、wechat
の桃翠園globalのビジネスアカウント作成

→各ビジネスアカウントを作成する際の注意点や、
　利用できる機能を調査＆アカウント作成＆テスト運用

<https://www.whatsapp.com/business/?lang=ja#:~:text=WhatsApp%20Business%E3%81%AF%E7%84%A1%E6%96%99%E3%81%A7,%E3%81%AB%E8%A8%AD%E8%A8%88%E3%81%95%E3%82%8C%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82|https://www.whatsapp.com/business/?lang=ja#:~:text=WhatsApp%20Business%E3%81%AF%E7%84%A1%E6%96[…]%81%95%E3%82%8C%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82>

<https://snaplace.biz/wechatcompac/>
  - attachments: [{"from_url": "https://www.whatsapp.com/business/?lang=ja#:~:text=WhatsApp%20Business%E3%81%AF%E7%84%A1%E6%96%99%E3%81%A7,%E3%81%AB%E8%A8%AD%E8%A8%88%E3%81%95%E3%82%8C%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82", "image_url": "https://static.whatsapp.net/rsrc.php/v3/yO/r/FsWUqRoOsPu.png", "image_width": 476, "image_height": 250, "image_bytes": 49298, "service_icon": "https://static.whatsapp.net/rsrc.php/v3/yP/r/rYZqPCBaG70.png", "id": 1, "original_url": "https://www.whatsapp.com/business/?lang=ja#:~:text=WhatsApp%20Business%E3%81%AF%E7%84%A1%E6%96%99%E3%81%A7,%E3%81%AB%E8%A8%AD%E8%A8%88%E3%81%95%E3%82%8C%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82", "fallback": "WhatsApp.com: WhatsApp Businessアプリ", "text": "WhatsApp Messenger: 180カ国以上で20億を超える人たちが、WhatsAppを使って、いつでもどこでも友人や家族と連絡を取り合っています。 WhatsAppは無料かつ、世界中の携帯電話で利用可能な、シンプルで安全で信頼性の高いメッセージと通話を提供します。", "title": "WhatsApp Businessアプリ", "title_link": "https://www.whatsapp.com/business/?lang=ja#:~:text=WhatsApp%20Business%E3%81%AF%E7%84%A1%E6%96%99%E3%81%A7,%E3%81%AB%E8%A8%AD%E8%A8%88%E3%81%95%E3%82%8C%E3%81%BE%E3%81%97%E3%81%9F%E3%80%82", "service_name": "WhatsApp.com"}]

## 2022-03-06

- [1646617165.841109] <@U0331FWGQRM>: 
  - files: [{"id": "F035V897E1Y", "created": 1646617159, "timestamp": 1646617159, "name": "alibaba todo.png", "title": "alibaba todo.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 238144, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F035V897E1Y/alibaba_todo.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F035V897E1Y/download/alibaba_todo.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F035V897E1Y-4e26fdbcf5/alibaba_todo_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F035V897E1Y-4e26fdbcf5/alibaba_todo_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F035V897E1Y-4e26fdbcf5/alibaba_todo_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 202, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F035V897E1Y-4e26fdbcf5/alibaba_todo_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 269, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F035V897E1Y-4e26fdbcf5/alibaba_todo_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F035V897E1Y-4e26fdbcf5/alibaba_todo_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 403, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F035V897E1Y-4e26fdbcf5/alibaba_todo_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 448, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F035V897E1Y-4e26fdbcf5/alibaba_todo_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 538, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F035V897E1Y-4e26fdbcf5/alibaba_todo_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 573, "image_exif_rotation": 1, "original_w": 2368, "original_h": 1326, "thumb_tiny": "AwAaADC0WAYjbxn1NLHh2IK9vU0xvvt9afB98/Ss03c0aVib5u2MU0yYODj8KfUTLuOQRWhmSAsf7tLikHSloAqsPnP1p8H3z9KsUVKjrcrm0sJUbA546VI1C9KokQYxS96Wg9KAP//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F035V897E1Y/alibaba_todo.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F035V897E1Y-6752f9e2ec", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F035V89AHJN", "created": 1646617162, "timestamp": 1646617162, "name": "alibabaスケジュール.png", "title": "alibabaスケジュール.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 1001148, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F035V89AHJN/alibaba_____________________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F035V89AHJN/download/alibaba_____________________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F035V89AHJN-ce53f3c506/alibaba______________________64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F035V89AHJN-ce53f3c506/alibaba______________________80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F035V89AHJN-ce53f3c506/alibaba______________________360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 202, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F035V89AHJN-ce53f3c506/alibaba______________________480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 269, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F035V89AHJN-ce53f3c506/alibaba______________________160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F035V89AHJN-ce53f3c506/alibaba______________________720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 403, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F035V89AHJN-ce53f3c506/alibaba______________________800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 448, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F035V89AHJN-ce53f3c506/alibaba______________________960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 538, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F035V89AHJN-ce53f3c506/alibaba______________________1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 574, "image_exif_rotation": 1, "original_w": 2378, "original_h": 1332, "thumb_tiny": "AwAaADC+SM4P86OFOfy5pf4qUgYoATfSlgAD6+lHHtSOORSbsNCGQ5GBxnBzTgQSPlb8RSBQRk9TT8j1oWoEeDupTml70UxCc0p7Zx+VKAMdKKAAEAdqUEdqTFHagD//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F035V89AHJN/alibaba_____________________.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F035V89AHJN-b200848954", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1646617262.264349] <@U0331FWGQRM>: 
  - files: [{"id": "F035NJQUR9C", "created": 1646617258, "timestamp": 1646617258, "name": "スクリーンショット 2022-03-07 10.40.49.png", "title": "スクリーンショット 2022-03-07 10.40.49.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 119804, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F035NJQUR9C/____________________________2022-03-07_10.40.49.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F035NJQUR9C/download/____________________________2022-03-07_10.40.49.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F035NJQUR9C-f72b588cd4/____________________________2022-03-07_10.40.49_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F035NJQUR9C-f72b588cd4/____________________________2022-03-07_10.40.49_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F035NJQUR9C-f72b588cd4/____________________________2022-03-07_10.40.49_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 70, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F035NJQUR9C-f72b588cd4/____________________________2022-03-07_10.40.49_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 94, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F035NJQUR9C-f72b588cd4/____________________________2022-03-07_10.40.49_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F035NJQUR9C-f72b588cd4/____________________________2022-03-07_10.40.49_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 140, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F035NJQUR9C-f72b588cd4/____________________________2022-03-07_10.40.49_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 156, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F035NJQUR9C-f72b588cd4/____________________________2022-03-07_10.40.49_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 187, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F035NJQUR9C-f72b588cd4/____________________________2022-03-07_10.40.49_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 200, "original_w": 2482, "original_h": 484, "thumb_tiny": "AwAJADDRLHOME0ivuzjnBwafQKAG5J/hNLz6UtFACZPpS0UUAf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F035NJQUR9C/____________________________2022-03-07_10.40.49.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F035NJQUR9C-9e18519878", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1646618016.650969] <@U0331FZS7JT>: 【アリババ サブアカウント】について
※メールも転送します。

(1) Account Type：Sales Assistant
Password： }p#c8c8}*&gt;YQ

(2) Account Type：Sales Representative
Password： gYmM&amp;u8mrNEH
---------------------------------------------------------
【サブアカウント設定・説明】
展示・運営代行サービスをご利用いただくにあたり、
弊社または業務委託先が貴社のアカウントにログインするための
サブアカウントの設定をお願いしております。

設定方法は、サブアカウント作成マニュアルをご確認ください。
<http://wp-service.alibaba.co.jp/manual_detail/id=435>

◇サブアカウントを設定いただくにあたり必要な情報

(1) Account Type：Sales Assistant
Email： <mailto:operation2413@aj-ggs.com|operation2413@aj-ggs.com>
Password：別メールでお送りいたします
Mobile Phone(Verification)：貴社の固定電話番号をご記入ください

(2) Account Type：Sales Representative
Email： <mailto:operation2414@aj-ggs.com|operation2414@aj-ggs.com>
Password：別メールでお送りいたします
Mobile Phone(Verification)：貴社の固定電話番号をご記入ください

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━■
┃アリババ日本サプライヤー様窓口
┃TEL： <tel:0367770169|03-6777-0169> （9：00～18：00 ※土日、祝日を除く）
<mailto:%E2%94%83%E3%83%A1%E3%83%BC%E3%83%AB%E3%82%A2%E3%83%89%E3%83%AC%E3%82%B9%EF%BC%9Awp_customer@alibaba-inc.jp|┃メールアドレス：><mailto:wp_customer@alibaba-inc.jp|wp_customer@alibaba-inc.jp>
┃オンラインマニュアル：<http://wp-service.alibaba.co.jp/>
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━■
  - attachments: [{"from_url": "http://wp-service.alibaba.co.jp/manual_detail/id=435", "id": 1, "original_url": "http://wp-service.alibaba.co.jp/manual_detail/id=435", "fallback": "アリババ オンラインマニュアル: サブアカウントの作成手順", "text": "世界最大の企業間取引サイト アリババドットコムへの掲載とそのサポートをするAlibaba.com日本会員向けサービスのオンラインマニュアルです。", "title": "サブアカウントの作成手順", "title_link": "http://wp-service.alibaba.co.jp/manual_detail/id=435", "service_name": "アリババ オンラインマニュアル"}, {"from_url": "http://wp-service.alibaba.co.jp/", "id": 2, "original_url": "http://wp-service.alibaba.co.jp/", "fallback": "アリババ オンラインマニュアル", "text": "世界最大の企業間取引サイト アリババドットコムへの掲載とそのサポートをするAlibaba.com日本会員向けサービスのオンラインマニュアルです。", "title": "アリババ オンラインマニュアル", "title_link": "http://wp-service.alibaba.co.jp/", "service_name": "wp-service.alibaba.co.jp"}]
- [1646621852.839539] <@U0331FWGQRM>: <@U033G4KN4TD>
alibaba向け商品の準備が必要な商材です。
宜しくお願いします。

＜有機ほうじ茶＞
リーフ　ひかわ　1600←Genuine
粉末 ひかわ　2300←Genuine


＜有機玄米茶＞
リーフ　鹿児島製茶秋冬番900＋丸菱玄米800＝851円/kg←Genuine
粉末 851+300（粉砕費/出雲精茶）*←要準備*

＜有機煎茶＞
リーフ
(1番茶)4500 4000　鹿児島製茶　*←要準備*
(2番茶)2500 まるゑい *←要準備*
(秋冬番)1200 鹿児島製茶　←Genuine

粉末 上記＋300　*←要準備*

## 2022-03-25

- [1648255894.327379] <@U0331FWGQRM>: <@U033G4KN4TD>
煎茶パウダー
ほうじ茶の焙煎機

の写真をゲットしてください。
よろしくお願いします
- [1648263261.243049] <@U033G4KN4TD>: <@U0331FWGQRM>
お疲れ様です
煎茶パウダーの写真を素材の煎茶パウダーのフォルダに入れております。
午後、焙煎機の写真を撮ってから、入れます。
よろしくお願い致します。
- [1648269580.807929] <@U033G4KN4TD>: <@U0331FWGQRM>
焙煎機の写真を素材フォルダに入れております。
よろしくお願い致します。
- [1648277457.845609] <@U033G4KN4TD>: <@U0331FWGQRM>
お疲れ様です。
5kg用bagのサイズを記入致しました。
ご確認よろしくお願い致します。

## 2022-04-04

- [1649124209.476869] <@U0331FZS7JT>: 22.4.5MTGメモ
my alibaba
会社情報
最低90%以上記載

キャンペーン
オーダー
は日本企業に対応していない

有効なバイヤーかを確認
・国旗：登録地
・メッセージ：どこから送ったか
→同じか？確認
怪しそうな場合アリババに相談は可能

登録から１年以上あるか？
なども判断材料に

Spamは10件以上でやばいバイヤー

バイヤーはミニサイトは見れるが
RFQは見れない

メッセージのやり取りは問題ない
※ファイルやURLは気を付ける

チャット：Message

サブアカウント：
制作チームが掲載作業を行う
１つはデータ確認と運用

RFQ
強みをメッセージに記載

価格のレンジがある場合は
メッセージで詳細を伝える

15日の17時ぐらいにRFQの数値は消える
半月で20件

RFQについては
ポイントが付与されて、ボーナスがつく

12製品300ページ作る
作成後は
13製品の場合自分達でページを別途作成する

とにかく引っ掛ける様々なページを作ったほうがよいか。
製品ページ→ミニサイト
の流れになるので、合わせたほうが良い。

製品ページ：12製品
・これを複製

・または用途別に→茶道用のページ
　　　　　　　　  お菓子用のページに

同じ製品で300ページか
色々なパターンで300ページを作るか（工数はかかる）


【次の面談データの見方】
GW明け
９日10時から

## 2022-04-26

- [1650966630.870369] <@U033G4KN4TD>: <@U0331FZS7JT> <@U0331FWGQRM> 
お疲れ様です。
19時からのMTGについて、参加予定ですけど、家庭の突然な事で欠席させていただきたいです。
申し訳ございませんが、明日、MTGの内容を聞かせていただきます。
よろしくお願い致します。
- [1650966920.022019] <@U033G4KN4TD>: 大変失礼致しました。

## 2022-05-08

- [1652062139.229849] <@U0331FZS7JT>: <!here>
22.5.9 本日のアリババMTGメモ
【データの見方】
・キーワード広告の開始時期
あと100ページ分できるが今後余裕あれば作成するが
現状は未定
・運営代行プランは来年２月までなので
　その後は自分達で追加する
※運営代行プランを継続した場合は問題ない

・Date　overview
カレンダー
month
search impression
UV:見た人の数
黄色：同業界のTOP５
緑：平均
青：自社
⇒Viewを上げる必要がある
ページ数を増やす、広告を打つが主な対策
円グラフ：桃翠園のことを検索している会社がある国
今は日本と中国（アリババが見てるから）

Product Index
のチェックで各商品などの検索数を確認できる
ワードを確認し、キーワードを変える

製品情報以外の動画や画像
会社情報

・次につながる要素を入れる
サンプルすぐ送れますよ！
どんな顧客をターゲットにしていますか？
などゴリゴリ

製品情報を入れる
（強み/価格・品質・資格・物流・すぐに返信、対応しますなどを載せる！）
客に対して比較をさせる！
見積（金額）についてはメッセージに記載する。

RFQ
オーガニックの提供に絞ってみる

問い合わせが来たら。。。
展示会のブースにその客が来た感じと同じ温度感
⇒どんどん強みを熱量持って伝えるべし！

広告が基本的にデフォルト
1000ドル広告費をいつ使うか

Smart marketing 最低500USD
Custom campaine 1日最低20USD
⇒キーワード選定：自社　価格：両社

６月：スマートでまずやってみよう！

## 2022-07-10

- [1657505421.954769] <@U0331FZS7JT>: 7/11　アリババMTG議事録

【最近の問い合わせ】
・インドネシア（抹茶、ほうじ茶、玄米茶）
・カナダ（フルーツ抹茶＆それ以外の抹茶）
→客からのFBはチャットワークに送る

最近競合増えてきた
今後の予定：１ヶ月３、４件サンプル→１件決まる

成約企業例：専属１人が結構（但し、人が足りていない）

【広告】
広告：Matchaでやって、フレーバーとかを後で提案するのが良いのでは
広告KW：Matcha, Organic Matcha, Hojicha Powder ,Genmaicha
→これまではAIだったが、上記の通り選定して広告する
　一旦先月同様600USD/月で効果（ViewがClickにつながるか）を確認する。

広告先国
成約につながりにくい国を外す（ex.Other Asian country）

RFQ：国絞る（バングラディシュやパキスタンを外す）
- [1657507586.907389] <@U0331FWGQRM>: （追記）
サンプル依頼されたお客様に、なんで数あるお茶屋の中から桃翠園を選んでくれたのか、聞けたら聞くこと。

## 2022-07-25

- [1658746237.331019] <@U033G4KN4TD>: <@U0331FWGQRM> <@U0331FZS7JT>
お疲れ様です。
出張中、すみません。
分からないところがありますので、お教えていただきたいと思います。
新規のお客様からのメール内容を転送いたします。

Dear
Good day and thanks for your kind response regarding our inquiry.
Please quote the listed product as attached in the document on our webpage below, with FOB prices, we need to make a new order for a 2 x 40 ft container next month also our descriptions, labels, packing, and other details can be found in our company webpage below.

*<https://guevaraata.com/viewproductforoder86463/maxed?eml=lo@tousuien.jp>*

*Please ensure to login correctly*
*Can you ship before August 29th?Also what is your FOB。*

上記のURLをクリックしたら、PWを入力して、ログインできない状態です。
「<mailto:lo@tousuien.jp|lo@tousuien.jp>」のPW「Overseas-100」であってますでしょうか？
よろしくお願いいたします。
- [1658746366.435469] <@U0331FWGQRM>: <@U033G4KN4TD> 
外出してますので、少々待ってください。

詐欺の可能性もあるので注意してくださいね！
- [1658746451.977719] <@U033G4KN4TD>: *<@U0331FWGQRM>* 
*Wang Lee*
*Purchasing Manager* 
*VECO Corporation.*
*SINGAPORE IMPORTERS &amp; DISTRIBUTORS.*
*271 Bukit Timah Rd, Singapore*
*OFFICE: <tel:+6581822380|+65 8182 2380>*
*DIRECT: <tel:+6531384618|+65 3138 4618>*
*SHOWROOM: <tel:+6563842819|+65 6384 2819>*
*E-MAIL:* <mailto:annielin02@vecocorporation.com|annielin02@vecocorporation.com>
<mailto:bonnie@blysspipes.com|bonnie@blysspipes.com>
*<https://www.veeco.com>*
  - attachments: [{"from_url": "https://www.veeco.com/", "id": 1, "original_url": "https://www.veeco.com", "fallback": "Veeco: Solving Tough Materials Engineering Challenges", "text": "Veeco is a leading manufacturer of technologies that play an integral role in producing LEDs for solid-state lighting and displays, and in the fabrication of advanced semiconductor devices.", "title": "Solving Tough Materials Engineering Challenges", "title_link": "https://www.veeco.com/", "service_name": "Veeco"}]
- [1658746510.149889] <@U033G4KN4TD>: <@U0331FWGQRM>
会社の情報はこちらになります。
- [1658746665.405789] <@U033G4KN4TD>: 経由：アリババのRFQ
- [1658748669.414049] <@U033G4KN4TD>: シンガポールの会社です。
- [1658796168.882829] <@U0331FWGQRM>: 下記の操作をお願いできますか？
  - files: [{"id": "F03QYGBHL91", "created": 1658796144, "timestamp": 1658796144, "name": "スクリーンショット 2022-07-26 7.42.19.png", "title": "スクリーンショット 2022-07-26 7.42.19.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 193236, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F03QYGBHL91/____________________________2022-07-26_7.42.19.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F03QYGBHL91/download/____________________________2022-07-26_7.42.19.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F03QYGBHL91-67e3fe5277/____________________________2022-07-26_7.42.19_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F03QYGBHL91-67e3fe5277/____________________________2022-07-26_7.42.19_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F03QYGBHL91-67e3fe5277/____________________________2022-07-26_7.42.19_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 305, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F03QYGBHL91-67e3fe5277/____________________________2022-07-26_7.42.19_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 407, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F03QYGBHL91-67e3fe5277/____________________________2022-07-26_7.42.19_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F03QYGBHL91-67e3fe5277/____________________________2022-07-26_7.42.19_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 610, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F03QYGBHL91-67e3fe5277/____________________________2022-07-26_7.42.19_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 944, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F03QYGBHL91-67e3fe5277/____________________________2022-07-26_7.42.19_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 814, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F03QYGBHL91-67e3fe5277/____________________________2022-07-26_7.42.19_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 868, "thumb_1024_h": 1024, "original_w": 1324, "original_h": 1562, "thumb_tiny": "AwAwACjTooprEj0oAdkZxRUff/7Kngk+lAC0UUUAFJkeopabtPrQAA5bHGPXNOpm1uxpQCOpoAdRRRQAUn50tFABRRRQAUUUUAf/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F03QYGBHL91/____________________________2022-07-26_7.42.19.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F03QYGBHL91-33de0fa7a8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1658796203.121669] <@U0331FWGQRM>: 一度こちらで試してみます。
- [1658796391.525209] <@U033G4KN4TD>: <@U0331FWGQRM>
すみません
メッセージの有効期限が切れました。
もう一度送って頂けますか？
- [1658797146.262519] <@U033G4KN4TD>: <@U0331FWGQRM>
メッセージが来ました
数字を教えて頂けますか？
- [1658798611.060669] <@U0331FWGQRM>: <@U033G4KN4TD>
Microsoftアカウント
アカウント：<mailto:lo@tousuien.jp|lo@tousuien.jp>
パスワード：tousuien10
- [1658810544.871279] <@U033G4KN4TD>: <@U0331FWGQRM> <@U0331FZS7JT>
お疲れ様です。
Wabi-Sabi Matcha Inc様の件ですが、
進捗状況をご報告させていただきます。

・１回目のフレーバー抹茶３種類のサンプルを発送済み、送料未収
　原因：先方の担当者はPayPalで送金する時、トラブルがあったみたい、未解決。
・「フレーバー抹茶のorderについて、10月、11月ぐらい発注します」と連絡がありました。
　注文詳細について、invoiceを添付いたします。
・パッケージについて、添付した画像通りです。
　先方の担当者から「パッケージのサンプルを送って頂けますか」と連絡があります。
　
現在の状況において、パッケージのサンプルの発送について、どうしたらいいですか？
（送料未回収）
よろしくお願いいたします。
  - files: [{"id": "F03QW66DQBF", "created": 1658810162, "timestamp": 1658810162, "name": "IMG_4525.jpeg", "title": "IMG_4525.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 48967, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F03QW66DQBF/img_4525.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F03QW66DQBF/download/img_4525.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F03QW66DQBF-34afde8f9e/img_4525_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F03QW66DQBF-34afde8f9e/img_4525_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F03QW66DQBF-34afde8f9e/img_4525_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 244, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F03QW66DQBF-34afde8f9e/img_4525_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 326, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F03QW66DQBF-34afde8f9e/img_4525_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F03QW66DQBF-34afde8f9e/img_4525_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 488, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F03QW66DQBF-34afde8f9e/img_4525_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 543, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F03QW66DQBF-34afde8f9e/img_4525_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 651, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F03QW66DQBF-34afde8f9e/img_4525_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 695, "original_w": 1284, "original_h": 871, "thumb_tiny": "AwAgADDSzgUoNNf7ooToaV9bALkeopcgdTUCD94PrSzD5gfahuyKtqTZGM54pMgjg5qtdjFoPqKbp/3ZPqKLhy6XLfbpmgdOlKOlFMkaAAc7aVgD1Gab5qev6GjzU9f0NACsAy4ZQR6GhUVAQqhfoKdQelAH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F03QW66DQBF/img_4525.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F03QW66DQBF-6793e14cb6", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F03QJHJHL3H", "created": 1658810395, "timestamp": 1658810395, "name": "QUOTATION_Tousuien(20220704).pdf", "title": "QUOTATION_Tousuien(20220704).pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 100887, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F03QJHJHL3H/quotation_tousuien_20220704_.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F03QJHJHL3H/download/quotation_tousuien_20220704_.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F03QJHJHL3H-159e7004be/quotation_tousuien_20220704__thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F03QJHJHL3H/quotation_tousuien_20220704_.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F03QJHJHL3H-f71b7bf8c5", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1658811638.915019] <@U033G4KN4TD>: 会社と担当者の情報を共有いたします。
担当者：Mr.Patrice belanger
HP:<https://www.wabisabimatcha.com/password>（新規事業です。）
instagram:<https://www.instagram.com/wabisabi.matcha/>
(フォロワーの中にMr.Patrice belangerのinstagramがあります、フォロワー4.9万人）
美容室とファッションブランド事業もやっています。
ファッションブランドのHPは下記の通りです。
HP:<https://antoinevictor.co/>
instagram:<https://www.instagram.com/patrice.belanger/>
  - attachments: [{"from_url": "https://www.wabisabimatcha.com/password", "image_url": "http://cdn.shopify.com/s/files/1/0657/4204/5410/files/logo-01_2ae90c7b-b50e-463a-9638-e04197d36a69.jpg?v=1658769462", "image_width": 250, "image_height": 250, "image_bytes": 118320, "id": 1, "original_url": "https://www.wabisabimatcha.com/password", "fallback": "Wabi-Sabi Matcha", "text": "Wabi-Sabi Matcha", "title": "Wabi-Sabi Matcha", "title_link": "https://www.wabisabimatcha.com/password", "service_name": "wabisabimatcha.com"}, {"from_url": "https://antoinevictor.co/", "thumb_url": "http://cdn.shopify.com/s/files/1/0467/9381/8270/files/Antoine_Victor_Logo_Official_a5f8399e-c00c-4890-a194-94fb689a4177_1024x.png?v=1616786811", "thumb_width": 1024, "thumb_height": 446, "service_icon": "http://cdn.shopify.com/s/files/1/0467/9381/8270/files/avfavicon4_32x32.png?v=1630013706", "id": 2, "original_url": "https://antoinevictor.co/", "fallback": "Antoine Victor", "text": "Antoine Victor", "title": "Antoine Victor", "title_link": "https://antoinevictor.co/", "service_name": "antoinevictor.co"}]

## 2022-07-26

- [1658821187.146519] <@U0331FWGQRM>: <@U033G4KN4TD> 
オーダーにつきまして、
10月、11月になる旨、承知しました。

現時点で送料の支払いが確認できておりません。入金確認出来次第、パッケージサンプルを送付させていただきます。

という感じで、少し冷たい感じでいいので、
お金払わないならあなたとは取引しない。
という感じで大丈夫です:man-gesturing-ok:

宜しくお願い致します！

## 2022-08-10

- [1660116847.942399] <@U033G4KN4TD>: <@U0331FZS7JT> 社長
お疲れ様です。
記入した案件数が少ないですけど、
ジェトロへ「案件報告書」を提出済です。
よろしくお願いいたします。

## 2022-09-25

- [1664169485.076349] <@U033G4KN4TD>: <@U0331FZS7JT> 社長<@U0331FWGQRM> 執行役

こんにちは
お問い合わせありがとうございます。
日本茶の生産者、株式会社桃翠園です。
弊社は日本の北西に位置します。
弊社のこれまでの海外への日本茶の販売実績として
FDA
FSSC
ISO
有機JASの認証を取得しています。

日本の全国の茶を全て高品質で取り扱う
こまめに現地に行きます！

メーカーの面と商社の面
全て望みの商品を発送できます。

製品については
茶師の日本一（スペシャリスト）が監修している
ヨーロッパには特に強く売り出せそう？

アメリカ：FDA JAS
ヨーロッパ：JAS
アジア用：
→後日、川井さんとシェア

抹茶産地
出雲
宇治
八女
静岡
西尾
鹿児島

何でも紹介できるから
客の欲しいものを探る

電話
やり取りが続いた後にはあり得る

アフリカ
アフリカ用メール

ドイツ
サンプル出た

アリババ利用者のバランス
中小企業が多い
大手が少し
価格帯は企業ごとに異なるが
プライヤーが中国企業が多いので
安いものが求められる傾向にはある

日本茶については安い必要はない


輸入に慣れているか否か：慣れてる企業が多い印象

客に何が良かったか、現地でのお茶のニーズについて確認する

年内サンプル10件
商談ブラッシュアップ

広告をかける国を限定する




メモ
国ごとに最初の提案価格を分ける

## 2022-10-16

- [1665966915.542259] <@U0331FWGQRM>: <!channel>

＜連絡＞
<@U041RJKV5JA> <@U0331FZTHEK>
オランダのTheeje（Sheng Hu様）からpaypalでサンプル代金頂戴しています。現在サンプルの発送内容を調整中です。
予定では、下記の通り。
・出雲抹茶（出雲翠の昔、宇迦の白、G, R, N, Fの全てか一部）
・鹿児島製茶　有機抹茶（A, B, C, Dの全てか一部）
・ブレンド抹茶（Ginger, Lemongrass, Mint, Cinnamon）
※上記いずれかor複数を用いたもの。

＜お願い＞
<@U041RJKV5JA>

①下記パウダーがあるか在庫確認いただけますか。
もしあれば常温で私の机に置いておいていただけますと助かります。
※サンプル作成用なので、各20gもあれば十分です。
（内容決まればブレンド抹茶作成しに会社行きます）

・レモングラス　島根有機ファーム
・レモングラス　福田龍
・有機ペパーミント　キタマ
・有機シナモン　　　キタマ
・有機ジンジャー　　キタマ


②下記抹茶も約100gくらいずつあれば福代さんに出しておいていただけると助かります。（冷蔵庫に缶に入れて1kgずつ保管しておいても良いと思うので、まだしていなければ、各1kgずつ出してもらってください）

出雲翠の昔
宇迦の白G
出雲抹茶R
出雲抹茶N
出雲抹茶F
鹿児島製茶　有機抹茶A
鹿児島製茶　有機抹茶B
鹿児島製茶　有機抹茶C
鹿児島製茶　有機抹茶D

宜しくお願いします。
（時差的に日本の方が7時間早い為、返信が今夜になると思うので、
今日中の準備であれば問題ないです）
- [1665966943.960849] <@U041RJKV5JA>: <@U041RJKV5JA>さんがチャンネルに参加しました
- [1665966944.191139] <@U0331FZTHEK>: <@U0331FZTHEK>さんがチャンネルに参加しました
- [1665967453.154399] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長
お疲れ様です。
オランダのTheeje（Sheng Hu様）サンプル送料代金の入金(PayPal)を確認致しました。
USD30.00-
回収(入金)処理致します。
よろしくお願いします。
- [1665967607.685509] <@U041RJKV5JA>: <@U0331FWGQRM>
確認後、連絡いたします。
- [1665984292.190479] <@U041RJKV5JA>: <@U0331FWGQRM>
CC: <@U0331FZTHEK>
在庫を連絡いたします。

・レモングラス　島根有機ファーム→在庫なし
・レモングラス　福田龍→在庫あり
・有機ペパーミント　キタマ→在庫なし
・有機シナモン　　　キタマ→在庫なし
・有機ジンジャー　　キタマ→在庫なし

・出雲翠の昔→在庫あり
・宇迦の白G→在庫あり
・出雲抹茶R→在庫あり
・出雲抹茶N→在庫あり
・出雲抹茶F→在庫はあるが古く、色が悪い。
・鹿児島製茶　有機抹茶A→在庫あり
・鹿児島製茶　有機抹茶B→在庫あり
・鹿児島製茶　有機抹茶C→在庫なし
・鹿児島製茶　有機抹茶D→在庫なし

在庫がない物は注文したほうが良いでしょうか？
- [1665985652.305209] <@U0331FWGQRM>: <@U041RJKV5JA>
上記不足分、各最低ロットで発注お願いします。
品質の悪いものは使用しないでください。
納期がわかれば教えてください。
宜しくお願いします。

・有機レモングラスK-D#7　島根有機ファーム
・有機ペパーミント　キタマ
・有機シナモン　　　キタマ
・有機ジンジャー　　キタマ
・出雲抹茶F→品質の良いもの
・鹿児島製茶　有機抹茶C
・鹿児島製茶　有機抹茶D

※お客様のフォルダに発注書を入れておりますので、
　FAX注文してください。（メールでもOK）

※鹿児島製茶はいつも通りしてください。
　私は取り敢えず1kgあればOKですが、他の方が必要であれば併せて注文してください。

宜しくお願いします。
- [1665985726.641629] <@U0331FWGQRM>: MOQが小さくならないか一応確認してみてください。
なるようであれば、少ない数量で注文してください。
各1kgとか

## 2022-10-18

- [1666081986.833569] <@U041RJKV5JA>: <@U0331FWGQRM>
不足原料の出荷日、着日になります。

・有機パウダー各種（キタマ）　10/21着
・有機レモングラス（島根有機ファーム）10/20着
・有機抹茶C、D（鹿児島製茶）10/20出荷
・出雲抹茶F　10/21完成
- [1666114750.786649] <@U0331FWGQRM>: <@U041RJKV5JA>
（情報共有）サンプル決定しました。

各10g

出雲翠の昔
宇迦の白
出雲抹茶G

鹿児島製茶　有機抹茶A
鹿児島製茶　有機抹茶B
鹿児島製茶　有機抹茶C
鹿児島製茶　有機抹茶D
	
鹿児島A	+ ginger
鹿児島B	 + lemongrass
鹿児島C	 + ginger
鹿児島C	 + lemongrass
	
出雲抹茶R + mint
出雲抹茶R + cinnamon
出雲抹茶N + mint
出雲抹茶N + cinnamon

## 2022-10-22

- [1666435231.967509] <@U0331FWGQRM>: <@U041RJKV5JA>
サンプル完成しました。
デスクにおいてるので、
火曜日の発送よろしくお願いします。

（社内用サンプルは小冷蔵庫に保管してます）

## 2022-10-24

- [1666661771.603499] <@U041RJKV5JA>: <@U0331FWGQRM>
EMSにて出荷完了しました。
- [1666663089.954489] <@U0331FWGQRM>: <@U041RJKV5JA>
 EMSの送り状ですが、
サンプル重量は各10gですので（20gになっています）
次回以降注意願います。
宜しくお願いします。
- [1666665893.866489] <@U041RJKV5JA>: <@U0331FWGQRM>
次回以降、注意いたします。
すみませんでした。

## 2022-10-31

- [1667262916.908749] <@U033G4KN4TD>: <@U041RJKV5JA> 部長
お疲れ様です。
wabisabimatcha様から注文が入りました。
INVOICE No. TSE-WSM-001-22です。
ご確認お願い致します。

原料：まるゑい　　　有機抹茶3000
　　（株）キタマ　　スイカパウダーB 3734

問題なければ、進ませていただきます。
よろしくお願い致します。
- [1667263249.397099] <@U041RJKV5JA>: <@U033G4KN4TD> さん
注文いただけてよかったですね。
インボイス確認しました。
進めて下さい。
よろしくお願いいたします。
- [1667277268.756959] <@U0331FZTHEK>: <@U033G4KN4TD> さん
　CC: <@U041RJKV5JA> 部長
お疲れ様です。
TSE-WSM-001-22（カナダ：Wabi-Sabi matcha Inc. 様）
USD74.45-
本日(11/1) 入金(PayPal) 確認致しました。
回収(入金)処理致します。
よろしくお願いします。

## 2022-11-08

- [1667954627.565269] <@U033G4KN4TD>: <@U041RJKV5JA> 部長
お疲れ様です。
wabisabimatcha様からサンプルの注文がありました。
出雲抹茶G、R、T、A1
本日発送のスイカ抹茶と合わせて発送致します。
ご報告いたします。
よろしくお願い致します。

## 2022-11-12

- [1668313984.336099] <@U0331FWGQRM>: <@U041RJKV5JA>
この客様宛に先日（10/25）にEMSでサンプル発送したのですが、まだついていないようです。

待っていれば到着するかもしれませんが、
お客様も不安になる（桃翠園と取引して大丈夫かな？と思う）かと思いますので再送しようと思います。

・送るサンプルは前回と同じ。
　下記7種類（10g）を準備願います。
出雲翠の昔
宇迦の白
出雲抹茶G
鹿児島製茶A
鹿児島製茶B
鹿児島製茶C
鹿児島製茶D

※ブレンド抹茶8種類は平川さんのデスクに置いておきます。（これは桃翠園の控えとして取っていたものですが今回のサンプルとして送ります。）

・発送方法はDHL（料金はもちろん取りません）
・産地証明（前回つけませんでしたが今回はつけたいと思います。）

・発送は最短でお願いします。火曜日出荷希望
（もし今回の出荷までにお客様の所へEMSで送ったサンプルが届けば今回の出荷は中止します）

宜しくお願いします。

## 2022-11-20

- [1668998391.192819] <@U0331FWGQRM>: <@U041RJKV5JA> cc: <!channel>
サウジアラビアのお客様からサンプル依頼です。
フォルダ名：Hussain Alhaddad（Alibaba）
準備お願いできますか。
各20gお願いします。

<@U0331FZTHEK>
サンプル代paypalで入金されると思います。

宜しくお願いします。
- [1668999459.868839] <@U03SGRNND5L>: <@U03SGRNND5L>さんがチャンネルに参加しました

## 2022-11-21

- [1669072753.226059] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長 <@U03SGRNND5L> さん
お疲れ様です。
Hussain Alhadda（Alibaba）様
USD30.00- 入金(PayPal) を確認致しました。
回収(入金)処理致します。
よろしくお願いします。
- [1669079005.816739] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
Hussain Alhadda（Alibaba）様のサンプル手配を進めて
おります。11/25（金）に出荷予定です。
送り先は　
Hussain Alhaddad
4145 rabieia st-alnasera 32641-6662,SAUDI ARABIA
で良いでしょうか？
また、貿易条件や運送会社の指定はございますか？
宜しくお願い致します。
- [1669082001.448609] <@U0331FWGQRM>: <@U03SGRNND5L>
上記で問題ございません。
ありがとうございます。
直近でサウジアラビアにサンプル発送していると思うので
それを真似してしようと思います。
貿易条件や運送会社　内容確認して、
共有してもらえますか？

<@U0331FZTHEK>
paypalの請求書になぜか
Hussain Alhaddad
ではなく
Hussain Z　と入っております。
（過去に設定してしまったような気がしておりますが）
原因がわからないので、確認してもらえますか？

・請求書を改めて出す必要はないです
・登録変更があればして欲しいです。
・出荷の際（今後のすべての表記を）に、Hussain Alhaddadで送れるようにしてください。

宜しくお願いします。
- [1669083480.719239] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。　
サウジアラビアへのサンプルの出荷はNGCO様へ直近で4月に
出荷しております　貿易条件はDDU、運送会社はDHLです。

製品の出荷は、NGCO様へ11月に出荷しております。
貿易条件はEXＷ、運送会社はDHLです。

宜しくお願い致します。
  - files: [{"id": "F04BHSYPUKZ", "created": 1669083380, "timestamp": 1669083380, "name": "TSE-NGC-SPL-001.pdf", "title": "TSE-NGC-SPL-001.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U03SGRNND5L", "user_team": "T033D70RR6H", "editable": false, "size": 923496, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04BHSYPUKZ/tse-ngc-spl-001.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04BHSYPUKZ/download/tse-ngc-spl-001.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F04BHSYPUKZ-d725ea1d26/tse-ngc-spl-001_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04BHSYPUKZ/tse-ngc-spl-001.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F04BHSYPUKZ-bfaa7e8cec", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F04CN4SR1KJ", "created": 1669083402, "timestamp": 1669083402, "name": "22.11.14 Invoice(TSE-NGC-001-22).pdf", "title": "22.11.14 Invoice(TSE-NGC-001-22).pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U03SGRNND5L", "user_team": "T033D70RR6H", "editable": false, "size": 76447, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04CN4SR1KJ/22.11.14_invoice_tse-ngc-001-22_.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04CN4SR1KJ/download/22.11.14_invoice_tse-ngc-001-22_.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F04CN4SR1KJ-8fa477f7eb/22.11.14_invoice_tse-ngc-001-22__thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04CN4SR1KJ/22.11.14_invoice_tse-ngc-001-22_.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F04CN4SR1KJ-d2b85168e4", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1669083760.436089] <@U0331FWGQRM>: <@U03SGRNND5L> 
ありがとうございます！
宜しくお願いします。

## 2022-11-26

- [1669467155.295409] <@U0331FWGQRM>: <@U041RJKV5JA> <@U03SGRNND5L> 
本件サンプル出荷されましたか?

## 2022-11-27

- [1669592009.303939] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
サンプルの準備はできておりますが
出荷はまだしておりません
- [1669594545.889739] <@U0331FWGQRM>: <@U03SGRNND5L> 
11/25出荷予定、
と先日書いていたので、出荷されたのかなと思って確認で質問しました。
もし予定変更がある際は教えてください。
また、出荷予定日がわかり次第教えてください。宜しくお願いします！
- [1669594988.073969] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
ご確認、ありがとうございます。
貿易条件や運送会社の指示があると思い
待っておりました。
誠に申し訳ございませんでした。
どのようにお手配すると良いですか？
- [1669595181.093589] <@U0331FWGQRM>: <@U03SGRNND5L> 
尾林さんが確認した上記の通り、
それを真似して出荷してください。
DDU
DHL
- [1669595438.397399] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
畏まりました。
本日、出荷できるように進めて行きます。
出荷したら、ご報告致します。
宜しくお願い致します。
- [1669595803.024379] <@U0331FWGQRM>: <@U03SGRNND5L>
写真も撮っていただけると助かります。
（ネット環境的にこちらで見れてないだけかもしれませんが。。）

<@U041RJKV5JA> 部長の承認の上、出荷完了させてくださいね。

宜しくお願いします。
- [1669596520.146289] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
畏まりました。
平川部長に承認を頂きながら、進めて参ります。
また、随時、写真も撮ってファイルに入れていきます。
宜しくお願い致します。
- [1669603177.961029] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
サウジアラビアの出荷手配を進めておりますが
サウジアラビアのNGCO様に4月にサンプル出荷の際に
原産地証明書を作っておりました。
私が失念しており、まだ準備が出来ておりませんでした。
本日、出雲商工会議所に申請に行きますので
明日の出荷となります。
宜しくお願い致します。
（INVOICE・Packing Listを作成して、Hussain Alhaddadの
　ファイルに入れております。合わせてご確認をお願い致します。）
- [1669610815.051359] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC: <@U041RJKV5JA> 部長

お疲れ様です。
原産地証明書を申請したところ、以下のご指摘を受けました。
①INVOICE番号が必ず必要（[sample]はダメ）
　　TSE-HA-001-22　とつけても良いですか？
　　INVOICE番号が無い場合は「NIL」と記載してほしいとのこと
②配送先の都市名が必要
　　rabieia st-alnasera　が都市名でしょうか？
お忙しいところ、誠に申し訳ございません。
宜しくお願い致します。
- [1669612498.271759] <@U0331FWGQRM>: <@U03SGRNND5L>
①それでお願いします。
②住所について漏れがありました。
4145 rabieia st-alnasera, Qatif 32641-6662
Saudia arabia

Qatif（カティーフ）が都市名の様です。
- [1669622142.568999] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC: <@U041RJKV5JA> 部長

お疲れ様です。
明日、原産地証明をもらいます。
DHLで出荷手続きをしたいのですが、会社名と
電話番号を教えてもらえないでしょうか？
ご担当者様は　Hussain Alhaddad　様で手配しようと
思います。
宜しくお願い致します。

## 2022-11-28

- [1669624728.075999] <@U0331FWGQRM>: 会社名はないです。
個人名で送付してください。

電話番号は下記で教えてもらっているのですが、
&gt; Phone number 00966554842404
恐らく下記が正解だと思うので桁数が合わなかったりしたら、
これを記載願います。
&gt; ＋966-55-4842404
宜しくお願いします。
- [1669699345.652559] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長

お疲れ様です。
本日14：15に西濃エキスプレス（DHL）にて
サウジアラビア　Hussain Alhaddad様のサンプル品を
出荷致しました。
AWB　No,5246745442です。
宜しくお願い致します。

## 2022-11-29

- [1669717662.620969] <@U0331FWGQRM>: <@U03SGRNND5L>（CC：<@U041RJKV5JA> ）
出荷書類のデータはどこにありますか？
（サイン入りのinvoice, packinglist,など）
フォルダにまとめておいてください。
- [1669764301.589569] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
おはようございます。
フォルダにいれておきます。
宜しくお願い致します。
- [1669792271.909009] <@U0331FWGQRM>: <@U03SGRNND5L> （CC：<@U041RJKV5JA> ）
入れたらそのタイミングでスラックで教えてください。

## 2022-11-30

- [1669858917.875299] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
出荷書類でございまいますが、サインした
インボイス、パッキングリスト（平川部長のサイン入り）を
保存せずに、出荷してしました。

サイン無のエクセルデータのインボイスとパッキングリストを
PDFにて保存しても良いでしょうか？
誠に申し訳ございません。
宜しくお願い致します。
- [1669860077.394329] <@U0331FWGQRM>: <@U03SGRNND5L>（CC：<@U041RJKV5JA> ）
データを見返したときに
サインしていないものが保存されていると、
どれが正式（お客様に提出した）ものかわからないので、
出荷したものと同じものを用意し、サインし直して保存してください。
- [1669860213.264259] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
畏まりました。
改めて平川部長にサインをしてもらい
ファイルにPDFにて保存致します。
誠に申し訳ございませんでした。
- [1669863488.136599] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
平川部長よりサインを頂いたインボイスと
パッキングリストをファイルに保存致しました。
誠に申し訳ございませんでした。

## 2022-12-17

- [1671288507.846489] <@U0331FWGQRM>: <@U041RJKV5JA> <!channel>

スペインのお客様にサンプル発送の準備をお願いします。
（月曜日の対応で大丈夫です）

ーーーー
＜送り先＞
住所　bertsolari txirrita 16 esc2 4b, 20017 San Sebastián, Spain
名前　LM.Santamaria
電話番号　<tel:+34669339689|+34 669339689>

＜サンプル内容＞
　商品名　　　　　　　　　　　原料
Organic Matcha Grade-1　：　鹿児島A  20g
Organic Matcha Grade-2　：　鹿児島1A  20g
ーーーー

DHLでお願いします。

<@U0331FZTHEK> サンプル料金はpaypalでUSD10頂いております。

※一応、invoiceとpacking listは作って入れてます。
　もし出荷時に必要であれば使ってください。
　サンプルなので産地証明は無しでいけると思います。

宜しくお願いします。

## 2022-12-18

- [1671369264.541079] <@U0331FZS7JT>: <@U041RJKV5JA> 部長 <@U0331FZTHEK> さん <@U033G4KN4TD> さん<@U03SGRNND5L> さん
CC：<@U0331FWGQRM> 執行役

お疲れ様です。
本件（EUへの茶の輸出・関税）について、補足で連絡します。

【EU輸出における原産地証明について】
結論：第３者機関のものは不要（インボイスに日本産であることを自社で明記で対応可能）
※今回はサンプルなので明記も不要だと思います！

下記URLより、ご確認ください（P.77〜）
<https://www.jetro.go.jp/ext_images/world/europe/eu/epa/pdf/euepa.pdf>
記載のメリット：下記HSコード品の関税(3.2%)がなくなる。
※HSコード：0902.10(緑茶：不発酵茶3kg以下/包装）

インボイスにURLの内容（P.81）を英語（日本語でもOKですが、英語推奨）で記載してください。
スウェーデンのYuko Ono Sthlm.からのインボイス及び、私がウクライナ（ポーランド/EU経由）のMr.Ivashchenkoに送っている、インボイス（2-4回）にも欄外に記載しています。
(5)の場所と日付けについて、ですがここはJETROに直接確認していただいた方が良いかもしれません。
⇒確認後、執行役、私にも共有願います。

(5)を私はコピペしていて、今のところ問題はないですが（P.83の軽微な誤りに該当？）、念の為確認をお願いします。

お客様から別途第３者機関（商工会議所等）の原産地証明が欲しい！と言われたら個別対応で良いと思います！

尚、
HSコード：0902.20(発酵していないその他の緑茶)については関税がそもそも非課税となっていますが、こちらはインボイスの欄外にも上記の記載は最初から不要？なのかこちらも確認願います！

確認していただいた方は、海外営業部会議にて説明をお願い致します！
以上、よろしくお願い致します:man-bowing:
- [1671400927.342509] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
お疲れ様です。
TSE-LMS-SPL-001-22（スペイン：LM.Santamaria 様）
USD10.00- 12/18 入金(PayPal)を確認致しました。
回収(入金)処理致します。
よろしくお願いします。
- [1671413175.216989] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
お疲れ様です。
サンプルは今日発送可能ですが、
発送して大丈夫でしょうか？
ご確認、よろしくお願いいたします。
- [1671413218.181379] <@U0331FWGQRM>: <@U033G4KN4TD>
はい、大丈夫です！
宜しくお願いします！
出荷完了したら教えてください。
- [1671415682.372119] <@U0331FWGQRM>: <@U033G4KN4TD>
すみません。念の為に、invoice, packing listに
Country of Origine : Japan
を追記しましたので、こちらをご使用ください。

宜しくお願いします！
- [1671423860.378429] <@U0331FWGQRM>: <@U041RJKV5JA> *<!channel>* 

シンガポールのお客様にサンプル発送の準備をお願いします。
ブレンド抹茶の出荷可能日が遅いようであれば、別々の発送でお願いします。
それに応じてinvoice等変更（２分割）しますので、また教えてください。
（参照ファイル名：作成中TSE-SPI-SPL-001-22_invoice_packing list）

ーーーー
＜送り先＞
住所　50, Raffles Place, Singapore land tower, 37th, Singapore 048623
名前　Kyaw San
会社名　Swiss Pharma International
電話番号　<tel:+6568297053|+65 68297053>

＜サンプル内容＞
　商品名　　　　　　　　　　　原料
Organic Matcha Grade-1　：　鹿児島A  500g
Organic Matcha Grade-2　：　鹿児島B  500g
Organic Matcha Grade-3　：　鹿児島C  500g
Organic Matcha Grade-4　：　鹿児島D  500g

Ginger matcha　　　 ：　鹿児島B 93% + キタマ 7%　20g
Lemonglass matcha　：　鹿児島B 80% + キタマ20%　20g
Mint matcha　　　    ：　鹿児島B 95% + キタマ5%　20g
Cinnamon matcha　  ：　鹿児島B 85% + キタマ15%　20g
ーーーー

<@U041RJKV5JA> DHLでお願いします。

<@U0331FZTHEK> サンプル料金はpaypalでUSD100.0請求しています。

宜しくお願いします。
- [1671430293.025469] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役<@U041RJKV5JA> 部長

お疲れ様です。
LM.Santamaria様の件、発送完了です。
DHL AWB No.：5246794313
よろしくお願いいたします。

## 2022-12-19

- [1671438864.180799] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長　 <@U033G4KN4TD> さん

お疲れ様です。
本件、12月22日（木）に出荷可能です。
宜しくお願い致します。

## 2022-12-27

- [1672207540.138699] <@U0331FWGQRM>: <@U03SGRNND5L> 
cc: <@U0331FZTHEK>
本日、サンプル代入金されました
発送は来年でokです！
宜しくお願い致します。
- [1672207866.566589] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U03SGRNND5L> さん
お疲れ様です。
TSE-SPI-SPL-001-22（シンガポール：Kyaw San 様）
USD100.00- 先程(12/28) 入金(PayPal)確認致しました。
回収(入金)処理致します。
よろしくお願いします。
- [1672209699.783589] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長　 <@U033G4KN4TD> さん
お疲れ様です。
来年、1/5に出荷します。
宜しくお願い致します。

## 2023-01-04

- [1672880389.632939] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC: <@U041RJKV5JA> 部長　 <@U033G4KN4TD> さん
お疲れ様です。
本件の送り状（DHL：PGE）を作成しました。
AWB NO.5246822921　です。
宜しくお願い致します。
- [1672882298.676299] <@U0331FWGQRM>: <@U041RJKV5JA>
cc : <@U0331FZS7JT> <@U0331FZTHEK> <@U033G4KN4TD> <@U03SGRNND5L>

日本からスペインへ茶を輸出する際は、
“植物検疫証明書“が無いと輸出できないそうで、
返送されて帰ってきました。

情報共有として、下記の通りペガサスからの返信メールを転送します。ご確認ください。

ーーーfrom 梶井さんーーー
最近の食品におけるスペインの事情をお知らせ致します。

スペインにおいて食品業界の通関を厳しくしており、
その背景に粗悪な中国茶がスペインに氾濫して防止するため、
お茶関連に関しましてスペイン税関は現地で様々な書類を求めていると思います。
（※規制は常に変化しますので、詳細は荷受人より現地税関に確認して頂くのが良いと思います）

特に最近スペインの食品における現地税関が厳しく、
お客様の中には配送先がスペインですが、輸入者（Importer）はオランダなどのケースも出てきております。
（※オランダで通関を切って、スペイン貨物を転送する）

スペイン側の規制が大きいので、日本側で出来ることは限られますが、
スペインに発送される際にはEU規制に必要な書類、また植物検疫証明書が必須になります。
ーーーーーーーーー
- [1672882343.362219] <@U0331FWGQRM>: <@U041RJKV5JA> cc <@U03SGRNND5L>
なので、植物検疫を取得後再送宜しくお願いします。
完了し次第、連絡ください。
宜しくお願い致します。
- [1672896179.035689] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長　 <@U033G4KN4TD> さん
お疲れ様です。
本件、14：20
DHL（西濃エキスプレス）にて出荷致しました。
AWB NO.5246822921　です。
宜しくお願い致します。

## 2023-01-09

- [1673331935.175539] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
本件の植物検疫証明書を取得し、集荷の手配を
DHL：PGE　にしました。
AWB NO,5246836243 です。
宜しくお願い致します。

## 2023-01-10

- [1673369648.837759] <@U0331FWGQRM>: <@U03SGRNND5L>　CC <@U041RJKV5JA>
今後の運用にも関わる事ですので、下記確認願います。

確認したいのですが、
植物検疫で開封されたのは一袋だけですか？？
念の為の確認ですが、段ボールは新品を使用して頂けましたか？（返送された段ボールにそのまま入れて送っておりませんか？）

また、フォルダの管理についてですが、
今後のこともあるので下記点に注意して管理よろしくお願いします。
・出荷書類はinvoice, 送り状、植物検疫の書類など、出荷時に送ったものはひとまとめにしたものを作成してください。（Groene様の管理方法と同じ）
※TSE-LMS-SPL-001-22_2であっているか確認願います。

・フォルダ名は“なるべく“統一して頂けますか？
例）送り状　再確認願います。

・その他、特に発送後は“送りました“と言う情報だけでなく、伝言しておくべき事があればスラックか電話でも良いので報告してください。

※電話はいつでも出れますので必要であればください。
出れない時は出ませんので。

以上、宜しくお願いします。
- [1673396978.463219] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
再発送便のパッキングリストをファイルに
いれております。
タイトル：TSE-LMS-SPL-001-22_packing list(再）
です。
宜しくお願い致します。
- [1673414365.380529] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
TSE-LMS-SPL-001-22　LM.Santamaria様の
発送品を14：15にDHL（セイノスーパーエキスプレス）に
お渡ししました。
AWB NO,5246836243 です。
宜しくお願い致します。

## 2023-01-11

- [1673443843.997689] <@U0331FWGQRM>: <@U041RJKV5JA> <!channel>
USAのお客様から抹茶のサンプル依頼がありました。
サンプルの準備宜しくお願いします。（各20gです）
ーーーーー
フォルダ名：アメリカ→Neels Nutrivina(Alibaba)
QUOTATION_Neels Nutrivina_SAMPLE_Tousuien(20230111)

（下記が正です。Quotationに書いている住所、名前ではありません）

Address: 1555 Phillips Rd 529, Po Box 70, Lambrook, Arkansas, 72353
Name: Neels Saayman
Company Name:Nutrivina Organics
USA Number: <tel:+18707140178|+18707140178>

・鹿児島 A
・鹿児島 1A
・まるゑいME上1
・鹿児島 B
・鹿児島 C
・鹿児島 D
・まるゑい有機抹茶3000
・MEA1

※ラベルはOrganic Matcha Grade-1〜Grade-8
※同梱で下記も入れる予定です。
・抹茶のスティックサンプル
・（間に合えば）資材のサンプル
ーーーーー

以上、宜しくお願いします。
- [1673443923.120199] <@U0331FWGQRM>: <@U041RJKV5JA> <@U03BLQ65GK0>
相談なのですが、添付のような冊子を作ってくれるとこわかりますか？
  - files: [{"id": "F04J80MSH62", "created": 1673443913, "timestamp": 1673443913, "name": "stand bag, plastic bag, card_2.jpeg", "title": "stand bag, plastic bag, card_2.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 204601, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04J80MSH62/stand_bag__plastic_bag__card_2.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04J80MSH62/download/stand_bag__plastic_bag__card_2.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04J80MSH62-65ae8380f1/stand_bag__plastic_bag__card_2_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04J80MSH62-65ae8380f1/stand_bag__plastic_bag__card_2_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04J80MSH62-65ae8380f1/stand_bag__plastic_bag__card_2_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 196, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04J80MSH62-65ae8380f1/stand_bag__plastic_bag__card_2_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 261, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04J80MSH62-65ae8380f1/stand_bag__plastic_bag__card_2_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04J80MSH62-65ae8380f1/stand_bag__plastic_bag__card_2_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 391, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04J80MSH62-65ae8380f1/stand_bag__plastic_bag__card_2_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1472, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04J80MSH62-65ae8380f1/stand_bag__plastic_bag__card_2_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 522, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04J80MSH62-65ae8380f1/stand_bag__plastic_bag__card_2_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 557, "thumb_1024_h": 1024, "original_w": 1200, "original_h": 2208, "thumb_tiny": "AwAwABpRZQg8hvzpxsoMcBvzpQxpdzY6GpuOxE1nCOfm/OoGhiDEc8GrO87uQQPrURTJz61S1E9B7sVIP50CfC/dJ+opZxxUXOeFJHqKOohVYu/pU+2ooVPmHIqfFNANKhhzTfJXtkfjTxTqQxiqE6Uu6gmmZoA//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04J80MSH62/stand_bag__plastic_bag__card_2.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F04J80MSH62-f68442422d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F04JEEVC3H9", "created": 1673443917, "timestamp": 1673443917, "name": "stand bag, plastic bag, card_3.jpeg", "title": "stand bag, plastic bag, card_3.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 202985, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04JEEVC3H9/stand_bag__plastic_bag__card_3.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04JEEVC3H9/download/stand_bag__plastic_bag__card_3.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04JEEVC3H9-20c5ecf6e1/stand_bag__plastic_bag__card_3_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04JEEVC3H9-20c5ecf6e1/stand_bag__plastic_bag__card_3_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04JEEVC3H9-20c5ecf6e1/stand_bag__plastic_bag__card_3_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 196, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04JEEVC3H9-20c5ecf6e1/stand_bag__plastic_bag__card_3_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 261, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04JEEVC3H9-20c5ecf6e1/stand_bag__plastic_bag__card_3_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04JEEVC3H9-20c5ecf6e1/stand_bag__plastic_bag__card_3_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 391, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04JEEVC3H9-20c5ecf6e1/stand_bag__plastic_bag__card_3_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1472, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04JEEVC3H9-20c5ecf6e1/stand_bag__plastic_bag__card_3_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 522, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04JEEVC3H9-20c5ecf6e1/stand_bag__plastic_bag__card_3_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 557, "thumb_1024_h": 1024, "original_w": 1200, "original_h": 2208, "thumb_tiny": "AwAwABqiIckfN19qc0Kqfv5HqBWgLWIEfez/AL1OMcf938zRdAZmwE45NL5a+9aISHJXau6oyFBPyr+VAE560hHPWkkO1gfWjdxnvUtagJsQOcDBpNlIDl/Q96nwKqIMbKN68dRUe1sdqnxzRihjIo0wck1L8vrSbaMUIR//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04JEEVC3H9/stand_bag__plastic_bag__card_3.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F04JEEVC3H9-307cf716de", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F04JH2KFDNG", "created": 1673443920, "timestamp": 1673443920, "name": "stand bag, plastic bag, card_4.jpeg", "title": "stand bag, plastic bag, card_4.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 295710, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04JH2KFDNG/stand_bag__plastic_bag__card_4.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04JH2KFDNG/download/stand_bag__plastic_bag__card_4.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04JH2KFDNG-25db0da8e1/stand_bag__plastic_bag__card_4_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04JH2KFDNG-25db0da8e1/stand_bag__plastic_bag__card_4_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04JH2KFDNG-25db0da8e1/stand_bag__plastic_bag__card_4_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 196, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04JH2KFDNG-25db0da8e1/stand_bag__plastic_bag__card_4_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 261, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04JH2KFDNG-25db0da8e1/stand_bag__plastic_bag__card_4_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04JH2KFDNG-25db0da8e1/stand_bag__plastic_bag__card_4_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 391, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04JH2KFDNG-25db0da8e1/stand_bag__plastic_bag__card_4_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1472, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04JH2KFDNG-25db0da8e1/stand_bag__plastic_bag__card_4_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 522, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04JH2KFDNG-25db0da8e1/stand_bag__plastic_bag__card_4_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 557, "thumb_1024_h": 1024, "original_w": 1200, "original_h": 2208, "thumb_tiny": "AwAwABp4YEAg8GnAg9Kih/1KfSpIz04+tIYuRmlpo6il7UARKQiqjE7gMYFO3op53VHE/wAgBGPlPOOtNHQcH8aQmWFwxwMin7fc0yI5lOBgVNTGV7cZt057VMOlR26A26HpxUwTaOOnpUiEU0tNUEDBOT606qQz/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04JH2KFDNG/stand_bag__plastic_bag__card_4.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F04JH2KFDNG-e2219d1bd5", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1673443940.276319] <@U03BLQ65GK0>: <@U03BLQ65GK0>さんがチャンネルに参加しました
- [1673486056.924979] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
CC: <@U03BLQ65GK0> 会長
吉村、タマヤ共に製造可能です。
イラストも手持ちのもので対応することが可能とのことです。
＊吉村は日本語で入稿後、英語に翻訳していただけます。
（ニュアンスが上手く伝わるか不安なので、お客様に確認はして欲しいそうです）

資材のサンプルですが、発色具合の確認もしていただきたい為、印刷してあるものを手配しました。

今週中に届きますので、同梱いたします。
- [1673486541.574069] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
本件について、
・抹茶の各種サンプル　1/13製造予定
・抹茶のスティックサンプル　済み
・資材のサンプル　今週中着

全部合わせて、1/16(月)発送可能です。
よろしくお願い致します。
- [1673486679.655829] <@U0331FWGQRM>: <@U041RJKV5JA> 
有難うございます！！
助かります！

もしデータさえあれば、
選択肢としては出雲の印刷会社とかでもできるのかな?と思ってましたが、どうでしょう？？
- [1673486851.995369] <@U0331FWGQRM>: <@U033G4KN4TD> 
有難うございます！
出荷日につきまして了解です！
私都合ですみませんが、
中身を確認したいので、
1／19出荷にしてもらえますか？？
（1/17or18に出社しますので、中身を確認したのち出荷できたらと思います）
宜しくお願いします！
※timetree変更しました
- [1673493884.183339] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長
お疲れ様です。
アメリカ→Neels Nutrivina(Alibaba)様
USD30.00- 1/11に入金(PayPal)を確認致しました。
回収(入金)処理致します。
よろしくお願いします。

## 2023-01-12

- [1673581533.307879] <@U0331FWGQRM>: <@U033G4KN4TD> <@U041RJKV5JA>
すみません。
抹茶のサンプルだけ先に最短で発送するこはできますか。
今日か明日発送できますか？？
（ごめんなさい急な要求で・・）

資材等は後から別便で送れたらいいと思います。

お客様的には1/19以前にサンプルを受け取れたらスケジュール的に嬉しいそうです。
だからFedexで送れたらいいかと思いますがどうでしょう。。。また相談します。
- [1673583078.150699] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役<@U041RJKV5JA> 部長

お疲れ様です。
確認いたします。
分かり次第、連絡いたします。
よろしくお願い致します。

## 2023-01-13

- [1673604065.972649] <@U0331FWGQRM>: <@U033G4KN4TD> <@U041RJKV5JA>
PNCはもうフォルダに入れておきました。
出荷書類も下記フォルダ名でまとめておきました。
TSE-NTV-001-23

急なお客様からの要望に対応して頂いて有難う御座いました。明日1/14出荷宜しくお願いします。
- [1673659347.193169] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長<@U0331FZTHEK> さん
お疲れ様です。
本件、準備完了、 FedExで本日発送する予定です。
Tracking No.：771025750455
よろしくお願い致します。

<@U0331FZTHEK> さん
本件、FedExでアメリカへの発送をお願い致します。
ご迷惑をおかけしてすみませんが、よろしくお願い致します。
- [1673673633.084149] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役 <@U033G4KN4TD> さん
　CC: <@U041RJKV5JA> 部長
お疲れ様です。
TSE-NTV-001-23（アメリカ：Neels Nutrivina(Alibaba)様）
➀PNC（1/13 18時頃取得）を出荷書類に追加しました。
②本日(1/14)14:00 出荷完了致しました。
　（TRK＃：は上記です）
よろしくお願いします。

## 2023-01-17

- [1673979410.991529] <@U0331FWGQRM>: <@U041RJKV5JA> cc <@U033G4KN4TD>
本件の出荷時の写真はありますか？
- [1674009561.658459] <@U033G4KN4TD>: <@U0331FWGQRM>執行役
CC：<@U041RJKV5JA>部長
お疲れ様です。
出社してから、共有いたします。
よろしくお願い致します。
- [1674015285.371429] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
出荷時の写真を【アメリカ：Neels Nutrivina(Alibaba)】のフォルダに入れております。
ご確認お願い致します。
よろしくお願い致します。

## 2023-01-18

- [1674031321.430969] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
USAのNeels様からのサンプル依頼です。
・抹茶缶
・資材（スタンド袋）
宜しくお願いします。
ーーーーー
フォルダ名：アメリカ→Neels Nutrivina(Alibaba)
ファイル名：TSE-NTV-002-23

Address: 1555 Phillips Rd 529, Po Box 70, Lambrook, Arkansas, 72353
Name: Neels Saayman
Company Name:Nutrivina Organics
USA Number: <tel:+18707140178|+18707140178>
ーーーーー
- [1674089450.003989] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
追加情報で、下記要求されました。
竹のストロー
個包装の茶杓
茶筅（恐らく写真のようなケースも欲しいかも）
ご確認ください。

1)竹製のストロー。2～6本入りのストローを1パックにまとめました。
2)抹茶スプーン：1本ずつ包装されています。
3)抹茶泡立て器(竹)

ーーーーー
1)Bamboo straw: Pack of 2 to 6 pack of straws packaged together
2)Matcha Bamboo Spoon : One spoon packaged separately
3)Matcha Whisk Bamboo
  - files: [{"id": "F04KJTAQXH9", "created": 1674089442, "timestamp": 1674089442, "name": "bamboo spoon.webp", "title": "bamboo spoon.webp", "mimetype": "image/webp", "filetype": "webp", "pretty_type": "WebP", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 100140, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04KJTAQXH9/bamboo_spoon.webp?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04KJTAQXH9/download/bamboo_spoon.webp?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04KJTAQXH9-a8e22aee88/bamboo_spoon_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04KJTAQXH9-a8e22aee88/bamboo_spoon_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04KJTAQXH9-a8e22aee88/bamboo_spoon_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04KJTAQXH9-a8e22aee88/bamboo_spoon_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04KJTAQXH9-a8e22aee88/bamboo_spoon_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04KJTAQXH9-a8e22aee88/bamboo_spoon_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04KJTAQXH9-a8e22aee88/bamboo_spoon_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 800, "original_w": 800, "original_h": 800, "thumb_tiny": "AwAwADCOj6807FFSUFFIaXJFAARRmjNFADqUY7jIPp1ox6UgyORjPcetAAU4ypyP5Uz+dS4z8y5DUmA/QYb09fpQBHn2ozQeKTNAExUjpSFh+NODY79aay7m9KQDTxzRkE89aTlTg0h5pgOYluvX19aYaXpSHmgD/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04KJTAQXH9/bamboo_spoon.webp", "permalink_public": "https://slack-files.com/T033D70RR6H-F04KJTAQXH9-cac1f1bb45", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F04KK1B4ZB4", "created": 1674089446, "timestamp": 1674089446, "name": "bamboo straw.webp", "title": "bamboo straw.webp", "mimetype": "image/webp", "filetype": "webp", "pretty_type": "WebP", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 25952, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04KK1B4ZB4/bamboo_straw.webp?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04KK1B4ZB4/download/bamboo_straw.webp?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04KK1B4ZB4-2aa0983422/bamboo_straw_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04KK1B4ZB4-2aa0983422/bamboo_straw_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04KK1B4ZB4-2aa0983422/bamboo_straw_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04KK1B4ZB4-2aa0983422/bamboo_straw_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04KK1B4ZB4-2aa0983422/bamboo_straw_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04KK1B4ZB4-2aa0983422/bamboo_straw_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 720, "original_w": 750, "original_h": 750, "thumb_tiny": "AwAwADC+SFGSQB70owRkdKguYy2GHOO1RQSmMkEkqe3p9KVx2LlFIGDLuByD3o60xC0U1mCLk1HHukfeeFHQUrgTVXmi53J17irFFMClHIytkcjuKs+cuzcPyqKZFV8g8nqB3qAM5kyOAvaovYu1y0ELtl+vp6VMBgYFRxOGH+1UlUiWFMlLhf3a7jmn0UxEaR7fmblv5VFNASd6cN6etWKWlYdzOBCndyG9KvRMWjBYc0pjQtu2jPrTqErA3c//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04KK1B4ZB4/bamboo_straw.webp", "permalink_public": "https://slack-files.com/T033D70RR6H-F04KK1B4ZB4-cf49b9cc57", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F04KK1B82RY", "created": 1674089448, "timestamp": 1674089448, "name": "bamboo whisk.jpg", "title": "bamboo whisk.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 25674, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04KK1B82RY/bamboo_whisk.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04KK1B82RY/download/bamboo_whisk.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04KK1B82RY-d09ab74e15/bamboo_whisk_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04KK1B82RY-d09ab74e15/bamboo_whisk_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04KK1B82RY-d09ab74e15/bamboo_whisk_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 324, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04KK1B82RY-d09ab74e15/bamboo_whisk_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 415, "original_h": 374, "thumb_tiny": "AwArADDTJxTTS1FllJGc0mx2H7sdelPqHcD7GnRN1U9ulJMLD2YKMsQBTfOj/viknQugCkDnvVbyXAxvHX0psEWzxTG5FS00oD7UNAiBuevWofO2yhVBZh1Aqy6MFO0ZOOKiWFTFGvII5yOue9SMsk5QEd6g53dRS42Hjp6UBSxyoqk7itYsUUUUxBSFc896WigCJuM7qjgYu24cDP5ip5ADGc+lJEoCDA61NtSr6H//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04KK1B82RY/bamboo_whisk.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F04KK1B82RY-03d3a1ce82", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1674090031.147119] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
本件、PNCを申請する必要がございますか？
よろしくお願い致します。
- [1674091507.515749] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
本件、PNCの申請してから、
いつ来るか分からないので、今日の発送には間に合わないかもしれません。
明日、1/20(金)発送する予定です。
よろしいでしょうか？
よろしくお願い致します。
- [1674093289.857599] <@U0331FWGQRM>: <@U033G4KN4TD>
了解です。
では明日発送にしましょう。
宜しくお願いします！

## 2023-01-19

- [1674191345.114839] <@U0331FWGQRM>: 2023.01.20　<@U0331FZS7JT> <@U033G4KN4TD>
Alibaba井口さんMTG
議事録、メモ
（追加あればスレッドで返信）
・Japan Expoの時間はターゲット時差を考慮して
・滞留案件に対してJapan Expoの案内
・終了後Japan Expoの動画を送る
・製品ページに動画を差し込む（45秒）
	工場での製造現場
	プロダクト＋製品動画
・バイヤーの属性を確認を意識
- [1674194416.451379] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
先ほど、FedExで発送完了いたしました。
AWB No.：<https://www.fedex.com/apps/fedextrack/?action=track&amp;tracknumbers=771066128722&amp;clienttype=ivshpalrt|771066128722>
よろしくお願い致します。

## 2023-01-20

- [1674204149.267619] <@U0331FWGQRM>: <@U041RJKV5JA>
商品別に進捗教えてください。
宜しくお願いします。
- [1674205164.099489] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
お疲れ様です。
＜国産＞
・竹製のストロー
　希望入り数のものはまだ見つけれておりません。
・茶杓
　中田喜三の商品は全て箱入りにしていただけるそうです。
　最安値は本体300円＋箱代100円（卸値）
　カタログ、写真は無いとのことです。
・茶筅
　既存取引先のものが複数あります。
本日は、松江方面の取引先を回っていたため、進めれておりません。
早急に探します。

海外産の物と合わせて、来週報告いたします。
- [1674205549.587279] <@U0331FWGQRM>: <@U041RJKV5JA> 
了解です。また来週教えてください。
無いなら無いで返信しますが、
無いと言う選択肢はないので、、宜しくお願いします。

来週の時点でわかっていることをエクセルにまとめて教えてください。

また、アリババや既存の取引先にとらわれる必要はないので宜しくお願いします。

可能でればロゴを入れてほしいとのことなので、どんなものなら出来るのかなども合わせて宜しくお願い致します。
- [1674223284.325629] <@U0331FWGQRM>: <@U041RJKV5JA>
冊子のサンプルについて、
それぞれ１枚あたり金額わかりますか？
ざっくりでいいです。
最小ロットでの注文時（1000枚とか5000枚とか？）で確認お願いします。

例）
どれが一番安いとか、
20-30円/枚くらい　など。
  - files: [{"id": "F04L76ZE6AV", "created": 1674223246, "timestamp": 1674223246, "name": "IMG_9276.jpg", "title": "IMG_9276.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 597893, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04L76ZE6AV/img_9276.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04L76ZE6AV/download/img_9276.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04L76ZE6AV-412a2814a1/img_9276_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04L76ZE6AV-412a2814a1/img_9276_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04L76ZE6AV-412a2814a1/img_9276_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04L76ZE6AV-412a2814a1/img_9276_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04L76ZE6AV-412a2814a1/img_9276_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04L76ZE6AV-412a2814a1/img_9276_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04L76ZE6AV-412a2814a1/img_9276_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04L76ZE6AV-412a2814a1/img_9276_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04L76ZE6AV-412a2814a1/img_9276_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 4032, "original_h": 3024, "thumb_tiny": "AwAkADCKN1CAEc0/zE9KjEDe9L5Deh/KgBJXBHFQFqfLEydc060Cq7M3UDincCNWxwan3rtxTZQbiclARgAc8UqwNSuFjQt5N8eeOvakaXDSf7OKhs5ES3w7AHJ4NIJohNKzMCCRjg88UgG3rFnVAPeoUlEUpJGcr2PvS3E48/cmSCoHTFRPIGk3HIGMcijoBMglknZ41yCAeTU3mPCAHUDNMt544zzkfLjhT6029kSUJ5ZJxnPBoH5CgUoFAoFQUR3gAWNsc7sUXSjyT7Ypb3/Vx/71F1/qG/CqJFsnLxsGOcU5hzTNP+4/1p7daGNH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04L76ZE6AV/img_9276.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F04L76ZE6AV-2f5d001e6f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F04KUHQJM3L", "created": 1674223253, "timestamp": 1674223253, "name": "IMG_9277.jpg", "title": "IMG_9277.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 495858, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04KUHQJM3L/img_9277.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04KUHQJM3L/download/img_9277.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04KUHQJM3L-7e97203a9c/img_9277_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04KUHQJM3L-7e97203a9c/img_9277_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04KUHQJM3L-7e97203a9c/img_9277_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04KUHQJM3L-7e97203a9c/img_9277_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04KUHQJM3L-7e97203a9c/img_9277_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04KUHQJM3L-7e97203a9c/img_9277_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04KUHQJM3L-7e97203a9c/img_9277_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04KUHQJM3L-7e97203a9c/img_9277_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04KUHQJM3L-7e97203a9c/img_9277_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 4032, "original_h": 3024, "thumb_tiny": "AwAkADCn81L81Xvs6/31o+zr/fWgCgSaZmrs8KomdwNLFDG0SkoCSKTdgKOaUE1pJbQkf6sdaiaBPPZVwoFCdwIY5CZFHuK0STjhCPwrKhIEyEnADDJrUN3AP+Wo/WmO5Tmjdg75GOT+VWIhKsSANHjA6r/9eqkk0Z8zDNk5wB0qyl3CEUbjwMdDUu4iUicjrF/3yao3EjLcMGxkYHFW/tcBP+tH0INUblhJcOyHIJ4NNAS7F/uj8qUIh/hH5UtKKgsr3AVZo1VVA9h1ouVCoNoA57UXX/HxH9B/OluvuL9askZa4Mu1lVgfUVZKKDwo/Kq1p/r1q03WkwR//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04KUHQJM3L/img_9277.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F04KUHQJM3L-0d15e76732", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1674275928.502439] <@U0331FWGQRM>: <@U041RJKV5JA> *<!channel>*
Saudi Arabiaのお客様から抹茶のサンプル依頼がありました。
サンプルの準備宜しくお願いします。（各20gです）
ーーーーー
フォルダ名：サウジアラビア→NQ(Alibaba)
invoice_NQ_Tousuien(20230121)

香岳園30000
香岳園20000
鹿児島　有機抹茶A
鹿児島　有機抹茶1A

address Saudi Arabia, hofuf, alaziziyah 2nd
phone number <tel:+966555066461|+966555066461>
Name noura
Company name matcha dose
ーーーーー
・住所が短いような気がするので確認中です。
→確認したところ上記住所であっているとのことでした。
*・paypal支払い待ちです*
・出荷可能日が分かり次第教えてください。→済

サンプルの準備宜しくお願いします。
- [1674278107.494789] <@U0331FWGQRM>: <@U041RJKV5JA> *<!channel>* 
USAのお客様から抹茶のサンプル依頼がありました。
サンプルの準備宜しくお願いします。（各100gです）
ーーーーー
フォルダ名：アメリカ→Marcus Fisher（Alibaba）
TSE-MCS-001-23_invoice

内容はフォルダ内のエクセルファイル
QUOTATION_Marcus Fisher_SAMPLE_Tousuien(20230119)
をご確認ください。

address 4882 Sand Dollar Drive, Westlake, Florida 33470, United States
phone number <tel:+14125120616|+1 412 512 0616>
Name Marcus Fisher
Company name ~SpaScents Inc.~*削除*
ーーーーー
・paypal支払い待ちです。→済み
*・出荷可能日が分かり次第教えてください。*

サンプルの準備宜しくお願いします。

## 2023-01-22

- [1674429870.659889] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長
お疲れ様です。
TSE-MCS-001-23（アメリカ：Marcus Fisher（Alibaba）様）
USD100.00- 1/23 入金(PayPal)を確認致しました。
回収(入金)処理致します。
よろしくお願いします。
- [1674433236.657959] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
本件、明日 1月25日（水）出荷可能です。
宜しくお願い致します。
- [1674437390.896689] <@U0331FWGQRM>: <@U03SGRNND5L>
それでは明日出荷宜しくお願いします。
- [1674439197.950749] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
本件、原産地証明書取得の為、
明後日の1月25日（水）に出荷致します。
- [1674452880.826459] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長

お疲れ様です。
本件、1月26日（木）出荷可能です。
宜しくお願い致します。

## 2023-01-24

- [1674626583.434049] <@U0331FWGQRM>: <@U041RJKV5JA> CC <!channel>
アメリカのNeels様向けで各種試験結果を要求されています。
鹿児島製茶の有機抹茶1A（AとBの配合品の為選択）を下記試験を行ってもらえますか？
・残留農薬検査
・重金属検査
・放射能検査

試料名は“有機抹茶“でOKです。
（汎用性の高い試験結果にしたいため）
※鹿児島などの表記は不要です。
※もちろんその試験に提出した試料名は忘れないように社内記録に残す必要はあります。
※過去の試験結果で“出雲抹茶“などで栄養成分の結果を入手してしまうと、他へ転用できないのかなと思いました。

・試験機関
・試料発送予定日
・結果入手予定日（データでOK）
・価格
などが分かり次第教えてください。
宜しくお願いします。
- [1674630977.329529] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
各種検査ですが、ユーロフィンで行う予定です。

・残留農薬検査
　プラン：アメリカ向け一斉分析
・重金属
　ヒ素、鉛、カドミウム、水銀
　＊先方より上記以外の要望はありますか？
　　他にスズ、セレン、アンチモン、銀、コバルトが分析可能です。
・放射能検査
　検出限界値の指定はございますか？
　検出限界：10Bq/kg,5Bq/kg,1Bq/kg

上記が分かり次第、見積を頂きます。
よろしくお願いいたします。
- [1674632434.594899] <@U0331FWGQRM>: <@U041RJKV5JA>
試験に関する詳細の要求はありませんので、一般的なもので大丈夫です。アメリカ輸出時に必要な要件を満たして入ればいいかと思います。
なので、一般的なもので見積もり取得願います。

“アメリカ向け一斉分析“というプランがあるということは
その辺りもユーロフィンの方が詳しい？と思うので確認していただけたらと思います。

宜しくお願いします。

## 2023-01-25

- [1674717328.925979] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
アメリカ：Marcus Fisher（Alibaba）様を
本日、16：10にDHL_PGEで出荷しました。
AWB NO.5246867721　です。
宜しくお願い致します。

## 2023-01-26

- [1674773136.298119] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U0331FZS7JT> 社長
お疲れ様です。
TSE-LMS-SPL-001-22（スペイン：LM.Santamaria 様）
EUR93.36- 現地輸入手数料（弊社負担分）
1/26支払(PayPal)を確認致しました。
ありがとうございます。
➀主任と確認し、処理を行います。
②海外営業収支への反映致します。
よろしくお願いします。

## 2023-01-27

- [1674810371.777169] <@U0331FWGQRM>: <@U033G4KN4TD>　CC <@U0331FZS7JT>
アリババから仕入れの件について、
X以外（★マーク）は全てサンプル要求してください。
ロゴ入れ可能かも知りたいので、
参考として、添付keynoteの関連ページのみをPDF化して
確認資料として使用してください。
※お客様からロゴだけもらっています。
　これでできるかどうか先に情報として持っておきたいです
。

ロゴができない場合でもサンプルは欲しいので要求してください。

不明点があれば教えてください。

宜しくお願いします。

※ストロー、竹製茶筅、茶杓は最優先で進めてください。
  - files: [{"id": "F04LDG1RSS3", "created": 1674810158, "timestamp": 1674810158, "name": "ロゴ入れ提案.key", "title": "ロゴ入れ提案.key", "mimetype": "application/x-iwork-keynote-sffkey", "filetype": "key", "pretty_type": "Keynote Document", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 2572167, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04LDG1RSS3/_____________________.key?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04LDG1RSS3/download/_____________________.key?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04LDG1RSS3/_____________________.key", "permalink_public": "https://slack-files.com/T033D70RR6H-F04LDG1RSS3-ee6f664f50", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-01-30

- [1675079553.203449] <@U0331FWGQRM>: <@U041RJKV5JA>
下記各20gサンプルの準備をお願いします。

宇治有機抹茶12000
星野有機抹茶13000
鹿児島有機抹茶A 9000

発送可能日教えてください。
他のものと一緒に送る可能性があるので、保留でお願いします。
- [1675131080.590349] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
発送可能日：2/1(水)
よろしくお願い致します。

## 2023-02-01

- [1675238409.406069] <@U0331FWGQRM>: <@U033G4KN4TD> <@U041RJKV5JA> cc: <!channel>
アリババのお客様の問い合わせが来ています。
早速ですが、昨日の話の通りですが、
試しに皆様で進めていただけたらと思います。

今回は、Gai Assoulineという香港のお客様です。
アリババメッセージを確認してください。

香港なので、今回は、
魯さん平川部長で進めてください。
<@U03SGRNND5L> さんは、チャットを見て確認したり、
100%の把握は不要ですが、メッセージの進め方や、
翻訳の使い方に慣れるために関わってください。

Googleのアカウントを作成しました。
桃翠園海外事業部
<mailto:tousuien.global@gmail.com|tousuien.global@gmail.com>
PW : tousuien10

こちらを利用してください。

※上記内容（皆でアリババをする）は、
　テスト的な要素を含んでおります。
　様々な問題が発生すると思いますので、
　それは誰かのせいとかではなく“仕方がないもの“と認識していただけたらと思います。
　上手くいけば“提案数“が劇的に増えることになります。
　毎週のmtgで何か良いアイデアがあれば出していただけたら嬉しいです。

宜しくお願いします！
- [1675239046.407439] <@U0331FWGQRM>: 
  - files: [{"id": "F04MA5QB294", "created": 1675239036, "timestamp": 1675239036, "name": "スクリーンショット 2023-02-01 16.53.35.png", "title": "スクリーンショット 2023-02-01 16.53.35.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 142273, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04MA5QB294/____________________________2023-02-01_16.53.35.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04MA5QB294/download/____________________________2023-02-01_16.53.35.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QB294-ed2718ee45/____________________________2023-02-01_16.53.35_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QB294-ed2718ee45/____________________________2023-02-01_16.53.35_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QB294-ed2718ee45/____________________________2023-02-01_16.53.35_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 288, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QB294-ed2718ee45/____________________________2023-02-01_16.53.35_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 384, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QB294-ed2718ee45/____________________________2023-02-01_16.53.35_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QB294-ed2718ee45/____________________________2023-02-01_16.53.35_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 577, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QB294-ed2718ee45/____________________________2023-02-01_16.53.35_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 999, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QB294-ed2718ee45/____________________________2023-02-01_16.53.35_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 769, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QB294-ed2718ee45/____________________________2023-02-01_16.53.35_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 820, "thumb_1024_h": 1024, "original_w": 836, "original_h": 1044, "thumb_tiny": "AwAwACbQY4J+9+ApQ3A4b8qXAz3596Qhc4yfzNACg5PQ0tIMdqWgAooooAaTz2pOSeg/KnHr0B+tJke2frQAgbHRcfhS5NG70x+dOHSgAGcc9aKKKAEJwe1BHoKOd3tS0AJj2oGf8ilooABRRRQB/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04MA5QB294/____________________________2023-02-01_16.53.35.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04MA5QB294-b10bceed69", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F04MA5QGEF8", "created": 1675239038, "timestamp": 1675239038, "name": "スクリーンショット 2023-02-01 16.48.02.png", "title": "スクリーンショット 2023-02-01 16.48.02.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 115285, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04MA5QGEF8/____________________________2023-02-01_16.48.02.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04MA5QGEF8/download/____________________________2023-02-01_16.48.02.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QGEF8-30a4bb078f/____________________________2023-02-01_16.48.02_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QGEF8-30a4bb078f/____________________________2023-02-01_16.48.02_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QGEF8-30a4bb078f/____________________________2023-02-01_16.48.02_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 332, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QGEF8-30a4bb078f/____________________________2023-02-01_16.48.02_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 442, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QGEF8-30a4bb078f/____________________________2023-02-01_16.48.02_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QGEF8-30a4bb078f/____________________________2023-02-01_16.48.02_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 663, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04MA5QGEF8-30a4bb078f/____________________________2023-02-01_16.48.02_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 869, "original_w": 838, "original_h": 910, "thumb_tiny": "AwAwACzRYgEZJFIrrjhi3NOY47E/SgHI6YoATePf8qDIo9fyp1N3n+41ADhyKKKKAEY49PxNNBPH3fzpx+tHPrQAZHrRkdiM0fjQOec8UAJ83tTqKKAGt+P4ULn3P40pBLA5PHajHuaADJ/u/rSYP+1+dKF/2jS0AJk+lLRRQB//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04MA5QGEF8/____________________________2023-02-01_16.48.02.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04MA5QGEF8-cd7b514b90", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F04MGL26W5R", "created": 1675239041, "timestamp": 1675239041, "name": "スクリーンショット 2023-02-01 17.08.34.png", "title": "スクリーンショット 2023-02-01 17.08.34.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 168091, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04MGL26W5R/____________________________2023-02-01_17.08.34.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04MGL26W5R/download/____________________________2023-02-01_17.08.34.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04MGL26W5R-e0f828e3f5/____________________________2023-02-01_17.08.34_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04MGL26W5R-e0f828e3f5/____________________________2023-02-01_17.08.34_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04MGL26W5R-e0f828e3f5/____________________________2023-02-01_17.08.34_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 285, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04MGL26W5R-e0f828e3f5/____________________________2023-02-01_17.08.34_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 380, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04MGL26W5R-e0f828e3f5/____________________________2023-02-01_17.08.34_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04MGL26W5R-e0f828e3f5/____________________________2023-02-01_17.08.34_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 570, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04MGL26W5R-e0f828e3f5/____________________________2023-02-01_17.08.34_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 633, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04MGL26W5R-e0f828e3f5/____________________________2023-02-01_17.08.34_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 759, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04MGL26W5R-e0f828e3f5/____________________________2023-02-01_17.08.34_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 810, "original_w": 1302, "original_h": 1030, "thumb_tiny": "AwAlADDRKjtgUYb+/wDpSn6UY9qADn1/Sjn+9Sc+lGPagB1FNwfSnCgANJkeopaMUAFFFFABRSA5paACiiigAooooAKKKKAP/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04MGL26W5R/____________________________2023-02-01_17.08.34.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04MGL26W5R-dc2e869ce9", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1675308290.556569] <@U0331FWGQRM>: <@U041RJKV5JA>
Neels (US)
竹製のストローについて下記問い合わせが来てます。
※後で返信する際CC入れるので確認しておいてください。
ーーメール抜粋ーー
竹製品の価格について
-竹製のストローは、ブランドロゴの入った4本入りのものを使用する予定です。
-竹製のスプーンについて、日本製と中国製の品質の違いは何ですか？
-竹スプーンについて、どのようなカスタマイズが可能か、どのような包装形態が可能か、もう少し詳しく教えてください。
-中国から安価に調達できる可能性があるのでしょうか
ーーーーーー
念の為、話が進んだ場合のために、
日本製のストローについて調べて欲しいことがあるのでお願いします。

・使い捨てと、100回使えるもの、のうち、
100回使えるものには何をコーティングしていますか？
それは食品用の塗料としてOKなものですか？
（↑これがアメリカでOKですか？分からないと思うのでこちらで要調査）
→電話かけました。返答待ち。2/2 12:35
*→食品衛生法に準拠。菜箸に使われるものと同じ塗料。分析表もあるので提出できるとのこと。*

・ロゴ入れを依頼した際のリードタイム
（3000本/lot, 4500本/lot）
*→30-40日*

・サンプルで20本購入できますか？
（20本が不可ならば5本でも、10本でもいいです。4本入りの箱を検討する可能性があるので、4本以上）
*→可能。*

・茶杓の箱と袋のサンプルが欲しいです。（3個くらい）
*→平川部長本日（2/2）サンプル依頼*
- [1675310156.728079] <@U0331FWGQRM>: 
  - files: [{"id": "F04ML40JU7P", "created": 1675310153, "timestamp": 1675310153, "name": "スクリーンショット 2023-02-02 12.55.49.png", "title": "スクリーンショット 2023-02-02 12.55.49.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 244043, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04ML40JU7P/____________________________2023-02-02_12.55.49.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04ML40JU7P/download/____________________________2023-02-02_12.55.49.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04ML40JU7P-3707fb3b76/____________________________2023-02-02_12.55.49_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04ML40JU7P-3707fb3b76/____________________________2023-02-02_12.55.49_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04ML40JU7P-3707fb3b76/____________________________2023-02-02_12.55.49_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 106, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04ML40JU7P-3707fb3b76/____________________________2023-02-02_12.55.49_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 142, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04ML40JU7P-3707fb3b76/____________________________2023-02-02_12.55.49_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04ML40JU7P-3707fb3b76/____________________________2023-02-02_12.55.49_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 213, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04ML40JU7P-3707fb3b76/____________________________2023-02-02_12.55.49_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 237, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04ML40JU7P-3707fb3b76/____________________________2023-02-02_12.55.49_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 284, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04ML40JU7P-3707fb3b76/____________________________2023-02-02_12.55.49_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 303, "original_w": 2434, "original_h": 720, "thumb_tiny": "AwAOADDQyN2CaWmhCTncc/hS7W/vn9KQxfzpaTaf77fpRtP99v0oADntS/hTdp/vt+lAVscu36UAf//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04ML40JU7P/____________________________2023-02-02_12.55.49.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04ML40JU7P-e8bdbf8664", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1675319398.551269] <@U0331FWGQRM>: <@U041RJKV5JA> （リマインドとして）
上記茶杓2種類を箱付き、袋付きでサンプル依頼願います。
各3本ずつ。
- [1675320048.219799] <@U0331FWGQRM>: <@U033G4KN4TD> <!channel>
●Alibaba運用方法の相談

アリババのお客様でチャットとして（1時間に10回やりとりするなど）使用する場合は、その期間だけミュートにしてチャットしてもらえますか？
チャットが終われば、ミュートを解除して、通知が来るように再設定してもらえたらOKです。
※チャットの度に通知が来るので、大事な通知を見逃したり、チャットに埋もれる可能性があります。
※とは言え、通知機能によって速いレスポンスが実現できると思うので、対策が必要です。

そもそも、もし魯さんがアリババのアプリを携帯に入れてない場合、
通知機能が必要ないと思うので、ミュートにしてもらえると助かります！
（もし入れているのであれば上記対応などの検討が必要です）

また相談させてください。
- [1675320447.066739] <@U0331FWGQRM>: 
  - files: [{"id": "F04MPDDGZDZ", "created": 1675320443, "timestamp": 1675320443, "name": "スクリーンショット 2023-02-02 15.46.25.png", "title": "スクリーンショット 2023-02-02 15.46.25.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 315971, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04MPDDGZDZ/____________________________2023-02-02_15.46.25.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04MPDDGZDZ/download/____________________________2023-02-02_15.46.25.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04MPDDGZDZ-0eecc81f75/____________________________2023-02-02_15.46.25_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04MPDDGZDZ-0eecc81f75/____________________________2023-02-02_15.46.25_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04MPDDGZDZ-0eecc81f75/____________________________2023-02-02_15.46.25_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 278, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04MPDDGZDZ-0eecc81f75/____________________________2023-02-02_15.46.25_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 371, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04MPDDGZDZ-0eecc81f75/____________________________2023-02-02_15.46.25_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04MPDDGZDZ-0eecc81f75/____________________________2023-02-02_15.46.25_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 557, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04MPDDGZDZ-0eecc81f75/____________________________2023-02-02_15.46.25_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1035, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04MPDDGZDZ-0eecc81f75/____________________________2023-02-02_15.46.25_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 742, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04MPDDGZDZ-0eecc81f75/____________________________2023-02-02_15.46.25_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 792, "thumb_1024_h": 1024, "original_w": 1036, "original_h": 1340, "thumb_tiny": "AwAwACXRABA+nrRtHv8AnUYQecH3nO3G2nALxyOvHHegB2PT+dIQc/8A16dTfm5zgc8UALilxSAZ7/kaXHuaAIwY9+P49uadxx1pARvxs/h+9ShsY4GKAFGAeB+tL3pM8/8A16XuaACiiigBBnA9MUfNxTRu39Tt2/hTgDxzQAvNHNHPc0fhQAnNHPpS0UAf/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04MPDDGZDZ/____________________________2023-02-02_15.46.25.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04MPDDGZDZ-c1f80dd82a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1675321331.792769] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長

お疲れ様です。
承知しました。
よろしくお願い致します。
- [1675321389.165479] <@U0331FWGQRM>: <@U033G4KN4TD> アプリ携帯に入れてますか？
- [1675321764.752249] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長
アプリ携帯に入れていません。:sweat_drops:
- [1675321795.734089] <@U0331FWGQRM>: 了解です。:ok_hand:ありがとうございます！
なら通知がミュートでも影響ないですか？？
- [1675322077.297799] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
そうですね。
影響がないと思います。

## 2023-02-02

- [1675325176.758979] <@U0331FWGQRM>: <@U033G4KN4TD> <@U041RJKV5JA> cc <!channel>
アリババのMarcos smithの件、誰が対応されてますか？
嘘（詐欺）くさいのですが、いずれにしてもレスポンスした方がいいので、
レスポンスお願いします。
下の文章を利用してください。

※詐欺なら早く見切りをつけないと時間の無駄。
※本当なら取り逃がしてはいけない。

ーーー
14000tは14000000kgです。
これは1年間の総注文数量という認識であっていますか？
Net wt.25kg/csなので560,000cartonsの発送になります。

数量が多いので下記質問にお答えください。

有機を希望ですか？
indonesiaへ納品希望ですか？
何回に分けて納品ですか？
ex)　500kg/order x 10times order/year
過去に輸入の経験はありますか？
その際の輸入手段は船便ですか？
あなたの会社のHPを教えてください。
ーーー
- [1675325882.671899] <@U0331FWGQRM>: <@U033G4KN4TD> 
詐欺っぽいですね！
勇気を持って、無視しましょう！！笑
- [1675405179.869189] <@U0331FWGQRM>: <@U033G4KN4TD>
サンプルのロゴはこれでお願いします。
あくまでサンプルなので。

どちらを入れるのがいいかは、
商品のサイズによって異なると思いますが。

“ロゴはこれです。２パターン見たいです。どちらか一方しか無理なのであれば、どちらでもいいので、デザイン上おすすめの方をお願いします。”

とかで依頼しますか！
  - files: [{"id": "F04MWENMLDQ", "created": 1675405017, "timestamp": 1675405017, "name": "TOUSUIENglobal_logo.jpg", "title": "TOUSUIENglobal_logo.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 769720, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04MWENMLDQ/tousuienglobal_logo.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04MWENMLDQ/download/tousuienglobal_logo.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04MWENMLDQ-1fb7ec8ca5/tousuienglobal_logo_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04MWENMLDQ-1fb7ec8ca5/tousuienglobal_logo_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04MWENMLDQ-1fb7ec8ca5/tousuienglobal_logo_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 83, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04MWENMLDQ-1fb7ec8ca5/tousuienglobal_logo_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 110, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04MWENMLDQ-1fb7ec8ca5/tousuienglobal_logo_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04MWENMLDQ-1fb7ec8ca5/tousuienglobal_logo_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 165, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04MWENMLDQ-1fb7ec8ca5/tousuienglobal_logo_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 183, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04MWENMLDQ-1fb7ec8ca5/tousuienglobal_logo_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 220, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04MWENMLDQ-1fb7ec8ca5/tousuienglobal_logo_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 235, "original_w": 2839, "original_h": 651, "thumb_tiny": "AwALADCWWOK3uomVAq7XLY9hT/tJiTLQ7QVLL82c/X0p06hryAMMgqwI/Cqtp++aZZCWCKVUE9BTstwLc115TEbM4UHOeOTilFzw5Kj5Y9/DZB6/4VnpK/2SWbefMBChvb0pZf3cVvsJHmLtbB6jP/16LAXGvdoHyAZbHzNgdM0G9Vd4K8qoYYPDcZ61Vu2MW5oztKy8e3yinEebaTs/zNtVs++0UWA//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04MWENMLDQ/tousuienglobal_logo.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F04MWENMLDQ-8b9883c6f4", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F04MTGHNVNZ", "created": 1675405021, "timestamp": 1675405021, "name": "TOUSUIENglobal_logo_T.png", "title": "TOUSUIENglobal_logo_T.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 33649, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04MTGHNVNZ/tousuienglobal_logo_t.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04MTGHNVNZ/download/tousuienglobal_logo_t.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04MTGHNVNZ-d4c741c1a2/tousuienglobal_logo_t_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04MTGHNVNZ-d4c741c1a2/tousuienglobal_logo_t_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04MTGHNVNZ-d4c741c1a2/tousuienglobal_logo_t_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 330, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04MTGHNVNZ-d4c741c1a2/tousuienglobal_logo_t_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 440, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04MTGHNVNZ-d4c741c1a2/tousuienglobal_logo_t_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04MTGHNVNZ-d4c741c1a2/tousuienglobal_logo_t_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 660, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04MTGHNVNZ-d4c741c1a2/tousuienglobal_logo_t_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 733, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04MTGHNVNZ-d4c741c1a2/tousuienglobal_logo_t_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 880, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04MTGHNVNZ-d4c741c1a2/tousuienglobal_logo_t_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 939, "original_w": 2512, "original_h": 2303, "thumb_tiny": "AwAsADDPyKMimUU7gPqa0hEjszche3rUI6UzPJpSV0I2AABgDAqKedYkPI3dhWZk+tFZqmMKKKK0AeOlMPWnjpTD1psAooopAFFFFADx0ph608dKYetNgFFFFID/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04MTGHNVNZ/tousuienglobal_logo_t.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04MTGHNVNZ-ff363e503a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-02-06

- [1675711463.640449] <@U0331FWGQRM>: <@U041RJKV5JA>
次回サンプル発送時まとめて送る予定のものです。
・100g抹茶スタンド袋３パターンを準備願います。
宜しくお願いします。

＜発送予定内容＞
・宇治有機抹茶12000　20gサンプル
・星野有機抹茶13000　20gサンプル
・竹製のストロー with包装資材
・茶杓 with箱 and plastic袋
・その他入手したサンプル（要検討）
・100g抹茶スタンド袋３パターン
∟商品としてどのような見た目になるのか気にされています。（袋は120mm x 214mmの袋、無地を使用。黒があれば黒、なければ白、それもなければシルバー。無いというのは在庫が無いという意味でなく商品として存在しない場合、という意味）
１：脱酸素剤も窒素ガスも、何も入れてないもの
２：脱酸素剤入り
３：窒素ガス入り
※入れる抹茶はなんでもOK（鹿児島Dや、まるゑいMEA1とかでOK）

ーーー
松井備忘録
ペンディング：
お茶の工場、茶畑、茶農家、これらのお茶が製造されている場所の高画質の画像の提出
*→2/8済*
- [1675729692.400329] <@U0331FZTHEK>: <@U041RJKV5JA> 部長
お疲れ様です。
Gai Assouline 様
USD30.00- 2/6入金(PayPal)を確認致しました。
回収(入金)処理致します。
よろしくお願いします。

## 2023-02-07

- [1675778776.913679] <@U0331FWGQRM>: <@U041RJKV5JA>
Alibabaのサウジアラビアのお客様です。
Shahad Almajdouie
見積書をほぼ作成しました（明日完成します）ので、
明日提出してくれますか？
そのままどなたか引き継いで対応お願いします。
※明日また口頭で説明します。
ーーー
Organic ceremonial matcha
30g tins
With designed label
100 tins/order
Ship to Saudi Arabia
ーーー
メールアドレスは聞いているので、
↓見積りを送ってやりとりしてください。
<mailto:Shahadmajdouie@hotmail.com|Shahadmajdouie@hotmail.com>

確度は不明です。
- [1675842697.943829] <@U0331FWGQRM>: <@U041RJKV5JA>
追加で、下記のサンプル各20gお願いします。
・鹿児島有機抹茶A 9000（上記1/30にお願いしてるのであると思います。）
・鹿児島有機抹茶C 4000

## 2023-02-09

- [1675949285.985939] <@U0331FWGQRM>: <@U041RJKV5JA> cc <@U0331FZS7JT> <@U03BLQ65GK0>
・残留農薬検査
→ビューロにて桃翠園オリジナルパッケージで検査に出してください。(US, EURO, 台湾対応)

・重金属検査
・放射能検査
→安いところで検査に出してください。

それぞれ、検査に出す際の条件（検査内容）を
本スレッドで共有願います。
宜しくお願いします。
- [1675949510.036849] <@U0331FWGQRM>: <@U033G4KN4TD> cc <@U041RJKV5JA>
金属製スプーンについて下記質問が来ています。
ーーー
-日本への配送料はいくらですか？
-このスプーンのリードタイムはどのくらいですか？
-将来的にこのスプーンを単体で販売することになった場合、どのような梱包方法がありますか？
ーーー

先日ロゴ入りで作ってくださったメーカーの見積があれば共有願います。
- [1675952678.651369] <@U0331FWGQRM>: <@U033G4KN4TD>
追加で質問です。
ーーー
・ストロークリーナーも一緒に包装してほしいのですが。
・中国製の茶筅の価格も教えてください。
ーーー
上記についても教えてください。
サンプルはいつ頃届きそうでしょうか？
宜しくお願いします。
  - files: [{"id": "F04P7T36ETT", "created": 1675952653, "timestamp": 1675952653, "name": "Hfc88a1016a0049f69d2213786fcf5584U.jpg_960x960.webp", "title": "Hfc88a1016a0049f69d2213786fcf5584U.jpg_960x960.webp", "mimetype": "image/webp", "filetype": "webp", "pretty_type": "WebP", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 25952, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04P7T36ETT/hfc88a1016a0049f69d2213786fcf5584u.jpg_960x960.webp?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04P7T36ETT/download/hfc88a1016a0049f69d2213786fcf5584u.jpg_960x960.webp?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04P7T36ETT-cb9cfc12ff/hfc88a1016a0049f69d2213786fcf5584u.jpg_960x960_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04P7T36ETT-cb9cfc12ff/hfc88a1016a0049f69d2213786fcf5584u.jpg_960x960_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04P7T36ETT-cb9cfc12ff/hfc88a1016a0049f69d2213786fcf5584u.jpg_960x960_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04P7T36ETT-cb9cfc12ff/hfc88a1016a0049f69d2213786fcf5584u.jpg_960x960_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04P7T36ETT-cb9cfc12ff/hfc88a1016a0049f69d2213786fcf5584u.jpg_960x960_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04P7T36ETT-cb9cfc12ff/hfc88a1016a0049f69d2213786fcf5584u.jpg_960x960_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 720, "original_w": 750, "original_h": 750, "thumb_tiny": "AwAwADC+SFGSQB70owRkdKguYy2GHOO1RQSmMkEkqe3p9KVx2LlFIGDLuByD3o60xC0U1mCLk1HHukfeeFHQUrgTVXmi53J17irFFMClHIytkcjuKs+cuzcPyqKZFV8g8nqB3qAM5kyOAvaovYu1y0ELtl+vp6VMBgYFRxOGH+1UlUiWFMlLhf3a7jmn0UxEaR7fmblv5VFNASd6cN6etWKWlYdzOBCndyG9KvRMWjBYc0pjQtu2jPrTqErA3c//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04P7T36ETT/hfc88a1016a0049f69d2213786fcf5584u.jpg_960x960.webp", "permalink_public": "https://slack-files.com/T033D70RR6H-F04P7T36ETT-7d5a1c007d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1675952723.965459] <@U0331FWGQRM>: <@U041RJKV5JA>
株式会社ひろせプロダクトの担当者の名前、メールアドレスを教えてください。
- [1675960212.358429] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
竹製ストロー4本、箱入、クリーナー付属（ブラシ）
を探されております。
日本製、中国製、で用意できますか？

<@U041RJKV5JA>
日本製の場合、
ストローはひろせプロダクト、
・クリーナーは要調査
・箱は資材メーカー
になると思います。
上記のような箱を作成した場合、デザインありでいくらになるか見積もり取ってもらえますか？
クリーナーも探してもらえますか？
宜しくお願いします。

<@U033G4KN4TD>
中国製の場合、
竹製のストロー4本入り、箱、クリーナー
をセットで仕入れられるところがありそうか調べてもらえますか？

宜しくお願いします。
- [1675960533.626479] <@U0331FWGQRM>: <@U041RJKV5JA>
連投ですみませんが、
100g袋がケースに何個入るか知りたいです。

No.6っておよそ20kgくらい入ると思っていたのですが、
100g袋120しか入らないのですか？
また、GB用の段ボールに何袋入るか早急に知りたいです。

※空気を抜いたら沢山入る、という議論は当然知っている上での質問ですので、通常の空気の入り具合の感じで何個入るか知りたいです。
  - files: [{"id": "F04P8S0HGGH", "created": 1675960266, "timestamp": 1675960266, "name": "スクリーンショット 2023-02-10 1.24.55.png", "title": "スクリーンショット 2023-02-10 1.24.55.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 168532, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04P8S0HGGH/____________________________2023-02-10_1.24.55.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04P8S0HGGH/download/____________________________2023-02-10_1.24.55.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04P8S0HGGH-5ca587b29d/____________________________2023-02-10_1.24.55_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04P8S0HGGH-5ca587b29d/____________________________2023-02-10_1.24.55_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04P8S0HGGH-5ca587b29d/____________________________2023-02-10_1.24.55_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 156, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04P8S0HGGH-5ca587b29d/____________________________2023-02-10_1.24.55_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 208, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04P8S0HGGH-5ca587b29d/____________________________2023-02-10_1.24.55_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04P8S0HGGH-5ca587b29d/____________________________2023-02-10_1.24.55_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 312, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04P8S0HGGH-5ca587b29d/____________________________2023-02-10_1.24.55_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 346, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04P8S0HGGH-5ca587b29d/____________________________2023-02-10_1.24.55_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 416, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04P8S0HGGH-5ca587b29d/____________________________2023-02-10_1.24.55_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 443, "original_w": 1682, "original_h": 728, "thumb_tiny": "AwAUADDRz703kt1px9utJ/EKAF2/yo2ilooAQDilx/nFGQKMjNADNxzQGJYUh60i/eoAkzRRRQAA5AzRSDoKWgD/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04P8S0HGGH/____________________________2023-02-10_1.24.55.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04P8S0HGGH-6cf9f815af", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1675978164.016409] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
ひろせプロダクトの担当者です。
武上　春美
Mobile:080-8997-4228
e-mail ：<mailto:mail@hiropro.jp|mail@hiropro.jp>

ケース入り数については、午前中にご連絡いたします。
- [1675993892.429149] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
100g袋の入数です。
・No.6　200個
・GB用　300個
- [1676002680.439099] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
ステンレス製のスプーンの見積書を共有フォルダに入れておきました。
「アリババ仕入→ DONGGUAN_1_QUO」
ご確認お願い致します。
- [1676003792.321409] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
ステンレス製スプーンの日本への配送料について、
数量はどれぐらいでしょうか？

400入/csです、
1cs、2cs、3cs、4csの４パターンの送料を確認中です。
輸送方法：クーリエ
それでよろしいでしょうか？

よろしくお願い致します。
- [1676005072.519729] <@U0331FWGQRM>: <@U033G4KN4TD>
見積を見ると
MOQが200pcのようですが、、、

100pc/cs x 1cs　←もし可能であれば。不可なら無くてOK
200pc/cs x 1cs　←もし可能であれば。不可なら無くてOK
400pc/cs x 1cs
400pc/cs x 2cs

で見積とっていただけますでしょうか？

## 2023-02-11

- [1676125715.980399] <@U0331FWGQRM>: <@U041RJKV5JA>
進捗とスケジュール共有願います。
- [1676165908.779099] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
茶杓についても日本、中国ともにロゴを入れたサンプルを入手いただけますか？
宜しくお願いします。
- [1676180168.463349] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
CC: <@U03BLQ65GK0> 会長 <@U0331FZS7JT> 社長
報告が遅くなり申し訳ございません。
検査内容、価格をPDFに纏めました。
ご確認お願いいたします。

検体は月曜日に会長に依頼し、準備ができ次第、検査機関へ提出いたします。
  - files: [{"id": "F04P76X5ANN", "created": 1676180157, "timestamp": 1676180157, "name": "残留農薬、重金属、放射能検査.pdf", "title": "残留農薬、重金属、放射能検査.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 295123, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04P76X5ANN/__________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04P76X5ANN/download/__________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F04P76X5ANN-7d68e31f27/___________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04P76X5ANN/__________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F04P76X5ANN-1a937577d1", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1676183957.007029] <@U0331FWGQRM>: <@U041RJKV5JA>
有難うございます。
検体提出前に申込書などはここで共有願います。
（表記方法など、確認したいです。）

残留農薬検査費用が高いんですね。

残留農薬検査については、
今回は、US,EU,台湾の農薬検査項目を網羅した、桃翠園オリジナルの検査項目をパッケージ化して検査して頂けて約20万円/検体。

一般的なパッケージ化されている農薬検査パックは大体〇〇円〜〇〇円/検体で上記よりも安いです。しかし検査項目については、USだけとか、台湾だけ、などである上、検査項目数についても過不足があるような検査内容です。

よって、多少今回が高額であったとしても、一回で済ませられるのであれば、桃翠園オリジナルの検査をした方がいいのでは？ということでこれを進めることになりました。

（↑事実だけでなく情報共有の要素もあるので、
会話していない人が見てもわかるように意識して情報発信してください。〇〇円〜〇〇円/検体のところだけ追加で教えてください。宜しくお願いします。）
- [1676184549.924019] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
検査費用は4万円～11.1万円/検体となります。
・アメリカ向け　8.5万円～11.1万円
・EU向け　8万円
・台湾向け　4万円～4.8万円
- [1676185814.525159] <@U0331FWGQRM>: <@U041RJKV5JA> 
Danah様のやりとり、誰がされてましたか?
返信対応しておきましたので、
続きのやりとりお願いします。
（もちろん月曜でokです）
  - files: [{"id": "F04P799M8LA", "created": 1676185774, "timestamp": 1676185774, "name": "IMG_9635.png", "title": "IMG_9635", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 827206, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04P799M8LA/img_9635.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04P799M8LA/download/img_9635.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04P799M8LA-f96558cc15/img_9635_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04P799M8LA-f96558cc15/img_9635_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04P799M8LA-f96558cc15/img_9635_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04P799M8LA-f96558cc15/img_9635_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 222, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04P799M8LA-f96558cc15/img_9635_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04P799M8LA-f96558cc15/img_9635_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 333, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04P799M8LA-f96558cc15/img_9635_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1731, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04P799M8LA-f96558cc15/img_9635_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 444, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04P799M8LA-f96558cc15/img_9635_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 473, "thumb_1024_h": 1024, "image_exif_rotation": 1, "original_w": 828, "original_h": 1792, "thumb_tiny": "AwAwABbRHB46VE90iNtKsT2wOtS1mrDdAuCrEHpyKALqSrKxBQj2apMJ/cH5VWtI5kz5v4dzVnFAC0UjfdNMwP8AOaYElFIopaAA8jim7W/vU/tnt60gZfUfnSAQDHU5paDgdTgfWk3L/fH50wP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04P799M8LA/img_9635.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04P799M8LA-cc3b7735c4", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-02-12

- [1676200747.472259] <@U0331FZS7JT>: <@U041RJKV5JA> 部長
CC：<@U0331FWGQRM>執行役

お疲れ様です。
情報共有ありがとうございます。

出雲精茶産の茶は恐らく今回の検査についてEU・アメリカ引っ掛かります。
で、あくまで数値（比較）確認でお願いします。
※台湾はOK

で、今年2023年の１番茶から全ての圃場がEU・US・台湾に対応します。
出雲精茶でもASIA GAPの都合上検査義務があるので
今回受けようとしているものと同様の内容を金山工場長と共有をお願いします。
尚、出雲精茶は生産家組合で補助金があるようなのでそれで提出します。
その際も出雲抹茶とせずに非有機でまとめて出そうと思います。
ロット検体名も共有をお願いします。

以上、よろしくお願いします。
- [1676201707.665409] <@U0331FWGQRM>: <@U0331FZS7JT> <@U041RJKV5JA> <@U03BLQ65GK0>
確か農薬検査は年一回がルールだった？と思うので、FSSC上のルールだけでいくと、
出雲精茶の抹茶の検査だけ、後ろ倒して6月とかに受けても差し支えないと思いますが、、どうでしたっけ？

それまでに3エリア混合の検査結果が必要になった場合は、この検査を受ければいいかと思いますが。
- [1676202219.825989] <@U0331FZS7JT>: <@U0331FWGQRM> <@U03BLQ65GK0> <@U041RJKV5JA> 
時期と回数が問題なければ、それで良いと思います。
<@U03BLQ65GK0>どうでしたっけ？

出雲精茶の検査については栽培面積で補助額決まる、よく分からん補助の要件なので、明日金山さんが県に確認をとります。
桃翠園的に問題なければ、出雲精茶は６月と秋碾の時期の２回を受ける予定で動きます。
- [1676204300.702619] <@U03BLQ65GK0>: <@U0331FZS7JT> <@U0331FWGQRM> 
FSSCのルールでは残留農薬の検査は年二回です。（一番茶が揃う7月と、秋碾の揃う2月）
その為、できれば今月中には検査に出したいとは思っています。
- [1676204752.040359] <@U0331FWGQRM>: <@U0331FZS7JT> <@U041RJKV5JA> 
て事は、桃翠園と出雲精茶で全く同じ検査を別々で2回するって事なんですね。。。

んー。桃翠園は受けずに結果だけもらうのもありかもですね:sweat_drops:

他のお茶屋からも農薬の検査結果をもらうのと同じように、出雲精茶からも貰うってことにしておくのがいいのでしょうか。。。

取り急ぎニールズさんの件は、検査結果に鹿児島製茶が出てしまうと微妙なので桃翠園で受けようと思ってます。

何かしらのルールの設定が必要そうですね。
- [1676205999.297149] <@U0331FZS7JT>: <@U0331FWGQRM> <@U041RJKV5JA> 
ニールズさんの件、桃翠園で受けるのが良いですね！
出雲精茶製品の確認、残留農薬以外の検査は桃翠園で受けたら良さそうですね！

<@U03BLQ65GK0> 
出雲精茶が独自で検査を受けた場合は、桃翠園で検査する中身は何になりましたっけ？
※仕入先が検査していない、国内基準のお茶やら玄米？
有機と非有機分けた場合に、
有機：・有機製品まとめて
非有機：・非有機の海外向け茶まとめて
・国内向け茶&amp;ブレンド材まとめて
の計３つになるんでしたっけ？
または非有機(海外対応含)、国内向けは１つにまとめての検体でしたっけ？

もし非有機&amp;国内向けが分けれていないのであれば、ルール上の
有機製品(今回の確認原料の残留農薬)確認＋国内向け製品の２つ確認で一旦FS上のルールはクリアできるかな、と。

で、出雲精茶はまとめて出雲精茶で確認で桃翠園に提出でも良いかな？と！

ルール設定は別途確認が必要だと思いますが！

- [1676248803.156439] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
私がやっています。
返信対応、ありがとうございます。
続けて、やりとりをしていきます。
よろしくお願い致します。
- [1676250232.852539] <@U03BLQ65GK0>: <@U0331FWGQRM>
FSSCのルールとしては、
残留農薬検査を桃翠園が検査する必要はない
➞仕入先から残留農薬の検査結果を入手する
なので、出雲精茶から残留農薬についてはもらうという形で良いのではないでしょうか。
今回残留農薬を桃翠園で行う背景には取引先に求められることがあるから行うということだったと思いますが、出雲精茶が行った検査結果でも問題ないのであれば良いと思いますよ！
- [1676250556.988319] <@U03BLQ65GK0>: <@U0331FZS7JT>
&gt; 出雲精茶が独自で検査を受けた場合は、桃翠園で検査する中身は何になりましたっけ？
➞重金属と一般生菌数の2つが必要です。
※基本的には残留農薬検査結果の提出のない原料の受入はできないというルールになっています。（受入後こちらで検査するのであれば問題ありません）

FSSCのルールとしては無作為に選出した検体の検査なので、有機と非有機を区別して行うといったことはなく、定期的に1つ（以上）の検体を検査すれば良いというものです。
その為、煎茶・抹茶・紅茶などをブレンドし検査に出すという形となります。これは出雲精茶のお茶以外も含んだ形となります。

その為、出雲精茶が行った残留農薬結果入手で問題はないですね！
何をどのタイミングで行うかなどのルールは言われる通り別途協議が必要ですね。
- [1676251326.728269] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
先週に茶杓のロゴ入りサンプルを入手しました。
先週発送済で、今週中に届くかもしれません。
写真を添付いたします。
よろしくお願い致します。
  - files: [{"id": "F04P1UR6G6A", "created": 1676251323, "timestamp": 1676251323, "name": "スクリーンショット 2023-02-13 午前10.21.20.png", "title": "スクリーンショット 2023-02-13 午前10.21.20.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 897463, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04P1UR6G6A/____________________________2023-02-13_______10.21.20.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04P1UR6G6A/download/____________________________2023-02-13_______10.21.20.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1UR6G6A-54165eb394/____________________________2023-02-13_______10.21.20_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1UR6G6A-54165eb394/____________________________2023-02-13_______10.21.20_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1UR6G6A-54165eb394/____________________________2023-02-13_______10.21.20_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 282, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1UR6G6A-54165eb394/____________________________2023-02-13_______10.21.20_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 376, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1UR6G6A-54165eb394/____________________________2023-02-13_______10.21.20_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1UR6G6A-54165eb394/____________________________2023-02-13_______10.21.20_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 565, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1UR6G6A-54165eb394/____________________________2023-02-13_______10.21.20_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 627, "thumb_800_h": 800, "original_w": 676, "original_h": 862, "thumb_tiny": "AwAwACWoMYFSQxCZwvb2pijGD7VatP8AWZ9akYotoY2wztn0NLPFGlu0iDJHIzVWZ5HlOeCasIzPayoxzhc1QigSScnrRSCloAseZsRcKhJxywzT4ZG+0Rk45bHAxxj0qS0hjli3OMkHHWrBgiVflRQRznFAFeeNDMWBwR1FKhVUcLzuGKfNtLHj5s+lLEi55H40hmUKWnzLtmdfRjTKYjQ08/umH+1/SrZ6VnWU6RBldsZIxV0zw4/1qfnSAjcfvCfepEGcUzzYWBBkUc8c0omgXnzV/OgZQvBi6f35qGp7x0efcjAjA6VBTEf/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04P1UR6G6A/____________________________2023-02-13_______10.21.20.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04P1UR6G6A-1a98e6ddfa", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1676251378.511579] <@U0331FZS7JT>: <@U03BLQ65GK0>
まとめると・・・
FSSCで自社検査必須項目
・一般生菌数
・重金属　　の２つ
⇒7月と2月
&gt; FSSCのルールでは残留農薬の検査は年二回です。（一番茶が揃う7月と、秋碾の揃う2月）
これは誤りですね？

他社からの情報受入で対応
・残留農薬検査
※検査結果だけでなく、栽培履歴や暦で問題ないと判断する（だったような。）

別途お客様の対応に際し必要だと判断した場合は
・自社で残留農薬検査
- [1676251599.553289] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
中国製、竹製のストロー4本入り、箱、クリーナーセットについて、
情報共有させて頂きます。
EXW価格：USD1.156 per sets
画像を添付いたします。
よろしくお願い致します。
  - files: [{"id": "F04P1V0KSLE", "created": 1676251591, "timestamp": 1676251591, "name": "スクリーンショット 2023-02-13 午前10.15.44.png", "title": "スクリーンショット 2023-02-13 午前10.15.44.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 2096462, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04P1V0KSLE/____________________________2023-02-13_______10.15.44.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04P1V0KSLE/download/____________________________2023-02-13_______10.15.44.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1V0KSLE-84e7b08f15/____________________________2023-02-13_______10.15.44_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1V0KSLE-84e7b08f15/____________________________2023-02-13_______10.15.44_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1V0KSLE-84e7b08f15/____________________________2023-02-13_______10.15.44_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 274, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1V0KSLE-84e7b08f15/____________________________2023-02-13_______10.15.44_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 365, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1V0KSLE-84e7b08f15/____________________________2023-02-13_______10.15.44_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1V0KSLE-84e7b08f15/____________________________2023-02-13_______10.15.44_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 548, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1V0KSLE-84e7b08f15/____________________________2023-02-13_______10.15.44_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 609, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1V0KSLE-84e7b08f15/____________________________2023-02-13_______10.15.44_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 730, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04P1V0KSLE-84e7b08f15/____________________________2023-02-13_______10.15.44_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 779, "original_w": 1112, "original_h": 846, "thumb_tiny": "AwAkADCQDjtTwFPHGaQEY703ncBSGKrZIwBg04uPM2ADoDUUZ4H0pSR9qP8AuilcCQsvfA6Uu32FQznCuf7pU/rVjIx1oTAiIAXJ7D0ppdSwxnrUhBK4PTFM2L6AU2A2P/P5mmk/6V/wAUqBwfuE479qb5cgmLFSRtA4pWAWb5knH+yKsId0St6iovLc7wVPIx+hpbbcIFDKQRxzQkBC8z5xUZlYHGaG61GfvVQiUSsBUizPntUAp69aALQlbHajzD7UwdKKYH//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04P1V0KSLE/____________________________2023-02-13_______10.15.44.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04P1V0KSLE-cfd351b73e", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1676251706.179109] <@U03BLQ65GK0>: <@U0331FZS7JT>
&gt; FSSCのルールでは残留農薬の検査は年二回です。（一番茶が揃う7月と、秋碾の揃う2月）
すみません、誤りでした。

&gt; ※検査結果だけでなく、栽培履歴や暦で問題ないと判断する（だったような。）
そうです、残留農薬などの製品の安全が担保できる何かしらのエビデンス資料があれば良いです。
- [1676252453.466399] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長
お疲れ様です。
アリババ仕入のステンレス製サジが日本までの国際送料について、
100pc/cs x 1cs：$40
200pc/cs x 1cs：$55　
400pc/cs x 1cs：$80
400pc/cs x 2cs：$150
リードタイム：
100pcs:3日
200pcs:7日
400pcs:10日
800pcs:15日
よろしくお願い致します。
- [1676257649.373539] <@U0331FWGQRM>: <@U033G4KN4TD>
上の写真の竹製ストローの

ロゴは
・自由に変更可能ですか？

紙の箱は
・何本入りですか？
・デザインは自由に変更可能ですか？
- [1676271504.016769] <@U041RJKV5JA>: <@U03BLQ65GK0> 会長 <@U0331FZS7JT> 社長 <@U0331FWGQRM> 執行役
今回は有機茶のみ検査を行います。
また、今回の検査はNeels様からの依頼がありますので、残留農薬検査はアメリカ向け100％対応のSGSのプランで行います。
重金属検査、放射能検査は検査機関に変更はありません。
再度、PDFを添付いたします。
  - files: [{"id": "F04P6EMAP2R", "created": 1676271483, "timestamp": 1676271483, "name": "残留農薬等検査.pdf", "title": "残留農薬等検査.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 254599, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04P6EMAP2R/_____________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04P6EMAP2R/download/_____________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F04P6EMAP2R-efb2291e27/______________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04P6EMAP2R/_____________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F04P6EMAP2R-418c7f1446", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1676273466.449309] <@U0331FWGQRM>: <@U033G4KN4TD>
あと、サンプル手配お願いします。
到着日も知りたいです。
- [1676274274.042769] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
竹製ストロー
ロゴは
・自由に変更可能ですか？
*→可能です。*

紙の箱は
・何本入りですか？*→ご希望の通りです。*
・デザインは自由に変更可能ですか？*→自由変更が可能です。*
よろしくお願い致します。
- [1676274396.223999] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
竹製ストローのサンプルが届いているのです。
サンプル手配お願いします。*→セットのサンプルですか？*
よろしくお願い致します。
- [1676274442.418789] <@U0331FWGQRM>: <@U033G4KN4TD> あ、ブラシです！
- [1676274900.698539] <@U033G4KN4TD>: <@U0331FWGQRM>
紙の箱は要りますか？

## 2023-02-13

- [1676281261.057529] <@U0331FWGQRM>: <@U033G4KN4TD>
もらえるのであれば全部もらってください:sweat_drops:
一緒に、全てにおいてオリジナルデザインが可能かどうかと、箱のサイズの変更が可能かどうかも聞いてください。
（お客様から聞かれる可能性のある要望については、今の段階で可否確認しておくと、後々便利かと思いますので。）
宜しくお願いします。

## 2023-02-16

- [1676552069.770459] <@U0331FWGQRM>: <@U041RJKV5JA>
上記、１、２、３は準備できていますか？
１：脱酸素剤も窒素ガスも、何も入れてないもの
２：脱酸素剤入り
３：窒素ガス入り
- [1676591103.651539] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
本日、午前中に完成予定です。
- [1676594521.098109] <@U041RJKV5JA>: <@U03BLQ65GK0> 会長 <@U0331FZS7JT> 社長 <@U0331FWGQRM> 執行役
本日、放射能測定を依頼いたします。
申込書のPDFを添付いたします。
  - files: [{"id": "F04PYUCL7MK", "created": 1676594454, "timestamp": 1676594454, "name": "15f-form-radioactivity.pdf", "title": "15f-form-radioactivity.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 154100, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04PYUCL7MK/15f-form-radioactivity.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04PYUCL7MK/download/15f-form-radioactivity.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F04PYUCL7MK-9256bdff3a/15f-form-radioactivity_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1096, "thumb_pdf_h": 1550, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04PYUCL7MK/15f-form-radioactivity.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F04PYUCL7MK-f24472c49b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-02-17

- [1676698511.255489] <@U0331FWGQRM>: <@U03BLQ65GK0> <!channel>
2/24. 25の13時からAlibaba Live streamを行います。
すみませんが、その時に使用する、
下記材料を用意して頂けますでしょうか。
宜しくお願いします。

色が綺麗であれば、なんでもOKです。
その辺においているものでもOKです。
アルミチャックつき袋（サイズは適切であればなんでもOK）に
入れていただければ助かります。

出雲の抹茶　   50g
煎茶一茶・秋冬番　   50g
ほうじ茶　　 100g
ほうじ茶粉末   20g
玄米茶　　　 100g
玄米茶粉末       20g

下記各20g（粉末）
レモングラス
シナモン
ジンジャー
ターメリック
ミント

宜しくお願いします。
- [1676699176.130159] <@U03BLQ65GK0>: <@U0331FWGQRM> 
了解です。
レモングラスから下は粉末ですよね？

## 2023-02-20

- [1676938455.676899] <@U041RJKV5JA>: <@U03BLQ65GK0> 会長 <@U0331FZS7JT> 社長 <@U0331FWGQRM> 執行役
有機抹茶/有機煎茶の放射能測定結果を下記フォルダへ入れておきます。
ご確認お願い致します。

お客様別-B-ビューローベリタス-有機抹茶・有機煎茶-放射能測定結果
- [1676958783.212289] <@U0331FWGQRM>: <@U041RJKV5JA> CC <!channel>
Neels様へサンプル発送お願いします。
（スレッドがわかりにくくなってきたので別で投稿します）
内容はインボイスをご確認ください。
TSE-NTV-003-23

※ラベルは抹茶にだけ、つければOKです。
インボイスの表記を使用してください。
あとはメールで対応します。

宜しくお願い致します。
- [1676959233.660979] <@U041RJKV5JA>: <@U03BLQ65GK0> 会長 <@U0331FZS7JT> 社長 <@U0331FWGQRM> 執行役
本日、SGSに検体を送ります。
＜検査内容＞
・残留農薬検査
・重金属検査
申込書のPDFを添付いたします。
（英語と日本語が混じっておりまが、先方に確認いただいております。）
  - files: [{"id": "F04QAFRC4NA", "created": 1676959224, "timestamp": 1676959224, "name": "2022 Application Form.pdf", "title": "2022 Application Form.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 303957, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04QAFRC4NA/2022_application_form.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04QAFRC4NA/download/2022_application_form.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F04QAFRC4NA-8355831d70/2022_application_form_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04QAFRC4NA/2022_application_form.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F04QAFRC4NA-cdb22c079d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1676962303.099869] <@U0331FWGQRM>: <@U041RJKV5JA>
放射能検査結果の英文はありますか？
- [1676962353.620029] <@U041RJKV5JA>: <@U0331FWGQRM>
同じファイル2枚めにあります。
ご確認お願いします。

## 2023-02-21

- [1677025909.095579] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役<@U041RJKV5JA> 部長

お疲れ様です。
Neels様へサンプル発送の件、今日発送していいですか？
よろしくお願い致します。
- [1677026995.884159] <@U0331FWGQRM>: <@U033G4KN4TD> 
はい、宜しくお願い致します！

## 2023-02-23

- [1677145497.852979] <@U0331FWGQRM>: <@U041RJKV5JA> <!channel>
カナダのお客様へサンプル発送お願いします。
入金確認後の発送でお願いします。

カナダ→Jenny Howack(Alibaba)

内容、発送先住所などは
INVOICEをご確認ください。
宜しくお願いします。
- [1677197002.477509] <@U0331FWGQRM>: <@U041RJKV5JA> <@U03SGRNND5L>
お客様の入金確認まで、サンプルの準備は開始しないでOKです。（入金されない可能性もあるので:sweat_drops:）
- [1677206941.900379] <@U0331FWGQRM>: <!channel>
今日の日本時間13時からAlibaba live streamを行います。
今までalibaba経由で問い合わせて、
連絡が止まっているお客様などに
下記URLとメッセージを添えてお知らせしてください。

Hello.
I hope you are doing well.

Well, I just contacted you today with an announcement.
Today and tomorrow(24 and 25 Feb.), we will have an Alibaba Live stream starting at 1:00 PM Japan time.
If you are interested, please take a look.

Today, it will start one hour later from now.
I will be waiting for you:)

Thanks.

24 Feb.
<https://onl.la/bXxfLiw>

25 Feb.
<https://onl.la/LAKEGHK>
  - attachments: [{"image_url": "https://sc04.alicdn.com/kf/A357f66a7165d43909548c01951edc0f5f.jpg", "image_width": 707, "image_height": 707, "image_bytes": 745871, "from_url": "https://onl.la/bXxfLiw", "service_icon": "http://is.alicdn.com/simg/single/icon/favicon.ico", "id": 1, "original_url": "https://onl.la/bXxfLiw", "fallback": "alibaba.com: Matcha : ceremonial - culinary grade, OEM (bag, tin, stick) Product Show Stream 2023 - Alibaba.com", "text": "Food &amp; Beverage suppliers and exhibitors live-stream at <http://Alibaba.com|Alibaba.com> Online Trade Show now.", "title": "Matcha : ceremonial - culinary grade, OEM (bag, tin, stick) Product Show Stream 2023 - Alibaba.com", "title_link": "https://onl.la/bXxfLiw", "service_name": "alibaba.com"}, {"from_url": "https://onl.la/LAKEGHK", "image_url": "https://sc04.alicdn.com/kf/A872f52e14d884601bc509522dd327aa6W.jpg", "image_width": 707, "image_height": 707, "image_bytes": 746838, "service_icon": "http://is.alicdn.com/simg/single/icon/favicon.ico", "id": 2, "original_url": "https://onl.la/LAKEGHK", "fallback": "alibaba.com: Matcha : ceremonial - culinary grade, OEM (bag, tin, stick)2 Product Show Stream 2023 - Alibaba.com", "text": "Food &amp; Beverage suppliers and exhibitors live-stream at <http://Alibaba.com|Alibaba.com> Online Trade Show now.", "title": "Matcha : ceremonial - culinary grade, OEM (bag, tin, stick)2 Product Show Stream 2023 - Alibaba.com", "title_link": "https://onl.la/LAKEGHK", "service_name": "alibaba.com"}]

## 2023-02-24

- [1677255335.983869] <@U0331FWGQRM>: <@U041RJKV5JA> <@U03SGRNND5L>
入金されました。
サンプル準備進めてください。
出荷可能日を教えてください。

<@U0331FZTHEK>
Kong Fai Tao
Esukoto’s Emporium Inc.
からサンプル代支払われました。
宜しくお願いします。
- [1677279171.647039] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長 <@U03SGRNND5L> さん
お疲れ様です。
Esukoto’s Emporium Inc.（カナダ：Jenny Howack(Alibaba) 様）
本日(2/25) 入金[PayPal]を確認致しました。
USD30.00-
回収(入金)処理致します。
よろしくお願いします。
- [1677279201.203599] <@U0331FZTHEK>: <@U041RJKV5JA> 部長
お疲れ様です。
Olga Sasoni Café  様（スイス）
本日(2/25) 入金[PayPal]を確認致しました。
USD30.00-
回収(入金)処理致します。
よろしくお願いします。
- [1677301281.187359] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
2/27（月）出荷可能です。
宜しくお願い致します。

## 2023-02-25

- [1677328890.198869] <@U0331FWGQRM>: <@U041RJKV5JA> <!channel>

シンガポールのお客様からサンプル依頼です。
入金確認後の発送お願いします。
※サンプル費USD20 入金済 <@U0331FZTHEK>
ーーーー
Highlanders International Pte Ltd
Jasmine Low

348 Jalan Boon Lay
Blk A #01-07A
Singapore 619529

<tel:+6597250068|+65 97250068>

*内容（非有機でOK）*
・玄米茶パウダー
∟出雲精茶@500＋丸菱（並玄米）
・有機玄米茶パウダー
∟鹿児島製茶（有機煎茶１B）＋丸菱（オーガニック玄米）

・出雲抹茶 W
・出雲抹茶 H
・出雲抹茶 P

※quotationは作成中です
ーーーー
- [1677376519.627329] <@U0331FWGQRM>: <@U033G4KN4TD> <@U041RJKV5JA>
一応、返信対応してます。（また来週対応願います）
  - files: [{"id": "F04RCPWRXAQ", "created": 1677376516, "timestamp": 1677376516, "name": "スクリーンショット 2023-02-26 10.54.31.png", "title": "スクリーンショット 2023-02-26 10.54.31.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 168193, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04RCPWRXAQ/____________________________2023-02-26_10.54.31.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04RCPWRXAQ/download/____________________________2023-02-26_10.54.31.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04RCPWRXAQ-b0f4ee72bf/____________________________2023-02-26_10.54.31_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04RCPWRXAQ-b0f4ee72bf/____________________________2023-02-26_10.54.31_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04RCPWRXAQ-b0f4ee72bf/____________________________2023-02-26_10.54.31_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 292, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04RCPWRXAQ-b0f4ee72bf/____________________________2023-02-26_10.54.31_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 390, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04RCPWRXAQ-b0f4ee72bf/____________________________2023-02-26_10.54.31_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04RCPWRXAQ-b0f4ee72bf/____________________________2023-02-26_10.54.31_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 584, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04RCPWRXAQ-b0f4ee72bf/____________________________2023-02-26_10.54.31_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 649, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04RCPWRXAQ-b0f4ee72bf/____________________________2023-02-26_10.54.31_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 779, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04RCPWRXAQ-b0f4ee72bf/____________________________2023-02-26_10.54.31_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 831, "original_w": 1274, "original_h": 1034, "thumb_tiny": "AwAmADC9uDOwBOR1pwOBTj0poIz6/hQAu4UoOelJx/d/SlHTpigAox70UUAB6Ugz6/pS0Y9hQAf8Co/GjA9BRx6UAFFJkDqaUHNACZozSHvR/n9aADGTnJFGz3NKtLQAgXHc0hQEg5ORTqKAP//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04RCPWRXAQ/____________________________2023-02-26_10.54.31.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04RCPWRXAQ-fa094d964a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-02-26

- [1677452809.275839] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長
お疲れ様です。
Highlanders International Pte Ltd
Jasmine Low 様
2/25 入金[PayPal]を確認致しました。
USD20.00-
回収(入金)処理致します。
よろしくお願いします。
- [1677458155.841469] <@U0331FWGQRM>: <@U041RJKV5JA>
追加で下記も宜しくお願い致します。

出雲抹茶R
出雲抹茶F

鹿児島有機A
鹿児島有機B
鹿児島有機D
- [1677461398.874969] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役<@U041RJKV5JA> 部長

お疲れ様です。
Neels様へサンプル発送について、
出荷書類の準備が出来ました。
DHLへの集荷依頼（本日2/27発送）を予約しました。
AWB No.：5246934383
出荷完了しましたら、改めて報告いたします。
よろしくお願い致します。
  - files: [{"id": "F04RBNF4L03", "created": 1677461331, "timestamp": 1677461331, "name": "TSE-NTV-004-23.pdf", "title": "TSE-NTV-004-23.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 1901655, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04RBNF4L03/tse-ntv-004-23.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04RBNF4L03/download/tse-ntv-004-23.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F04RBNF4L03-01acd45e65/tse-ntv-004-23_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04RBNF4L03/tse-ntv-004-23.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F04RBNF4L03-3e800d0543", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1677471716.171459] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
シンガポールJasmine Low 様
2/28、サンプルを出荷予定です。
よろしくお願い致します。
- [1677475547.774859] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
DHLで発送完了です。
AWB No.は上記記載通りです。
よろしくお願い致します。
- [1677475935.748999] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
Esukoto’s Emporium Inc.（カナダ：Jenny Howack(Alibaba) 様）を
本日14：20にDHLにて出荷しました。
Tracking No,5246933204 です。
宜しくお願い致します。

## 2023-02-27

- [1677487807.233219] <@U0331FWGQRM>: <@U033G4KN4TD> <@U041RJKV5JA>
すみません。
玄米茶パウダーのサンプル各1kg欲しいそうです。
出荷日は延期して大丈夫です。
3/2で行けそうですか？

<@U0331FZTHEK>
追加でUSD30請求します。

宜しくお願いします。
- [1677539446.033629] <@U0331FZTHEK>: <@U03SGRNND5L> さん
 CC: <@U041RJKV5JA> 部長
お疲れ様です。
アメリカ：David Michael Weissman 様
本日(2/28) 入金[PayPal]を確認致しました。
USD30.00-
回収(入金)処理致します。
よろしくお願いします。
- [1677539464.234869] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長 <@U033G4KN4TD> さん
お疲れ様です。
Highlanders International Pte Ltd
Jasmine Low 様
2/27 入金[PayPal]を確認致しました。
USD20.00-（2回目）
回収(入金)処理致します。
よろしくお願いします。
- [1677541171.324539] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
玄米茶パウダーの在庫量：
有機玄米茶パウダー：920g
玄米茶パウダー：1kg未満

有機玄米茶パウダーが少ないですが、再粉砕する必要があるんですか？

よろしくお願い致します。
- [1677541397.631209] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

もし上記の量で大丈夫でしたら、本日発送できます。
よろしくお願い致します。
- [1677542301.698069] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
やっぱり各1.5kg追加粉砕して
各1kgずつ出荷でお願いします。
※残り約1kgずつは在庫保管してください。

変更してすみませんが宜しくお願い致します。
- [1677545696.099119] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
3/2出荷可能です。
よろしくお願い致します。
- [1677550585.082969] <@U03SGRNND5L>: <@U041RJKV5JA> 部長
CC： <@U0331FZTHEK> さん
お疲れ様です。
アメリカ：David Michael Weissman 様（Alibaba）
（TSE-DAV-SPL-001-23）を3/1（水）に
サンプルをDHL_PGEにて出荷します。
Tracking No. 5246938373 です。
宜しくお願いします。

## 2023-02-28

- [1677584846.247619] <@U0331FWGQRM>: <@U03SGRNND5L> <@U041RJKV5JA> cc <@U0331FZS7JT>
アメリカのDavidさんからもう少し情報を聞き出したいので、明日の出荷完了後の連絡は私がしますね。

なので、すみませんが、明日２回連絡いただけますか？
・写真を撮ってファイルに保存したら教えてください。
・出荷したら教えてください。

※写真について※
・5種類並べてラベルが見える状態で１枚
・緩衝材に包んで１枚
・箱の外観１枚

“Davidさんが何に使用されようとしているのか”
を確認したいです。
1kg bulkで仕入れようとしているのか
化粧品の原料にしたいのか
canに詰めて売りたいのか
cafeにおろしたいのか　など。

これがわかれば色々と提案する幅や、
（会話が途切れた時の）声をかけるバリエーションが増えるなと思います。
宜しくお願いします。
- [1677585090.165519] <@U0331FWGQRM>: <@U03SGRNND5L>
一点、確認したいのですが、
最初はDavid様とやりとりをしていて、
途中からInna Kiselgof様に変わったという感じですか？
CCでJeannieを入れているという感じですか？
- [1677597172.841889] <@U0331FWGQRM>: <@U041RJKV5JA>
Janet Basora
USのお客様にサンプル発送お願いします。
各50g
鹿児島製茶　B
鹿児島製茶　C
鹿児島製茶　D

※amazonに出店したいらしい。
- [1677619836.801469] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
はい　そうです。
途中からInna Kiselgof様に変わりました。
CCでJeannieを入れています。
- [1677626249.828339] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長
お疲れ様です。
Janet Basora 様
2/28 入金[PayPal]を確認致しました。
USD20.00-
回収(入金)処理致します。
よろしくお願いします。
- [1677627201.874909] <@U0331FWGQRM>: <@U033G4KN4TD> cc <@U041RJKV5JA> <@U0331FZS7JT> 
Dave ogg様について、
一度、私と社長で返信を進めますね！
宜しくお願い致します
- [1677633986.303029] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
アメリカ　Janet Basora様にサンプル発送予定：
DHLで3/2(木)です。
よろしくお願い致します。
- [1677643692.893489] <@U0331FWGQRM>: <@U041RJKV5JA>

タイ maneerat様
入金されました。cc <@U0331FZTHEK>
サンプル出荷宜しくお願いします。

各20g

出雲R
出雲N
出雲W

香岳園6000
香岳園4500
香岳園2500
- [1677644181.323639] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長
お疲れ様です。
タイ：maneerat ongartpanya 様
本日(3/1) 入金[PayPal]を確認致しました。
USD20.00-
回収(入金)処理致します。
よろしくお願いします。
- [1677644991.447609] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
お疲れ様です。
・5種類並べてラベルが見える状態で１枚
・緩衝材に包んで１枚
・箱の外観１枚　
を撮影し、アメリカ：David Michael Weissman(Alibaba)ファイル　
⇒　写真  に保存しました。
本日、予定通り出荷します。
出荷したらご連絡します。
宜しくお願いします。
- [1677647963.328899] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
明日（3/2）、EMSにて出荷いたします。
- [1677648442.481779] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
アメリカ：David Michael Weissman 様（Alibaba）
（TSE-DAV-SPL-001-23）をDHL_PGEにて出荷しました。
Tracking No. 5246938373 　　です。
よろしくお願いします。
- [1677649273.437959] <@U0331FWGQRM>: <!channel>
２点、情報共有

１、
messageの右上のところからラベルをつけられます。
“サンプル発送”　など
自由に作成してつけることができます。
右クリック→Label as

※ソートを掛けることもできます。
メッセージ一覧の右上の四角をクリック

２、
アリゲートというページから顧客管理が可能になりました。
<https://alibabab2b.my.site.com/CustomerPortal/s/>
ユーザー名　<mailto:alibaba.matsui@tousuien.jp|alibaba.matsui@tousuien.jp>
パスワード　tousuien10

まだ使ったことはありませんので、
自由に使って更新していってください。
  - files: [{"id": "F04RSGYMV6E", "created": 1677649211, "timestamp": 1677649211, "name": "スクリーンショット 2023-03-01 14.40.03.png", "title": "スクリーンショット 2023-03-01 14.40.03.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 46548, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04RSGYMV6E/____________________________2023-03-01_14.40.03.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04RSGYMV6E/download/____________________________2023-03-01_14.40.03.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04RSGYMV6E-98bc4c3a7f/____________________________2023-03-01_14.40.03_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04RSGYMV6E-98bc4c3a7f/____________________________2023-03-01_14.40.03_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04RSGYMV6E-98bc4c3a7f/____________________________2023-03-01_14.40.03_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 257, "thumb_360_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04RSGYMV6E-98bc4c3a7f/____________________________2023-03-01_14.40.03_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 328, "original_h": 460, "thumb_tiny": "AwAwACKxpxxa/wDAjVokDvVOzJFplefmNWuTjKj8RTYr62HD60HtzjmmktxgDrz1pxGRSGFFFFAFKzDtZ/IcHefarfIADMc45xVSy3fZBtz941ZAfuTTYk9SQc/xE0Y5zk1HhuOTS/N70hj6KKKAKNoA1l8zY+c1bAUADcDx1qrZbfsXzAn5j0q2CMDAOMcc0BdWsHysQMgnrTjjvTN3A+U9f71SduOaAEooooA//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04RSGYMV6E/____________________________2023-03-01_14.40.03.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04RSGYMV6E-087b76daa8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1677650144.080369] <@U0331FWGQRM>: <@U03SGRNND5L>
些細な質問なのですが、
尾林さんの画像って、なんでPDFなんですか？
（何か理由ありますか？PCの問題？）
画像は、jpegかpngがいいです。
書類はpdfがいいです。

※アリババでquotationを出す場合は、
　画像データでなければ送れないので、pngで送ってますが。
- [1677651123.336909] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
こだわりとかPCの問題ではないです。
できるだけ軽くした方が良いということで
それ以来、PDFにしていました。
画像は、jpegかpng
書類はpdf　で保存します。

アリババでquotationを出す場合は
画像データ（png)で送るのですね
まだ、送ったことがなかったので教えて頂き
ありがとうございました。
（アメリカ：David Michael Weissman様には
　g-mailでquotationを送っていました。）
- [1677651635.950909] <@U0331FWGQRM>: <@U03SGRNND5L>
認識の擦り合わせをしたかったです。
了解です！ありがとうございます！

少しずつ情報共有していけたらと思っております。
お手隙で下の参考文をご確認ください。
一応、URL貼っておきますが、中身は読む必要はありません（笑）

＜参考＞
ー文章抜粋ー
JPEGは主に画像用に使用しますが、PDFはテキストや画像ベースのあらゆる種類の文書を扱うことができます。JPEGは画像データを圧縮するため、ファイルサイズが比較的小さくなります。そのため、webや電子メールでデジタル画像を共有するための便利な手段となります。

<https://www.adobe.com/jp/creativecloud/file-types/image/comparison/jpeg-vs-pdf.html#:~:text=JPEG%E3%81%AF%E4%B8%BB%E3%81%AB%E7%94%BB%E5%83%8F,%E4%BE%BF%E5%88%A9%E3%81%AA%E6%89%8B%E6%AE%B5%E3%81%A8%E3%81%AA%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82|https://www.adobe.com/jp/creativecloud/file-types/image/comparison/jpeg-vs-pdf.html#:~:text=JPEG%E3%81%AF%E4%B8%BB[…]2%8A%E3%81%BE%E3%81%99%E3%80%82>
  - attachments: [{"image_url": "https://www.adobe.com/content/dam/cc/us/en/creativecloud/file-types/image/comparison/jpeg-vs-pdf/OG-1200x800_jpg-vs-pdf.jpg", "image_width": 1200, "image_height": 800, "image_bytes": 59914, "from_url": "https://www.adobe.com/jp/creativecloud/file-types/image/comparison/jpeg-vs-pdf.html#:~:text=JPEG%E3%81%AF%E4%B8%BB%E3%81%AB%E7%94%BB%E5%83%8F,%E4%BE%BF%E5%88%A9%E3%81%AA%E6%89%8B%E6%AE%B5%E3%81%A8%E3%81%AA%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82", "service_icon": "https://www.adobe.com/content/dam/cc/Adobe_favicon.ico", "id": 1, "original_url": "https://www.adobe.com/jp/creativecloud/file-types/image/comparison/jpeg-vs-pdf.html#:~:text=JPEG%E3%81%AF%E4%B8%BB%E3%81%AB%E7%94%BB%E5%83%8F,%E4%BE%BF%E5%88%A9%E3%81%AA%E6%89%8B%E6%AE%B5%E3%81%A8%E3%81%AA%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82", "fallback": "JPEGとPDF：どちらが適しているか| Adobe", "text": "よく使用される2つの画像ファイル形式、JPEGとPDFの違いと共通点について説明します。JPEGとPDFを比較して、プロジェクトに適した形式を判断しましょう。", "title": "JPEGとPDF：どちらが適しているか| Adobe", "title_link": "https://www.adobe.com/jp/creativecloud/file-types/image/comparison/jpeg-vs-pdf.html#:~:text=JPEG%E3%81%AF%E4%B8%BB%E3%81%AB%E7%94%BB%E5%83%8F,%E4%BE%BF%E5%88%A9%E3%81%AA%E6%89%8B%E6%AE%B5%E3%81%A8%E3%81%AA%E3%82%8A%E3%81%BE%E3%81%99%E3%80%82", "service_name": "adobe.com"}]
- [1677652176.015129] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
参考文、ありがとうございます。
URLを貼って下さってますので、中身を見ますね（笑）
画像は、jpegかpng
書類はpdf　で保存します。
宜しくお願いします。

## 2023-03-01

- [1677734372.694089] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
Jasmine Low様の件、
EMSで出荷完了致しました。
追跡番号：EN 241 029 260 JP
出荷画像が共有フォルダに入れておきました。
ご確認お願い致します。
- [1677734417.723019] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
本日、EMSにて発送いたしました。
＜送り状番号＞
EN 243 626 659 JP
- [1677734774.387519] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
アメリカ　Janet Basora様の件、
本日出荷の準備が完了致しました。
DHL AWB No.：5246940565
出荷画像が共有フォルダに入れておきました。
よろしくお願い致します。

## 2023-03-02

- [1677762304.629209] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD> <@U0331FZS7JT>
（進捗共有）
ブレンド抹茶を含む全商品の見積書を提出しました。

Daveがpurechimpと関係あるか分かりませんが、
念の為に、purechimpに提案した時のブレンド抹茶の価格に近い（少し安い）価格で提案しました。
- [1677764735.422639] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD> cc<@U0331FZS7JT>

サンプル依頼がありました。
入金済みです。<@U0331FZTHEK>
発送準備宜しくお願いします。

Address: 62 Hillside Road, Southminster, Essex
Zip Code: CM0 7AL
Phone number: (+44) 07789808089
Company Name: Mayfair
Your Name: David Ogg
EORI No. GB512432979000

ーーー
鹿児島有機抹茶Dだけ　50g

30g　プルトップ缶（缶のサンプル）
50g　プルトップ缶（缶のサンプル）
100g用　AL-12チャック付きスタンド袋

（下記各20g）

玄米茶パウダー（鹿児島有機煎茶1B+丸菱有機玄米）
ほうじ茶パウダー（ひかわ鹿児島産有機ほうじ茶）

鹿児島　有機抹茶A
鹿児島　有機抹茶A1
鹿児島　有機抹茶B
鹿児島　有機抹茶C
鹿児島　有機抹茶D
和香園　有機抹茶44
まるゑい　有機抹茶3000
まるゑい　有機抹茶ME2

鹿児島A＋シナモン
鹿児島A＋ミント
鹿児島A＋レモングラス
鹿児島A＋ジンジャー
鹿児島A＋ターメリック

鹿児島B＋シナモン
鹿児島B＋ミント
鹿児島B＋レモングラス
鹿児島B＋ジンジャー
鹿児島B＋ターメリック

鹿児島D＋シナモン
鹿児島D＋ミント
鹿児島D＋レモングラス
鹿児島D＋ジンジャー
鹿児島D＋ターメリック

和香園有機抹茶44＋シナモン
和香園有機抹茶44＋ミント
和香園有機抹茶44＋レモングラス
和香園有機抹茶44＋ジンジャー
和香園有機抹茶44＋ターメリック

※割合はエクセル参照
※パッケージテストのために、一つだけ50gにしてほしいらしいです。
- [1677798518.810069] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
 <@U041RJKV5JA> 部長 <@U033G4KN4TD> さん
　CC: <@U0331FZS7JT>社長
お疲れ様です。
Dave Ogg 様
3/2 入金[PayPal]を確認致しました。
USD30.00-
回収(入金)処理致します。
よろしくお願いします。
- [1677823776.692819] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
有機ターメリックパウダーの原料について、
キタマに確認して、最小注文ロットは10kgですけど、
100g有償サンプルでいただけるかどうか　キタマさんはメーカーに確認中、返信待ちです。
おそらく来週木曜日（3/9）納品になる可能性が高いと言われてます。

有機ターメリックパウダー以外の原料は揃えていますので、
3/6製造する予定です。

合わせて、3/10(金)発送可能です。
確実の発送日はキタマからの返信次第です。

よろしくお願い致します。
- [1677826839.590329] <@U0331FWGQRM>: <@U033G4KN4TD>
すみません、追加です。
宜しくお願いします。

各20g

鹿児島D＋シナモン
鹿児島D＋ミント
鹿児島D＋レモングラス
鹿児島D＋ジンジャー
鹿児島D＋ターメリック

## 2023-03-03

- [1677831617.823199] <@U0331FWGQRM>: <@U033G4KN4TD>
再度追加です。

各20g

鹿児島A
鹿児島A1
鹿児島B
鹿児島C

## 2023-03-04

- [1677935695.534189] <@U0331FWGQRM>: <@U033G4KN4TD>
また追加です。

30g　プルトップ缶
50g　プルトップ缶

（下記各20g）

玄米茶パウダー（鹿児島有機煎茶1B+丸菱有機玄米）
ほうじ茶パウダー（ひかわ鹿児島産有機ほうじ茶）

鹿児島A＋シナモン
鹿児島A＋ミント
鹿児島A＋レモングラス
鹿児島A＋ジンジャー
鹿児島A＋ターメリック

鹿児島B＋シナモン
鹿児島B＋ミント
鹿児島B＋レモングラス
鹿児島B＋ジンジャー
鹿児島B＋ターメリック
- [1677935850.903169] <@U0331FWGQRM>: <@U033G4KN4TD>
種類多すぎるので来週末発送とかでもOKです。

## 2023-03-05

- [1678071031.785209] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
```30g　プルトップ缶
50g　プルトップ缶```
*→空き缶の発送と理解であってますでしょうか？*

```ほうじ茶パウダー（ひかわ鹿児島産有機ほうじ茶）```
*→Genuine Tea用ほうじ茶パウダーと同じ原料の理解であってますでしょうか？*

よろしくお願い致します。

## 2023-03-06

- [1678093872.765029] <@U0331FWGQRM>: 情報共有
  - files: [{"id": "F04SVRHNCGZ", "created": 1678093866, "timestamp": 1678093866, "name": "IMG_9878.PNG", "title": "IMG_9878.PNG", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 315191, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04SVRHNCGZ/img_9878.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04SVRHNCGZ/download/img_9878.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04SVRHNCGZ-c2c38aeb8c/img_9878_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04SVRHNCGZ-c2c38aeb8c/img_9878_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04SVRHNCGZ-c2c38aeb8c/img_9878_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04SVRHNCGZ-c2c38aeb8c/img_9878_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 222, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04SVRHNCGZ-c2c38aeb8c/img_9878_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04SVRHNCGZ-c2c38aeb8c/img_9878_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 333, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04SVRHNCGZ-c2c38aeb8c/img_9878_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1731, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04SVRHNCGZ-c2c38aeb8c/img_9878_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 444, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04SVRHNCGZ-c2c38aeb8c/img_9878_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 473, "thumb_1024_h": 1024, "image_exif_rotation": 1, "original_w": 828, "original_h": 1792, "thumb_tiny": "AwAwABafY/YUbH9KejqBgg04SIOhP5VTdidCHHNFPBAz8oPPHNGR/cFF0AzvRn/OalVVZc4/WgiNeoqZK4NDAciikJ546UmTQosViRVUrnH608Qg9jR5IH8RxSCJf7/602yiNuGIHrSVOIQPf60vlChMVj//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04SVRHNCGZ/img_9878.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04SVRHNCGZ-7a9b8dbdc2", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1678151292.337499] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
ストロー用ブラシのサンプルが届きました。
デスクに置いておきます。
見積書を共有フォルダのお客様別ーB - BALISM　に入れておきます。

ストローブラシ
＜ロット＞
・50本　＠85
・100本　＠80
・500本　＠65
＊税別

また、ストロー1本＋ブラシ1本のセットもあるとのことで、こちらも見積もりをいただいております。
ストローへの刻印も可能です。
製造国は、ストロー、ブラシともにインドネシアになります。
よろしくお願いいたします。
- [1678152066.950529] <@U0331FWGQRM>: <@U041RJKV5JA>
ありがとうございます。
エクセル一覧に追記願います。

ひろせプロダクトのストローの製造国はどこですか？
宜しくお願いします。
- [1678152402.965579] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
承知しました。
ひろせプロダクトのストローは、
中国製となります。
よろしくお願いいたします。

## 2023-03-09

- [1678351013.958649] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
明日（3/10）発送する予定ですが、
追加がございますか？
なければ、予定通り発送いたします。

上記の缶についての確認もお願い致します。

よろしくお願い致します。
- [1678357000.003299] <@U0331FWGQRM>: <@U033G4KN4TD>
返信遅くなりすみません。
缶のサンプルについて、空き缶でOKです。
AL-12のチャック付きスタンド袋も送る様にします！

明日発送OKです。
宜しくお願いします。
- [1678365109.113209] <@U0331FWGQRM>: <@U041RJKV5JA> すみません。
僕がド忘れしてるのですが、
neelsさんに100g袋のフィルムはまだ送ってなかったでしたっけ？？
冊子と一緒に送ってくださいって言ってましたっけ？
明日の返信でOKです。また明日教えてください。
- [1678365591.513469] <@U041RJKV5JA>: <@U0331FWGQRM>
忘れるといけないので、返信します。
フィルムとアルミスタンド袋8枚を2月27日に送っております。
- [1678405448.319309] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
イギリス向けですので、EORI番号が必要かと思っておりますが、
ご確認お願い致します。
- [1678408101.109769] <@U0331FWGQRM>: <@U033G4KN4TD> 
了解です。確認します。

※ <@U041RJKV5JA> 
サンプルの時にもEORI番号が必要かどうか、念のために確認してもらえますか？
- [1678412866.766629] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
送り状登録時、お客様の電話番号が必要ですので、
ご確認お願いしてよろしいですか？
- [1678412980.503239] <@U0331FWGQRM>: <@U033G4KN4TD>

Address: 62 Hillside Road, Southminster, Essex
Zip Code: CM0 7AL
Phone number: (+44) 07789808089
Company Name: Mayfair
Your Name: David Ogg

## 2023-03-10

- [1678511703.331259] <@U0331FWGQRM>: <@U033G4KN4TD> <@U041RJKV5JA>
あと3営業日くらいでEORI番号を取得されるそうです。

## 2023-03-11

- [1678560517.395379] <@U0331FZS7JT>: <@U033G4KN4TD> <@U041RJKV5JA> 
お疲れ様です。
サウジアラビアのDANAHさんの件、
送料確認したいようなので、返信をお願いします。
※50gバッグ×50と30g缶×50のそれぞれの送料
よろしくお願いします。
  - files: [{"id": "F04TW2818V7", "created": 1678560510, "timestamp": 1678560510, "name": "IMG_4182.jpg", "title": "IMG_4182", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 97087, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04TW2818V7/img_4182.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04TW2818V7/download/img_4182.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04TW2818V7-7238d25b54/img_4182_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04TW2818V7-7238d25b54/img_4182_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04TW2818V7-7238d25b54/img_4182_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 274, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04TW2818V7-7238d25b54/img_4182_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 365, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04TW2818V7-7238d25b54/img_4182_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04TW2818V7-7238d25b54/img_4182_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 548, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04TW2818V7-7238d25b54/img_4182_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1051, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04TW2818V7-7238d25b54/img_4182_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 731, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04TW2818V7-7238d25b54/img_4182_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 779, "thumb_1024_h": 1024, "original_w": 1242, "original_h": 1632, "thumb_tiny": "AwAwACTR7Uf8CFFGR7UAH/AhQPqDRke1Lke1ACUUUUAFFFFABSbuaWmd/wCL86YD6KB0paQCUm6lpmT9fxpgO3CjIpMn0/WjJ9P1oAcOlFA6UtID/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04TW2818V7/img_4182.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F04TW2818V7-550ca6dc54", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-03-13

- [1678714339.240089] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
EORI No. GB512432979000

発送日は3/20（月）で宜しくお願いします！

## 2023-03-15

- [1678934953.117129] <@U0331FWGQRM>: <@U041RJKV5JA>  
下記3件見積書を作成してもらえますか?
  - files: [{"id": "F04TSC7558F", "created": 1678934948, "timestamp": 1678934948, "name": "IMG_9942.png", "title": "IMG_9942", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 204532, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04TSC7558F/img_9942.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04TSC7558F/download/img_9942.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04TSC7558F-5f8c711224/img_9942_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04TSC7558F-5f8c711224/img_9942_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04TSC7558F-5f8c711224/img_9942_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04TSC7558F-5f8c711224/img_9942_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 222, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04TSC7558F-5f8c711224/img_9942_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04TSC7558F-5f8c711224/img_9942_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 333, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04TSC7558F-5f8c711224/img_9942_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1731, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04TSC7558F-5f8c711224/img_9942_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 444, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04TSC7558F-5f8c711224/img_9942_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 473, "thumb_1024_h": 1024, "image_exif_rotation": 1, "original_w": 828, "original_h": 1792, "thumb_tiny": "AwAwABbRHtS5pKD7GgAIBPIz9aNqf3R+VAz60UAB5BqPB/vLUlMAH+1TAcue5BpaQfj+NLQAU0Lgkmn9s9vWkDL6j86QCYoxSnA6nA+tJuX++Pzpgf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04TSC7558F/img_9942.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04TSC7558F-9b497dbc74", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F04UKGVN2AV", "created": 1678934948, "timestamp": 1678934948, "name": "IMG_9943.png", "title": "IMG_9943", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 207426, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04UKGVN2AV/img_9943.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04UKGVN2AV/download/img_9943.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04UKGVN2AV-f7b1e916b9/img_9943_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04UKGVN2AV-f7b1e916b9/img_9943_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04UKGVN2AV-f7b1e916b9/img_9943_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04UKGVN2AV-f7b1e916b9/img_9943_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 222, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04UKGVN2AV-f7b1e916b9/img_9943_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04UKGVN2AV-f7b1e916b9/img_9943_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 333, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04UKGVN2AV-f7b1e916b9/img_9943_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1731, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04UKGVN2AV-f7b1e916b9/img_9943_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 444, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04UKGVN2AV-f7b1e916b9/img_9943_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 473, "thumb_1024_h": 1024, "image_exif_rotation": 1, "original_w": 828, "original_h": 1792, "thumb_tiny": "AwAwABbR6dMUbuehopaAG/KTyM/Wl2p/dH5UUUAB6Gmhj3/SnHpTB/wKmA4HNLSD8fxpaACmhcEk0/tnt60gZfUfnSAKKDgdTgfWk3L/AHx+dMD/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04UKGVN2AV/img_9943.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04UKGVN2AV-b9a59a91e3", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1678935055.204559] <@U0331FWGQRM>: <@U041RJKV5JA> 
これもです！
  - files: [{"id": "F04U6U9NLTU", "created": 1678935048, "timestamp": 1678935048, "name": "IMG_9944.png", "title": "IMG_9944", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 214909, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04U6U9NLTU/img_9944.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04U6U9NLTU/download/img_9944.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04U6U9NLTU-6d70ada688/img_9944_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04U6U9NLTU-6d70ada688/img_9944_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04U6U9NLTU-6d70ada688/img_9944_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04U6U9NLTU-6d70ada688/img_9944_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 222, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04U6U9NLTU-6d70ada688/img_9944_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04U6U9NLTU-6d70ada688/img_9944_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 333, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04U6U9NLTU-6d70ada688/img_9944_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1731, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04U6U9NLTU-6d70ada688/img_9944_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 444, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04U6U9NLTU-6d70ada688/img_9944_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 473, "thumb_1024_h": 1024, "image_exif_rotation": 1, "original_w": 828, "original_h": 1792, "thumb_tiny": "AwAwABbRHHT+VLmkoJx1oACATyM/Wjan90flRkGigAoIB6ignAzTd/tQA4ADoKKQHPaloACMjimBW/vVJ2z29aQMvqPzoAQAjqc0tBwOpwPrSbl/vj86YH//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04U6U9NLTU/img_9944.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04U6U9NLTU-7af23440c6", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1678935380.381639] <@U0331FWGQRM>: <@U041RJKV5JA> 
夕方から作業できそうなので、
それまでにできそうならしてください。
無理そうならこっちでしますので、
内容だけ把握しておくだけでokです！
- [1678935511.632779] <@U041RJKV5JA>: <@U0331FWGQRM>
夕方までに何件見積もりが作成できたのか連絡します。
- [1678936586.492229] <@U0331FWGQRM>: <@U041RJKV5JA> 
petja

まるゑい　1C   売価USD30で。
まるゑい　ME2 
鹿児島　有機D
鹿児島　有機C
鹿児島　有機B

usd30-100で探されてる。
中でも安い抹茶と抗酸化作用を気にされてる。Trade assurance も気にされてる。



roaa
鹿児島　有機B
鹿児島　有機C
鹿児島　有機D
ドリンクグレードで苦味が少ないものを希望。

mohammad
鹿児島　A
鹿児島　1A
鹿児島　B

有機セレモニアル希望されてる。

## 2023-03-16

- [1679008356.011589] <@U0331FWGQRM>: <@U041RJKV5JA> 
アメリカのPetja様に商品サンプル準備お願いします。まるゑい1C 1kgは確定ですが、ほかのグレード各20gは確認中です。
出荷は来週火曜日くらいで宜しくお願いします。無理な場合は教えてください。

<@U0331FZTHEK> w&amp;w（会社名）からの入金ありましたので宜しくお願い致します。
- [1679008516.205629] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長
お疲れ様です。
w&amp;w（ Petja Warzel （アメリカ）様）
本日(3/17) 入金[PayPal]を確認致しました。
USD30.00-
回収(入金)処理致します。
よろしくお願いします。
- [1679022664.572579] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役<@U041RJKV5JA> 部長

お疲れ様です。
サンプルのInvoiceとPackinglistですが、
種類が多すぎて、発送用のInvoiceとお客様に提供するInvoiceが別々でよろしいでしょうか？

発送用のInvoiceとPackinglistを添付いたします。
ご確認お願いいたします。
  - files: [{"id": "F04UDU26RK5", "created": 1679022652, "timestamp": 1679022652, "name": "INVOICE_TOUSUIEN_20230310.xlsx", "title": "INVOICE_TOUSUIEN_20230310.xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 58977, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04UDU26RK5/invoice_tousuien_20230310.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04UDU26RK5/download/invoice_tousuien_20230310.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F04UDU26RK5-5e33ae333d/invoice_tousuien_20230310_converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F04UDU26RK5-5e33ae333d/invoice_tousuien_20230310_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04UDU26RK5/invoice_tousuien_20230310.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F04UDU26RK5-a6c47c2598", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1679023379.931539] <@U0331FWGQRM>: <@U033G4KN4TD> okです！
中身がわかるようにラベルが貼っていればOKです。
今からでも可能であれば、分かりやすいように袋に入れて分けてあると親切かと思います。

Stand-up bagは英語として合ってるかは分かりませんが、ziplock bagとかで良いかとおもいます。

間も無く返信見れなくなのであとは <@U041RJKV5JA> <@U0331FZS7JT>に確認してください。
宜しくお願い致します。

## 2023-03-17

- [1679038028.725909] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役 <@U03SGRNND5L> さん
まるゑい1C 1kgの準備は完了しました。
他のサンプルが必要ない場合は、月曜日出荷が可能です。
必要な場合は、連絡をいただいいた時点で最短の出荷可能日をご連絡いたします。
- [1679095341.453469] <@U0331FWGQRM>: <@U041RJKV5JA> 他も必要ですので宜しくお願いします。

## 2023-03-19

- [1679276240.720489] <@U0331FWGQRM>: <@U03SGRNND5L>
他も進めてください。宜しくお願いします！
- [1679276498.709679] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
承知しました。
運送会社の指定がありますか？
- [1679276988.216419] <@U0331FWGQRM>: <@U03SGRNND5L> <@U041RJKV5JA>
ないです。アメリカ向けサンプルで過去の実績から選ぶか、
コストか、何かしらで選択してください。
平川部長に相談してください。
- [1679277131.115689] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
承知しました。平川部長と相談し、
進めて行きます。
宜しくお願いします。
- [1679289324.766049] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
Dave Ogg様へのサンプル出荷が完了致しました。
DHL　AWB No.：5246979533
よろしくお願い致します。
- [1679295360.702249] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
本件、出荷の準備が出来ました。
ですがPNCがまだ届きません。
届き次第、出荷します。
宜しくお願いします。

## 2023-03-20

- [1679317114.341369] <@U0331FZS7JT>: <@U033G4KN4TD> さん
<@U041RJKV5JA> 部長

サウジアラビアのDANAH alさんの件、
サンプル依頼がありました。
以前送った画像12点の発送でOKです。
銀行情報は伝えており、銀行からの送金予定とのことです。
着金後にサンプル準備と発送で問題ありません。

サンプル用のインボイスは作成します。
※現在、詳細な送り先等確認中

よろしくお願いします。
- [1679373980.945189] <@U0331FWGQRM>: このスレッドに転記します。

*<@U041RJKV5JA>*   [20:10]
<@U0331FWGQRM> 執行役
CC : channel
SGSより残留農薬検査結果、重金属検査結果が届きました。
1通に両方の検査結果が記載されております。
可能であれば、検査結果を各検査毎に分けた書類をいただけるよう依頼しております。
また、和文の重金属検査の試験項目の記載に誤りがありますので、訂正依頼をしております。
（スズがチタンになっております。）
検査はスズの検出を間違いなく行っております。

重金属の検査項目で、カドミウムと鉛が微量検出されました。
アメリカでは重金属についての明確な指標はないそうですが、限りなく０が望ましいとのことです。

検査結果は下記フォルダに入れておきます。
訂正後の検査結果を入手しましたら、入れ替えておきます。

・お客様別-S-SGS
・検査結果（残留農薬・重金属・放射線・栄養成分）-農薬関係（残留農薬）-分析結果ー2023

ご確認お願いいたします。

ーーーーーーーーーーー

*松井*  [00:06]
<@U041RJKV5JA>
有難うございます。
微量なので問題ないと思います。
過去のデータを見てもどれも出ていることが多いので、
出ることは出るっぽいですね。

正しい書類を入手したら差し替えの上教えてください。

## 2023-03-21

- [1679443435.718549] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
本件、PNCを取得しましたので
DHLにて出荷します。
Tracking No. 5246984094　です。
宜しくお願いします。
- [1679455330.607609] <@U0331FWGQRM>: <@U041RJKV5JA> <!channel>
Neelsの冊子のサンプルですが、
・吉村の方を、
・三つ折りにおった状態で
・箔押し、箔なし　各５部ずつ

他のサンプルと一緒に
サンプルとして発送願います。

出荷日分かれば教えてください。
宜しくお願いします。
- [1679459429.437699] <@U0331FWGQRM>: *<@U041RJKV5JA>*   [13:17]
<@U0331FWGQRM> 執行役
明日（3/23）DHLにて発送いたします。

※スレッドにコピペしました。松井
- [1679459563.833989] <@U0331FWGQRM>: <@U041RJKV5JA>
冊子の写真を送りたいので、
三つ折りにしたものを写真で貰えますか？
閉じた状態、開いた状態、三つ折りの表と裏など

いらないやつは消しとくんで、
いっぱい撮って、フォルダに入れておいてください。
宜しくお願いします。
- [1679462216.918339] <@U03SGRNND5L>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
DHLにて14：10に出荷しました。
宜しくお願いします。

## 2023-03-22

- [1679468911.791409] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
冊子の写真を撮りました。
Neels→発送写真→5回目20230323をご確認お願い致します。
- [1679472798.867449] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
写真を追加しました。
必要であれば、ご利用ください。
よろしくお願い致します。
- [1679488869.332329] <@U0331FWGQRM>: <@U041RJKV5JA> <!channel>
Neels 様　サンプル発送について

・Greeting card（箔押し・通常印刷）　吉村・サヌキ
・Bamboo straws with Logo
・Plastic bag with “Thank you” Sticker（33mm, 40mm両方）
・100g bag 用のFilm　残り

を送ってください。
出荷予定日も教えてください。
宜しくお願いします。
- [1679490742.924269] <@U0331FWGQRM>: <@U041RJKV5JA> 明日3/23出荷ですね。書類を確認しました。宜しくお願いします。

※OPP袋 クリスタルパック T15-25 , T4-25 の両方も数枚入れておいてください。すでに入れていたら追加の必要はないです。
- [1679499683.978009] <@U0331FWGQRM>: <@U041RJKV5JA> cc <@U0331FZS7JT>
度々すみませんが、
冊子はやっぱり、*吉村とサヌキ印刷*
*両方を同じ部数ずつ入れてください。*

※例えば、
サヌキの箔押しが少なかったと思うので、
仮に３冊しかなければ、全部各３冊ずつでOKです。と言う意味です。
- [1679548649.971669] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
先ほど、DHLで発送完了です。
よろしくお願いいたします。

## 2023-03-26

- [1679883202.320309] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
CC : channel
お疲れ様です。
残留農薬検査結果、重金属検査結果について、各検査毎に書類を分けていただきました。
また、和文の重金属検査の試験項目の誤りも訂正してあります。
下記フォルダに入れておきますので、ご確認お願いいたします。

・お客様別-S-SGS
・検査結果（残留農薬・重金属・放射線・栄養成分）- 農薬関係（残留農薬）-分析結果 - 2023 - 有機抹茶・有機煎茶
・検査結果（残留農薬・重金属・放射線・栄養成分）- 重金属検査 - 有機抹茶・有機煎茶

## 2023-04-07

- [1680889069.320629] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
ポーランドTim Schopinski（Alibaba）

サンプル発送
USD30入金済み <@U0331FZTHEK>
EORI番号確認中
確認取れ次第出荷準備願います。

## 2023-04-09

- [1681053945.182969] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
サウジアラビアのお客様へサンプル発送です。
各20g

Organic Matcha Upper grade-1　鹿児島製茶 有機抹茶A
Organic Matcha Upper grade-2　鹿児島製茶 有機抹茶1A

address: KSA Riyadh prince bandar street.
post code: 13223
name : Haya Rashad Alkahtani
Mobile : <tel:+966531616625|+966531616625>

宜しくお願いします。

発送手段は何でもいいです。
- [1681081943.894139] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長 <@U033G4KN4TD> さん
お疲れ様です。
本件、入金を確認致しました。
・4/8 [PayPal]
・USD30.00-
回収(入金)処理致します。
よろしくお願いします。

## 2023-04-10

- [1681115647.543599] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
本件、4/12(水)出荷可能です。
よろしく御願い致します。

## 2023-04-11

- [1681203548.872509] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長 <@U033G4KN4TD> さん
お疲れ様です。
本件、入金を確認致しました。
・4/11 [PayPal]
・USD30.00-
回収(入金)処理致します。
よろしくお願いします。
- [1681268511.799449] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
本日、EMSにて発送しました。
お問い合わせ番号　EN 250 028 130 JP
よろしくお願いします。

## 2023-04-12

- [1681347745.232959] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
イギリスのDaveさんにサンプル発送です。
缶と抹茶とブレンド抹茶のサンプル発送です。

Organic Matcha HQK-3は鹿児島有機抹茶Bです。
詳細はエクセルをご確認ください。
（Daveさんのフォルダ内、下記quotationの赤文字箇所です。）
QUOTATION_TOUSUIEN_20230412

*ーーーーー*
*奥村製缶の40g缶（色は白・黒・銀）*

*Organic Matcha TQ-1（碧翠園16000）*
*Organic Matcha TQ-2（碧翠園12000）*
*Organic Matcha TQ-3（碧翠園10500）*

*Organic Matcha HQK-3 + Cinamon (20%)*
*Organic Matcha HQK-3 + Cinamon (25%)*

*Organic Matcha HQK-3 + Lemongrass (25%)*
*Organic Matcha HQK-3 + Lemongrass (30%)*

*Organic Matcha HQK-3 + Ginger (15%)*
*Organic Matcha HQK-3 + Ginger (25%)*
*ーーーーー*

宜しくお願いします。
- [1681348630.065139] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長 <@U033G4KN4TD> さん
お疲れ様です。
本件、入金を確認致しました。
・4/12 [PayPal]
・USD30.00-
回収(入金)処理致します。
よろしくお願いします。

## 2023-04-13

- [1681375201.305639] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
出荷可能日は明日に返信いたします。
よろしく御願い致します。
- [1681389935.184679] <@U0331FWGQRM>: *<@U041RJKV5JA>* *<@U033G4KN4TD>* 
*奥村製缶の40g缶（色は確認中）*
→色は、白・黒・シルバー３色お願いします。
もし不足している場合は、奥村製缶に発注してください。

## 2023-04-14

- [1681456313.668599] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
本件、4/20出荷可能です。
よろしく御願い致します。
- [1681472258.866579] <@U0331FWGQRM>: <@U033G4KN4TD> <@U041RJKV5JA> 
念のための確認ですが、
30g缶と40g缶は
大きさが違うので注意してください。
宜しくお願い致します。

## 2023-04-16

- [1681648834.569909] <@U0331FWGQRM>: <@U041RJKV5JA> <!channel>

*Neels様*の件について連絡です。
袋の入荷予定日は4/29ですが、2日くらい早まる可能性がありますので、
その可能性を加味して、加工スケジュールを予定して下さい。

ロットナンバーと賞味期限を印字する必要があります。
もし現時点で、賞味期限と、ロットナンバー（小分け加工日＋通し番号？）
が分かるようであれば、教えて下さい。
※賞味期限は製造日から1年（窒素充填加工して下さい）

竹ストローのThank youのシール位置はセンターになるように指示されていますよね？
どのように指示されたか共有いただけますか？（サンプルを渡したんでしょうか？）

以上、ご確認とスレッドでの返信宜しくお願いします。
- [1681686547.765249] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
竹ストローのシール位置はセンターになるように依頼しております。
ストローを入れる方向についても説明済みです。
サンプルも渡してあります。

## 2023-04-17

- [1681776998.998529] <@U0331FZS7JT>: <@U041RJKV5JA> 部長<@U033G4KN4TD> さん
<!channel>

alibaba（サウジアラビア）のDANAH alさんから
サンプル代30USDの銀行送金の連絡がありました。

パッキングリストの完成とサンプルの発送をお願いします。
<@U033G4KN4TD> さん
サンプルはQuotationの欄外に50gの原価がありますが
以前のメッセージを確認しましたが無かったので
20gで良いですよね？

以上、よろしくお願いします。
- [1681778186.642079] <@U033G4KN4TD>: <@U0331FZS7JT> 社長
CC：<@U041RJKV5JA> 部長

お疲れ様です。

Quotationの欄外に50gの原価は50g商品の場合の原価です。
サンプルは20gで大丈夫と思いますが、再確認いたします。

よろしくお願いいたします。
- [1681799996.765969] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
本件、お客様が一向にEORI番号を教えてくれない（取得する気がない）のですが、
今回は、サンプル代を貰っているので、EORI番号なしでもう送ってしまいましょうか。
過去にFedexでEORI番号なしで日本から仕入れたことがあるそうですので、
Fedexxで送りましょう。

但し、条件として下記の内容を事前にお客様に伝えるようにします。

・現地で手続きが発生する可能性があります。
・万が一、トラブルが起きた場合は現地で対応願います。
・追加の通関費用を請求された場合は支払い願います。
・サンプルではなく、正式なビジネスを進める場合はEORI番号取得後でお願いします。

これで進めたいと思います。
宜しく願いします。
- [1681800250.478109] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
サンプルの準備が完了しましたので、
FedExに送り状作成と集荷依頼して、明日4/19発送いたします。
よろしく御願い致します。

## 2023-04-18

- [1681826962.629409] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
<!channel>
alibaba（フランス）のKhalil AhlAngadさんから
サンプル（各20g）依頼がありました。
Paypal入金済みです。<@U0331FZTHEK>

注文内容は下記の通りです。
*100g bag, 200 g bag, 袋にオリジナル印刷*
*30g cans　ステッカー*

缶と袋のサンプルもつけてあげてください。
30g pull top canサンプル
100g bag　AL-12
200g bag ???←*ちょうどいい袋を探してください*

ーーー
お客様情報
Name : BELHOUACHI Khalil
Adress : 7 avenue Eugène Thomas
Postal code : 94270
City : Le Kremlin-Bicêtre
Country : France
E-mail: <mailto:k.ahlangad@gmail.com|k.ahlangad@gmail.com>
Phone : +33 (0)7 81 42 26 79
EORI : FR82066986900019
ーーー

宜しくお願いします。
- [1681860171.142989] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
おはようございます。
本件のお客様、PayPalでの入金が見当たらないのですが・・・、
すみません、ご確認いただけますか。
  - files: [{"id": "F053EVD8P9D", "created": 1681859321, "timestamp": 1681859321, "name": "スクリーンショット 2023-04-19 065534.png", "title": "スクリーンショット 2023-04-19 065534.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FZTHEK", "user_team": "T033D70RR6H", "editable": false, "size": 49247, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F053EVD8P9D/____________________________2023-04-19_065534.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F053EVD8P9D/download/____________________________2023-04-19_065534.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F053EVD8P9D-17729e4484/____________________________2023-04-19_065534_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F053EVD8P9D-17729e4484/____________________________2023-04-19_065534_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F053EVD8P9D-17729e4484/____________________________2023-04-19_065534_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 195, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F053EVD8P9D-17729e4484/____________________________2023-04-19_065534_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 261, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F053EVD8P9D-17729e4484/____________________________2023-04-19_065534_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F053EVD8P9D-17729e4484/____________________________2023-04-19_065534_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 391, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F053EVD8P9D-17729e4484/____________________________2023-04-19_065534_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 434, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F053EVD8P9D-17729e4484/____________________________2023-04-19_065534_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 521, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F053EVD8P9D-17729e4484/____________________________2023-04-19_065534_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 556, "original_w": 1555, "original_h": 844, "thumb_tiny": "AwAaADC4bWHHKfqaPskH/PP9TU1KKd2KyK/2SHP+rGPqaX7HB/zzH5mpTndnPHpRk+lF2FkRfZIP+ef6mkNrbgElOOvU1P2pHXehXpkYouwsLS01ulKPuikMKQUHrSJ0oAd2ooPSjtQB/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F053EVD8P9D/____________________________2023-04-19_065534.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F053EVD8P9D-b3b358ebb2", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1681869971.023019] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
FedExに送り状作成してみましたが、送料が19000円以上で、
ちょっと高いかと思いますので、
EMSで発送してもよろしいでしょうか？
EMS送料：3150円です。
よろしく御願い致します。
- [1681870646.721409] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
*奥村製缶の40g缶について、*
サンプルが届きましたけど、
奥村製缶から「40g白の在庫がないため、30gご対応させて頂いております」とメモが入りましたので、白30g、黒40g、シルバー40gをお客様に対応させていただきます。
よろしく御願い致します。
- [1681881388.438919] <@U033G4KN4TD>: <@U0331FZS7JT> 社長
CC：<@U041RJKV5JA> 部長

お疲れ様です。
本件、明日4/20(木曜日)発送する予定です。
よろしく御願い致します。
- [1681881582.842059] <@U0331FZS7JT>: <@U033G4KN4TD> さん
CC：<@U041RJKV5JA> 部長

明日発送、了解です。
発送後、発送資料とトラッキングナンバーの共有をお願いします。

## 2023-04-19

- [1681888493.321229] <@U0331FZTHEK>: <@U0331FZS7JT> 社長
　CC:  <@U033G4KN4TD> さん <@U041RJKV5JA> 部長
お疲れ様です。
本件、銀行より被仕向送金連絡ありました。
・4/19 外貨普通預金
・USD30.00- → 3,932円に換金されて送金
（念書手続きにて当座預金へ・・・手続き実施済み）
計算書届き次第、回収(入金)処理致します。
よろしくお願いします。
- [1681894765.903109] <@U0331FWGQRM>: <@U033G4KN4TD> <@U041RJKV5JA>
EMSでOKとのことです！
宜しくお願いします。
- [1681894835.274379] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

承知致しました。
それでは、明日4/20(木)にEMSで発送いたします。
よろしく御願い致します。
- [1681896273.084549] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。

本件、袋が4/29入荷する場合、「5/1〜5/2」に小分け加工する予定です。
加工No.：20230501-1
賞味期限：2024.4.30

出荷可能日：5/8（月）あるいは5/9（火）

よろしく御願い致します。
- [1681900831.946649] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
出荷日につきまして了解です。
ありがとうございます。

賞味期限の表記につきましては
下記の通り（*Month/Day/Year*）で
宜しくお願いします。

*LOT 20230501-1*
*EXP 04/30/2024*

印字はハンドヘルドプリンターで宜しくお願い致します。

<@U041RJKV5JA>
印字場所については、良い場所を探してください。もし何箇所か良い場所があればその写真を撮って送ってください。
Neelsさんに写真を送って確認したいと思います。

宜しくお願いします。
- [1681913777.500659] <@U0331FWGQRM>: <@U041RJKV5JA> <@U0331FZTHEK>
入金確認が取れました。
出荷準備を進めてください。
宜しくお願いします。
- [1681945474.014999] <@U041RJKV5JA>: <@U0331FWGQRM>
不足原料が4/21（金）到着
4/24（月）出荷いたします。
- [1681949659.050759] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長
おはようございます。
本件、入金を確認致しました。
・4/19 [PayPal]
・30 USD
回収(入金)処理致します。
よろしくお願いします。
- [1681956413.982009] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
すみませんが、私のミスで一種類原料発注漏れがあります。
*Organic Matcha TQ-3（碧翠園10500）*

出荷日を延期させていただきたいのですが、
よろしいでしょうか？
先ほど、原料発注しましたが、納期待ちです。
分かり次第、出荷可能日を改めてご連絡致します。

ご迷惑をおかけして、申し訳ございませんが、
よろしく御願い致します。
- [1681968311.365999] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
先ほど、碧翠園さんから納期の連絡が入りました。
4/22(土)着です。
サンプル全商品4/24（月）DHLで発送可能です。
よろしく御願い致します。
- [1681971767.993369] <@U033G4KN4TD>: <@U0331FZS7JT> 社長
CC：<@U041RJKV5JA> 部長

お疲れ様です。
EMSで発送完了です。
追跡番号：EN 252 348 794 JP
よろしく御願い致します。
- [1681971880.740819] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
EMSで発送完了です。
追跡番号：EN 253 429 335 JP
よろしく御願い致します。

## 2023-04-21

- [1682065370.782329] <@U0331FWGQRM>: <@U041RJKV5JA>
invoice作成したので確認願います。
修正が必要な箇所があれば適宜修正してください。
- [1682070648.631179] <@U0331FWGQRM>: <@U041RJKV5JA> <!channel>
サウジアラビア　raghad suliman（Alibaba）
のお客様でサンプルの準備をお願いします。
・各20g
・EMSでの発送
paypal請求中ですので
入金確認後の出荷で宜しくお願い致します。
- [1682141576.813839] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
4/24（月）DHLにて発送します。
AWB NO, 9731042506
よろしくお願いします。

## 2023-04-23

- [1682314908.426989] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
本件、4/24（月）出荷完了です。
*AWB No.：9731043825*
よろしく御願い致します。

## 2023-04-24

- [1682388678.994609] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長<@U0331FZTHEK> さん

お疲れ様です。
本件、準備完了です。
入金待ちです。
よろしく御願い致します。
  - files: [{"id": "F05543LHNFK", "created": 1682388670, "timestamp": 1682388670, "name": "IMG20230425110150.jpg", "title": "IMG20230425110150.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 793834, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05543LHNFK/img20230425110150.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05543LHNFK/download/img20230425110150.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F05543LHNFK-5bcaacbc33/img20230425110150_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F05543LHNFK-5bcaacbc33/img20230425110150_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F05543LHNFK-5bcaacbc33/img20230425110150_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F05543LHNFK-5bcaacbc33/img20230425110150_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F05543LHNFK-5bcaacbc33/img20230425110150_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F05543LHNFK-5bcaacbc33/img20230425110150_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F05543LHNFK-5bcaacbc33/img20230425110150_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 800, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F05543LHNFK-5bcaacbc33/img20230425110150_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F05543LHNFK-5bcaacbc33/img20230425110150_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 1024, "original_w": 3456, "original_h": 3456, "thumb_tiny": "AwAwADCaQ4xTVJJ4z+VStjvQuKAGMTkUAnPII+tPJAoBH40ANLYNKrZNLxQAM570AMYZNOGMUpU4zQFOf/r0gG4NGOeDTtp9aMH1pgMwaVQd+e1LjgZpRQApNIPxpFkUY+YdfWntKh/iH50gGg8fjSdqEkCjqOvrT2kXjkfnQAzPyjntQDQrDCjI6UrsobqOlAH/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05543LHNFK/img20230425110150.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F05543LHNFK-37149fb27b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F054TUPN46Q", "created": 1682388672, "timestamp": 1682388672, "name": "IMG20230425110555.jpg", "title": "IMG20230425110555.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U033G4KN4TD", "user_team": "T033D70RR6H", "editable": false, "size": 618797, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F054TUPN46Q/img20230425110555.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F054TUPN46Q/download/img20230425110555.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F054TUPN46Q-4e4ce3c82f/img20230425110555_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F054TUPN46Q-4e4ce3c82f/img20230425110555_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F054TUPN46Q-4e4ce3c82f/img20230425110555_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F054TUPN46Q-4e4ce3c82f/img20230425110555_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F054TUPN46Q-4e4ce3c82f/img20230425110555_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F054TUPN46Q-4e4ce3c82f/img20230425110555_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F054TUPN46Q-4e4ce3c82f/img20230425110555_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 800, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F054TUPN46Q-4e4ce3c82f/img20230425110555_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F054TUPN46Q-4e4ce3c82f/img20230425110555_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 1024, "original_w": 3456, "original_h": 3456, "thumb_tiny": "AwAwADB5XNGylO7GRikAc9/0pDDyxR5a0pV8/eP5UCMnqxoANqilGO1MKAN3py8ZoAkXpTlx6U1ASM1KV460xCN7U3pk4p4UetNYAdTigCA8tmhfalYAYINIvekBIhwak3AVFRQMkDDHamswJpoNFAgPSmqOtOpKAP/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F054TUPN46Q/img20230425110555.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F054TUPN46Q-720904fed8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-04-25

- [1682436460.129899] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
Neels様からサンプル依頼です。
今週末か来週頭の発送を目処で大丈夫です。
準備出来次第発送でお願いします。
１、２だけ先に発送になると思います。

ーーーーーーー
１：standup pouch for 30g-60g
∟4/27amに出社しますので、その際にお伝えします。
※今回出荷する100g抹茶の小さい袋バージョンを検討するそうです。30g, 40g,50g,60gあたりで検討中。

サイズ感だけ検討できたらいいので、無地の袋を数種類送ろうと考えています。
（すでに事務所に届いていると思います。）

清和
10230　（110×110）
10231　（120×150） ＊60gピッタリ
10275　（90×145）　＊
~38001　（90×147）~

２：Tin Cans for 30g,40g,50g,100g
30g、40g：奥村製缶
50g、100g：日東産業

３：Stick for 1g, 2g, 4g
∟静パックに確認中
ーーーーーーー
- [1682436544.921819] <@U0331FWGQRM>: メモ（関連コメント抜粋）
I will offer a smaller size culinary grade stand up pouch for our customer
What sizes do you offer smaller than 100g bags?
30g ,40g,50g, or any size smaller than 100g bags
For This bag I would like to use a compact style pouch (Not a lot of empty space left in bag after matcha has been filled)

For these smaller sizes I would like to sample a few different dimensions if possible
I do want to test the packaging you sent in the previous email. I also believe it will work well for these smaller sizes.
Do you offer all three of these sizes? 30g -50g-60g?

For the printing we will use it will depend on the cost per unit,I would like to use original printing if possible to match our other product.
Could you get me a rough estimated price for these smaller size culinary packages? Same grade as our 100g matcha product.

## 2023-04-26

- [1682578317.123489] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
入金確認しましたので、
本日、出荷いたします。
AWB：EN 254 470 731 JP
よろしく御願い致します。
- [1682578444.450719] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長 <@U033G4KN4TD> さん
お疲れ様です。
本件、入金を確認致しました。
・4/27 [PayPal]
・30.00 USD
回収(入金)処理致します。
よろしくお願いします。

## 2023-04-30

- [1682875145.225469] <@U0331FZS7JT>: <@U041RJKV5JA>部長<@U033G4KN4TD> さん

先日、イギリスのDaveさん宛に発送した
下記サンプルですが、原料残ってます？？
---------------
*Organic Matcha TQ-1（碧翠園16000）*

*Organic Matcha HQK-3 + Cinamon (25%)*

*Organic Matcha HQK-3 + Lemongrass (30%)*

*Organic Matcha HQK-3 + Ginger (25%)*
*--------------*
上記と
*・Organic Matcha HQK-3 + Mint (15%)*

*・オーガニックほうじ茶のリーフ＋水色*

*・オーガニック玄米茶のリーフ＋水色*
*※手元に在庫あるもので良いです。*

の画像が欲しいということで、
パウダーはパウダーのみの画像と
各1gを100ccに溶かした
画像をお願いします。

フォルダは
アメリカ→Florita Blake(Alibaba)
にお願いします！

宜しくお願いします。

## 2023-05-01

- [1682933092.647909] <@U041RJKV5JA>: <@U0331FZS7JT> 社長
お疲れ様です。
フォルダに画像を入れておきました。
フォルダ名：画像
ご確認お願いいたします。

## 2023-05-15

- [1684220020.777569] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
フィリピンのお客様 Ralph Go様からサンプル依頼です。
有機、非有機それぞれの玄米茶パウダー*各50g*です。

原料
有機　　鹿児島製茶1B＋丸菱　有機玄米
非有機　出雲精茶500円＋丸菱　並玄米


The Superfood Grocer Philippines Inc
Ralph Go様

address
56A 12th St New Manila
Quezon City
Metro Manila Philippines
1110

phone
639175102697
  - files: [{"id": "F057HEF0XL7", "created": 1684219588, "timestamp": 1684219588, "name": "Quotation_genmaicha_tousuien.pdf", "title": "Quotation_genmaicha_tousuien.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 220942, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F057HEF0XL7/quotation_genmaicha_tousuien.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F057HEF0XL7/download/quotation_genmaicha_tousuien.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F057HEF0XL7-1b771ee902/quotation_genmaicha_tousuien_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F057HEF0XL7/quotation_genmaicha_tousuien.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F057HEF0XL7-22083589df", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-05-16

- [1684221082.524549] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
各50gに変更です。
- [1684226253.964779] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
明日5/18に発送可能かもしれません。
EMSでよろしいでしょうか？
よろしく御願い致します。
- [1684226450.450159] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長 <@U033G4KN4TD> さん
お疲れ様です。
本件、入金を確認致しました。
・5/16 [PayPal]
・30 USD
回収(入金)処理致します。
よろしくお願いします。

## 2023-05-17

- [1684310195.858169] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC：<@U041RJKV5JA> 部長

お疲れ様です。
本件、EMSで発送完了です。
追跡番号：EN 256 865 224 JP
よろしく御願い致します。

## 2023-05-30

- [1685462175.687389] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
サウジアラビアのsaja salman様から
サンプル依頼です。EMS出荷でOKです。
宜しくお願いします。

Address : Jeddah - alsafa- Talib Al-Haq Street
Postal code : 23451
Name : saja salman
Phone number : 966543717316

下記各20g

碧翠園16000
碧翠園12000
鹿児島製茶　有機抹茶A
- [1685489461.046549] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長 <@U033G4KN4TD> さん
お疲れ様です。
本件、入金を確認致しました。
・5/31 [PayPal]
・50 USD
回収(入金)処理致します。
よろしくお願いします。
- [1685495562.024619] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
明日、EMSにて出荷します。
商品ラベルは、QUOTATIONに記載の商品名で作成します。
よろしくお願いします。

## 2023-05-31

- [1685585437.875189] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
本日、EMSにて出荷しました。
お問い合わせ番号：EN 258 636 051 JP
よろしくお願いします。

## 2023-06-04

- [1685887529.642149] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>

インドネシアのお客様Sujana様（alibaba）
サンプル出荷お願いします。
種類が多くてすみませんが、下記各20gお願いします。
※発送はEMSでOK
※商品１つの価格はUSD0.25にしてください。
合計USD3.0になるようにしてください。
※通関で引っかかっても責任は取りませんと伝えています。
※入金確認後でOKです。
※優先順位は低目でOKです。

ーーーーー
鹿児島製茶	鹿児島 A
鹿児島製茶	鹿児島 1A
鹿児島製茶	鹿児島 B
鹿児島製茶	鹿児島 C
鹿児島製茶	鹿児島 D	
まるゑい	有機抹茶3000
	
出雲精茶	G
出雲精茶	R
出雲精茶	T
出雲精茶	N
出雲精茶	F
出雲精茶	W
ーーーーー

ーーーーー
送り先
Address : Jl. Agung Utara 4 Blok A 36D no 19, Sunter Agung, North Jakarta, Indonesia
Postal code : 14350
Company name : -
Your name : sujana
Phone number : <tel:+628161112788|+628161112788>
ーーーーー
- [1685924799.177079] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長 <@U033G4KN4TD> さん
お疲れ様です。
本件、入金を確認致しました。
・6/5 [PayPal]
・5,598 JPY
回収(入金)処理致します。
よろしくお願いします。

## 2023-06-05

- [1685962485.511389] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
お疲れ様です。
明日（6/6）に出荷します。
よろしくお願いします。
- [1686025893.437689] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
本日、EMSにて出荷しました。
お問い合わせ番号 : EN 261 051 845 JP
よろしくお願いします。

## 2023-06-07

- [1686166798.576229] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
サウジアラビアのFay Alosaimi様からサンプル依頼です。
下記２つ各20gです。
鹿児島A
鹿児1A

出荷方法はなんでも良いです。
宜しくお願いします。

※メモ※
先方手配の中国から袋が届いて、それに抹茶を詰めてサウジアラビアに送ると言う流れになりそうです。

## 2023-06-11

- [1686526650.719789] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長 <@U033G4KN4TD> さん
お疲れ様です。
本件、入金を確認致しました。
・6/12 [PayPal]
・30 USD
回収(入金)処理致します。
よろしくお願いします。

## 2023-06-13

- [1686723765.853949] <@U0331FWGQRM>: <@U033G4KN4TD> <@U041RJKV5JA>
本件、サンプル出荷の準備をお願いします。
EMSでOKです。
宜しくお願いします。

## 2023-06-14

- [1686729732.257979] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
承知しました。
中国からの袋が届き次第、発送いたします。
- [1686729941.992229] <@U0331FWGQRM>: <@U041RJKV5JA> 
これは、いつも通りのサンプルです。
いつものアルミ袋で送ってください。
宜しくお願いします

- [1686781068.100519] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
スペインのお客様からサンプル依頼です。
各20gで宜しくお願いします。

company name: MATCHAFLIX SL
NAME: DAVID BERNARDO
ADRESS: AVDA DE LA DEMOCRACIA 7, NAVE 402, ESPAÑA, MADRID 28031
PHONE: <tel:+34675870442|+34 675870442>
EORI: ES72890411B

宜しくお願いします。

※スペインって、植物検疫が要るんでしたっけ？:sweat_drops:
その辺りも結論として、後日共有して頂けたら嬉しいです。
  - files: [{"id": "F05CYV2N1QR", "created": 1686780701, "timestamp": 1686780701, "name": "スクリーンショット 2023-06-15 7.10.08.png", "title": "スクリーンショット 2023-06-15 7.10.08.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 124572, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05CYV2N1QR/____________________________2023-06-15_7.10.08.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05CYV2N1QR/download/____________________________2023-06-15_7.10.08.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F05CYV2N1QR-3444e4949b/____________________________2023-06-15_7.10.08_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F05CYV2N1QR-3444e4949b/____________________________2023-06-15_7.10.08_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F05CYV2N1QR-3444e4949b/____________________________2023-06-15_7.10.08_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 168, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F05CYV2N1QR-3444e4949b/____________________________2023-06-15_7.10.08_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 224, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F05CYV2N1QR-3444e4949b/____________________________2023-06-15_7.10.08_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F05CYV2N1QR-3444e4949b/____________________________2023-06-15_7.10.08_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 336, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F05CYV2N1QR-3444e4949b/____________________________2023-06-15_7.10.08_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 373, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F05CYV2N1QR-3444e4949b/____________________________2023-06-15_7.10.08_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 448, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F05CYV2N1QR-3444e4949b/____________________________2023-06-15_7.10.08_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 478, "original_w": 1444, "original_h": 674, "thumb_tiny": "AwAWADB55oo70tACUuBSUtAE8Ifyxg8U/bJ/epIR+6HHr2qXtTAoZ5ozSd6KQC5pc02igC3AMxDp37VLjjFR2/8AqR+NSUAf/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05CYV2N1QR/____________________________2023-06-15_7.10.08.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F05CYV2N1QR-dd95ee73f0", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1686802654.665129] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
お疲れ様です。
植物検疫証明書は必要ございません。
4月に植物検疫について神戸植物防疫所広島支所境港出張所に魯さんより確認いただいております。
以下、メール内容となります。
「スペイン向けお茶（製茶）についてですが、上部機関を通じてEUのコンタクトポイント（検疫条件等の確認を行うところ）に確認してもらったところ、明確に「植物検疫証明書は必要ない」とのことでした。
植物防疫法の改正により、植物検疫証明書の添付を必要としないものに植物検疫証明書を添付することができなくなりましたのでご理解いただければ幸いです。
なお、現地で何かあった場合は、「EUのコンタクトポイントに確認し、植物検疫証明書は必要ない旨確認している」旨、スペインの植物検疫機関にお伝えください。
抹茶、ほうじ茶、玄米茶、ショウガ抹茶とも同じ取扱いです。」
よろしくお願いいたします。

## 2023-06-15

- [1686812572.948929] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
お疲れ様です。
本日、EMSにて出荷しました。
お問い合わせ番号：EN 261 840 021 JP
よろしくお願いします。

## 2023-06-27

- [1687910077.296339] <@U0331FWGQRM>: <@U041RJKV5JA> <@U0331FZTHEK> 
TrusharBhalsod様（イギリス）からサンプル依頼です。
準備&amp;発送宜しくお願い致します。

各20gずつお願いします。
宜しくお願い致します。
EMSで大丈夫です。

EORI number: GB093525206000

address:
Trushar Bhalsod
20 Gunthorpe Road
Marlow
Buckinghamshire
SL7 1UH
UK
<tel:+44(0)7544077098|+44 (0) 7544 077 098>
  - files: [{"id": "F05E4321739", "created": 1687910066, "timestamp": 1687910066, "name": "IMG_1465.png", "title": "IMG_1465", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 519095, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05E4321739/img_1465.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05E4321739/download/img_1465.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F05E4321739-7f5d72b854/img_1465_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F05E4321739-7f5d72b854/img_1465_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F05E4321739-7f5d72b854/img_1465_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F05E4321739-7f5d72b854/img_1465_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 222, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F05E4321739-7f5d72b854/img_1465_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F05E4321739-7f5d72b854/img_1465_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 333, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F05E4321739-7f5d72b854/img_1465_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1731, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F05E4321739-7f5d72b854/img_1465_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 444, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F05E4321739-7f5d72b854/img_1465_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 473, "thumb_1024_h": 1024, "original_w": 1170, "original_h": 2532, "thumb_tiny": "AwAwABbQJCnAB/pRvPofypSQD/8AWo3D/IoAblT1Vj9Rmj5P+ef/AI7TtwpdwouFhCcHqfyo3D3/ACoOc9DRk+hoANw96XcPekyfQ0ZPoaBinr2/Oj8qMjGe3rSblPcfnQIWj8qCwX7xA+tJ5if31/OgD//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05E4321739/img_1465.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F05E4321739-07a9c956d3", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F05EFLVQ493", "created": 1687910066, "timestamp": 1687910066, "name": "IMG_1464.png", "title": "IMG_1464", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 368120, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05EFLVQ493/img_1464.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05EFLVQ493/download/img_1464.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F05EFLVQ493-6ed46d008e/img_1464_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F05EFLVQ493-6ed46d008e/img_1464_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F05EFLVQ493-6ed46d008e/img_1464_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 166, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F05EFLVQ493-6ed46d008e/img_1464_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 222, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F05EFLVQ493-6ed46d008e/img_1464_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F05EFLVQ493-6ed46d008e/img_1464_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 333, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F05EFLVQ493-6ed46d008e/img_1464_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1731, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F05EFLVQ493-6ed46d008e/img_1464_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 444, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F05EFLVQ493-6ed46d008e/img_1464_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 473, "thumb_1024_h": 1024, "original_w": 1170, "original_h": 2532, "thumb_tiny": "AwAwABbR7570m85xR3pn8X40k7gOLbT3/Ok80+lD/fNNpgS1H/F+NSVH/F+NACv980lK33zSUASVH/F+NScY7VFuXf1HWgBz/fNJSt980lAH/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05EFLVQ493/img_1464.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F05EFLVQ493-568a65bd0f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-06-28

- [1687994721.176919] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
本日（6/29）発送いたします。
発送しましたら、伝票番号をご連絡します。
よろしくお願いします。
- [1688016733.365699] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
本日、EMSにて発送しました。
お問い合わせ番号：EN 264 834 095 JP
よろしくお願いします。

## 2023-06-29

- [1688050587.182879] <@U0331FWGQRM>: <@U041RJKV5JA>
あーーすみません！！
全種類（10種類）です。。。
言葉足らずでした。再送宜しくお願いします。

送った分はそのまま送ってください！:sweat_drops:
- [1688075995.981369] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長
お疲れ様です。
本件、入金を確認致しました。
・6/30 [PayPal]
・40 USD
回収(入金)処理致します。
よろしくお願いします。
- [1688106478.878629] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
本日、EMSにて発送しました。
お問い合わせ番号：EN 264 457 978 JP
よろしくお願いします。

## 2023-07-20

- [1689868473.768799] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U0331FZS7JT>
アリババ
Anwar khan様問い合わせ。
下記商品ありますか？
杉本製茶になりますかね？
ご確認宜しくお願いします。

（サウジアラビア向け）
静岡県産
Non Organic
Ceremonial premium grade
Zip lock and can
1 to 50 kg initially monthly
- [1689868523.794349] <@U0331FWGQRM>: 杉本製茶の有機はこれらラインナップは聞いております。
  - files: [{"id": "F05HKR1GFQF", "created": 1689868495, "timestamp": 1689868495, "name": "スクリーンショット 2023-07-21 0.54.48.png", "title": "スクリーンショット 2023-07-21 0.54.48.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 17970, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05HKR1GFQF/____________________________2023-07-21_0.54.48.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05HKR1GFQF/download/____________________________2023-07-21_0.54.48.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F05HKR1GFQF-8dfe1aa617/____________________________2023-07-21_0.54.48_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F05HKR1GFQF-8dfe1aa617/____________________________2023-07-21_0.54.48_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F05HKR1GFQF-8dfe1aa617/____________________________2023-07-21_0.54.48_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 20, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F05HKR1GFQF-8dfe1aa617/____________________________2023-07-21_0.54.48_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 27, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F05HKR1GFQF-8dfe1aa617/____________________________2023-07-21_0.54.48_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F05HKR1GFQF-8dfe1aa617/____________________________2023-07-21_0.54.48_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 40, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F05HKR1GFQF-8dfe1aa617/____________________________2023-07-21_0.54.48_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 45, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F05HKR1GFQF-8dfe1aa617/____________________________2023-07-21_0.54.48_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 54, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F05HKR1GFQF-8dfe1aa617/____________________________2023-07-21_0.54.48_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 57, "original_w": 1265, "original_h": 71, "thumb_tiny": "AwACADDRopaSgBOxpRSdjSigA70HqKO9B6igD//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05HKR1GFQF/____________________________2023-07-21_0.54.48.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F05HKR1GFQF-fe65776489", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1689883967.997109] <@U0331FZS7JT>: <@U0331FWGQRM>
<@U03BLQ65GK0> <@U041RJKV5JA>

茗広にも以前平川部長に確認をとっていただいています。※Non organic
<@U041RJKV5JA> 部長
今年３月16日のメールの内容です。
あれっていくらでしたっけ？
併せて表への反映をお願いします。
- [1689913826.194779] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
 <@U03BLQ65GK0>会長 <@U0331FZS7JT> 社長
お疲れ様です。
茗広茶業に1種類あります。
・商品名：抹茶「黒智」
・品種/やぶきた
・茶期/1番茶
・ブレンド/単品
・摘採方法/ハサミ
・被覆期間/25日間
・年間供給可能量/50㎏
・粉砕方法/石臼
＜価格＞
・2kg詰め　26,000円
・1kg詰め　13,100円
・40g缶 750円
 取扱商品一覧表にも記載しておきました。
よろしくお願いいたします。
  - files: [{"id": "F05J0N999PF", "created": 1689913795, "timestamp": 1689913795, "name": "20230721_抹茶黒智お見積り.pdf", "title": "20230721_抹茶黒智お見積り.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 64541, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05J0N999PF/20230721_________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05J0N999PF/download/20230721_________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F05J0N999PF-c35aa7cecc/20230721__________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05J0N999PF/20230721_________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F05J0N999PF-01869b360a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-07-24

- [1690216679.769929] <@U0331FWGQRM>: <@U041RJKV5JA> <@U0331FZS7JT>

アメリカのCarmine Del Sordiからの問い合わせです。

Organic matcha Top grade2-2
*碧翠園の12000国産有機抹茶（MIX）*
※宇治抹茶ではない方のやつ

の今年の残り供給可能数量はわかりますか？

取扱商品一覧表では500kg/年と書いておりますので、
当初は500kgは可能だったと思うのですが、
現時点ではどのくらい可能か確認願います！
- [1690251852.561299] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役 <@U0331FZS7JT> 社長
碧翠園の12000国産有機抹茶（MIX）の供給可能数量ですが、
確認時と変わらず500㎏の供給が可能との事です。
よろしくお願いします。

## 2023-08-29

- [1693318834.176129] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
イギリスのossu tea（David ogg様）から、
近いうちに下記注文が来る予定です。進捗共有しておきます。
（現在３週間ほどholidayらしいので１ヶ月くらい先の話です）

ーーー
初回注文予定
（初回はturmeric抹茶は注文しません。しかし、2回目か3回目の注文時に追加するつもりです。）

（10/2更新）
*100 x 40g Tins Organic Matcha TQ-2*
*500 x 40g Tin Organic Matcha TQ-3*
*400 x 40g Tin Organic Matcha K-1*

*500 x 40g Tin Organic Matcha HQ-3 MINT 5%*
*500 x 40g Tin Organic Matcha HQ-3 CINNAMON 25%*
*500 x 40g Tin Organic Matcha HQ-3 GINGER 15%*
*500 x 40g Tin Organic Matcha HQ-3 LEMONGRASS 30%*
 
*Total tins = 3000*

~200 x 40g Tins Organic Matcha TQ-2~
~400 x 40g Tin Organic Matcha TQ-3~
~400 x 40g Tin Organic Matcha K-1~

~400 x 40g Tin Organic Matcha HQ-3 MINT 5%~
~400 x 40g Tin Organic Matcha HQ-3 CINNAMON 25%~
~400 x 40g Tin Organic Matcha HQ-3 GINGER 15%~
~400 x 40g Tin Organic Matcha HQ-3 LEMONGRASS 30%GRASS _*30%*_~
~*Total tins = 2600*~

*缶の種類について*
40g, silver, ring pull top
→奥村製缶の40g pulltop　シルバーを使用するか、中国製を使用するか検討中です。
気持ち的に80%くらいは奥村製缶で行こうと思ってますが、
もし品質確認が間に合えば中国製も視野に入れたいと思っています。
奥村製缶のリードタイムだけ確認しておいていただけますか？
ーーー

## 2023-08-31

- [1693534411.631049] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
奥村製缶様リードタイムになります。
・在庫有の場合：受注後2日～3日前後での発送
・在庫無の場合：受注後3週間～4週間前後での発送
現状、2,600缶の在庫は無いとの事です。
よろしくお願いします。

## 2023-09-01

- [1693559427.647059] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長 <@U033G4KN4TD> さん
お疲れ様です。
本件、入金を確認致しました。
・9/1 [PayPal]
・30 USD
回収(入金)処理致します。
よろしくお願いします。
- [1693581857.416259] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
サンプル出荷お願いします

## 2023-09-03

- [1693793480.377589] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA>部長
お疲れ様です。
本日、EMSにて出荷しました。
AWB <http://NO.JP|NO.273608747JP>
よろしくお願いします。

## 2023-09-07

- [1694101182.724249] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
サウジアラビアのAnfal Altamimi様（MoMatcha）から、
近いうちに下記注文が来る予定です。
変な注文なので、情報進捗共有しておきます。
まだ進めないでOKです。
※中国からサンプルがまもなく届くので、巻締機のテストをして、
OKであれば、缶は中国製を使おうと考えています。

ーーー
アルミ袋に入れた抹茶を30g pull top 缶の中に入れる商品。
（←謎です。一応入るか確認願います。）

Organic Matcha Upper grade - 1　（鹿児島A）
30g x 500can
発送はFedexが最安
缶の裏面に賞味期限を印字（賞味期限1年）
例）
EXP　31/10/2024
ーーー
  - files: [{"id": "F05RACV14QM", "created": 1694101090, "timestamp": 1694101090, "name": "03494C131387CCA730CE444556C1FB2E.jpg", "title": "03494C131387CCA730CE444556C1FB2E.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 51804, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05RACV14QM/03494c131387cca730ce444556c1fb2e.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05RACV14QM/download/03494c131387cca730ce444556c1fb2e.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV14QM-3e7cb51646/03494c131387cca730ce444556c1fb2e_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV14QM-3e7cb51646/03494c131387cca730ce444556c1fb2e_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV14QM-3e7cb51646/03494c131387cca730ce444556c1fb2e_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 240, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV14QM-3e7cb51646/03494c131387cca730ce444556c1fb2e_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 320, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV14QM-3e7cb51646/03494c131387cca730ce444556c1fb2e_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV14QM-3e7cb51646/03494c131387cca730ce444556c1fb2e_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 480, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV14QM-3e7cb51646/03494c131387cca730ce444556c1fb2e_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1200, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV14QM-3e7cb51646/03494c131387cca730ce444556c1fb2e_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 640, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV14QM-3e7cb51646/03494c131387cca730ce444556c1fb2e_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 683, "thumb_1024_h": 1024, "original_w": 1080, "original_h": 1620, "thumb_tiny": "AwAwACCiA/8AdNIUc9q1BCvenCBPSgDKCuB0/Wgq/pWv9nT+7QbZD/CKAJAKSR1iXJ69hUUlysZxgkiqs9z5zrhcYHegC5bTCbIKkEc81YxVezOV4AH0qxQBCYUY5K5qsWgEzL5Y+XjJq2DTGgjZ95GG9QcUAPhxj5fumpKaqhRwKdmgD//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05RACV14QM/03494c131387cca730ce444556c1fb2e.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F05RACV14QM-1e1bdc96e8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F05RACV9TUM", "created": 1694101093, "timestamp": 1694101093, "name": "C24E8B6BF4E274DF9191F8FCBB444899.jpg", "title": "C24E8B6BF4E274DF9191F8FCBB444899.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 50999, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05RACV9TUM/c24e8b6bf4e274df9191f8fcbb444899.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05RACV9TUM/download/c24e8b6bf4e274df9191f8fcbb444899.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV9TUM-c49b0f9265/c24e8b6bf4e274df9191f8fcbb444899_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV9TUM-c49b0f9265/c24e8b6bf4e274df9191f8fcbb444899_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV9TUM-c49b0f9265/c24e8b6bf4e274df9191f8fcbb444899_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 240, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV9TUM-c49b0f9265/c24e8b6bf4e274df9191f8fcbb444899_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 320, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV9TUM-c49b0f9265/c24e8b6bf4e274df9191f8fcbb444899_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV9TUM-c49b0f9265/c24e8b6bf4e274df9191f8fcbb444899_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 480, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV9TUM-c49b0f9265/c24e8b6bf4e274df9191f8fcbb444899_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1200, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV9TUM-c49b0f9265/c24e8b6bf4e274df9191f8fcbb444899_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 640, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F05RACV9TUM-c49b0f9265/c24e8b6bf4e274df9191f8fcbb444899_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 683, "thumb_1024_h": 1024, "original_w": 1080, "original_h": 1620, "thumb_tiny": "AwAwACCjh/Q03y3PatUQr3p4gT0oAyQrgf8A16Qq/pWwLdP7tBt0P8IoAkApHcIQOrEZAqJ7pYyRgnFVZbkyShlG3A9aALtvMJS6lCrIcEZzU+KgtDlCcAfSp6AIDDGxyVqvut/NK7B8pxk96tg1G1vG0m/BDHrjvQMkh+7x93txUlNVQowKdmgR/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05RACV9TUM/c24e8b6bf4e274df9191f8fcbb444899.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F05RACV9TUM-3e9e65c659", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-09-09

- [1694315116.464399] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
サウジアラAlanood Ali様からサンプル依頼です。
下記抹茶各20gをEMSで発送願います。

Organic Matcha Top grade - 1
Organic Matcha Top grade - 2

＜FYI＞
サンプルはEMSでいいが、出荷はDHLを希望とのこと。
サウジでは、EMSだと税関・税金関係が面倒らしい。
サウジではDHLがベストとのこと。

・Company name（brand name）
サウジでは会社名を書くと追加で税金を請求されるらしいので、
会社名は書かないでとのこと。
・Your name Alanood Ali
・Address Saudi Arabia
Riyadh, alnarjis distrect
Alsalamh street
・Postal code（Zip code）13328
・Phone number <tel:+966530343158|+966530343158>
・email address <mailto:alanoud121212@hotmail.com|alanoud121212@hotmail.com>

## 2023-09-10

- [1694386996.017609] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC: <@U041RJKV5JA> 部長 <@U033G4KN4TD> さん
お疲れ様です。
本件、入金を確認致しました。
・9/10 [PayPal]
・30 USD
回収(入金)処理致します。
よろしくお願いします。
- [1694410648.996659] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
本日、EMSにて出荷しました。
AWB NO. EN277132082JP
よろしくお願いします。

## 2023-09-11

- [1694441935.237469] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
Anfal Altamimi様の商品でJANコード（GS1コード）を取得して欲しいと連絡がありました。
なので取得して番号を教えてください。

※おそらく本来ブランド所有者のJANコードを入れると思うのですが、
　欲しいというので、桃翠園のJANコードを連絡したいと思います。
※これをするとおそらく、JANコード上は、桃翠園の小売商品がサウジで流通している、
　という認識になると思うのですが、、、まぁ問題ないと思うのでそれで進めます。
- [1694443074.632959] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
40g　pulltop　シルバー（艶あり）
中国の缶メーカーで進めたいと思います。
4000缶発注しました。
宜しくお願いします。

## 2023-09-12

- [1694502052.464679] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
アメリカのお客様Carmine Del Sordi(Alibaba)様から
近いうちに注文が来ると思います。

※奥村製缶の納期だけ確認願います。
在庫で対応できるようであれば*まだ注文は不要*です。

※予備考慮して110缶注文願います。
奥村製缶　ストレージ缶No.1　白マット（カートン：No.6）

ーーー
＜＜注文内容＞＞
抹茶：Top grade 2-2（碧翠園12000MIX）
内容：100g x 100bags in tin
缶：奥村製缶　ストレージ缶No.1　白マット（カートン：No.6）

ラベル：デザインはお客様が供給、こちらで印刷。
W x L = 20.55 x 9.4 (cm)
ーーー
- [1694525058.924189] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
明日、いただけますか？
数字だけでOKです。
- [1694525988.725229] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD>
イギリスのお客様Trushar(Alibaba)様から
近いうちに注文が来ると思います。

＜スケジュール＞
2023年9/20 Trusherが缶の品質を確認。
→問題なければ、デザインはtrusherからもらい、
そのデザインデータを桃翠園→静岡製缶に入稿し、注文する。

紙箱はTrusherが注文する。
Trusherが注文してから2週間で桃翠園に届く。（どこで製造かは不明）

ーーー
＜＜注文内容＞＞
Organic matcha Middle grade 1　40g bag
※鹿児島B
初回注文　500缶

缶底にExp.とLot No.
例）
EXP. dd/mm/yyyy　（1年）
Lot. T20230714　（ロット番号は桃翠園の書式でOK）

抹茶袋には
SKUと賞味期限を印字する。

＜売価＞
USD~7.37~→USD7.0
ーーー
  - files: [{"id": "F05RK3G72JK", "created": 1694525970, "timestamp": 1694525970, "name": "8d6ddc5e1f9671e87d2d9cd292e20a49.jpg", "title": "8d6ddc5e1f9671e87d2d9cd292e20a49.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 176177, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05RK3G72JK/8d6ddc5e1f9671e87d2d9cd292e20a49.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05RK3G72JK/download/8d6ddc5e1f9671e87d2d9cd292e20a49.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F05RK3G72JK-e0ee89eb1d/8d6ddc5e1f9671e87d2d9cd292e20a49_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F05RK3G72JK-e0ee89eb1d/8d6ddc5e1f9671e87d2d9cd292e20a49_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F05RK3G72JK-e0ee89eb1d/8d6ddc5e1f9671e87d2d9cd292e20a49_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F05RK3G72JK-e0ee89eb1d/8d6ddc5e1f9671e87d2d9cd292e20a49_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F05RK3G72JK-e0ee89eb1d/8d6ddc5e1f9671e87d2d9cd292e20a49_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F05RK3G72JK-e0ee89eb1d/8d6ddc5e1f9671e87d2d9cd292e20a49_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F05RK3G72JK-e0ee89eb1d/8d6ddc5e1f9671e87d2d9cd292e20a49_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F05RK3G72JK-e0ee89eb1d/8d6ddc5e1f9671e87d2d9cd292e20a49_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F05RK3G72JK-e0ee89eb1d/8d6ddc5e1f9671e87d2d9cd292e20a49_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1536, "original_h": 2048, "thumb_tiny": "AwAwACR+KMEU4EAc5xSF0xwDSsO44ISOGA+tJtPPI4pAGIyBS7Xx83HvRYLhgijBqMls/KNw9aMyf3KLBce7nPCfrUTPIeNi/nUrUw0rjsCzSqMbQPxpWmZlwV/M0wmkzRcViSOTYuMU7zvaoM0ZouOxMaaRTjTCaQxKbQTSZoAWikooEf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05RK3G72JK/8d6ddc5e1f9671e87d2d9cd292e20a49.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F05RK3G72JK-31ce395fb4", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F05S2302PNG", "created": 1694525978, "timestamp": 1694525978, "name": "redirectFileUrl.jpg", "title": "redirectFileUrl.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 12078, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05S2302PNG/redirectfileurl.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05S2302PNG/download/redirectfileurl.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F05S2302PNG-9c7dca87f6/redirectfileurl_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F05S2302PNG-9c7dca87f6/redirectfileurl_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F05S2302PNG-9c7dca87f6/redirectfileurl_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F05S2302PNG-9c7dca87f6/redirectfileurl_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 416, "original_h": 312, "thumb_tiny": "AwAkADCVelMcgAk9KeOlNC73JPRP50gIsO3QBR/tdaesLnoVP6UM2DT0kA70wI2yOCCCOxpmasSusij1Heqe7mkBcH3aWPhH9zmk/hqPfjNACvMq8baj+0Lg/L2qOQ5PFR7TQA9HJcCm5yaD+7BAOWP6Ui0AXc/LULVL2qJqAGGmHjpTjTTQBGetOWmnrTl70Af/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05S2302PNG/redirectfileurl.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F05S2302PNG-1dbc5b31f3", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1694560373.155619] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
遅くなりました。
4975115509679
よろしくお願いします。
- [1694572545.890579] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
現在在庫がなく、9月末～10月初旬にかけての製造・納品との事です。
110缶注文しておきます。
よろしくお願いします。

## 2023-09-27

- [1695833570.529619] <@U0331FWGQRM>: <@U041RJKV5JA> <@U033G4KN4TD> <@U0331FZS7JT> <@U03BLQ65GK0> <@U05KGS6HN9H>
お客様から、サンプルについて下記連絡がきました。
ーーーーー
TOP-1、TOP-2
を試して、TOP-2が圧倒的に良かった。
TOP-1は何か古いものなんでしょうか。
もしそうなのであればもう一度、正しいものを試飲して見たい。
ーーーーー
万が一のために、品質を確認してもらえますか？
もし何か原因がありそうなら教えてください。

お客様が味を分かっているとは思えないので、
今回は原因が分からなくても、再度サンプルを発送してください。

再発送の大義名分としては
今回は輸送中の気温が高すぎて品質が悪化したのかもしれないから、
段ボールで送り直します。
ということにして、再度サンプルを送ることにしました。
なので、小さい段ボールで出荷してください。

（サイズはなんでもいいです。
紙袋よりは丈夫そうで温度を通しにくそうだと体感で思う方法でお願いします。）
- [1695833581.277449] <@U05KGS6HN9H>: <@U05KGS6HN9H>さんがチャンネルに参加しました
- [1695883404.489689] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
 <@U03BLQ65GK0> 会長 <@U0331FZS7JT> 社長 <@U033G4KN4TD> さん <@U05KGS6HN9H> さん
会長と確認しました。
水色はTOP-1の方がTOP-2よりも冴えた緑色をしており、苦渋味は少なく、旨味、香りも圧倒的にTOP-1の方が勝っておりました。
本日、サンプル再送いたします。

## 2023-09-28

- [1695887898.795869] <@U033G4KN4TD>: <@U0331FWGQRM> 執行役
CC： <@U041RJKV5JA> 部長
お疲れ様です。
本日、EMSにて出荷しました。
AWB No. EN279088090JP
よろしくお願いします。
段ボール：ダブルNo.6E (240x160x200)にて出荷しております。

## 2023-10-01

- [1696219079.175499] <@U0331FWGQRM>: <@U041RJKV5JA> <@U05KGS6HN9H> <@U033G4KN4TD>
注文予定数量の更新です。
ご確認宜しくお願いします。

ーーー
100 x 40g Tins Organic Matcha TQ-2
500 x 40g Tin Organic Matcha TQ-3
400 x 40g Tin Organic Matcha K-1

500 x 40g Tin Organic Matcha HQ-3 MINT 5%
500 x 40g Tin Organic Matcha HQ-3 CINNAMON 25%
500 x 40g Tin Organic Matcha HQ-3 GINGER 15%
500 x 40g Tin Organic Matcha HQ-3 LEMONGRASS 30%

Total tins = 3000
ーーー

## 2023-10-03

- [1696342798.589029] <@U0331FWGQRM>: <@U041RJKV5JA> <@U05KGS6HN9H> <@U0331FZTHEK> <@U033G4KN4TD> <@U03BLQ65GK0> <@U0331FZS7JT>
本件について、入金されましたので、
製造開始はOKの段階になりました。

*進捗・情報共有します。*
・~30gプルトップ缶~ 40g プルトップ缶
・500缶
・プルトップ缶の中に、さらに袋を入れる（画像参照）
・ラベルデータは先方所掌（データ待ち状態）
・ラベルを貼り付けて出荷

*現在確認中＆進めて欲しいこと*
・缶のサイズが、桃翠園の扱っているサイズと違うそうなので、中国で製造可能か確認中
・袋だけ先に詰めてください。（袋：窒素充填、缶：巻締めのみ）
  - files: [{"id": "F05VAL71RJM", "created": 1696342310, "timestamp": 1696342310, "name": "46CCAD200E6FD9732ACF35427DC46702.jpg", "title": "46CCAD200E6FD9732ACF35427DC46702.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 40816, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05VAL71RJM/46ccad200e6fd9732acf35427dc46702.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05VAL71RJM/download/46ccad200e6fd9732acf35427dc46702.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F05VAL71RJM-2d4d283af3/46ccad200e6fd9732acf35427dc46702_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F05VAL71RJM-2d4d283af3/46ccad200e6fd9732acf35427dc46702_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F05VAL71RJM-2d4d283af3/46ccad200e6fd9732acf35427dc46702_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 339, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F05VAL71RJM-2d4d283af3/46ccad200e6fd9732acf35427dc46702_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 452, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F05VAL71RJM-2d4d283af3/46ccad200e6fd9732acf35427dc46702_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F05VAL71RJM-2d4d283af3/46ccad200e6fd9732acf35427dc46702_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 678, "original_w": 750, "original_h": 706, "thumb_tiny": "AwAtADDSIyepFAGO5NBOBTQcdqAB229z9KEfd3P40xpFBIb86FdSw28nuaAJqKjLEnO04+tPXBGRn8aAEfOMgZx2qMyMeFQ596WS4SM4bP5U6OZZfu5oAh8krnILA05Iz1A2/wBakklWP72aRZlYgYIz60AGR34NPUYz70tFAFO7Xkn3qS1XCZAGafLEH6ninRxhBgHigCG5BIPrj+tKePJ9yKkkTcc5/DFJ5e7bk/d5HFADpJFQfM4WmpPEx4lU596JYQ+DnGPamJECR049qAP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05VAL71RJM/46ccad200e6fd9732acf35427dc46702.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F05VAL71RJM-09b676772c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F05UV3RD2ER", "created": 1696342312, "timestamp": 1696342312, "name": "スクリーンショット 2023-10-03 20.07.38.png", "title": "スクリーンショット 2023-10-03 20.07.38.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 577187, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05UV3RD2ER/____________________________2023-10-03_20.07.38.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05UV3RD2ER/download/____________________________2023-10-03_20.07.38.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F05UV3RD2ER-3ab02159b6/____________________________2023-10-03_20.07.38_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F05UV3RD2ER-3ab02159b6/____________________________2023-10-03_20.07.38_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F05UV3RD2ER-3ab02159b6/____________________________2023-10-03_20.07.38_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 321, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F05UV3RD2ER-3ab02159b6/____________________________2023-10-03_20.07.38_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 429, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F05UV3RD2ER-3ab02159b6/____________________________2023-10-03_20.07.38_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F05UV3RD2ER-3ab02159b6/____________________________2023-10-03_20.07.38_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 643, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F05UV3RD2ER-3ab02159b6/____________________________2023-10-03_20.07.38_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 896, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F05UV3RD2ER-3ab02159b6/____________________________2023-10-03_20.07.38_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 857, "thumb_960_h": 960, "original_w": 900, "original_h": 1008, "thumb_tiny": "AwAwACpRCPSnC3FWNtKAfQ0AV/sq0v2VasHgc5pwHtQBVNotN+yCruKTFACAUpO1ST2GagkuFjODyahkvgVYBOox1oAbNO7uNhKgelW7UuYv3nUHj6VnwuQV6GtOEkpk0APoxRRQBWe3DnOcVE9pGq7nfAq2KrXsTyKpTnb2oAatqijgksOmT0q5H93GMY981RgD553D1BFXkzjkYoAfSUUUAf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05UV3RD2ER/____________________________2023-10-03_20.07.38.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F05UV3RD2ER-036d91bbaa", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F05URC0HZ7Y", "created": 1696342316, "timestamp": 1696342316, "name": "スクリーンショット 2023-10-03 20.07.47.png", "title": "スクリーンショット 2023-10-03 20.07.47.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 526558, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05URC0HZ7Y/____________________________2023-10-03_20.07.47.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05URC0HZ7Y/download/____________________________2023-10-03_20.07.47.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F05URC0HZ7Y-0a0a0595d3/____________________________2023-10-03_20.07.47_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F05URC0HZ7Y-0a0a0595d3/____________________________2023-10-03_20.07.47_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F05URC0HZ7Y-0a0a0595d3/____________________________2023-10-03_20.07.47_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 337, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F05URC0HZ7Y-0a0a0595d3/____________________________2023-10-03_20.07.47_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 449, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F05URC0HZ7Y-0a0a0595d3/____________________________2023-10-03_20.07.47_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F05URC0HZ7Y-0a0a0595d3/____________________________2023-10-03_20.07.47_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 673, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F05URC0HZ7Y-0a0a0595d3/____________________________2023-10-03_20.07.47_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 748, "original_w": 894, "original_h": 836, "thumb_tiny": "AwAsADC3jNKAfQ0oFOAoAQD2oA9qhMpkZlTI29SKigmlF35LNvXufSgC5ilxS0UAQmRV6kCmm7iHeoJYHZiRzURtJD0BoGNWUhyVyBk4wcHFXLZg2MDGaqpaSg7eB75q3bKqkguCwOMUCLNFLSUAMFRXUrRQ5XqTjPpUgoZVdSrDINAFKK5O1d34n1q3G29QeKgFusb/ACFh7Zq0iADNAx9FFFAj/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05URC0HZ7Y/____________________________2023-10-03_20.07.47.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F05URC0HZ7Y-1d2eb4bf31", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-10-04

- [1696404299.665229] <@U0331FWGQRM>: <@U041RJKV5JA> <@U05KGS6HN9H> <@U033G4KN4TD>
30g缶と40g缶をサンプルでそれぞれ、
2個ずつAnfal様に送ってください。

2個のうち一つは
抹茶を入れて（鹿児島A）巻締めしたもの
もう一つは巻締めしてないもの。

まとめると、
30g can  抹茶袋を入れて巻締め
30g can  抹茶を入れないにNOT巻締めしない
40g can  抹茶袋を入れて巻締め
40g can  抹茶を入れない、巻締めしない

発送する前に、写真や動画を送ってきていください。

※できればお客様指定の缶ではなく、桃翠園の標準の缶で進めたいと思っているので、
　その提案です。

宜しくお願い致します。

## 2023-10-05

- [1696565420.174209] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
 <@U033G4KN4TD> さん <@U05KGS6HN9H> さん
サンプル準備が整いました。
中袋ですが、30gと40gでは入れる向きが異なります。
理由は40gと同じ向きで入れると30g缶の高さが低い為、製缶時に袋を噛んでしまうためになります。
ご確認お願いします。
  - files: [{"id": "F060D63D76V", "created": 1696565367, "timestamp": 1696565367, "name": "30g缶.jpg", "title": "30g缶.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 189634, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F060D63D76V/30g___.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F060D63D76V/download/30g___.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F060D63D76V-51251f56a3/30g____64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F060D63D76V-51251f56a3/30g____80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F060D63D76V-51251f56a3/30g____360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 271, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F060D63D76V-51251f56a3/30g____480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 361, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F060D63D76V-51251f56a3/30g____160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F060D63D76V-51251f56a3/30g____720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 542, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F060D63D76V-51251f56a3/30g____800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 602, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F060D63D76V-51251f56a3/30g____960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 722, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F060D63D76V-51251f56a3/30g____1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 771, "original_w": 1156, "original_h": 870, "thumb_tiny": "AwAkADBqGn5pIo2f7oz61I0TLjI696kq5GTSGjO7JVWYDuBSY3DA70rDuIaSnNFtUlR0PbqKaQRjIwfSk42BMsQT+UpXBweeKWScy8Ywvv1NQA4pwOSB707isSpcQKgBcLgdMc1VlfzCXXIGf0q21vETyM/jTZIUEbEZ4HrTdxKxU+1OvAwfc0ocvyTk0xo8nipI4z2GcDNS3cpIdRRRSGIaKDRQAGnRsV3Y7jFNNC9/pSGf/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F060D63D76V/30g___.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F060D63D76V-0d34790489", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F06030LQGQ4", "created": 1696565371, "timestamp": 1696565371, "name": "40g缶.jpg", "title": "40g缶.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 3034620, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06030LQGQ4/40g___.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06030LQGQ4/download/40g___.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F06030LQGQ4-02b91259c7/40g____64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F06030LQGQ4-02b91259c7/40g____80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F06030LQGQ4-02b91259c7/40g____360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F06030LQGQ4-02b91259c7/40g____480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F06030LQGQ4-02b91259c7/40g____160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F06030LQGQ4-02b91259c7/40g____720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F06030LQGQ4-02b91259c7/40g____800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F06030LQGQ4-02b91259c7/40g____960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F06030LQGQ4-02b91259c7/40g____1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 5712, "original_h": 4284, "thumb_tiny": "AwAkADB4Wl2UiOTxUpVlXNRYu5EykUw08M8gJVCV9c1DKWAwvDE4+lKwXHUlNaJhgA4b17U707UmrDTuPjba2T0qSSYbSqnJP6VDRTUgaJFuUjjCkNkeg61WkcsS5GMnOPSrZlj7qfyqKZo3UBBg554xQSiIXAyMJgelODZqLy+akUYpN3KSsPpKWkpDCkpaSgBDSikpRSGf/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06030LQGQ4/40g___.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F06030LQGQ4-58da695cb8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0600DXRF3M", "created": 1696565380, "timestamp": 1696565380, "name": "右：30g缶、左：40g缶.jpg", "title": "右：30g缶、左：40g缶.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 3533619, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0600DXRF3M/______30g____________40g___.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0600DXRF3M/download/______30g____________40g___.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DXRF3M-142390a151/______30g____________40g____64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DXRF3M-142390a151/______30g____________40g____80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DXRF3M-142390a151/______30g____________40g____360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DXRF3M-142390a151/______30g____________40g____480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DXRF3M-142390a151/______30g____________40g____160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DXRF3M-142390a151/______30g____________40g____720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DXRF3M-142390a151/______30g____________40g____800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DXRF3M-142390a151/______30g____________40g____960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DXRF3M-142390a151/______30g____________40g____1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 5712, "original_h": 4284, "thumb_tiny": "AwAkADCGXh+nNXIkRo0JjUnHPy1BGqo25wCBVhrmMDO78qUWglcXyov+eSflUJREc7VA+lPin80scYA6UoKFiGIyemaHrsC03ITGjdUBpwIUAAYAp7bRzkAU3rWbui1Zi7cjFVnGB0GR7Ve2VWnjwSfWnsG421I+YUXA+cfSmwj5jipJU3CkMrpgyAE8Zq3VMoVNTxk4pMEXNxprAOPmpaKskZtCjAFNNPNMNSykMYUgpTSCoKP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0600DXRF3M/______30g____________40g___.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0600DXRF3M-b83e3c8a65", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0600DY6CG3", "created": 1696565390, "timestamp": 1696565390, "name": "製缶.mp4", "title": "製缶.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 5496796, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DY6CG3-e22f6b7726/______.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DY6CG3-e22f6b7726/______.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0600DY6CG3/download/______.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DY6CG3-e22f6b7726/file.m3u8?_xcb=8203f&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTA2NDAxOCxBVkVSQUdFLUJBTkRXSURUSD04OTI3MzMsQ09ERUNTPSJhdmMxLjY0MDAxZixtcDRhLjQwLjUiLFJFU09MVVRJT049NjA4eDEwODAsRlJBTUUtUkFURT0yOS45NzAKZGF0YTphcHBsaWNhdGlvbi92bmQuYXBwbGUubXBlZ3VybDtiYXNlNjQsSTBWWVZFMHpWUW9qUlZoVUxWZ3RWa1ZTVTBsUFRqb3pDaU5GV0ZRdFdDMVVRVkpIUlZSRVZWSkJWRWxQVGpvM0NpTkZXRlF0V0MxTlJVUkpRUzFUUlZGVlJVNURSVG94Q2lORldGUXRXQzFRVEVGWlRFbFRWQzFVV1ZCRk9sWlBSQW9qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEyTURCRVdUWkRSek10WlRJeVpqWmlOemN5Tmk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBMk1EQkVXVFpEUnpNdFpUSXlaalppTnpjeU5pOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TWk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTJNREJFV1RaRFJ6TXRaVEl5WmpaaU56Y3lOaTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd015NTBjd29qUlZoVVNVNUdPakl1T1Rjd0xBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakEyTURCRVdUWkRSek10WlRJeVpqWmlOemN5Tmk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOQzUwY3dvalJWaFVMVmd0UlU1RVRFbFRWQW89CiNFWFQtWC1TVFJFQU0tSU5GOkJBTkRXSURUSD02Nzg4NzgsQVZFUkFHRS1CQU5EV0lEVEg9NTc5OTY0LENPREVDUz0iYXZjMS42NDAwMWUsbXA0YS40MC41IixSRVNPTFVUSU9OPTQwNng3MjAsRlJBTUUtUkFURT0yOS45NzAKaHR0cHM6Ly9maWxlcy5zbGFjay5jb20vZmlsZXMtdG1iL1QwMzNENzBSUjZILUYwNjAwRFk2Q0czLWUyMmY2Yjc3MjYvZmlsZV9IXzI2NF8xMjgweDcyMF8zNTAwS0JQU183UVZCUi5tM3U4Cg==", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DY6CG3-e22f6b7726/_______trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 20987, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DY6CG3-e22f6b7726/_______thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0600DY6CG3/______.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F0600DY6CG3-d07ae6b86f", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F05V013A4CF", "created": 1696565395, "timestamp": 1696565395, "name": "窒素充填.mp4", "title": "窒素充填.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 11397504, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F05V013A4CF-b7132caf30/____________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F05V013A4CF-b7132caf30/____________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05V013A4CF/download/____________.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F05V013A4CF-b7132caf30/file.m3u8?_xcb=da89e&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9NzgwNzk3LEFWRVJBR0UtQkFORFdJRFRIPTUyNDMwMCxDT0RFQ1M9ImF2YzEuNjQwMDFmLG1wNGEuNDAuNSIsUkVTT0xVVElPTj02MDh4MTA4MCxGUkFNRS1SQVRFPTI5Ljk3MApkYXRhOmFwcGxpY2F0aW9uL3ZuZC5hcHBsZS5tcGVndXJsO2Jhc2U2NCxJMFZZVkUwelZRb2pSVmhVTFZndFZrVlNVMGxQVGpvekNpTkZXRlF0V0MxVVFWSkhSVlJFVlZKQlZFbFBUam8zQ2lORldGUXRXQzFOUlVSSlFTMVRSVkZWUlU1RFJUb3hDaU5GV0ZRdFdDMVFURUZaVEVsVFZDMVVXVkJGT2xaUFJBb2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTFWakF4TTBFMFEwWXRZamN4TXpKallXWXpNQzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01TNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakExVmpBeE0wRTBRMFl0WWpjeE16SmpZV1l6TUM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNaTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBMVZqQXhNMEUwUTBZdFlqY3hNekpqWVdZek1DOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TXk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTFWakF4TTBFMFEwWXRZamN4TXpKallXWXpNQzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd05DNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakExVmpBeE0wRTBRMFl0WWpjeE16SmpZV1l6TUM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBMVZqQXhNMEUwUTBZdFlqY3hNekpqWVdZek1DOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3Tmk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTFWakF4TTBFMFEwWXRZamN4TXpKallXWXpNQzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd055NTBjd29qUlZoVVNVNUdPakV1TWpBeExBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakExVmpBeE0wRTBRMFl0WWpjeE16SmpZV1l6TUM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdPQzUwY3dvalJWaFVMVmd0UlU1RVRFbFRWQW89CiNFWFQtWC1TVFJFQU0tSU5GOkJBTkRXSURUSD01MzMzODYsQVZFUkFHRS1CQU5EV0lEVEg9MzY1NDY0LENPREVDUz0iYXZjMS42NDAwMWUsbXA0YS40MC41IixSRVNPTFVUSU9OPTQwNng3MjAsRlJBTUUtUkFURT0yOS45NzAKaHR0cHM6Ly9maWxlcy5zbGFjay5jb20vZmlsZXMtdG1iL1QwMzNENzBSUjZILUYwNVYwMTNBNENGLWI3MTMyY2FmMzAvZmlsZV9IXzI2NF8xMjgweDcyMF8zNTAwS0JQU183UVZCUi5tM3U4Cg==", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F05V013A4CF-b7132caf30/_____________trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 43243, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F05V013A4CF-b7132caf30/_____________thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 720, "thumb_video_h": 1280, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05V013A4CF/____________.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F05V013A4CF-f295d00c18", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0600DYL803", "created": 1696565402, "timestamp": 1696565402, "name": "窒素充填前.jpg", "title": "窒素充填前.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 3711865, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0600DYL803/_______________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0600DYL803/download/_______________.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DYL803-71a1b23587/________________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DYL803-71a1b23587/________________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DYL803-71a1b23587/________________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DYL803-71a1b23587/________________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DYL803-71a1b23587/________________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DYL803-71a1b23587/________________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DYL803-71a1b23587/________________800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DYL803-71a1b23587/________________960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0600DYL803-71a1b23587/________________1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 5712, "original_h": 4284, "thumb_tiny": "AwAkADB++X1H5GjzJAMkgfgaqfaZv7/6CrMDNJFlznOaVgFZ5c4yP1pwMmM7lqlNK6SlUYgAVckbEBwRvAyKT0GPBkx95f1pcyf3l/WqQupcfeH5U77TL/eH5UwKua07RQIEJ64zVTfH/wA+6fmaTzEHSFB+JpiEvREJAY2LMc7uelW08naM4ZiO5zVMuhOfJT8zQJFz/q1/M0gHSzeaR8qqBwMUzI9alUx4/wBRGfzpf3f/ADwT9aBlck0hJoNIaAELGkyaDRQBYjORTixFNj+6KU0Af//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0600DYL803/_______________.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0600DYL803-17f68dbc81", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1696569724.005139] <@U0331FWGQRM>: <@U041RJKV5JA> <@U05KGS6HN9H> <@U033G4KN4TD> 
30gについて、向きを変えて入れて、
商品の品質として、サプライヤーである我々が見て、問題がないようであれば、サンプル出荷を進めてください。

もし問題があるようなら40gのみの出荷として進めてください。

宜しくお願い致します。


## 2023-10-06

- [1696616345.479399] <@U0606SPN4BW>: <@U0606SPN4BW>さんがチャンネルに参加しました
- [1696633456.131299] <@U0331FWGQRM>: <@U041RJKV5JA> <@U05KGS6HN9H> <@U033G4KN4TD>
本件どうですか？
返答願います。30g、商品としていけますか？
- [1696635964.097169] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
 <@U05KGS6HN9H> さん <@U033G4KN4TD> さん
返事遅くなりました。
30gも商品として問題ございません。
本日（10/7）、サンプル出荷できる様準備を進めます。
- [1696659170.904029] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
 <@U05KGS6HN9H> さん <@U033G4KN4TD> さん
本日、商品・伝票の準備は出来ましたが、ペガサスが休みの為集荷が不可となりました。
直接、集荷委託先の西濃エクスプレスに依頼しましたが持ち帰りは出来ないとの事でした。
10月10日（火）に出荷いたします。
すみませんが、よろしくお願いいたします。
- [1696659629.877449] <@U0331FWGQRM>: <@U041RJKV5JA> 
持ち帰りはできないってことは、
持ち込めばokなんですか？
- [1696660436.729609] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
ペガサスからの依頼がないと西濃側は引き受けることが出来ないとの事でしたので、
持ち込んでも受け付けていただくことはできません。
確認不足でした。

## 2023-10-09

- [1696915836.284809] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
本日、DHLにて出荷しました。
AWB NO. 5267066103
出荷書類はAnfal様フォルダ-サンプル発送フォルダに入れております。
よろしくお願いします。

## 2023-10-13

- [1697211163.308989] <@U0331FWGQRM>: <@U041RJKV5JA> <@U05KGS6HN9H> <@U033G4KN4TD> cc <@U0606SPN4BW>
ラベルデータを入手したので、
今、シール直送便でテスト印刷中です。
来週、火曜か水曜に事務所着です。

１：到着したら写真を撮って送ってください。
・W60x68Hmmの缶（シルバー）に貼ったもの。
・シール単体

この写真を先方に確認してもらってOKが出たら受注です。

２：OKが出たら500枚印刷（再注文でOK）
３：缶は中国から現在輸送中(1000缶)　
※別件ですが、この間をオランダのsander様でも使うかも！？です。

受注したら、スレッド立てます。

## 2023-10-16

- [1697464905.993719] <@U0331FWGQRM>: <@U041RJKV5JA> <@U05KGS6HN9H> <@U033G4KN4TD>
＜連絡＞
先方にサンプルが届き、
缶はW60x68Hmmの40g pull top缶でOKと
連絡がありました。

## 2023-10-19

- [1697698828.255859] <@U0331FWGQRM>: <@U041RJKV5JA> <@U05KGS6HN9H> <@U033G4KN4TD> 
ラベル届いてます?
- [1697699820.793309] <@U0331FWGQRM>: <@U041RJKV5JA> 
3種類あるうちの一つはそうなのですが、
袋の2種類は？
- [1697699891.030659] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
届いております。
画像、映像を後程お送りします。
- [1697703826.911029] <@U0331FWGQRM>: <@U041RJKV5JA> 
あ、これオランダのsanders様のやつですね！

Anfalのラベルはデザイン不備で保留になってました！:sweat_drops:

なので、この画像はsandersの方にお願いします。

なので削除でokです！
- [1697777265.798849] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
 <@U05KGS6HN9H> さん <@U033G4KN4TD> さん
当初使用予定の30gプルトップスクリュー缶 1,000缶が届きました。
40g缶を使用との事ですので、Ossu tea様注文分 4,000缶から500缶使用いたします。
＊40g缶は未着ですので、届きましたらご連絡いたします。

## 2023-10-20

- [1697791006.255659] <@U0331FWGQRM>: <@U041RJKV5JA> <@U05KGS6HN9H> <@U033G4KN4TD>
OKです！
40gプルトップ缶は船便なので、7日から10日くらい後かもです:sweat_drops:

※30gプルトップ缶のクオリティをまた“なんでもOK”でレビュー願います！

## 2023-10-22

- [1698024070.624339] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
 <@U05KGS6HN9H> さん <@U033G4KN4TD> さん
ラベルが届きました。
ご確認お願いいたします。
  - files: [{"id": "F062N4S8L2D", "created": 1698023982, "timestamp": 1698023982, "name": "DSC_2779.jpg", "title": "DSC_2779.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 2360697, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F062N4S8L2D/dsc_2779.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F062N4S8L2D/download/dsc_2779.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F062N4S8L2D-5b61575800/dsc_2779_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F062N4S8L2D-5b61575800/dsc_2779_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F062N4S8L2D-5b61575800/dsc_2779_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F062N4S8L2D-5b61575800/dsc_2779_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F062N4S8L2D-5b61575800/dsc_2779_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F062N4S8L2D-5b61575800/dsc_2779_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F062N4S8L2D-5b61575800/dsc_2779_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F062N4S8L2D-5b61575800/dsc_2779_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F062N4S8L2D-5b61575800/dsc_2779_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 4160, "original_h": 3120, "thumb_tiny": "AwAkADCbyIh/yzT8qPKi/wCeaflTxyKTvStqBBugGQ6IvPcUZgYgIiNk9hT5YUkZHbsfzqRVQElVAPfAqrCGeRCf+WSflSG2gP8AyzFSd6U1NtRiCjuaWkPrTT1AZjGD8ufrSkbuTt/OoNyxnJDHd6Uu5JPuhuPUYoK5VexY7ig9qF5APtS0r6khRRRUgNKKe1ARR0FOooHdhRSUUCP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F062N4S8L2D/dsc_2779.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F062N4S8L2D-95feeb4201", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0629CL3VM1", "created": 1698023991, "timestamp": 1698023991, "name": "DSC_2780.jpg", "title": "DSC_2780.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 4539834, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0629CL3VM1/dsc_2780.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0629CL3VM1/download/dsc_2780.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CL3VM1-a063164dbd/dsc_2780_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CL3VM1-a063164dbd/dsc_2780_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CL3VM1-a063164dbd/dsc_2780_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CL3VM1-a063164dbd/dsc_2780_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CL3VM1-a063164dbd/dsc_2780_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CL3VM1-a063164dbd/dsc_2780_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CL3VM1-a063164dbd/dsc_2780_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CL3VM1-a063164dbd/dsc_2780_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CL3VM1-a063164dbd/dsc_2780_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 4160, "original_h": 3120, "thumb_tiny": "AwAkADB/2aH5v3Y4PFQeWn/PNfyq2wYltrYGfSoAq/3/APx00EO4xYkPWNKGijHRFqQKv98Z+ho2KP4xn6GgV2ReVH/zzWnLBEXUGMcntmnhV/vjP0NOjVQ6kMCc+lA1ceXClgfU1ABxVnk7uvWq4d/7x/OmDEHHOKUknr0pQ7Z5c0rO3Zz+dIQwe/Snx8yL6ZpvmPn7xp8bsZFG4nmgEIWLE9s+lJtAHegdad2pFNCbBjvS7BjvS9qXtQFhmwAdTQoCsCO1ONJ3oBI//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0629CL3VM1/dsc_2780.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0629CL3VM1-0286f26c36", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F062YF6EYE4", "created": 1698023998, "timestamp": 1698023998, "name": "DSC_2787.jpg", "title": "DSC_2787.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 3620208, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F062YF6EYE4/dsc_2787.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F062YF6EYE4/download/dsc_2787.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F062YF6EYE4-4b3601b7ed/dsc_2787_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F062YF6EYE4-4b3601b7ed/dsc_2787_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F062YF6EYE4-4b3601b7ed/dsc_2787_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F062YF6EYE4-4b3601b7ed/dsc_2787_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F062YF6EYE4-4b3601b7ed/dsc_2787_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F062YF6EYE4-4b3601b7ed/dsc_2787_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F062YF6EYE4-4b3601b7ed/dsc_2787_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F062YF6EYE4-4b3601b7ed/dsc_2787_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F062YF6EYE4-4b3601b7ed/dsc_2787_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3120, "original_h": 4160, "thumb_tiny": "AwAwACSrS0gxTwjsMqjMPYUANopfKmP/ACzOPamE7Tg5B96AHUVHvo30ARg1ppcbkAyFxWXVyPayDIOcdjQF7FsTesiVTvZhIy4HTvUvlhfvK/54qrckbwAMACgL3GeYR2FHmn0FMooAKuQEiMc8dKqU+OV4/unr1B5FAmrl3ce2BVKf/WmpPtUmMLtX3UYNQGkCQlFFFMZ//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F062YF6EYE4/dsc_2787.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F062YF6EYE4-f9678fc3ed", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0629CLHH43", "created": 1698024004, "timestamp": 1698024004, "name": "DSC_2788.jpg", "title": "DSC_2788.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 3554821, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0629CLHH43/dsc_2788.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0629CLHH43/download/dsc_2788.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CLHH43-741494a8f7/dsc_2788_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CLHH43-741494a8f7/dsc_2788_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CLHH43-741494a8f7/dsc_2788_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CLHH43-741494a8f7/dsc_2788_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CLHH43-741494a8f7/dsc_2788_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CLHH43-741494a8f7/dsc_2788_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CLHH43-741494a8f7/dsc_2788_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CLHH43-741494a8f7/dsc_2788_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F0629CLHH43-741494a8f7/dsc_2788_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3120, "original_h": 4160, "thumb_tiny": "AwAwACSqOnNLimBxnoasfZpiucBfqaAIicUm4GpfsUpPLCopY2hIDLjPQ0AGaM0z5vSj5vSgBiHDgjqDWkt1lRuJH071l1eADLkgdOtAmycTx53B3z+dVLyYyEegNTwRK+cjoarXoCyhR0AoGQbj60bm9TSUUAFXIuY1OeOlVKfHK8Z+VsZoE1cvwMFDeueBVK6bdOxPWl+0y4IDBc+gxUJoBCUUtFAz/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0629CLHH43/dsc_2788.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F0629CLHH43-71d5daf7e4", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F062BUL958U", "created": 1698024010, "timestamp": 1698024010, "name": "DSC_2789.jpg", "title": "DSC_2789.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 2928500, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F062BUL958U/dsc_2789.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F062BUL958U/download/dsc_2789.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F062BUL958U-867806f93a/dsc_2789_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F062BUL958U-867806f93a/dsc_2789_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F062BUL958U-867806f93a/dsc_2789_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F062BUL958U-867806f93a/dsc_2789_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F062BUL958U-867806f93a/dsc_2789_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F062BUL958U-867806f93a/dsc_2789_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F062BUL958U-867806f93a/dsc_2789_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F062BUL958U-867806f93a/dsc_2789_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F062BUL958U-867806f93a/dsc_2789_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3120, "original_h": 4160, "thumb_tiny": "AwAwACTOzR160lABJwBk0AODAUbs0hVl6gj6ikoAfgHvRgetR0UATW8XnS7ScKOSa0jHGsexfkPYr1FUbFgHYHuKtvJh+doHcmgaVx+xQBvZ24/iOaqXlsqDzIxgdxVjfwNuw/jRdMPs7E9xxQDVjLooooEKjFGDDtVvzVYfMvX8RVOpUkAGGH4igLtbFlHhXkAk+wqC5mMhC4wo7UpmQDgEn6YFQE5OT1oHdsSiiigR/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F062BUL958U/dsc_2789.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F062BUL958U-bc998d0de8", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0629FD5V8A", "created": 1698024015, "timestamp": 1698024015, "name": "MOV_2781.mp4", "title": "MOV_2781.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 11732138, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "complete", "locale": "ja-JP"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F0629FD5V8A-4a17344465/mov_2781.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F0629FD5V8A-4a17344465/mov_2781.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0629FD5V8A/download/mov_2781.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "vtt": "https://files.slack.com/files-tmb/T033D70RR6H-F0629FD5V8A-4a17344465/file.vtt?_xcb=7a7f5&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F0629FD5V8A-4a17344465/file.m3u8?_xcb=7a7f5&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9NTMyNjE2NixBVkVSQUdFLUJBTkRXSURUSD01MzI2MTY2LENPREVDUz0iYXZjMS42NDAwMjgsbXA0YS40MC41IixSRVNPTFVUSU9OPTE5MjB4MTA4MCxGUkFNRS1SQVRFPTI5Ljk3MCxTVUJUSVRMRVM9InN1YnMiCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pVdU16TTVMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBMk1qbEdSRFZXT0VFdE5HRXhOek0wTkRRMk5TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TVM1MGN3b2pSVmhVTFZndFJVNUVURWxUVkFvPQojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MjQ4ODk4MSxBVkVSQUdFLUJBTkRXSURUSD0yNDg4OTgxLENPREVDUz0iYXZjMS42NDAwMWYsbXA0YS40MC41IixSRVNPTFVUSU9OPTEyODB4NzIwLEZSQU1FLVJBVEU9MjkuOTcwLFNVQlRJVExFUz0ic3VicyIKaHR0cHM6Ly9maWxlcy5zbGFjay5jb20vZmlsZXMtdG1iL1QwMzNENzBSUjZILUYwNjI5RkQ1VjhBLTRhMTczNDQ0NjUvZmlsZV9IXzI2NF8xMjgweDcyMF8zNTAwS0JQU183UVZCUi5tM3U4CiNFWFQtWC1NRURJQTpUWVBFPVNVQlRJVExFUyxHUk9VUC1JRD0ic3VicyIsTkFNRT0iRW5nbGlzaCIsREVGQVVMVD1ZRVMsQVVUT1NFTEVDVD1ZRVMsRk9SQ0VEPU5PLExBTkdVQUdFPSJlbmciLFVSST0iZGF0YTphcHBsaWNhdGlvbi92bmQuYXBwbGUubXBlZ3VybDtiYXNlNjQsSTBWWVZFMHpWUW9qUlZoVUxWZ3RWa1ZTVTBsUFRqb3pDaU5GV0ZRdFdDMVVRVkpIUlZSRVZWSkJWRWxQVGpvMk1EQUtJMFZZVkMxWUxVMUZSRWxCTFZORlVWVkZUa05GT2pFS0kwVllWQzFZTFZCTVFWbE1TVk5VTFZSWlVFVTZWazlFQ2lORldGUkpUa1k2TlM0ek16Z3NDbWgwZEhCek9pOHZabWxzWlhNdWMyeGhZMnN1WTI5dEwyWnBiR1Z6TFhSdFlpOVVNRE16UkRjd1VsSTJTQzFHTURZeU9VWkVOVlk0UVMwMFlURTNNelEwTkRZMUwyWnBiR1V1ZG5SMENpTkZXRlF0V0MxRlRrUk1TVk5VIgo=", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F0629FD5V8A-4a17344465/mov_2781_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 5338, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F0629FD5V8A-4a17344465/mov_2781_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 1920, "thumb_video_h": 1080, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0629FD5V8A/mov_2781.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F0629FD5V8A-97eb4b2aa3", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F0626HQ21S9", "created": 1698024023, "timestamp": 1698024023, "name": "MOV_2782.mp4", "title": "MOV_2782.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 13287600, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "complete", "locale": "ja-JP"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F0626HQ21S9-1a3941a9a7/mov_2782.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F0626HQ21S9-1a3941a9a7/mov_2782.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0626HQ21S9/download/mov_2782.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "vtt": "https://files.slack.com/files-tmb/T033D70RR6H-F0626HQ21S9-1a3941a9a7/file.vtt?_xcb=8c3db&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F0626HQ21S9-1a3941a9a7/file.m3u8?_xcb=8c3db&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MzU3NDk0MixBVkVSQUdFLUJBTkRXSURUSD0zNTc0OTQyLENPREVDUz0iYXZjMS42NDAwMjgsbXA0YS40MC41IixSRVNPTFVUSU9OPTE5MjB4MTA4MCxGUkFNRS1SQVRFPTI5Ljk3MCxTVUJUSVRMRVM9InN1YnMiCmRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzNDaU5GV0ZRdFdDMU5SVVJKUVMxVFJWRlZSVTVEUlRveENpTkZXRlF0V0MxUVRFRlpURWxUVkMxVVdWQkZPbFpQUkFvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBMk1qWklVVEl4VXprdE1XRXpPVFF4WVRsaE55OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TVM1MGN3b2pSVmhVU1U1R09qQXVNRE16TEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTJNalpJVVRJeFV6a3RNV0V6T1RReFlUbGhOeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01pNTBjd29qUlZoVUxWZ3RSVTVFVEVsVFZBbz0KI0VYVC1YLVNUUkVBTS1JTkY6QkFORFdJRFRIPTE4NDYwNjgsQVZFUkFHRS1CQU5EV0lEVEg9MTg0NjA2OCxDT0RFQ1M9ImF2YzEuNjQwMDFmLG1wNGEuNDAuNSIsUkVTT0xVVElPTj0xMjgweDcyMCxGUkFNRS1SQVRFPTI5Ljk3MCxTVUJUSVRMRVM9InN1YnMiCmh0dHBzOi8vZmlsZXMuc2xhY2suY29tL2ZpbGVzLXRtYi9UMDMzRDcwUlI2SC1GMDYyNkhRMjFTOS0xYTM5NDFhOWE3L2ZpbGVfSF8yNjRfMTI4MHg3MjBfMzUwMEtCUFNfN1FWQlIubTN1OAojRVhULVgtTUVESUE6VFlQRT1TVUJUSVRMRVMsR1JPVVAtSUQ9InN1YnMiLE5BTUU9IkVuZ2xpc2giLERFRkFVTFQ9WUVTLEFVVE9TRUxFQ1Q9WUVTLEZPUkNFRD1OTyxMQU5HVUFHRT0iZW5nIixVUkk9ImRhdGE6YXBwbGljYXRpb24vdm5kLmFwcGxlLm1wZWd1cmw7YmFzZTY0LEkwVllWRTB6VlFvalJWaFVMVmd0VmtWU1UwbFBUam96Q2lORldGUXRXQzFVUVZKSFJWUkVWVkpCVkVsUFRqbzJNREFLSTBWWVZDMVlMVTFGUkVsQkxWTkZVVlZGVGtORk9qRUtJMFZZVkMxWUxWQk1RVmxNU1ZOVUxWUlpVRVU2Vms5RUNpTkZXRlJKVGtZNk5pNHdNemtzQ21oMGRIQnpPaTh2Wm1sc1pYTXVjMnhoWTJzdVkyOXRMMlpwYkdWekxYUnRZaTlVTURNelJEY3dVbEkyU0MxR01EWXlOa2hSTWpGVE9TMHhZVE01TkRGaE9XRTNMMlpwYkdVdWRuUjBDaU5GV0ZRdFdDMUZUa1JNU1ZOVSIK", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F0626HQ21S9-1a3941a9a7/mov_2782_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 6039, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F0626HQ21S9-1a3941a9a7/mov_2782_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 1920, "thumb_video_h": 1080, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0626HQ21S9/mov_2782.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F0626HQ21S9-7d23b9ce34", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-10-23

- [1698061044.878279] <@U0331FWGQRM>: <@U03BLQ65GK0> cc <@U041RJKV5JA> <@U033G4KN4TD> <@U05KGS6HN9H>
お客様の希望で、
この缶を手に持って茶園の前で撮影して欲しいとのことです。

プロのカメラマンに撮影して欲しいらしく、
吉田写真堂に依頼いただけますか？
まずは“お願いしたいです“という話だけ先にしておいて、
・スケジュール
・希望のカット数
などは未定です、として、
前話をしておいてください。

希望のカットやその数については、
先方から入手できる予定ですので、
入手したらお渡しします。

## 2023-10-27

- [1698448537.695019] <@U0331FWGQRM>: <@U03BLQ65GK0> cc <@U041RJKV5JA> <@U033G4KN4TD> <@U05KGS6HN9H>
撮影の話、一旦キャンセルでお願いします。

<@U0331FZS7JT> に相談役と撮影してもらいます:sweat_drops:

## 2023-10-29

- [1698634751.560159] <@U0331FWGQRM>: <@U0331FZS7JT>
Anfal様向けの写真を下記先へ保存願います。

<https://drive.google.com/drive/folders/15BD3solgojzpxwJ4nXTCc8D0Gp833QpI?usp=sharing>
- [1698635783.697569] <@U0331FZS7JT>: <@U0331FWGQRM>
保存、完了しました。

## 2023-10-30

- [1698721498.612599] <@U0331FWGQRM>: <@U041RJKV5JA> <@U05KGS6HN9H> <@U033G4KN4TD>
缶の裏面に賞味期限を印字してくださいとのことです。
ーーー
缶の裏面に賞味期限を印字（賞味期限1年）
例）
EXP　31/10/2024
ーーー

## 2023-11-01

- [1698885064.537109] <@U0331FZS7JT>: <@U041RJKV5JA> <@U05KGS6HN9H> <@U0331FZTHEK> <@U033G4KN4TD>

オランダ Idriss Warsame(Alibaba)様からサンプル依頼です。
下記抹茶とブレンド抹茶各20gをEMSで発送願います。
※入金後の製造開始で問題ありません。
<@U0331FZTHEK>
PayPalでUSD40を請求しています。

-----サンプル内容-----
・Organic Matcha Top grade - 1
・Organic Matcha Top grade - 2
・Organic Matcha Upper grade - 1
・Organic Matcha Upper grade - 2
・Organic Cinnamon Matcha
・Organic Lemongrass Matcha

<@U041RJKV5JA>
原料が無いものは、代替製品での製造をお願いします。
よろしくお願いします。

## 2023-11-06

- [1699339905.744669] <@U0331FZTHEK>: <@U0331FZS7JT>
 <@U041RJKV5JA> <@U05KGS6HN9H> <@U033G4KN4TD>
本件、ご入金を確認致しました。
・11/7 [当座預金]
・6,000円
回収(入金)処理致します。
※PayPalでのお支払いではなく、6,000円をUSD外貨普通預金をご指定、送金されたようです。
　「念書」手続きにより当座預金に入金致します。
よろしくお願いします。
- [1699341704.639799] <@U0331FZS7JT>: <@U041RJKV5JA> <@U033G4KN4TD> <@U05KGS6HN9H> 

それではサンプル各20gの製造、発送をお願いします。
併せて、以前スティックに詰めた抹茶も一緒に送って欲しいということですので、3本一緒に送ってください。

発送可能日がわかったら共有をお願いします。
よろしくお願いします。

## 2023-11-07

- [1699346767.281179] <@U041RJKV5JA>: <@U0331FZS7JT>
 <@U05KGS6HN9H> <@U033G4KN4TD>
出荷可能日：11月9日（木）
よろしくお願いします。

## 2023-11-09

- [1699517656.757849] <@U041RJKV5JA>: <@U0331FZS7JT>
 <@U05KGS6HN9H> <@U033G4KN4TD>
本日、EMSにて出荷しました。
AWB NO. EN285477479JP
よろしくお願いします。

## 2023-11-23

- [1700786235.890669] <@U0331FZS7JT>: <@U03BLQ65GK0> <@U041RJKV5JA> <@U05KGS6HN9H>  <@U033G4KN4TD>

カナダJust Great Tea（Allison Chan）様から問い合わせがありました。
ほうじ茶 Tea Bag の個包装（１煎パック）かつ生分解性のTea Bagが欲しいということです。
※4g/TB（画像はお客様の今の製品）
10,000-20,000袋を注文する予定。

調べたところ・・・
Tea bag：清和No.58575
で対応が可能。

１煎パック：吉村のデジタル印刷で可能。
※30,000袋以上の場合はグラビア印刷の方が安価。
　但し、いきなりグラビア印刷やるのは取引が始まっていない相手で
　リスクがあるため先ずはデジタル印刷で状況に応じてグラビア印刷を検討しています。

進めていく手段として下記の方法があるかと思います。
①送られてきた袋に桃翠園で賞味期限などを印字
　桃翠園でTB製造（熱圧着）
　桃翠園で袋詰め＆シール

②他社（ひかわや吉村の下請け）にTB製造依頼。
　他社（吉村の下請け）で印字＋個包装

③他社（ひかわや吉村の下請け）にTB製造依頼。
　桃翠園で印字＋個包装

上記かと思いますが、他に何か案がありますでしょうか？
またTBでもっと安いとこあるよなどあればこちらもお願いします:man-bowing:

①は数量的にも掛かる時間的にも現実的ではない？？と思いますが
　いかがでしょうか。

②吉村には確認・見積もり依頼をしているので、
　ひかわや他社などに確認をとっていただきスレッドで結果の共有をお願いします。

③折衷案みたいな感じですが、できればなるべく外注でやれたらと思います。
　但し②も同様ですがFSSCの観点で何か問題があれば<@U03BLQ65GK0> 教えてください。

以上、よろしくお願いします。
  - files: [{"id": "F06746R3L7M", "created": 1700786229, "timestamp": 1700786229, "name": "Canada TB.jpg", "title": "Canada TB.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 325630, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06746R3L7M/canada_tb.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06746R3L7M/download/canada_tb.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F06746R3L7M-7d396eb508/canada_tb_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F06746R3L7M-7d396eb508/canada_tb_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F06746R3L7M-7d396eb508/canada_tb_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F06746R3L7M-7d396eb508/canada_tb_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F06746R3L7M-7d396eb508/canada_tb_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F06746R3L7M-7d396eb508/canada_tb_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F06746R3L7M-7d396eb508/canada_tb_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F06746R3L7M-7d396eb508/canada_tb_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F06746R3L7M-7d396eb508/canada_tb_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 1773, "original_h": 2364, "thumb_tiny": "AwAwACS3RSE4GajyeoNSUS0VGrk9waeGzQAtFFFAEch+X61BKpeIqDgmpJD0pnWgQ23jZCzHAB7A1ZTuajU8YqSMgrwQaBj6KKKAIqTYKAaWgCvJIUJGMehqLcUO5TUtxyKiADJg0hosJdnaMgGnfa/9kVQCsOCDRhvQ0DP/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06746R3L7M/canada_tb.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F06746R3L7M-d9f3b0adb4", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-11-26

- [1701067571.207779] <@U0331FZS7JT>: <@U03BLQ65GK0>
Tea bag：清和No.58575
<https://www.seiwa-p.co.jp/shop/g/g070002-58575?number_search=58575>
横62mm×縦82mm
ほうじ茶カット品4g入れる

確認願います。
清和にはロールで納品可能か確認します。
  - attachments: [{"from_url": "https://www.seiwa-p.co.jp/shop/g/g070002-58575?number_search=58575", "service_icon": "https://www.seiwa-p.co.jp/images/common/webclipicon.png", "thumb_url": "https://www.seiwa-p.co.jp/img/goods/S/S_070002_58575.jpg", "thumb_width": 111, "thumb_height": 111, "id": 1, "original_url": "https://www.seiwa-p.co.jp/shop/g/g070002-58575?number_search=58575", "fallback": "パッケージ通販: タグ付き生分解性フィルター62×82", "text": "タグ付き生分解性フィルター62×82　　｜パッケージ通販（パケ通）は株式会社　清和が運営する包装資材の通販サイトです。", "title": "タグ付き生分解性フィルター62×82", "title_link": "https://www.seiwa-p.co.jp/shop/g/g070002-58575?number_search=58575", "service_name": "パッケージ通販"}]
- [1701068572.871009] <@U0331FZS7JT>: <@U041RJKV5JA>
Tea bag：清和No.58575
<https://www.seiwa-p.co.jp/shop/g/g070002-58575?number_search=58575>
横62mm×縦82mm

これをロール納品可能か、
ロール納品の場合、紐があることで難しいなどあれば無しで問題ありません。
※お客様は紐無しの方が良いと言われています。

## 2023-11-27

- [1701153410.633979] <@U041RJKV5JA>: <@U0331FZS7JT>
清和より連絡がありました。
製造メーカーにご確認いただきましたが、ロールでの納品は出来ず、製袋したものしか販売しないと連絡があったそうです。
よろしくお願いいたします。

## 2023-11-28

- [1701158450.230519] <@U0331FZS7JT>: 【メモ】
ひかわで生分解性のTBにて製造可能。
※袋詰めは不可。
¥9/1p

素材：ソイロン
<https://store.hammys.co.jp/blogs/blog/siron>
  - attachments: [{"image_url": "http://store.hammys.co.jp/cdn/shop/articles/DSC07996.jpg?v=1660634009", "image_width": 2000, "image_height": 1333, "image_bytes": 149584, "from_url": "https://store.hammys.co.jp/blogs/blog/siron", "service_icon": "http://store.hammys.co.jp/cdn/shop/files/shop_32x32.png?v=1661147006", "id": 1, "original_url": "https://store.hammys.co.jp/blogs/blog/siron", "fallback": "Hammy's Online Store: ソイロンとは？生分解性ティーバッグってなに？", "text": "こんにちは、Hammy'sです！前回のブログで「ティーバッグは体に悪い？お茶を入れるとマイクロプラスチックが116億個飛び散る」と、ティーバッグについて書きましたが、今回は記事内でも紹介した「ソイロン」について紹介します！\nソイロンとは？\nソイロンとは、植物（トウモロコシ）のデンプンを原料にした繊維素材のことです。環境や身体のことを考えられて作られた新しい素材で、ティーバッグのフィルターなどに使用されています。\n引用：山中産業（株）\n\n植物のデンプンを原料として、乳酸発酵及び重合化（ポリ乳酸）などの工程を経て、繊維化して織り上げられた製品です。均一な目開きで通水性に優れているので、リーフ用ティーバッグフィルターに最適です。\n熱湯抽出で有害な物質は検出されません。食品衛生法の食品・添加物等の規格基準（第370号)にも合格しています。\n土中に埋設すると、加水分解した後、微生物によって完全に分解され、最終的に水と二酸化炭素になります。分解速度は土壌の温度、湿度、PHや微生物の種類と数により、大きく異なります。\n燃焼時には有害ガス（ダイオキシン等）を発生せず、通常のプラスチックと比較して、地球温暖化ガス(二酸化炭素)の発生も少ないです。\n素材のポリ乳酸には静菌性と防カビ性があることが報告されています。\n再生可能な植物を原料としており、持続可能な社会の発展に貢献します。このことから、グリーンプラマーク[No.243]を取得しています。また、欧州・アメリカではコンポスト施設での推肥化が可能であることの認証を取得しています。\n\n \n\nつまり、ソイロンは完全分解されるので、ゴミになっても完全に土に還る地球環境にとってもやさしい素材ということです。\n最近、ティーバッグフィルターでソイロン製ティーバッグを使用しているお茶や紅茶が増えてきています。ソイロン製ティーバッグが増えて生きている理由は、実は従来のティーバッグは環境だけでなく、人間の身体に悪いのではないかと言われているからです。\n\n紅茶のティーバッグから116億個のプラスチックが検出\n\nお茶のティーバッグの多くはプラスチックを含む素材を使用しており、2019年に、ティーバッグにお湯を注ぐと約116億個のマイクロプラスチックが飛散していることが分かりました。\n\n参考：Science News\nマイクロプラスチックは、人間では消化することが不可能で人体に蓄積し悪影響を及ぼすのでは？と考察されています。まだ人体への影響は不明とのことですが、ミジンコは身体構造や行動に以上が出たそうです。\n生分解性ティーバッグとは？\nソイロンの他にも生分解性ティーバッグは存在しますが、そもそも生分解性って何？という方も多くいらっしゃると思います。\n生分解とは、微生物などの力で有機化学物質が完全に分解され、水や二酸化炭素に還ることです。\nつまり生分解性ティーバッグは、地球に還る環境にやさしいティーバッグのことです。\nソイロンは環境にもからだにもやさしいティーバッグ\nHammy'sのオリジナルブランドTassas無農薬栽培茶シリーズは、すべてソイロン製のテトラ型ティーバッグを使用しています。\n熊本県で無農薬栽培された茶葉を使用し、安心安全にお茶を楽しむことができます。やぶきた種をメインとした緑茶と、国産紅茶の和紅茶の2種類を販売しています。\n水出しでもお湯出しでも美味しく飲めますので、是非チェックしてみてください。\n緑茶は一番茶を強めに火入れし、白折れをブレンドしました。無農薬で育った自然の茶葉の香ばしい味わいを楽しめます。\n\n \n紅茶は二番茶を完全発酵させて日本の紅茶「和紅茶」として仕上げました。 どこか日本茶の風味を感じることのできる飲みやすい紅茶です。\n\n和紅茶についてはこちらの記事を参考にしてください和紅茶とは？", "title": "ソイロンとは？生分解性ティーバッグってなに？", "title_link": "https://store.hammys.co.jp/blogs/blog/siron", "service_name": "Hammy's Online Store"}]
- [1701197986.874899] <@U0331FWGQRM>: <@U041RJKV5JA> <@U0331FZS7JT>
お客様が添付のような片口茶碗を探されています。
中国でも購入できますが、数量がわからないので、
日本で購入が現状いいかなと思っています。（送料の点で）

ネットで1000円くらいで購入できそうなんで、
数量が小さければそれでいいかなと思いましたが、
大量注文が万が一あった時に対応できた方がいいので、
山寺とか茶器屋さんのカタログで確認してもらえますか？
  - files: [{"id": "F067P4F34DR", "created": 1701197978, "timestamp": 1701197978, "name": "image_720.png", "title": "image_720.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 122790, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F067P4F34DR/image_720.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F067P4F34DR/download/image_720.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F067P4F34DR-c11ebb1067/image_720_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F067P4F34DR-c11ebb1067/image_720_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F067P4F34DR-c11ebb1067/image_720_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 187, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F067P4F34DR-c11ebb1067/image_720_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 249, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F067P4F34DR-c11ebb1067/image_720_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F067P4F34DR-c11ebb1067/image_720_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 374, "original_w": 720, "original_h": 374, "thumb_tiny": "AwAYADDR4pHIVGb0GaYq9ufzyPzp0i4hfv8AKaAIUuWcZEL4+ooN0VZQ0LDJAzkVTileNdvlkj2p3mPJIgMZA3DrQBp4pOlLRQAxPuenJ9KcRnHJ49O9Rj/VH6n+dSjpTYBS0lFIAoooFAH/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F067P4F34DR/image_720.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F067P4F34DR-d81f728dd4", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-11-29

- [1701303387.113099] <@U0331FWGQRM>: <@U041RJKV5JA> 
ざっくり価格でいいので、
これに似た茶碗の価格と、カタログの写真を貰えますでしょうか？宜しくお願い致します。
- [1701311695.141119] <@U041RJKV5JA>: <@U0331FWGQRM>
当社取引先と取引依頼をかけている販売先の商品をご連絡いたします。
茶道具屋の山寺等は取り扱いはありませんでした。
（理由：余り売れるものではない為、取り扱っていない）
よろしくお願いします。
  - files: [{"id": "F067HL3UQS3", "created": 1701311691, "timestamp": 1701311691, "name": "片口抹茶椀.pdf", "title": "片口抹茶椀.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 356696, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F067HL3UQS3/_______________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F067HL3UQS3/download/_______________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F067HL3UQS3-9a13a1ddd3/________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1286, "thumb_pdf_h": 910, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F067HL3UQS3/_______________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F067HL3UQS3-1946be445a", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-09-10

- [1725976112.662589] <@U0331FZS7JT>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
遅くなりました:pray::sweat_drops:
昨日のアリババMTGの録画URLを共有します！
<https://youtu.be/cd4V80C6Gyw>
よろしくお願いします。
  - attachments: [{"from_url": "https://youtu.be/cd4V80C6Gyw", "service_icon": "https://a.slack-edge.com/80588/img/unfurl_icons/youtube.png", "thumb_url": "https://i.ytimg.com/vi/cd4V80C6Gyw/hqdefault.jpg", "thumb_width": 480, "thumb_height": 360, "video_html": "<iframe width=\"400\" height=\"300\" src=\"https://www.youtube.com/embed/cd4V80C6Gyw?feature=oembed&autoplay=1&iv_load_policy=3\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen title=\"20240909 アリババMTG\"></iframe>", "video_html_width": 400, "video_html_height": 300, "id": 1, "original_url": "https://youtu.be/cd4V80C6Gyw", "fallback": "YouTube Video: 20240909 アリババMTG", "title": "20240909 アリババMTG", "title_link": "https://youtu.be/cd4V80C6Gyw", "author_name": "祐太", "author_link": "https://www.youtube.com/@user-to3ef4be4l", "service_name": "YouTube", "service_url": "https://www.youtube.com/"}]
- [1725976124.247229] <@U066P20UQH1>: <@U066P20UQH1>さんがチャンネルに参加しました
- [1725977298.685299] <@U0331FWGQRM>: <@U0331FZS7JT>
僕のマイクの音悪いですね:sweat_drops:
音悪い場合は、言ってもらえると助かります。。。
- [1725978301.931409] <@U0331FZS7JT>: <@U0331FWGQRM>
了解です。
昨日聞いてる時はここまで悪くなかったので:sweat_drops:
気をつけます:pray:
- [1726016557.564509] <@U0331FWGQRM>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
ざっくりMTGのまとめです。

アリババのスターレーティングの指標として、
返信速度、がなくなりました。
なので、初回返信のタイミングが遅くても、
星には影響しないとのことなので、短期的には気にしなくてOKになりました。
でも、お客様の満足度の観点と、
今後アリババの指標に再変更があった際に、（返信を遅くしていると）一発で星が下がる可能性があるので、引き続き同じ対応を続ける。でいいかと思っています。

その他下記については、
ページの更新が必要な内容についてです。
メモ
・FDAの期間が切れている？
・価格幅
	最小価格の３倍以内
・FDAを持っていると書いてはいけない。
	FDAの施設登録
・効果効能を謳ってはいけない

また相談させてください。

※動画内の、
有効なページ数が151になっているのは<@U066P20UQH1> さんが直前に修正してくださったことが理由です。w
:star:️５をキープしてくださって、ありがとうございます！笑
- [1726017741.417049] <@U066P20UQH1>: <@U0331FWGQRM>
MTG確認しました！
まとめてくださり、ありがとうございます:woman-bowing:

ページの更新に関して、基本的には3点警告がきます。
・FDAについての記載NG
・効果効能表現
・価格幅

直近ではFDAと効果効能についての警告が主です。
FDAは文字では謳っていないと思いますが、画像が引っかかっていると思うので、警告がきたページから、FDAが載っている画像を載っていないものに差し替えています。（添付：修正前→修正後）

効果効能表現は先日の指示通り、表現部分の削除をしています。

一気にやると時間かかるので、日々少しずつ、非表示になっているものも上記の変更をしながら再表示していっています。
広告対象ページになっているのは40ページなので、広告対象外ページはパフォーマンスが出づらく、非表示になりやすい傾向があると思いますので、再表示してもパフォーマンスが出なければ再度非表示になる可能性はありますが。。。

いつかに話した、ページの画像の更新や、新たなページの追加なども随時検討してもいいかもしれません・・。

また、FDAの有効期限は切れていなさそうです。
提出済み認証書類の確認ページを添付します：FDA他提出認証書類状況

広告費チャージ検討タイミングは10月末くらいにリマインド依頼されていましたが、
一応タイムツリーにも10/28に入れておきました。

よろしくお願いします！
  - files: [{"id": "F07LVJ50K26", "created": 1726017718, "timestamp": 1726017718, "name": "修正前.jpeg", "title": "修正前.jpeg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 228918, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07LVJ50K26/_________.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07LVJ50K26/download/_________.jpeg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07LVJ50K26-53112af547/__________64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07LVJ50K26-53112af547/__________80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07LVJ50K26-53112af547/__________360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 336, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07LVJ50K26-53112af547/__________480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 448, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07LVJ50K26-53112af547/__________160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07LVJ50K26-53112af547/__________720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 672, "original_w": 750, "original_h": 700, "thumb_tiny": "AwAsADC/Mw2lSxUnuKgWJmbAuJM1ZZQW5FIq7XODx6YqbO4aEHllZBGZpCxGaXyWbIE7gj61Jj983rtH9aemdozjPtTsFiuYGXrcSVNCRsChy/ue9D53HaM8dKELbhuAH0p2AcwPY4/ChQc8n9KJEEiFSSAfSoRaoBjc9ICQp+93gnpjGKeP88VD9lT+81IbWMfxNzQBKy5OeaFXBzz+NQm3jzty/Pep40EaBQSQPWmA6oWTMgbJ47Z4NTVGepoAeowOgH0obtSJ0oc4AIoAAKdUSsc4qWgD/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07LVJ50K26/_________.jpeg", "permalink_public": "https://slack-files.com/T033D70RR6H-F07LVJ50K26-da4d689255", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07LSMSGGSZ", "created": 1726017721, "timestamp": 1726017721, "name": "修正後.png", "title": "修正後.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 558953, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07LSMSGGSZ/_________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07LSMSGGSZ/download/_________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07LSMSGGSZ-1f31207709/__________64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07LSMSGGSZ-1f31207709/__________80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07LSMSGGSZ-1f31207709/__________360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 253, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07LSMSGGSZ-1f31207709/__________480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 338, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07LSMSGGSZ-1f31207709/__________160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07LSMSGGSZ-1f31207709/__________720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 507, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07LSMSGGSZ-1f31207709/__________800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1136, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07LSMSGGSZ-1f31207709/__________960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 676, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07LSMSGGSZ-1f31207709/__________1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 721, "thumb_1024_h": 1024, "original_w": 1232, "original_h": 1750, "thumb_tiny": "AwAwACHTyM4zzUbIWyRIQPQU4gZzzSBQowAeuaAGhGyMyN9KlyPWmFQzA4PHoaVVAJODQA6iiigBD0pqkk84pzfdpq7QflNACsSOmKVeRzSMATycClXpQAtFFFABnFNB+tKaQAjNADXL7sL0p0ZJTkg/SgnnoTSr09KXUYtFFFMR/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07LSMSGGSZ/_________.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07LSMSGGSZ-4b668c99ca", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F07LY33EN2G", "created": 1726017725, "timestamp": 1726017725, "name": "FDA他提出認証書類状況.png", "title": "FDA他提出認証書類状況.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 212093, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07LY33EN2G/fda___________________________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07LY33EN2G/download/fda___________________________.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07LY33EN2G-c9271c9b07/fda____________________________64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07LY33EN2G-c9271c9b07/fda____________________________80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07LY33EN2G-c9271c9b07/fda____________________________360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 219, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07LY33EN2G-c9271c9b07/fda____________________________480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 292, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07LY33EN2G-c9271c9b07/fda____________________________160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07LY33EN2G-c9271c9b07/fda____________________________720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 437, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07LY33EN2G-c9271c9b07/fda____________________________800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 486, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07LY33EN2G-c9271c9b07/fda____________________________960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 583, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07LY33EN2G-c9271c9b07/fda____________________________1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 622, "original_w": 1473, "original_h": 895, "thumb_tiny": "AwAdADC0LaH/AJ5J+VL9khP/ACyX8qkGc0/mgCD7Jb/88V/Kl+yW/wDzxX8qmooAhFrAP+WS/lQbWA/8s1/KpS23Gc80tMBtOptLSAMc0uBSUflQAuBR2pKKAP/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07LY33EN2G/fda___________________________.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07LY33EN2G-c78d43b8d5", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1726018357.113959] <@U0331FWGQRM>: <@U066P20UQH1> cc <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
ありがとうございます！！

&gt; ページの画像の更新や、新たなページの追加なども随時検討してもいいかもしれません・・。
→この件について、金曜日11時のMTGで会話させてください。
　方針、計画の大枠を決められたらと思います。

アリババのページ更新をしていく延長線上で、
ついでにと言ったら変ですが、
攻めの活動（商品追加、新商品開発など）も少し含めて行けたらいいなと思っています。

