# Slack channel: 03_原料仕入れ

## 2022-03-21

- [1647908710.815229] <@U0331FZS7JT>: <@U0331FZS7JT>さんがチャンネルに参加しました
- [1647908711.155549] <@U0331FZS7JT>: がこのチャンネルの説明を「原料の仕入れ着タイミングなどを記載します」に設定しました
- [1647908715.330319] <@U0331FWGQRM>: <@U0331FWGQRM>さんがチャンネルに参加しました
- [1647908715.419859] <@U0331FZTHEK>: <@U0331FZTHEK>さんがチャンネルに参加しました
- [1647908715.477529] <@U033G4KN4TD>: <@U033G4KN4TD>さんがチャンネルに参加しました
- [1647908927.461909] <@U0331FZS7JT>: <@U0331FZTHEK> さん
3/24(木)　抹茶１C（200kg/まるゑい）着
※3/4注文分
※Genuine：summer用

各所と情報共有をしてパッキングの指示等を進めて下さい。

## 2023-07-11

- [1689080303.840399] <@U0331FWGQRM>: チャンネル名を「原料仕入れ」から「03_原料仕入れ」に変更しました

## 2023-07-21

- [1689991524.880459] <@U0331FWGQRM>: <!channel>
鹿児島製茶　鹿児島Aの原料今後出荷が出来ない状態の件について。
このスレッド上で情報更新してください。

・<@U041RJKV5JA> 鹿児島製茶A以外の、　1A, B, C, Dの状況は確認していますか？
・本問題の対応策はいつまでに解決しますか？
∟ 出荷ができない。はただの報告なので、解決してください。
　西製茶の抹茶しか選択肢がないわけではないです。
　他の選択肢もオプションとして検討してください。
・<@U0331FZTHEK> 鹿児島Aを出荷しているお客様のリストがあればください。
　なければ対応するお客様を教えてください。

<@U0331FZS7JT>
下記抹茶は同等ですか？比較検討の余地のある抹茶をチョイス願います。

西製茶　確認中　西製茶の１番茶（碾茶）
碧翠園　国産有機抹茶12000
碧翠園　国産有機抹茶10500
和香園　上12100（25kg 11000)
大石茶園　確認してください
杉本製茶　有機抹茶A（10000）
- [1689995112.994389] <@U0331FZS7JT>: <@U041RJKV5JA> 部長
記載のある各抹茶と有機抹茶Aについて、、、
15時過ぎにに会社に行くので、準備(給湯室の冷蔵庫から出しておいて下さい)をお願いします。

・大石サンプル依頼済
→¥9,000/kg：500kg供給可
→¥7,000/kg：200kg供給可

よろしくお願いします。

- [1690001909.611509] <@U0331FZTHEK>: <@U0331FWGQRM> 執行役
　CC:@channel
 お疲れ様です。
鹿児島Aを出荷しているお客様 は下記2者様です。
（2022年2月～2023年6月）
➀YUKO ONO STHLM AB 様（スウェーデン）
➁Fay Alosaimi 様（サウジアラビア）
よろしくお願いします。
  - files: [{"id": "F05JZ5TKBPA", "created": 1690001796, "timestamp": 1690001796, "name": "有機抹茶A_お客様.pdf", "title": "有機抹茶A_お客様.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FZTHEK", "user_team": "T033D70RR6H", "editable": false, "size": 49528, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05JZ5TKBPA/____________a__________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05JZ5TKBPA/download/____________a__________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F05JZ5TKBPA-2d05277d8d/____________a___________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1286, "thumb_pdf_h": 910, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05JZ5TKBPA/____________a__________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F05JZ5TKBPA-5d578948db", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1690005732.435459] <@U041RJKV5JA>: <@U0331FWGQRM> 執行役
有機抹茶A、B共に確保することが出来ました。
条件として、
・碾茶での納品
・１A用として合組をして送るのはできない。
以下、確保数量になります。
〇有機抹茶A
・碾茶130㎏
＊参考：納品数（期間2022/7/1～2023/6/30）
・１A用-61.5㎏
・A単品-16㎏
 〇有機抹茶１A
・有機碾茶A・Bを自社で合組
 〇有機抹茶B
・碾茶　230㎏
＊参考：納品数（期間2022/7/1～2023/6/30）
・１A用：51.5kg
・B単品：127kg（Olly様は原料変更になりましたので、カウントしておりません）
 〇有機抹茶C
・抹茶200㎏
・碾茶400㎏
 〇有機抹茶D
・現状在庫なし。
	8月下旬から9月初旬頃から供給可能
	 
有機碾茶A、B共に今後取引先が増えることを考え、1年間の実績より多く依頼しております。
今後の為に、他のサプライヤーで代替品として使用できるものがないのか探していきます。
よろしくお願いします。
- [1690008712.355809] <@U0331FZS7JT>: <@U0331FWGQRM> <@U041RJKV5JA> <@U03BLQ65GK0>

鹿児島有機抹茶A代替可能品
※上から品質がより近いもの

①杉本製茶　有機抹茶A（10000）
②碧翠園　国産有機抹茶10500
③西製茶    有機1茶碾茶8,000

①②については誤差レベル
③少し海苔の香りと旨みが強いが、気付くかな？
というもの。水色は１分経たずに同じ。
パウダー色：②が最も近く③、①の順。
①は緑が鮮やかで、有機抹茶Aの少し黄色味がかった色が無い。
滋味・香気：①が最も近く誤差の範囲で②。
水色：①が最も近く誤差の範囲で②。

以上により、
上記３つを代替品として可能と判断。

大石のサンプルについては届き次第別途官能します。

<@U041RJKV5JA>
鹿児島製茶の有機抹茶Aが碾茶仕入れになるということで、碧翠園にも碾茶で仕入れが可能か確認をお願いします。
また、仕入れ原料をまとめている共有フォルダに、上記の件、メモで記載し代替可能なことがわかるようにお願いします。

<@U03BLQ65GK0> ロットで誤差を超える品質差が判明した場合、上記計４つの原料のブレンドでその誤差を埋めて下さい。

よろしくお願いします。
- [1690008758.721919] <@U03BLQ65GK0>: <@U03BLQ65GK0>さんがチャンネルに参加しました

## 2023-07-22

- [1690016445.501579] <@U0331FWGQRM>: <@U0331FZS7JT>
碧翠園　国産有機抹茶10500（聞いている供給可能量は500kgですが。。）
の原料が、鹿児島産も含まれているので、原料の内容としては一番変更が少なく済むかなと思いました。

代替品が見つかってよかったです。
引き続き提案は続けますが、
ケースバイケースですが、原料の産地は下記に変更して
京都、奈良、鹿児島
提案しようと思います。

## 2023-08-01

- [1690935317.663729] <@U041RJKV5JA>: <!channel>
葵製茶　榊原様より納品価格について連絡がありました。
現状の納品価格はMOQ10kgの価格であり、10㎏未満の場合は次回納品分より下記の価格での納品とさせていただきたいとの事です。
MOQ以下でも価格を変えず納品いただいていた理由は、取引量が増えると見込んでいたためとの事でした。
10㎏で仕入れればいいのですが、年間使用量が下記の通りとなっております。
＜1年間の仕入れ数量＞
・西尾の抹茶NA－6㎏
・西尾の抹茶NB－3㎏
・西尾の抹茶NC－8㎏
＜納品金額(㎏)＞（MOQ10㎏~） （10㎏未満）
・西尾の抹茶NA 　10,000円 　　  12,000円
・西尾の抹茶NB       8,000円   　　10,000円
・西尾の抹茶NC       6,000円    　　 8,000円
 また、送料元払いの条件は変わりはございません。（税別5万円以上）
見積書を添付いたしますので、 ご確認お願いいたします。
  - files: [{"id": "F05KUT62NJX", "created": 1690935308, "timestamp": 1690935308, "name": "桃翠園様　ロット割れ時　御見積書.pdf", "title": "桃翠園様　ロット割れ時　御見積書.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 362444, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F05KUT62NJX/________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F05KUT62NJX/download/________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F05KUT62NJX-eb1edfcc16/_________________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1286, "thumb_pdf_h": 910, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F05KUT62NJX/________________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F05KUT62NJX-96c8e1ccdc", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-10-06

- [1696616329.113099] <@U0606SPN4BW>: <@U0606SPN4BW>さんがチャンネルに参加しました

## 2023-11-08

- [1699489362.732609] <@U0331FWGQRM>: <@U041RJKV5JA>
了解です。
&gt; MOQ以下でも価格を変えず納品いただいていた理由は、取引量が増えると見込んでいたためとの事でした。
こういう考えは、勝手に向こうがそのように思い込んでやっていただけで、
（おそらく）こっちが頼んでもないのに、こう言うこと言われると、
なんか嫌な気持ちになりますね！w

## 2023-11-12

- [1699852193.514499] <@U0331FZS7JT>: <@U041RJKV5JA>
CC：<@U05KGS6HN9H> <@U033G4KN4TD>

先日お伝えしていた、オーガニック原料の仕入れ先の候補の
関谷さん宛にターゲットサンプルの送付をお願いします。
-----------
〒880-2113
宮崎県宮崎市小松台北町1-7
tel：<tel:07023672450|070-2367-2450>
関谷祥嗣さま
-----------
よろしくお願いします。
- [1699852198.885959] <@U05KGS6HN9H>: <@U05KGS6HN9H>さんがチャンネルに参加しました

## 2023-12-12

- [1702446188.575099] <@U041RJKV5JA>: <@U0331FWGQRM>
<!channel>
Genuine teaで使用している「鹿児島製茶　有機煎茶1A」ですが、
今回（TSE-048-23）使用分より製造ロット変更の為、納品価格が変更となっております。
旧価格 1,450円/㎏→新価格 1,500円/kg
連絡が遅くなり申し訳ありません。
よろしくお願いいたします。

## 2024-01-11

- [1704976165.204909] <@U0331FWGQRM>: <@U041RJKV5JA> <@U05KGS6HN9H> <@U033G4KN4TD> <@U0331FZS7JT>
ブレンド材を探す件について、
このスレッドで共有できたらと思います。
※重複した調査を避けるため。
よろしくお願いします。

ジンジャー、レモングラス、ペパーミント、シナモン、ターメリック

有機
ジンジャー：キタマ？

非有機
シナモン（ニッキ）
- [1704976294.026359] <@U0331FWGQRM>: 調査先：株式会社大和 / なごみ（楽天ショップ）
<https://nagomi-natulure.jp/businesses/%e5%8d%b8%e5%a3%b2.html>
<https://item.rakuten.co.jp/nagomisabo/peppermint50/>
※上記二つのURLは同じ組織
  - attachments: [{"from_url": "https://nagomi-natulure.jp/businesses/%e5%8d%b8%e5%a3%b2.html", "id": 1, "original_url": "https://nagomi-natulure.jp/businesses/%e5%8d%b8%e5%a3%b2.html", "fallback": "nagomi-NATULURE | なごみナチュルア | 一杯のティーで幸せを: 卸売", "text": "卸売 : 株式会社大和はオーガニックハーブティーのライフスタイルブランド「nagomi-NATULURE」（なごみナチュルア）を通して、我々の価値を皆さまにお届けしています。ＯＥＭ（オリジナル受託製造）商品や飲食店への業務用原料の提案や開発、なごみナチュルアオーガニックハーブティーカフェのフランチャイズ展開をしております。", "title": "卸売", "title_link": "https://nagomi-natulure.jp/businesses/%e5%8d%b8%e5%a3%b2.html", "service_name": "nagomi-NATULURE | なごみナチュルア | 一杯のティーで幸せを"}, {"from_url": "https://item.rakuten.co.jp/nagomisabo/peppermint50/", "service_icon": "https://item.rakuten.co.jp/favicon.ico", "thumb_url": "https://shop.r10s.jp/nagomisabo/cabinet/img_herb/peppermint50.jpg", "thumb_width": 770, "thumb_height": 770, "id": 2, "original_url": "https://item.rakuten.co.jp/nagomisabo/peppermint50/", "fallback": "楽天市場: 【楽天市場】有機JAS オーガニック・ペパーミントティー 50g 【 ハーブティー 無農薬 リーフティー ドライハーブ 茶葉 】：アロマ ルイボスnaturalshopなごみ", "text": "ペパーミント オーガニック・ハーブ。有機JAS オーガニック・ペパーミントティー 50g 【 ハーブティー 無農薬 リーフティー ドライハーブ 茶葉 】", "title": "【楽天市場】有機JAS オーガニック・ペパーミントティー 50g 【 ハーブティー 無農薬 リーフティー ドライハーブ 茶葉 】：アロマ ルイボスnaturalshopなごみ", "title_link": "https://item.rakuten.co.jp/nagomisabo/peppermint50/", "service_name": "楽天市場"}]
- [1704978890.420409] <@U0331FWGQRM>: 調査先：connecto
<https://www.connecto-sales.jp/shop/shopdetail.html?brandcode=000000001880&amp;search=&amp;sort=order>
  - attachments: [{"from_url": "https://www.connecto-sales.jp/shop/shopdetail.html?brandcode=000000001880&search=&sort=order", "thumb_url": "https://makeshop-multi-images.akamaized.net/connecto/itemimages/000000001880_rBlCPPd.jpg", "thumb_width": 1000, "thumb_height": 1000, "id": 1, "original_url": "https://www.connecto-sales.jp/shop/shopdetail.html?brandcode=000000001880&amp;search=&amp;sort=order", "fallback": "業務用ハーブのコネクト: シナモン茶葉400g-業務用ハーブのコネクト", "text": "気温の変化にも負けないカラダ作りをサポート\n\nスパイシーな風味が、からだの芯から活力が沸いてくるようなイメージです。\n\nぽかぽか温まりたい時や、フルーティーなハーブティーへの\nトッピングハーブとしてもおすすめです。\n\n・（学名）Cinnamomum cassia\n・（科目）クスノキ科\n・（使用部位）樹皮\n・（別名）カシア、ニッケイ、ニッキ、ケイヒ\n\n風味奥に甘味のある、ウッディでスパイシーな香りと味\n\n原材料シナモン（樹皮）\n\n内容量茶葉400ｇ\n\n賞味期限賞味期限まで1年半以上ある商品をお届けします\n\n美味しい淹れ方ティーカップ1杯（200cc）に対し、大さじすりきり1杯（約7g）のシナモンが適量です。\n\n保存方法高温多湿を避け冷暗所で保存してください。高温になりやすい夏場、営業時間と営業時間外で室温の変化がある時期などは冷蔵庫（または冷凍庫）での保存をおすすめします。", "title": "シナモン茶葉400g-業務用ハーブのコネクト", "title_link": "https://www.connecto-sales.jp/shop/shopdetail.html?brandcode=000000001880&search=&sort=order", "service_name": "業務用ハーブのコネクト"}]
- [1704988097.794289] <@U0331FWGQRM>: 調査先：有限会社ミサキファーム
<http://www.misakifarm.com/organicherb.html>
- [1705016272.205459] <@U041RJKV5JA>: <@U0331FWGQRM>
 <@U0331FZS7JT> <@U05KGS6HN9H> <@U033G4KN4TD>
現状で揃えることが可能な原料は下記となります。
よろしくお願いいたします。
＜有機＞
・ジンジャー：島根有機ファーム
・レモングラス：島根有機ファーム
＜非有機＞
・シナモン（ニッキ）：キタマ
・ターメリック：福田龍、丸菱、鈴木㈱

## 2024-01-12

- [1705049502.096019] <@U041RJKV5JA>: <@U0331FWGQRM>
 <@U0331FZS7JT> <@U05KGS6HN9H> <@U033G4KN4TD>
＜イギリス向けに使用する有機原料について＞
・日本と有機同等性を結んでいる国から仕入れた有機原料と、国内産有機原料を混ぜて有機格付けを行いイギリスへ輸出は可能。
・原料として仕入れる場合は、輸入の有機認定業者の資格は無くても良い。
・イギリスと原料仕入れ国が有機同等性を結んでいなくても可。
　2024年1月12日　島根有機農業協会　米田様確認（電話）

## 2024-01-15

- [1705363974.124989] <@U0331FZS7JT>: <@U041RJKV5JA>
<@U0331FWGQRM> <@U033G4KN4TD> <@U05KGS6HN9H>

下記原料で製造したブレンド抹茶の品質確認をしたいのですが
ブレンド原料は手元にありますか？

＜有機＞
・ジンジャー：島根有機ファーム
・レモングラス：島根有機ファーム（発送できるため不要）
＜非有機＞５％でテスト
・シナモン（ニッキ）：キタマ
・ターメリック：福田龍、丸菱、鈴木㈱
- [1705364400.036179] <@U041RJKV5JA>: <@U0331FZS7JT>
 <@U0331FWGQRM> <@U05KGS6HN9H> <@U033G4KN4TD>
手元にあるのは、ジンジャーとレモングラスになります。
シナモン（ニッキ）とターメリックはサンプル手配中となります。
入荷次第ご連絡いたします。
- [1705365527.932869] <@U0331FZS7JT>: <@U041RJKV5JA>
<@U0331FWGQRM> <@U033G4KN4TD> <@U05KGS6HN9H>

ジンジャーが手元にあるのであれば試しましょう。
ターゲット製品とそれぞれの原料の準備をお願いします。

## 2024-02-01

- [1706835031.290879] <@U041RJKV5JA>: <!channel>
鹿児島製茶　田里様より有機煎茶を新たにご提案いただきました。
＜新規商品＞
・有機煎茶40号
・有機煎茶28号
取扱商品一覧表に追記しております。
よろしくお願いいたします。
- [1706840114.144069] <@U041RJKV5JA>: <@U0331FWGQRM>
 <@U0331FZS7JT> <@U0606SPN4BW> <@U05KGS6HN9H> <@U033G4KN4TD>
下記サンプルが入荷しました。
・かごしま有機生産組合：有機春ウコンパウダー、有機蒸し生姜パウダー
・キタマ：シナモンの根（こちらを粉砕してパウダーにしてくださいとの事です。皮の部分は無いのか確認いただいております。）
　　　　　粉砕後、品質確認いたします。
  - files: [{"id": "F06GE5SK5RD", "created": 1706840067, "timestamp": 1706840067, "name": "DSC_3372.jpg", "title": "DSC_3372.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 4064856, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06GE5SK5RD/dsc_3372.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06GE5SK5RD/download/dsc_3372.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F06GE5SK5RD-3d94e0fc44/dsc_3372_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F06GE5SK5RD-3d94e0fc44/dsc_3372_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F06GE5SK5RD-3d94e0fc44/dsc_3372_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 270, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F06GE5SK5RD-3d94e0fc44/dsc_3372_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 360, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F06GE5SK5RD-3d94e0fc44/dsc_3372_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F06GE5SK5RD-3d94e0fc44/dsc_3372_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 540, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F06GE5SK5RD-3d94e0fc44/dsc_3372_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1067, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F06GE5SK5RD-3d94e0fc44/dsc_3372_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 720, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F06GE5SK5RD-3d94e0fc44/dsc_3372_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 768, "thumb_1024_h": 1024, "original_w": 3120, "original_h": 4160, "thumb_tiny": "AwAwACSqozwevakqZRzxTWX5aAI6cCRTtmKXbSAZmjNOxS49qAH9FBoOCtIxyKjZs0wHBuacOlM6DNPTkUAJRTzScelADWNRZxiptjehprIc9MUWC40NxipIsHHNR+Ww/wDrVLHlR90iiwXJGXBpNtTFg2D7UmRSA//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06GE5SK5RD/dsc_3372.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F06GE5SK5RD-56456ea053", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F06H7BX8LHF", "created": 1706840075, "timestamp": 1706840075, "name": "DSC_3373.jpg", "title": "DSC_3373.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 3391077, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06H7BX8LHF/dsc_3373.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06H7BX8LHF/download/dsc_3373.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F06H7BX8LHF-eaab671d99/dsc_3373_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F06H7BX8LHF-eaab671d99/dsc_3373_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F06H7BX8LHF-eaab671d99/dsc_3373_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F06H7BX8LHF-eaab671d99/dsc_3373_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F06H7BX8LHF-eaab671d99/dsc_3373_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F06H7BX8LHF-eaab671d99/dsc_3373_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F06H7BX8LHF-eaab671d99/dsc_3373_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F06H7BX8LHF-eaab671d99/dsc_3373_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F06H7BX8LHF-eaab671d99/dsc_3373_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 4160, "original_h": 3120, "thumb_tiny": "AwAkADCr5T+gH1IpfJb1X86vqw2A4GCM807fxgKtC1EZhjfdgDP0ppBU4YEH3rRc8HgZpSMnkA/WlcZm5ozWkAoH3R19KTjHQflTAE/1ajjGBTiPQ4psePKQ98CnVndgJJkRn1xQaR+UIzjigsoP3h+dVEBf5Y9aaQCp5w3saQyLn7wH407Kn7pBz71VxmeZ5Dxux9KcssmPvt+dQmnr92mkSxzSuy4LEg1EeDT+1MbrQCDvUir3yaj71MvSpZSP/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06H7BX8LHF/dsc_3373.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F06H7BX8LHF-722865174b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F06H7BXTZJM", "created": 1706840087, "timestamp": 1706840087, "name": "納品書　かごしま有機生産組合.pdf", "title": "納品書　かごしま有機生産組合.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 38354, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06H7BXTZJM/__________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06H7BXTZJM/download/__________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F06H7BXTZJM-b39ce15edf/___________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06H7BXTZJM/__________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F06H7BXTZJM-2794e6d288", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-03-27

- [1711607462.743959] <@U041RJKV5JA>: <@U0331FZS7JT> <@U0331FWGQRM>
和香園様より製造スケジュールを決めたい為、抹茶44、抹茶１Bの年間必要量の提示を求められております。
年間実績（2023年3月24日～2024年3月23日）は下記の通りです。
ご確認お願いいたします。
 【抹茶44】
・年間使用実績　8256㎏
内訳：Genuine Tea 3,631㎏、GB向け 4,625㎏
【抹茶1B】
・年間使用実績　354㎏
内訳：Olly 250kg、Genuine Tea 94kg

## 2024-04-02

- [1712052336.593169] <@U0331FZS7JT>: <@U041RJKV5JA>
<@U0331FWGQRM>

抹茶44については昨年同様でお願いします。
※Purechimpはこの先わかりませんが
　Genuineが船便数回あるかもということもあるので
　同じぐらいとお伝えください。

抹茶１Bについては
量が増えるかもしれません。
Ollyさんも兆しが良さそうなところと
Genuineについても船便があるということが理由です。
念の為倍量の確保をお願いしますとお伝えください。

## 2024-06-30

- [1719814658.064369] <@U041RJKV5JA>: <!channel>
鹿児島製茶より有機碾茶Aの納品価格改定の連絡がございました。
現状7750円→改定後8100円
また、有機抹茶は全て碾茶での納品となります。
理由は、粉砕作業が立て込んでおり、新たな依頼を受けることが出来ない為です。
取扱商品一覧表の価格を変更しております。
よろしくお願いいたします。
- [1719815215.219799] <@U0331FZS7JT>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
であれば、ある程度事前に仕入れて、粉砕して在庫しなければなりませんね。
抹茶原価も変更になると思うのでそちらの反映もお願いします。
例)有機抹茶A¥9,000/kg→¥8,482/kg(8,100/0.99+300)

## 2024-07-05

- [1720167603.944839] <@U041RJKV5JA>: <!channel>
丸菱より国産玄米の価格改定の連絡がございました。
８月より下記価格となります。
・並玄米　240円→340円
・並玄米塩入　280円→380円
・上A玄米　340円→440円
・特上子玄米　460円→510円
＊キロ単価となります。
ご確認よろしくお願いいたします。

## 2024-12-23

- [1734940895.551859] <@U05KGS6HN9H>: <!channel>
大石茶園より八女抹茶50の価格改定連絡が入りました。
◆現状5000円 → 改定後6500円
※八女抹茶F（あじさい代替品）で70%配合に使用している原料です。
※2025年2月1日伝票日付より改定
ご確認のほどお願い申し上げます。
  - files: [{"id": "F0861GQLCNS", "created": 1734940884, "timestamp": 1734940884, "name": "20241223_八女抹茶50価格改定.pdf", "title": "20241223_八女抹茶50価格改定.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 190990, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0861GQLCNS/20241223_____________50____________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0861GQLCNS/download/20241223_____________50____________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0861GQLCNS-f87bcb3587/20241223_____________50_____________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 910, "thumb_pdf_h": 1287, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0861GQLCNS/20241223_____________50____________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F0861GQLCNS-ec42b1c12e", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-01-29

- [1738196198.497529] <@U08BA1AGC0H>: <@U08BA1AGC0H>さんがチャンネルに参加しました

## 2025-02-06

- [1738853690.309199] <@U08BA1AGC0H>: <@U08BA1AGC0H>さんがチャンネルに参加しました

## 2025-03-31

- [1743469670.038579] <@U08L89G6JSG>: <@U08L89G6JSG>さんがチャンネルに参加しました

## 2025-08-20

- [1755674408.682089] <@U0840UVFVA8>: <@U0840UVFVA8>さんがチャンネルに参加しました
- [1755674888.718219] <@U08U8MMTH43>: <@U08U8MMTH43>さんがチャンネルに参加しました

