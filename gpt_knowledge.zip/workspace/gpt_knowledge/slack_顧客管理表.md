# Slack channel: 顧客管理表

## 2024-08-09

- [1723259084.326439] <@U066P20UQH1>: <@U066P20UQH1>さんがチャンネルに参加しました
- [1723259117.561639] <@U066P20UQH1>: <!channel>
顧客管理表について、何かあればこちらのチャンネルへご連絡ください！
- [1723259142.851179] <@U0331FWGQRM>: <@U0331FWGQRM>さんがチャンネルに参加しました
- [1723259142.931679] <@U0331FZS7JT>: <@U0331FZS7JT>さんがチャンネルに参加しました
- [1723259142.996069] <@U0331FZTHEK>: <@U0331FZTHEK>さんがチャンネルに参加しました
- [1723259143.067919] <@U033G4KN4TD>: <@U033G4KN4TD>さんがチャンネルに参加しました
- [1723259143.170559] <@U03BLQ65GK0>: <@U03BLQ65GK0>さんがチャンネルに参加しました
- [1723259143.402919] <@U041RJKV5JA>: <@U041RJKV5JA>さんがチャンネルに参加しました
- [1723259143.488309] <@U05KGS6HN9H>: <@U05KGS6HN9H>さんがチャンネルに参加しました
- [1723259143.557599] <@U0606SPN4BW>: <@U0606SPN4BW>さんがチャンネルに参加しました
- [1723259197.149329] <@U066P20UQH1>: :mega:　*受注登録更新*
- [1723259274.164519] <@U066P20UQH1>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
受注登録U列「ラベル表示」を追加しました。
主にサンプルラベル表示の価格についての指示を書く欄としてご利用ください。
自由記入で良いと思いますが、Quotationファイル名などがわかりやすいかと思います。

よろしくお願いいたします！
- [1723259367.091419] <@U066P20UQH1>: :mega:　*invoiceメモ更新*
- [1723259413.299849] <@U066P20UQH1>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
現在4つ目の部屋にブレンド用を構築中です。
完成したらお知らせいたします:woman-bowing:
- [1723268190.874639] <@U066P20UQH1>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
invoiceメモ〜Excel invoiceへの転記の流れを5分くらいで画面収録したので是非ご確認ください。
  - files: [{"id": "F07H1JM862U", "created": 1723268154, "timestamp": 1723268154, "name": "invoiceメモ〜Excel invoiceの活用の流れ.mp4", "title": "invoiceメモ〜Excel invoiceの活用の流れ.mp4", "mimetype": "video/mp4", "filetype": "mp4", "pretty_type": "MPEG 4 Video", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 138525020, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F07H1JM862U-3127532dc0/invoice_________excel_invoice__________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F07H1JM862U-3127532dc0/invoice_________excel_invoice__________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07H1JM862U/download/invoice_________excel_invoice__________________.mp4?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F07H1JM862U-3127532dc0/file.m3u8?_xcb=d627a&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F07H1JM862U-3127532dc0/invoice_________excel_invoice___________________trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 284751, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F07H1JM862U-3127532dc0/invoice_________excel_invoice___________________thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 1920, "thumb_video_h": 1080, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07H1JM862U/invoice_________excel_invoice__________________.mp4", "permalink_public": "https://slack-files.com/T033D70RR6H-F07H1JM862U-c7b7b52431", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-10-03

- [1727940801.050949] <@U066P20UQH1>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
主にサンプル案件で受注登録のシート記入時に金額がUSD0のままになっている案件がちらほらあります。
入力ルールは特にありませんが、入力漏れがあるような気がするので、入金の有無に限らず、請求金額を記入ください。
もし未入金→キャンセルとなった場合は行ごと取り消し線で、AA列にキャンセル経緯などをご記載ください。
USD0というフィルタを作成したので、そこから該当の案件の修正をお願いします。（皆様のお手隙で大丈夫です）
よろしくお願いします！
- [1727941193.235399] <@U066P20UQH1>: 
  - files: [{"id": "F07QK7LMMRP", "created": 1727941188, "timestamp": 1727941188, "name": "スクリーンショット 2024-10-03 16.33.45.png", "title": "スクリーンショット 2024-10-03 16.33.45.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 310249, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07QK7LMMRP/____________________________2024-10-03_16.33.45.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07QK7LMMRP/download/____________________________2024-10-03_16.33.45.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07QK7LMMRP-bd57b929aa/____________________________2024-10-03_16.33.45_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07QK7LMMRP-bd57b929aa/____________________________2024-10-03_16.33.45_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07QK7LMMRP-bd57b929aa/____________________________2024-10-03_16.33.45_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 202, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07QK7LMMRP-bd57b929aa/____________________________2024-10-03_16.33.45_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 270, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07QK7LMMRP-bd57b929aa/____________________________2024-10-03_16.33.45_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07QK7LMMRP-bd57b929aa/____________________________2024-10-03_16.33.45_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 405, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07QK7LMMRP-bd57b929aa/____________________________2024-10-03_16.33.45_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 450, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F07QK7LMMRP-bd57b929aa/____________________________2024-10-03_16.33.45_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 540, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F07QK7LMMRP-bd57b929aa/____________________________2024-10-03_16.33.45_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 576, "original_w": 1375, "original_h": 773, "thumb_tiny": "AwAaADDQx7ClwKiKMTnzXAPak2Pj/XP+lMRNn3oz71DtfGfNelCOf+Wr0WAl/GgDd74qJUb/AJ6tUwpDGelRSyrCqlgTk9qk7Cqt/wD6uP6mk9ioJOVmWByoNPH9aYP9WPpTh0qiegDp+FLnAzTe1OP3aQj/2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07QK7LMMRP/____________________________2024-10-03_16.33.45.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07QK7LMMRP-451155bcd9", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1727965147.505709] <@U0606SPN4BW>: <@U066P20UQH1>
「企業コードの重複チェック機能」のセルが見当たらなくなりました:sweat_drops:
（Ctrl+F で重複チェックはできていますので支障はないです)
お手数ですが、ご確認よろしくお願いします！
  - files: [{"id": "F07QM6R2Y8Z", "created": 1727964887, "timestamp": 1727964887, "name": "image.png", "title": "image.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0606SPN4BW", "user_team": "T033D70RR6H", "editable": false, "size": 81554, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07QM6R2Y8Z/image.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07QM6R2Y8Z/download/image.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07QM6R2Y8Z-f8b52792c4/image_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07QM6R2Y8Z-f8b52792c4/image_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07QM6R2Y8Z-f8b52792c4/image_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 229, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F07QM6R2Y8Z-f8b52792c4/image_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 305, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07QM6R2Y8Z-f8b52792c4/image_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F07QM6R2Y8Z-f8b52792c4/image_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 458, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F07QM6R2Y8Z-f8b52792c4/image_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 509, "original_w": 813, "original_h": 517, "thumb_tiny": "AwAeADDQ2D0z9aNvtTJDKG+Tbj3FNLTjvH+RoCxNtx2owark3OeqflSj7SO6H8KB2LHNHPoKr7rj1j/I0m657+X+RoCxM3akbpSt1pG6UmAoUmnUzIB704MDQgG96Xb9fyoHem0Af//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07QM6R2Y8Z/image.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07QM6R2Y8Z-6a74ee3a97", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1727965240.142269] <@U066P20UQH1>: <@U0606SPN4BW> アナウンスしておらずすみません:sweat_drops:重複したら入力したセルが赤くなるように設定を変更しました！ためしに既存コードを新規入力時に入れてみてくださいっ
- [1727965316.370569] <@U0606SPN4BW>: <@U066P20UQH1>
おおっ！便利にアップデートされたのですね、ありがとうございますっ！＾＾
  - files: [{"id": "F07Q5MD711T", "created": 1727965278, "timestamp": 1727965278, "name": "image.png", "title": "image.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0606SPN4BW", "user_team": "T033D70RR6H", "editable": false, "size": 13861, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F07Q5MD711T/image.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F07Q5MD711T/download/image.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F07Q5MD711T-2c1c5df5a5/image_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F07Q5MD711T-2c1c5df5a5/image_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F07Q5MD711T-2c1c5df5a5/image_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 138, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F07Q5MD711T-2c1c5df5a5/image_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "original_w": 415, "original_h": 159, "thumb_tiny": "AwASADC+3U8Dr7ULjFLwSeTQQAp60DEbGG9aYp9Bmoo1k3rvwB3w1WQoHrUsBN2OMD86A2TjaM/Wnce9HHvTAF+81ONNX7zU6mIKKKKACiiigD//2Q==", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F07Q5MD711T/image.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F07Q5MD711T-b36d49066d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2024-11-25

- [1732586485.741879] <@U066P20UQH1>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
invoiceフォーマットを更新しました。
格納場所：標準 &gt; invoice, quotation &gt; invoice &gt; *invoice241126*
顧客管理表のinvoiceメモと連携して活用ください。

以下書類準備の費用を請求項目に入れています。
・植物検疫（USD10）
・原産地証明書or第一種特定原産地証明書（USD10）
・衛生証明（USD10）
・自由販売証明（USD10）
・有機同等性証明（COI or NOP）（USD50）

その他必要な項目があれば教えてください。

上記について、
請求額が10万円以上の顧客に対しては請求しなくてもOK
既存顧客においては関係性によって判断
という共通認識をもてればと思います。

フォーマット不備、Windowsとの互換性による不備などあれば個別でも構いませんのでご連絡ください。
あるいはもっとこうして欲しいなどの要望もあればください。
よろしくお願いします:woman-bowing:
  - files: [{"id": "F0828RXAY6S", "created": 1732586479, "timestamp": 1732586479, "name": "invoice241126.xlsx", "title": "invoice241126.xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 169050, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0828RXAY6S/invoice241126.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0828RXAY6S/download/invoice241126.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0828RXAY6S-8d4e602d7a/invoice241126_converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0828RXAY6S-8d4e602d7a/invoice241126_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0828RXAY6S/invoice241126.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F0828RXAY6S-ba6ab154e7", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-01-13

- [1736815012.536449] <@U0331FWGQRM>: <@U066P20UQH1> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
今日の顧客管理表のMTGですが、13:00からに変更して頂けますか？
参加可否だけ教えてください。

内容は顧客管理表の運用してみて、のフィードバックにしたいです。
（まだ使ってなくてもOKです。）
会議室に集まると面倒だと思うので、
各自の席からハドルMTGかGoogleMeetで行いましょう。
宜しくお願い致します。
- [1736824048.514689] <@U0331FWGQRM>: <@U066P20UQH1> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
レスポンスください！！！
- [1736824768.545099] <@U033G4KN4TD>: <@U0331FWGQRM>
遅くなり申し訳ございません。
福井13時から参加します。
- [1736824939.598249] <@U041RJKV5JA>: <@U0331FWGQRM>
連絡が遅くなり申し訳ございません。
参加いたします。
- [1736825337.120879] <@U066P20UQH1>: <@U0331FWGQRM>
遅くなりすみません:sweat_drops: 参加します
- [1736825969.924189] <@U05KGS6HN9H>: 連絡遅くなり、すみません。参加致します。
- [1736827182.353379] <@U0331FWGQRM>: <@U066P20UQH1> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
<https://meet.google.com/mjq-uqqd-ycf>
  - attachments: [{"from_url": "https://meet.google.com/mjq-uqqd-ycf", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "id": 1, "original_url": "https://meet.google.com/mjq-uqqd-ycf", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/mjq-uqqd-ycf", "service_name": "meet.google.com"}]
- [1736833507.542799] <@U0331FWGQRM>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
今日はありがとうございました。
・在庫管理、製造指示書、invoiceメモ、周りの整備
・フォルダの整備
を一旦、<@U066P20UQH1> <@U0331FWGQRM> で進めますので、ある程度整ってきしだい、改めてMTGを設定しますので、それまでお待ちください。
（なので、来週以降のmtgは参加不要です）
宜しくお願いします。

## 2025-02-21

- [1740182410.404329] <@U0331FWGQRM>: <@U066P20UQH1>
スプシ顧客管理表の会社情報登録の一番右に
　製造指示書用メモ
の列を追加してもらえます？？
- [1740182687.535809] <@U066P20UQH1>: <@U0331FWGQRM>
追加しましたのでご確認ください:woman-bowing:
  - files: [{"id": "F08EB8B88P8", "created": 1740182674, "timestamp": 1740182674, "name": "スクリーンショット 2025-02-22 9.04.24.png", "title": "スクリーンショット 2025-02-22 9.04.24.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 121596, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08EB8B88P8/____________________________2025-02-22_9.04.24.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08EB8B88P8/download/____________________________2025-02-22_9.04.24.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08EB8B88P8-9ae5fc6f3b/____________________________2025-02-22_9.04.24_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08EB8B88P8-9ae5fc6f3b/____________________________2025-02-22_9.04.24_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08EB8B88P8-9ae5fc6f3b/____________________________2025-02-22_9.04.24_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 110, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08EB8B88P8-9ae5fc6f3b/____________________________2025-02-22_9.04.24_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 146, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08EB8B88P8-9ae5fc6f3b/____________________________2025-02-22_9.04.24_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08EB8B88P8-9ae5fc6f3b/____________________________2025-02-22_9.04.24_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 219, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08EB8B88P8-9ae5fc6f3b/____________________________2025-02-22_9.04.24_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 244, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08EB8B88P8-9ae5fc6f3b/____________________________2025-02-22_9.04.24_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 292, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08EB8B88P8-9ae5fc6f3b/____________________________2025-02-22_9.04.24_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 312, "original_w": 1393, "original_h": 424, "thumb_tiny": "AwAOADC6XwceU/1GOaQSntDJ+lPbqKAPagY3ziP+WUn6Uec3/PGT9Kc3X8KcOlAERkJ/5YSfpQZiAcwyY7nipqZL/qn/AN00Af/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08EB8B88P8/____________________________2025-02-22_9.04.24.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F08EB8B88P8-5cb3a604f1", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-02-22

- [1740213803.863329] <@U066P20UQH1>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> cc: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
顧客管理表の商品情報とExcelに直接入力する内容が異なることがないように、
商品情報から包装資材などの情報もExcelにコピペで反映できるようにしました。
実際にコピペするまでの作業を画面録画しましたので、ご確認よろしくお願いいたします。
Excelにコピペ後、直接Excelを編集することがあるかもしれませんが、顧客管理表と情報が変わる場合は顧客管理表の更新もするようにお願いいたします:woman-bowing:
  - files: [{"id": "F08EKCETJLS", "created": 1740213756, "timestamp": 1740213756, "name": "20250222_invoice更新.mov", "title": "20250222_invoice更新.mov", "mimetype": "video/quicktime", "filetype": "mov", "pretty_type": "QuickTime Movie", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 73850577, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F08EKCETJLS-d5d008a691/20250222_invoice______.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F08EKCETJLS-d5d008a691/20250222_invoice______.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08EKCETJLS/download/20250222_invoice______.mov?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F08EKCETJLS-d5d008a691/file.m3u8?_xcb=608b6&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTY3MzUzMSxBVkVSQUdFLUJBTkRXSURUSD0xMTg2Mjk4LENPREVDUz0iYXZjMS42NDAwMjgsbXA0YS40MC41IixSRVNPTFVUSU9OPTE5MjB4MTA4MCxGUkFNRS1SQVRFPTI5Ljk3MApkYXRhOmFwcGxpY2F0aW9uL3ZuZC5hcHBsZS5tcGVndXJsO2Jhc2U2NCxJMFZZVkUwelZRb2pSVmhVTFZndFZrVlNVMGxQVGpvekNpTkZXRlF0V0MxVVFWSkhSVlJFVlZKQlZFbFBUam8zQ2lORldGUXRXQzFOUlVSSlFTMVRSVkZWUlU1RFJUb3hDaU5GV0ZRdFdDMVFURUZaVEVsVFZDMVVXVkJGT2xaUFJBb2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSVXREUlZSS1RGTXRaRFZrTURBNFlUWTVNUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01TNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UlV0RFJWUktURk10WkRWa01EQTRZVFk1TVM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNaTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFJVdERSVlJLVEZNdFpEVmtNREE0WVRZNU1TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TXk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSVXREUlZSS1RGTXRaRFZrTURBNFlUWTVNUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd05DNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UlV0RFJWUktURk10WkRWa01EQTRZVFk1TVM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFJVdERSVlJLVEZNdFpEVmtNREE0WVRZNU1TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3Tmk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSVXREUlZSS1RGTXRaRFZrTURBNFlUWTVNUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd055NTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UlV0RFJWUktURk10WkRWa01EQTRZVFk1TVM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdPQzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFJVdERSVlJLVEZNdFpEVmtNREE0WVRZNU1TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3T1M1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSVXREUlZSS1RGTXRaRFZrTURBNFlUWTVNUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE1DNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UlV0RFJWUktURk10WkRWa01EQTRZVFk1TVM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXhNUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFJVdERSVlJLVEZNdFpEVmtNREE0WVRZNU1TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF4TWk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSVXREUlZSS1RGTXRaRFZrTURBNFlUWTVNUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE15NTBjd29qUlZoVVNVNUdPakl1TURNMUxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UlV0RFJWUktURk10WkRWa01EQTRZVFk1TVM5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXhOQzUwY3dvalJWaFVMVmd0UlU1RVRFbFRWQW89Cg==", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F08EKCETJLS-d5d008a691/20250222_invoice_______trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 80113, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F08EKCETJLS-d5d008a691/20250222_invoice_______thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 1920, "thumb_video_h": 1080, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08EKCETJLS/20250222_invoice______.mov", "permalink_public": "https://slack-files.com/T033D70RR6H-F08EKCETJLS-e3f1a531e0", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1740213824.925849] <@U082RF7UF1V>: <@U082RF7UF1V>さんがチャンネルに参加しました
- [1740213825.128089] <@U0840UVFVA8>: <@U0840UVFVA8>さんがチャンネルに参加しました

## 2025-03-05

- [1741225669.196879] <@U066P20UQH1>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
*会社情報登録　AB列　に　2025年5月（6月？）からの値上げ予想に向けてお客さんに伝えたかどうかを記録する欄を作りました*のでご活用ください！:raised_hands:
プルダウン式にしていて、伝えていなければ選択なし。伝えていれば（合意）か（抵抗）を選択し、必要に応じてAC列のメモに詳細を記録していただければと思います。
（プルダウンにもっといい案があれば、修正していただいて全く問題ないです:pray:）
よろしくお願いします！
- [1741227590.044309] <@U066P20UQH1>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
会社情報登録　AA列　に　*産地・品種要望があるお客様についての記載欄*を設けました！
様々なパターンがあると思いますので、自由記載としております。随時追記していただければと思います。:pray:
- [1741229489.446079] <@U066P20UQH1>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> cc: <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
*小分け製造指示書シートが追加されています！*
受注内容と商品内容から製造に必要な情報を引用するようになっています。
小分け製造指示書作成の時間短縮が目的です。ぜひご利用ください！
*商品登録の項目をこれに合わせて少し増やしているので、気づいた時に更新してください。*（これは営業サイドでの対応になると思います）

なお、すでにご利用されていると思いますが、想定利用フローを画面収録したので添付します。（1分半程度なのでよければおめど押しください:pray:）

より使いやすい方法や、必要な項目・不要な項目などご意見があればお待ちしております:woman-bowing:
ご確認よろしくお願いいたします！
  - files: [{"id": "F08GQ8NFY3B", "created": 1741228393, "timestamp": 1741228393, "name": "小分け製造指示書作成フロー.mov", "title": "小分け製造指示書作成フロー.mov", "mimetype": "video/quicktime", "filetype": "mov", "pretty_type": "QuickTime Movie", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 70301875, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F08GQ8NFY3B-24e743c2b9/_______________________________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F08GQ8NFY3B-24e743c2b9/_______________________________________.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08GQ8NFY3B/download/_______________________________________.mov?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F08GQ8NFY3B-24e743c2b9/file.m3u8?_xcb=6558a&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTU3MTExMSxBVkVSQUdFLUJBTkRXSURUSD0xMDg5NDc3LENPREVDUz0iYXZjMS42NDAwMjgsbXA0YS40MC41IixSRVNPTFVUSU9OPTE5MjB4MTA4MCxGUkFNRS1SQVRFPTI5Ljk3MApkYXRhOmFwcGxpY2F0aW9uL3ZuZC5hcHBsZS5tcGVndXJsO2Jhc2U2NCxJMFZZVkUwelZRb2pSVmhVTFZndFZrVlNVMGxQVGpvekNpTkZXRlF0V0MxVVFWSkhSVlJFVlZKQlZFbFBUam8zQ2lORldGUXRXQzFOUlVSSlFTMVRSVkZWUlU1RFJUb3hDaU5GV0ZRdFdDMVFURUZaVEVsVFZDMVVXVkJGT2xaUFJBb2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSMUU0VGtaWk0wSXRNalJsTnpRell6SmlPUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01TNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UjFFNFRrWlpNMEl0TWpSbE56UXpZekppT1M5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNaTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFIxRTRUa1paTTBJdE1qUmxOelF6WXpKaU9TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TXk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSMUU0VGtaWk0wSXRNalJsTnpRell6SmlPUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd05DNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UjFFNFRrWlpNMEl0TWpSbE56UXpZekppT1M5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFIxRTRUa1paTTBJdE1qUmxOelF6WXpKaU9TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3Tmk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSMUU0VGtaWk0wSXRNalJsTnpRell6SmlPUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd055NTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UjFFNFRrWlpNMEl0TWpSbE56UXpZekppT1M5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdPQzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFIxRTRUa1paTTBJdE1qUmxOelF6WXpKaU9TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3T1M1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSMUU0VGtaWk0wSXRNalJsTnpRell6SmlPUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE1DNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UjFFNFRrWlpNMEl0TWpSbE56UXpZekppT1M5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXhNUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFIxRTRUa1paTTBJdE1qUmxOelF6WXpKaU9TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF4TWk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSMUU0VGtaWk0wSXRNalJsTnpRell6SmlPUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE15NTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UjFFNFRrWlpNMEl0TWpSbE56UXpZekppT1M5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXhOQzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFIxRTRUa1paTTBJdE1qUmxOelF6WXpKaU9TOW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF4TlM1MGN3b2pSVmhVU1U1R09qTXVNRE0yTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSMUU0VGtaWk0wSXRNalJsTnpRell6SmlPUzltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE5pNTBjd29qUlZoVUxWZ3RSVTVFVEVsVFZBbz0K", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F08GQ8NFY3B-24e743c2b9/________________________________________trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 93126, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F08GQ8NFY3B-24e743c2b9/________________________________________thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 1920, "thumb_video_h": 1080, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08GQ8NFY3B/_______________________________________.mov", "permalink_public": "https://slack-files.com/T033D70RR6H-F08GQ8NFY3B-f8d4c14ff6", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-03-06

- [1741305355.483249] <@U066P20UQH1>: <!channel>
*フィルターの使い方*
顧客管理表を利用する際に、フィルターをかけるのが便利です！
使い方の例を画面収録したのでぜひ参考までにご覧ください。:pray:（1分半程度です）
基本的には*電卓のようなマークからフィルターを作成してください。*左隣のフィルターマークは、全員にフィルターが反映されてしまうので、*基本的には自分用のフィルタを作ってご利用ください。*
また、フィルタはずっと使用していると表示がおかしくなることがあるので、定期的に作成し直すことをお勧めします:pray:
よろしくお願いいたします！
  - files: [{"id": "F08GWMH8DC1", "created": 1741305240, "timestamp": 1741305240, "name": "スクリーンショット 2025-03-07 7.45.46.png", "title": "スクリーンショット 2025-03-07 7.45.46.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 421531, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08GWMH8DC1/____________________________2025-03-07_7.45.46.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08GWMH8DC1/download/____________________________2025-03-07_7.45.46.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08GWMH8DC1-9f42d5d53f/____________________________2025-03-07_7.45.46_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08GWMH8DC1-9f42d5d53f/____________________________2025-03-07_7.45.46_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08GWMH8DC1-9f42d5d53f/____________________________2025-03-07_7.45.46_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 120, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08GWMH8DC1-9f42d5d53f/____________________________2025-03-07_7.45.46_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 160, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08GWMH8DC1-9f42d5d53f/____________________________2025-03-07_7.45.46_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08GWMH8DC1-9f42d5d53f/____________________________2025-03-07_7.45.46_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 241, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08GWMH8DC1-9f42d5d53f/____________________________2025-03-07_7.45.46_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 267, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08GWMH8DC1-9f42d5d53f/____________________________2025-03-07_7.45.46_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 321, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08GWMH8DC1-9f42d5d53f/____________________________2025-03-07_7.45.46_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 342, "original_w": 2614, "original_h": 874, "thumb_tiny": "AwAQADC8WiU4LqD9aPNiH/LRfzoYD0H5UuBnoOnpT0EHmx/89F/OjzY/+ei/nTcDHQflQAMHgdT2o0AUPGxwrrk+hp+ARzim4AI4HWnjGKQz/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08GWMH8DC1/____________________________2025-03-07_7.45.46.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F08GWMH8DC1-ab22109382", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F08GLFZP3B4", "created": 1741305243, "timestamp": 1741305243, "name": "画面収録 2025-03-07 8.49.53.mov", "title": "画面収録 2025-03-07 8.49.53.mov", "mimetype": "video/quicktime", "filetype": "mov", "pretty_type": "QuickTime Movie", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 106134563, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "transcription": {"status": "none"}, "mp4": "https://files.slack.com/files-tmb/T033D70RR6H-F08GLFZP3B4-eb045a6573/_____________2025-03-07_8.49.53.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private": "https://files.slack.com/files-tmb/T033D70RR6H-F08GLFZP3B4-eb045a6573/_____________2025-03-07_8.49.53.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08GLFZP3B4/download/_____________2025-03-07_8.49.53.mov?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls": "https://files.slack.com/files-tmb/T033D70RR6H-F08GLFZP3B4-eb045a6573/file.m3u8?_xcb=f1b67&t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "hls_embed": "data:application/vnd.apple.mpegurl;base64,I0VYVE0zVQojRVhULVgtVkVSU0lPTjozCiNFWFQtWC1JTkRFUEVOREVOVC1TRUdNRU5UUwojRVhULVgtU1RSRUFNLUlORjpCQU5EV0lEVEg9MTg2NzYwNCxBVkVSQUdFLUJBTkRXSURUSD0xMzkyOTA5LENPREVDUz0iYXZjMS42NDAwMjgsbXA0YS40MC41IixSRVNPTFVUSU9OPTE5MjB4MTA4MCxGUkFNRS1SQVRFPTI5Ljk3MApkYXRhOmFwcGxpY2F0aW9uL3ZuZC5hcHBsZS5tcGVndXJsO2Jhc2U2NCxJMFZZVkUwelZRb2pSVmhVTFZndFZrVlNVMGxQVGpvekNpTkZXRlF0V0MxVVFWSkhSVlJFVlZKQlZFbFBUam8zQ2lORldGUXRXQzFOUlVSSlFTMVRSVkZWUlU1RFJUb3hDaU5GV0ZRdFdDMVFURUZaVEVsVFZDMVVXVkJGT2xaUFJBb2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSMHhHV2xBelFqUXRaV0l3TkRWaE5qVTNNeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd01TNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UjB4R1dsQXpRalF0WldJd05EVmhOalUzTXk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdNaTUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFIweEdXbEF6UWpRdFpXSXdORFZoTmpVM015OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3TXk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSMHhHV2xBelFqUXRaV0l3TkRWaE5qVTNNeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd05DNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UjB4R1dsQXpRalF0WldJd05EVmhOalUzTXk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdOUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFIweEdXbEF6UWpRdFpXSXdORFZoTmpVM015OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3Tmk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSMHhHV2xBelFqUXRaV0l3TkRWaE5qVTNNeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBd055NTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UjB4R1dsQXpRalF0WldJd05EVmhOalUzTXk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXdPQzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFIweEdXbEF6UWpRdFpXSXdORFZoTmpVM015OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF3T1M1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSMHhHV2xBelFqUXRaV0l3TkRWaE5qVTNNeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE1DNTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UjB4R1dsQXpRalF0WldJd05EVmhOalUzTXk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXhNUzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFIweEdXbEF6UWpRdFpXSXdORFZoTmpVM015OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF4TWk1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSMHhHV2xBelFqUXRaV0l3TkRWaE5qVTNNeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE15NTBjd29qUlZoVVNVNUdPall1TURBMkxBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UjB4R1dsQXpRalF0WldJd05EVmhOalUzTXk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXhOQzUwY3dvalJWaFVTVTVHT2pZdU1EQTJMQXBvZEhSd2N6b3ZMMlpwYkdWekxuTnNZV05yTG1OdmJTOW1hV3hsY3kxMGJXSXZWREF6TTBRM01GSlNOa2d0UmpBNFIweEdXbEF6UWpRdFpXSXdORFZoTmpVM015OW1hV3hsWDBoZk1qWTBYekU1TWpCNE1UQTRNRjgyTlRBd1MwSlFVMTgzVVZaQ1VsOHdNREF4TlM1MGN3b2pSVmhVU1U1R09qWXVNREEyTEFwb2RIUndjem92TDJacGJHVnpMbk5zWVdOckxtTnZiUzltYVd4bGN5MTBiV0l2VkRBek0wUTNNRkpTTmtndFJqQTRSMHhHV2xBelFqUXRaV0l3TkRWaE5qVTNNeTltYVd4bFgwaGZNalkwWHpFNU1qQjRNVEE0TUY4Mk5UQXdTMEpRVTE4M1VWWkNVbDh3TURBeE5pNTBjd29qUlZoVVNVNUdPakF1TmpBeExBcG9kSFJ3Y3pvdkwyWnBiR1Z6TG5Oc1lXTnJMbU52YlM5bWFXeGxjeTEwYldJdlZEQXpNMFEzTUZKU05rZ3RSakE0UjB4R1dsQXpRalF0WldJd05EVmhOalUzTXk5bWFXeGxYMGhmTWpZMFh6RTVNakI0TVRBNE1GODJOVEF3UzBKUVUxODNVVlpDVWw4d01EQXhOeTUwY3dvalJWaFVMVmd0UlU1RVRFbFRWQW89Cg==", "mp4_low": "https://files.slack.com/files-tmb/T033D70RR6H-F08GLFZP3B4-eb045a6573/_____________2025-03-07_8.49.53_trans.mp4?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "duration_ms": 96696, "media_display_type": "video", "thumb_video": "https://files.slack.com/files-tmb/T033D70RR6H-F08GLFZP3B4-eb045a6573/_____________2025-03-07_8.49.53_thumb_video.jpeg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_video_w": 1920, "thumb_video_h": 1080, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08GLFZP3B4/_____________2025-03-07_8.49.53.mov", "permalink_public": "https://slack-files.com/T033D70RR6H-F08GLFZP3B4-d15c910abb", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-03-16

- [1742167801.581079] <@U066P20UQH1>: <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> cc <@U03BLQ65GK0>
*小分け製造指示書アップデート完了しました！本日から利用可能です！*

利用方法は上記スレッド内画面収録動画の通りです。
今後は*営業がinvoice作成時に小分け製造指示書も同時に土台作成する流れ*となります。
invoiceメモ同様、受注登録・商品登録の内容から引用した形になりますので、入力ミス・抜け漏れなどないよう、ダブルチェックをお願いします。
特に、*商品登録は抜けている情報や曖昧な情報が多い*ので、最初の方は内容を確認しながら進めてください。

フォーマットは
```管理＞標準＞invoice, quotation, 履歴＞invoice, 小分け製造指示書```
の中にあります。

コピペする時間が省けた分、ダブルチェックして書類を格納するようにしましょう！！

不明点などあればこのスレッドに返信お願いします。:woman-bowing:

## 2025-03-21

- [1742613272.881319] <@U066P20UQH1>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou>
古川さんの指示書を見ると、Windowsだと互換性の関係でうまく反映されていないようです。。
セルの在り方など調整します・・・調整完了次第共有します:woman-bowing:

## 2025-03-26

- [1742989117.755829] <@U041RJKV5JA>: <@U066P20UQH1>
 <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani> <!subteam^S088LEJ1U5T|@kanayama-fukui-miyoshi-yokoi-takuwa-hara-imaoka-agou> <!subteam^S073HEMKWV7|@hirakawa-adachi-yamamoto-fuse>
顧客管理表の小分け製造指示書シートの内容が、製造指示書フォーマットにきちんと反映されません。
修正をお願いできないでしょうか:sweat_drops:
よろしくお願いいたします。
  - files: [{"id": "F08KGAEGR6F", "created": 1742989088, "timestamp": 1742989088, "name": "スクリーンショット 2025-03-26 20.34.29.png", "title": "スクリーンショット 2025-03-26 20.34.29.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U041RJKV5JA", "user_team": "T033D70RR6H", "editable": false, "size": 390781, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08KGAEGR6F/____________________________2025-03-26_20.34.29.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08KGAEGR6F/download/____________________________2025-03-26_20.34.29.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08KGAEGR6F-025951a34e/____________________________2025-03-26_20.34.29_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08KGAEGR6F-025951a34e/____________________________2025-03-26_20.34.29_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08KGAEGR6F-025951a34e/____________________________2025-03-26_20.34.29_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 223, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08KGAEGR6F-025951a34e/____________________________2025-03-26_20.34.29_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 297, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08KGAEGR6F-025951a34e/____________________________2025-03-26_20.34.29_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08KGAEGR6F-025951a34e/____________________________2025-03-26_20.34.29_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 446, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08KGAEGR6F-025951a34e/____________________________2025-03-26_20.34.29_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 495, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08KGAEGR6F-025951a34e/____________________________2025-03-26_20.34.29_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 594, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08KGAEGR6F-025951a34e/____________________________2025-03-26_20.34.29_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 634, "original_w": 1405, "original_h": 870, "thumb_tiny": "AwAdADC4XIJ+RcepbGaXzDjO0e2G61mTSv8AapAJGABPGa0Lbc1uhJ5wOTzTAfvkxnywPq1OBJXJ4/Gmc5Oc9aphm+3bdxxuHekBoA5pefbNIKWgDGmx9rkyCeTWlaD/AEaPj+Gs24yLqTHqa0LWT/Roxj+EUwJcHJ4qiP8Aj/6fxCtAN7VQH/IQ/wCBCkBof56UUtFAH//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08KGAEGR6F/____________________________2025-03-26_20.34.29.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F08KGAEGR6F-1d51312413", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1742989192.227999] <@U066P20UQH1>: <@U041RJKV5JA> 
今調整中なんですが、編集中のフォーマットで試してみていただいても良いですか？？:sweat_drops:
- [1742989273.358749] <@U041RJKV5JA>: <@U066P20UQH1>
標準フォルダにあるフォーマットですか？
そうであれば試しましたがうまく反映されませんでした。
- [1742989385.257849] <@U066P20UQH1>: <@U041RJKV5JA>
これなんですが、できないですか・・？？
  - files: [{"id": "F08KGAY4R2P", "created": 1742989372, "timestamp": 1742989372, "name": "編集中【小分け】製造指示書_250326_ver.3.xlsx", "title": "編集中【小分け】製造指示書_250326_ver.3.xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 1762951, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08KGAY4R2P/________________________________________250326_ver.3.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08KGAY4R2P/download/________________________________________250326_ver.3.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08KGAY4R2P-9396da1c0d/________________________________________250326_ver.3_converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F08KGAY4R2P-9396da1c0d/________________________________________250326_ver.3_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08KGAY4R2P/________________________________________250326_ver.3.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F08KGAY4R2P-22e7b835b2", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1742989502.705039] <@U041RJKV5JA>: <@U066P20UQH1>
きちんと反映されました:sparkles:
ありがとうございます！

## 2025-04-24

- [1745558732.723149] <@U066P20UQH1>: <!channel>
ちょこちょこフィルターが全員に適用されている状態を見かけるのであらためてアナウンスです:pray:
フィルターを使う際は、*自分専用のフィルターを作成してください。*
自分用のフィルターは、１行目を選択した後、フィルターマークではなく、*電卓のようなマークから作成できます*。（添付参照）
全員に適用されていると、新規入力する際にフィルターを解除することになり、作業に支障が出る可能性があります。
使用する人数が増えてきているので、ご協力いただきますようお願いいたします。
（ちなみに、漏れがないようにフィルターは頻繁に削除・再作成をお勧めします）
やり方がわからない場合はご連絡ください:woman-bowing:
  - files: [{"id": "F08PRL85WBV", "created": 1745558545, "timestamp": 1745558545, "name": "スクリーンショット 2025-04-25 14.17.18.png", "title": "スクリーンショット 2025-04-25 14.17.18.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U066P20UQH1", "user_team": "T033D70RR6H", "editable": false, "size": 175820, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F08PRL85WBV/____________________________2025-04-25_14.17.18.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F08PRL85WBV/download/____________________________2025-04-25_14.17.18.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F08PRL85WBV-94084d718a/____________________________2025-04-25_14.17.18_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F08PRL85WBV-94084d718a/____________________________2025-04-25_14.17.18_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F08PRL85WBV-94084d718a/____________________________2025-04-25_14.17.18_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 108, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F08PRL85WBV-94084d718a/____________________________2025-04-25_14.17.18_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 144, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F08PRL85WBV-94084d718a/____________________________2025-04-25_14.17.18_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F08PRL85WBV-94084d718a/____________________________2025-04-25_14.17.18_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 215, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F08PRL85WBV-94084d718a/____________________________2025-04-25_14.17.18_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 239, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F08PRL85WBV-94084d718a/____________________________2025-04-25_14.17.18_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 287, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F08PRL85WBV-94084d718a/____________________________2025-04-25_14.17.18_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 306, "original_w": 1557, "original_h": 466, "thumb_tiny": "AwAOADC75if3H/75o85f7sn/AHyaceho7mmITzl/uyf980u8EfdbHuKT+IU8UAMBUE4U/lS7gf4Tz7U+ikB//9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F08PRL85WBV/____________________________2025-04-25_14.17.18.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F08PRL85WBV-f2ced51480", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2025-06-04

- [1749024075.438009] <@U08RVRNBY00>: <@U08RVRNBY00>さんがチャンネルに参加しました
- [1749024075.583449] <@U08N3SKSL75>: <@U08N3SKSL75>さんがチャンネルに参加しました
- [1749024075.685049] <@U08U8MMTH43>: <@U08U8MMTH43>さんがチャンネルに参加しました
- [1749024075.792229] <@U08FZUNPSQ3>: <@U08FZUNPSQ3>さんがチャンネルに参加しました
- [1749024075.928769] <@U08L89G6JSG>: <@U08L89G6JSG>さんがチャンネルに参加しました
- [1749026977.193179] <@U066P20UQH1>: <@U08N3SKSL75> <@U08RVRNBY00> <@U08U8MMTH43> <@U08L89G6JSG>
お疲れ様です！
顧客管理表の利用において、フィルターの方法について案内しております。
一度お目通しをお願いいたします:woman-bowing:

## 2025-06-16

- [1750064763.957309] <@U066P20UQH1>: <!channel>
*商品登録上の2025年価格の追記方法について*
これまでは価格やその他情報が変更になった際は新たに製品を追加しておりましたが、作業量が膨大になることを見越し、
*`価格はBI列に上書きする形で対応`*をお願いいたします。
上書きした際は、BK列に以下を記載願います
ご認識をよろしくお願いいたします！:woman-bowing:
```日付と、改訂前・改定後価格の記載
例）
2025/6/16 USD1.0→USD2.0
2025/6/17 USD2.0→USD3.0```

## 2025-07-24

- [1753424132.535089] <@U066P20UQH1>: <!channel>
管理表の関数が入っている箇所がちょこちょこ消えていたり書き変わっていたりするのですが、
気付いた場合は修正・修正対応が難しい場合は一度ご一報ください:pray:
日に日に複雑になっていっておりますが、記入の際には今一度気をつけるようにお願いいたします:bow:
- [1753424168.927099] <@U095LLEH09G>: <@U095LLEH09G>さんがチャンネルに参加しました

## 2025-08-21

- [1755766772.752129] <@U033G4KN4TD>: <!channel>
原料登録の名称少しずつ変更しております。
経緯として、現在原料登録されている名称と現場が呼んでいる名称が合っていないため
現場が指示書を見たときに混乱するため
現在手書きで直している状態で、手間がかかるためです。

例）出雲精茶/茎ほうじパウダー　→　碾茶棒ほうじパウダー
　　香岳園/宇治抹茶K50000　→　宇治抹茶K-A　　

変更前の名称をAP列にいれておきます。
よろしくお願いいたします。
- [1755775785.774319] <@U0331FWGQRM>: <@U033G4KN4TD>
現場で呼ぶ名称を正式側に合わせればいいのでは？
と思うのですが、何か呼び名がズレる理由があるのでしょうか？？

（はじめに設定した正式名称が間違っていた、
もしくは不適切な名称だったとかですか？？）

参考に知りたいです
- [1755817143.893809] <@U033G4KN4TD>: <@U0331FWGQRM>
碾茶棒ほうじパウダーについては、はじめに設定した名称に合わせても良いと思います。

ただし、他のサプライヤーについては入荷時の名称（伝票上の名称）に合わせたい意図があります。
香岳園に関しては、以前桃翠園で決めた名称に統一したいと考えています。

例）
ひかわ
・入荷時名称：国産有機ほうじ茶パウダー
・顧客管理表上名称：有機ほうじ茶HTJ10を粉砕

## 2025-09-01

- [1756771200.868699] <@U066P20UQH1>: <!channel>
商品登録と受注登録で関数が入ってる列の文字の色をピンク色にしました。
ご認識をお願いいたします:woman-bowing:

## 2025-09-04

- [1756971900.452699] <@U066P20UQH1>: <!channel>
すみません、商品登録がおかしくなってます
今急いで治してますので少しお待ちください・・
- [1756972188.541979] <@U066P20UQH1>: 直りました。ご不便おかけしてすみません:sweat_drops:

