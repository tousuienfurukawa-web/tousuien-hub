# Slack channel: 海外営業mtg

## 2022-10-24

- [1666595338.135049] <@U0331FWGQRM>: がこのチャンネルの説明を「ミーテォングで話しておきたいこと等をメモとして使用して、情報共有漏れを防ぐために使用します。」に設定しました
- [1666595341.699099] <@U0331FZTHEK>: <@U0331FZTHEK>さんがチャンネルに参加しました
- [1666595341.800059] <@U033G4KN4TD>: <@U033G4KN4TD>さんがチャンネルに参加しました
- [1666595341.892249] <@U03BLQ65GK0>: <@U03BLQ65GK0>さんがチャンネルに参加しました
- [1666595341.957969] <@U03SGRNND5L>: <@U03SGRNND5L>さんがチャンネルに参加しました
- [1666595342.018989] <@U041RJKV5JA>: <@U041RJKV5JA>さんがチャンネルに参加しました
- [1666595708.263229] <@U0331FWGQRM>: <!channel>
海外営業MTG用のチャンネルを作成しました。
次回以降の海外営業MTGは、

■会議前の段階で何について会議をするのかアジェンダを作成した上で開始する様にします（心がけます）

■会議で会話する内容は会話をしたり、色んな人の意見を聞きたかったり、社長とか僕に確認しておきたいことがあったり、する様な内容にしたいと思います。
ここにメモなどなんでも書き込んでください。
もしかすると、ここで事前に共有することで、
会議で話す前に解決することがあるかもしれません。

※会議のための会議を防止するのが意図です。

なので、僕一人の運用ではできませんので、
協力宜しくお願いします。

## 2022-11-06

- [1667725134.146379] <@U0331FWGQRM>: 11/7 16:00からのmtgですが、
11/8 16:00に変更してもらえますか？？
- [1667778224.346619] <@U041RJKV5JA>: <!channel>
皆様、本日の会議ですが、明日の16時に変更してもよろしいでしょうか？
- [1667785130.374819] <@U041RJKV5JA>: <!channel>
それでは、会議は明日の16時から行います。
よろしくお願いいたします。

## 2022-11-12

- [1668317968.201669] <@U0331FWGQRM>: <!channel>
急ですみませんが、
次回の海外営業MTGは火曜日に変更お願いします。
11/15  14-15時でお願いします。
- [1668318020.244799] <@U0331FWGQRM>: ■次回、海外営業MTG議題
（会議で話したい内容は、スレッドで返信してメモ追記ください）
- [1668318236.562049] <@U0331FWGQRM>: ・サンプル用冷蔵庫（缶）の完成予定日は？
・取扱商品一覧表の穴埋め（粉砕方法など）
・FSSC、ISO取得しました（連絡）
・問合せ内容をリスト化。
→対応速度を上げる＋誰でも対応できるように整備したい。
・ケース入り数算出　共有

## 2022-12-11

- [1670803202.782529] <@U0331FWGQRM>: <!channel>
今日の海外営業MTGですが議題があれば、
スレッド返信でメモ形式でいいのでお願いします。
- [1670803611.289319] <@U0331FZTHEK>: @channel
お疲れ様です。
・11月度、2022年2月～11月
　海外営業収支、売上高報告 致します。
- [1670805079.210229] <@U0331FZS7JT>: @channel
下記進捗&amp;報告、確認
【マレーシア】
・ゆずパウダーの製造終了タイミング確認
【他】
・魯さん台湾向け原料準備進捗確認
※東海澱粉に何を依頼するかそろそろ知りたい
・我々が海外出張行っていた際に、露見した課題や問題点等（あれば）

以上、よろしくお願いします！
- [1670818922.685489] <@U033G4KN4TD>: @channel
お疲れ様です。
・香港へ冷凍食品を輸出時、必要な書類の報告
・台湾向けフレーバー抹茶／フレーバーほうじ茶／フレーバー煎茶の進捗報告いたします。
・他の営業先の進捗状況を報告
よろしくお願いいたします。
- [1670819002.245449] <@U0331FWGQRM>: ・海外出張の情報共有
∟それに伴う結論
（タイ・シンガポール・インドネシア・マレーシア）
・アメリカ出張について
∟2024年1月USAの展示会にでる
→海外の展示会下見、USA西海岸下見
・今後の営業の進め方
・今年の振り返り
- [1670828418.023639] <@U0331FWGQRM>: <https://meet.google.com/ubt-yccm-kxz>
  - attachments: [{"from_url": "https://meet.google.com/ubt-yccm-kxz", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "id": 1, "original_url": "https://meet.google.com/ubt-yccm-kxz", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/ubt-yccm-kxz", "service_name": "meet.google.com"}]
- [1670828430.551549] <@U0331FWGQRM>: <!channel>
これで入れますか？

## 2022-12-12

- [1670832173.493249] <@U0331FWGQRM>: <https://meet.google.com/xsj-pzqn-pck>
  - attachments: [{"from_url": "https://meet.google.com/xsj-pzqn-pck", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "id": 1, "original_url": "https://meet.google.com/xsj-pzqn-pck", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/xsj-pzqn-pck", "service_name": "meet.google.com"}]
- [1670897752.249479] <@U03SGRNND5L>: <!channel>
お疲れ様です。
昨日の海外ミーティングの議事録を
桃翠園共有フォルダ　→　海外営業フォルダ　→　海外ミーティング議事録フォルダ
に入れております。
宜しくお願い致します。

## 2022-12-18

- [1671407113.219249] <@U0331FWGQRM>: <!channel> 
今日の営業会議について、
何か議題がありますか？？なければスキップでいいかと思います。
もし何かあればしましょう。
細かい確認事項とかでも大丈夫です。
スレッドで返信お願いします。
- [1671409065.159789] <@U0331FZS7JT>: 僕個人的には特にないです！
昨夜、<#C033UNL1V17|アリババ> （<https://grp-ssm9297.slack.com/archives/C033UNL1V17/p1671369264541079?thread_ts=1671288507.846489&amp;cid=C033UNL1V17>）の件のEUに対する関税等の情報の吸上げをしたいですが、
昨日の今日なので、詳しい情報はまとまっていないと思います（必要なのも実際取引が始まるまでのタイミングで良い、と思うので！）。
まとまったら聞きたいので、<@U041RJKV5JA> 部長進捗を確認の上、連絡をよろしくお願いします！
  - attachments: [{"from_url": "https://grp-ssm9297.slack.com/archives/C033UNL1V17/p1671369264541079?thread_ts=1671288507.846489&amp;cid=C033UNL1V17", "ts": "1671369264.541079", "author_id": "U0331FZS7JT", "channel_id": "C033UNL1V17", "channel_team": "T033D70RR6H", "is_msg_unfurl": true, "is_reply_unfurl": true, "message_blocks": [{"team": "T033D70RR6H", "channel": "C033UNL1V17", "ts": "1671369264.541079", "message": {"blocks": [{"type": "rich_text", "block_id": "FO7OB", "elements": [{"type": "rich_text_section", "elements": [{"type": "user", "user_id": "U041RJKV5JA"}, {"type": "text", "text": " 部長 "}, {"type": "user", "user_id": "U0331FZTHEK"}, {"type": "text", "text": " さん "}, {"type": "user", "user_id": "U033G4KN4TD"}, {"type": "text", "text": " さん"}, {"type": "user", "user_id": "U03SGRNND5L"}, {"type": "text", "text": " さん\nCC："}, {"type": "user", "user_id": "U0331FWGQRM"}, {"type": "text", "text": " 執行役\n\nお疲れ様です。\n本件（EUへの茶の輸出・関税）について、補足で連絡します。\n\n【EU輸出における原産地証明について】\n結論：第３者機関のものは不要（インボイスに日本産であることを自社で明記で対応可能）\n※今回はサンプルなので明記も不要だと思います！\n\n下記URLより、ご確認ください（P.77〜）\n"}, {"type": "link", "url": "https://www.jetro.go.jp/ext_images/world/europe/eu/epa/pdf/euepa.pdf"}, {"type": "text", "text": "\n記載のメリット：下記HSコード品の関税(3.2%)がなくなる。\n※HSコード：0902.10(緑茶：不発酵茶3kg以下/包装）\n\nインボイスにURLの内容（P.81）を英語（日本語でもOKですが、英語推奨）で記載してください。\nスウェーデンのYuko Ono Sthlm.からのインボイス及び、私がウクライナ（ポーランド/EU経由）のMr.Ivashchenkoに送っている、インボイス（2-4回）にも欄外に記載しています。\n(5)の場所と日付けについて、ですがここはJETROに直接確認していただいた方が良いかもしれません。\n⇒確認後、執行役、私にも共有願います。\n\n(5)を私はコピペしていて、今のところ問題はないですが（P.83の軽微な誤りに該当？）、念の為確認をお願いします。\n\nお客様から別途第３者機関（商工会議所等）の原産地証明が欲しい！と言われたら個別対応で良いと思います！\n\n尚、\nHSコード：0902.20(発酵していないその他の緑茶)については関税がそもそも非課税となっていますが、こちらはインボイスの欄外にも上記の記載は最初から不要？なのかこちらも確認願います！\n\n確認していただいた方は、海外営業部会議にて説明をお願い致します！\n以上、よろしくお願い致します"}, {"type": "emoji", "name": "man-bowing", "unicode": "1f647-200d-2642-fe0f"}]}]}]}}], "id": 1, "original_url": "https://grp-ssm9297.slack.com/archives/C033UNL1V17/p1671369264541079?thread_ts=1671288507.846489&amp;cid=C033UNL1V17", "fallback": "[December 18th, 2022 5:14 AM] yuta.oka.0915: <@U041RJKV5JA> 部長 <@U0331FZTHEK> さん <@U033G4KN4TD> さん<@U03SGRNND5L> さん\nCC：<@U0331FWGQRM> 執行役\n\nお疲れ様です。\n本件（EUへの茶の輸出・関税）について、補足で連絡します。\n\n【EU輸出における原産地証明について】\n結論：第３者機関のものは不要（インボイスに日本産であることを自社で明記で対応可能）\n※今回はサンプルなので明記も不要だと思います！\n\n下記URLより、ご確認ください（P.77〜）\n<https://www.jetro.go.jp/ext_images/world/europe/eu/epa/pdf/euepa.pdf>\n記載のメリット：下記HSコード品の関税(3.2%)がなくなる。\n※HSコード：0902.10(緑茶：不発酵茶3kg以下/包装）\n\nインボイスにURLの内容（P.81）を英語（日本語でもOKですが、英語推奨）で記載してください。\nスウェーデンのYuko Ono Sthlm.からのインボイス及び、私がウクライナ（ポーランド/EU経由）のMr.Ivashchenkoに送っている、インボイス（2-4回）にも欄外に記載しています。\n(5)の場所と日付けについて、ですがここはJETROに直接確認していただいた方が良いかもしれません。\n⇒確認後、執行役、私にも共有願います。\n\n(5)を私はコピペしていて、今のところ問題はないですが（P.83の軽微な誤りに該当？）、念の為確認をお願いします。\n\nお客様から別途第３者機関（商工会議所等）の原産地証明が欲しい！と言われたら個別対応で良いと思います！\n\n尚、\nHSコード：0902.20(発酵していないその他の緑茶)については関税がそもそも非課税となっていますが、こちらはインボイスの欄外にも上記の記載は最初から不要？なのかこちらも確認願います！\n\n確認していただいた方は、海外営業部会議にて説明をお願い致します！\n以上、よろしくお願い致します:man-bowing:", "text": "<@U041RJKV5JA> 部長 <@U0331FZTHEK> さん <@U033G4KN4TD> さん<@U03SGRNND5L> さん\nCC：<@U0331FWGQRM> 執行役\n\nお疲れ様です。\n本件（EUへの茶の輸出・関税）について、補足で連絡します。\n\n【EU輸出における原産地証明について】\n結論：第３者機関のものは不要（インボイスに日本産であることを自社で明記で対応可能）\n※今回はサンプルなので明記も不要だと思います！\n\n下記URLより、ご確認ください（P.77〜）\n<https://www.jetro.go.jp/ext_images/world/europe/eu/epa/pdf/euepa.pdf>\n記載のメリット：下記HSコード品の関税(3.2%)がなくなる。\n※HSコード：0902.10(緑茶：不発酵茶3kg以下/包装）\n\nインボイスにURLの内容（P.81）を英語（日本語でもOKですが、英語推奨）で記載してください。\nスウェーデンのYuko Ono Sthlm.からのインボイス及び、私がウクライナ（ポーランド/EU経由）のMr.Ivashchenkoに送っている、インボイス（2-4回）にも欄外に記載しています。\n(5)の場所と日付けについて、ですがここはJETROに直接確認していただいた方が良いかもしれません。\n⇒確認後、執行役、私にも共有願います。\n\n(5)を私はコピペしていて、今のところ問題はないですが（P.83の軽微な誤りに該当？）、念の為確認をお願いします。\n\nお客様から別途第３者機関（商工会議所等）の原産地証明が欲しい！と言われたら個別対応で良いと思います！\n\n尚、\nHSコード：0902.20(発酵していないその他の緑茶)については関税がそもそも非課税となっていますが、こちらはインボイスの欄外にも上記の記載は最初から不要？なのかこちらも確認願います！\n\n確認していただいた方は、海外営業部会議にて説明をお願い致します！\n以上、よろしくお願い致します:man-bowing:", "author_name": "岡祐太", "author_link": "https://grp-ssm9297.slack.com/team/U0331FZS7JT", "author_icon": "https://avatars.slack-edge.com/2022-02-16/3118160981555_2c9de1514f262063f72d_48.png", "author_subname": "岡祐太", "mrkdwn_in": ["text"], "footer": "Slack の会話内のスレッド"}]
- [1671423195.913159] <@U041RJKV5JA>: 海外チームも特にございません。
スキップでお願いします。

## 2022-12-25

- [1672016759.900079] <@U041RJKV5JA>: <!channel>
お疲れ様です。
本日の営業会議ですが、報告、確認事項等はございますか？
スタンプ:man-gesturing-ok::man-gesturing-no:での返信で結構です。
よろしくお願いします。
- [1672031893.592429] <@U041RJKV5JA>: お疲れ様です。
本日の営業会議は中止といたします。
よろしくお願いいたします。

## 2023-01-15

- [1673829532.405199] <@U041RJKV5JA>: <!channel>
お疲れ様です。
本日16時からの営業会議ですが、報告、確認事項等はございますか？
スタンプ:man-gesturing-ok::man-gesturing-no:での返信で結構です。
よろしくお願いします。
- [1673830120.209809] <@U0331FWGQRM>: <@U041RJKV5JA> 
連絡遅くなりすみません。
本日16:00出席できそうにないですので、もし開催した際は、議事録確認するようにします。
私からは今週は無いです（来週シェアしたいことあります）
- [1673843308.766879] <@U041RJKV5JA>: お疲れ様です。
本日の会議は中止といたします。
なお、来週は開催しますのでよろしくお願いいたします。

## 2023-01-29

- [1675012026.543439] <@U0331FWGQRM>: <!channel> 
海外営業mtg私からは何もないのでスキップでokです。
皆様どうでしょう？

- [1675035460.521539] <@U0331FZS7JT>: 私もないので、、スキップでOKです！
- [1675041772.610559] <@U041RJKV5JA>: 海外チームもございません。
スキップでお願いします。

## 2023-02-02

- [1675389360.617129] <@U0331FWGQRM>: <!channel>
2/6　議題メモ
・Alibabaの運用について（見るポイント、進め方）
・Gmailの運用について（誰の名前でするのか）
・invoiceのケースに同梱するか箱に貼り付けるかについて（ケーススタディ：Nadhaya）

## 2023-02-11

- [1676125917.338119] <@U0331FWGQRM>: 2/14　海外営業会議　議題メモ
・サウジ進捗共有（お願いします）
・残留農薬その他、進捗、スケジュール共有
・Neels 様メモ　サンプル進捗確認
・RFQ進捗報告
発送先と請求先の住所が異なる。
サンプル発送の際10商品以上送る。（らしい）
（抜粋）※よくわからんですけど。
Also please include 10 items or more on this invoice
These updates are for our amazon applications and we need this invoice to have certain requirements for amazon standards

2/15　営業会議
・アリババからの仕入商品についての情報共有

## 2023-02-16

- [1676547487.976729] <@U0331FWGQRM>: 2/21
メモ
全員がランダムにRFQやる意図を再確認したい
- [1676613820.516889] <@U0331FZS7JT>: メモ
・出荷書類のミスについて原因と対策
（Invoice・原産地証明サイン）
・出荷に際した情報伝達のタイミング

## 2023-02-17

- [1676621312.734279] <@U0331FWGQRM>: （案）
出荷の際の情報伝達のタイミングについて
→出荷後の報告ではなく、出荷準備が整ったら教えて下さい。
→出荷日当日に、リマインド。
→出荷完了後は、報告。

※文章は不要で、スタンプ　でOK

（例）
●注文が入りました。出荷可能日を教えてください。
　↓
●00/00出荷可能です。→:了解です:

●先ほど出荷準備完了しました。
予定通り00/00に出荷します。→:了解です:

当日リマインドとしてお願いします。 :本日出荷:
報告としてお願いします。 :出荷完了:
- [1676621344.335039] <@U0331FWGQRM>: 例）
先ほど出荷準備完了しました。
00/00に出荷します。
宜しくお願いします。
- [1676621516.918029] <@U0331FWGQRM>: メンション＆リアクションで通知されますので、
出荷当日と出荷完了後にスタンプの連絡でOKです。

## 2023-02-18

- [1676720486.539189] <@U0331FWGQRM>: 送信予約が可能なので、本日出荷予定については、
スタンプではなく、送信予約でも良いかもしれません。
また相談させてください。

## 2023-02-20

- [1676965321.768559] <@U0331FWGQRM>: <!channel>
<https://emoji-gen.ninja/>
  - attachments: [{"from_url": "https://emoji-gen.ninja/", "image_url": "https://emoji-gen.ninja/assets/img/ogp_summary.png", "image_width": 1200, "image_height": 630, "image_bytes": 95154, "service_icon": "https://emoji-gen.ninja/assets/img/favicon_ja.ico", "id": 1, "original_url": "https://emoji-gen.ninja/", "fallback": "絵文字ジェネレーター - Slack 向け絵文字を無料で簡単生成", "text": "絵文字ジェネレーターで、綺麗な絵文字を生成しよう! 好みのテキストと色を指定するだけで、便利なリアクション絵文字(リアク字)・スタンプが無料で簡単生成できます! Slack などチャットツールでの利用に最適! 絵文字でコミュニケーションを活発化しましょう。", "title": "絵文字ジェネレーター - Slack 向け絵文字を無料で簡単生成", "title_link": "https://emoji-gen.ninja/", "service_name": "emoji-gen.ninja"}]

## 2023-02-21

- [1676967814.223789] <@U0331FWGQRM>: <https://docs.google.com/spreadsheets/d/15ZYJtfLrDKAoQW-u9bXNh1UOycLEf4SEWEpLHxgvZOc/edit?usp=sharing>

## 2023-02-22

- [1677120943.750349] <@U0331FWGQRM>: 2/28
フォルダ分けのルールについて、どう言う基準？
  - files: [{"id": "F04R8PWMGM7", "created": 1677120911, "timestamp": 1677120911, "name": "スクリーンショット 2023-02-23 11.54.04.png", "title": "スクリーンショット 2023-02-23 11.54.04.png", "mimetype": "image/png", "filetype": "png", "pretty_type": "PNG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 333703, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04R8PWMGM7/____________________________2023-02-23_11.54.04.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04R8PWMGM7/download/____________________________2023-02-23_11.54.04.png?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04R8PWMGM7-cf94475be4/____________________________2023-02-23_11.54.04_64.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04R8PWMGM7-cf94475be4/____________________________2023-02-23_11.54.04_80.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04R8PWMGM7-cf94475be4/____________________________2023-02-23_11.54.04_360.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 289, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04R8PWMGM7-cf94475be4/____________________________2023-02-23_11.54.04_480.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 386, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04R8PWMGM7-cf94475be4/____________________________2023-02-23_11.54.04_160.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04R8PWMGM7-cf94475be4/____________________________2023-02-23_11.54.04_720.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 578, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04R8PWMGM7-cf94475be4/____________________________2023-02-23_11.54.04_800.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 643, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04R8PWMGM7-cf94475be4/____________________________2023-02-23_11.54.04_960.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 771, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04R8PWMGM7-cf94475be4/____________________________2023-02-23_11.54.04_1024.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 823, "original_w": 1628, "original_h": 1308, "thumb_tiny": "AwAmADDRI/zmgc0NxSgjFADS2DSgcc0jR7jnew+lAjIOfMYj0OKYDsGlxRRSAa1KB6YpH60i5z3oAfRRRQAUUUUANYZpR0oPWhfu0ALRRRQAUUUUAf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04R8PWMGM7/____________________________2023-02-23_11.54.04.png", "permalink_public": "https://slack-files.com/T033D70RR6H-F04R8PWMGM7-6910a7578d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-03-02

- [1677770227.099639] <@U0331FWGQRM>: 3/7
・Dave oggのquotation　左上の from　は何？
・alibabaのチャットでもpdf送れることがわかった。
・groene様のリストを埋める
・ハラル認証について
・出荷の際の情報伝達のタイミングについて。運用状況確認。
- [1677770428.054619] <@U0331FZS7JT>: 取り扱い原料一覧を埋めてほしい
※茶期、産地、品種、粉砕方法 等
　年間供給可能数量についても（まるゑいはお客様別フォルダに入っているので反映をお願いします）
- [1677805479.749559] <@U0331FWGQRM>: 上記社長の件について情報を埋める際に、サプライヤーへ問い合わせることもあると思うので、
添付のリストを使用してヒアリングしてみてください。
ヒアリングすべき情報として、添付のエクセルに不足事項があるかどうか確認したいので
各自フィードバックください。宜しくお願いします。※もしあれば、スレッドで返信でOK
  - files: [{"id": "F04SVPJUBPA", "created": 1677805294, "timestamp": 1677805294, "name": "製品情報一覧表.xlsx", "title": "製品情報一覧表.xlsx", "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "filetype": "xlsx", "pretty_type": "Excel Spreadsheet", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 11193, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04SVPJUBPA/_____________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04SVPJUBPA/download/_____________________.xlsx?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "converted_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F04SVPJUBPA-a16fd0ba0e/______________________converted.pdf?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F04SVPJUBPA-a16fd0ba0e/______________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04SVPJUBPA/_____________________.xlsx", "permalink_public": "https://slack-files.com/T033D70RR6H-F04SVPJUBPA-e608abc19d", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1677829739.136019] <@U0331FZS7JT>: EORI番号について教えて下さい。
※EU出荷便（経由含め）全て必要？と読んだ気がするので。
情報共有含めているので、よろしくお願いします。

## 2023-03-06

- [1678091144.352179] <@U0331FWGQRM>: 密閉シール機について情報共有
チャック付き袋の窒素ガス充填の可否について。
  - files: [{"id": "F04S938FELW", "created": 1678064250, "timestamp": 1678064250, "name": "DSC_0801.JPG", "title": "DSC_0801.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 2331514, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04S938FELW/dsc_0801.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04S938FELW/download/dsc_0801.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04S938FELW-673d363d7d/dsc_0801_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04S938FELW-673d363d7d/dsc_0801_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04S938FELW-673d363d7d/dsc_0801_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04S938FELW-673d363d7d/dsc_0801_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04S938FELW-673d363d7d/dsc_0801_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04S938FELW-673d363d7d/dsc_0801_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04S938FELW-673d363d7d/dsc_0801_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04S938FELW-673d363d7d/dsc_0801_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04S938FELW-673d363d7d/dsc_0801_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 4000, "original_h": 3000, "thumb_tiny": "AwAkADA8wY5FAk9BUXnnJAQAeuKWOWRmAOcHrgUATLuY9MfhT3ULjMg/QVV8idm+8xHqxqQQKrEyOvTGKAJTsI4fNRb1B5cmlCxqSFDMacqsfuoo+gyaQDd8S8qgI/OlEzt91MChIiRwgA/2qmEQx8xJ9ugphYgw7HDOfoKlWDJyR+JqZQFGAAKUnAoAYIlHXmpFZVGOAKjyaaTgVHN2K5RQeKieZl6YqTtUEtUIVJXc4LY+lTleOSTVaH71Wu1MQwUnY0opOxrF7mi2P//Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04S938FELW/dsc_0801.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F04S938FELW-ca121749dd", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F04SFM2MTDY", "created": 1678064257, "timestamp": 1678064257, "name": "DSC_0802.JPG", "title": "DSC_0802.JPG", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 2003237, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04SFM2MTDY/dsc_0802.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04SFM2MTDY/download/dsc_0802.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04SFM2MTDY-d00bbc2f18/dsc_0802_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04SFM2MTDY-d00bbc2f18/dsc_0802_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04SFM2MTDY-d00bbc2f18/dsc_0802_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 360, "thumb_360_h": 270, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04SFM2MTDY-d00bbc2f18/dsc_0802_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 480, "thumb_480_h": 360, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04SFM2MTDY-d00bbc2f18/dsc_0802_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04SFM2MTDY-d00bbc2f18/dsc_0802_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 720, "thumb_720_h": 540, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04SFM2MTDY-d00bbc2f18/dsc_0802_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 600, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04SFM2MTDY-d00bbc2f18/dsc_0802_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 960, "thumb_960_h": 720, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04SFM2MTDY-d00bbc2f18/dsc_0802_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 1024, "thumb_1024_h": 768, "original_w": 4000, "original_h": 3000, "thumb_tiny": "AwAkADBFIJ4GfoKV/l6gj2qPe4c7EG3sQKcvns5LZ249hSAUEnopp6AAZd1Qe9QmAkfPL+pNAihAwSWxzxQBOxjCkeZntwKiSRBkEk59OKdnqVj5Pdu9OVJD0AH0FADC0hA5wfQ8UoR2HJJ+gqyiIo4Ap3WgCult/wDrJqZYVH/1uKcKXdTANqr0ApN1DMMVCZOeKAHA8U5TTR0pVpDHGoZXKqSKlNQT/wCrNMQo5AJ9KSlH3R9KSsTQ/9k=", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04SFM2MTDY/dsc_0802.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F04SFM2MTDY-faa20ff339", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F04SFM2V1HQ", "created": 1678064264, "timestamp": 1678064264, "name": "真空機.pdf", "title": "真空機.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 454666, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04SFM2V1HQ/_________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04SFM2V1HQ/download/_________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F04SFM2V1HQ-1d296f8e23/__________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04SFM2V1HQ/_________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F04SFM2V1HQ-f0fe16a55b", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F04S93943HC", "created": 1678064267, "timestamp": 1678064267, "name": "桃翆園　A-3-G　29.pdf", "title": "桃翆園　A-3-G　29.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 104295, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04S93943HC/____________a-3-g___29.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04S93943HC/download/____________a-3-g___29.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F04S93943HC-406f416b7a/____________a-3-g___29_thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 909, "thumb_pdf_h": 1286, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04S93943HC/____________a-3-g___29.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F04S93943HC-f2d4be021c", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-03-13

- [1678696795.016749] <@U0331FZS7JT>: <!channel>
写真フォルダの袋などの情報をまとめて欲しいです。
画像のような感じでお願いします（正解かわかりませんが、こんな感じ。）
※画像（AL-10）30-50gと書いていますが、本当にそうか、なども必要かなと思います。
  - files: [{"id": "F04TP6U24DA", "created": 1678696694, "timestamp": 1678696694, "name": "30-50g_aluminum bag.jpg", "title": "30-50g_aluminum bag.jpg", "mimetype": "image/jpeg", "filetype": "jpg", "pretty_type": "JPEG", "user": "U0331FZS7JT", "user_team": "T033D70RR6H", "editable": false, "size": 1387427, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F04TP6U24DA/30-50g_aluminum_bag.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F04TP6U24DA/download/30-50g_aluminum_bag.jpg?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_64": "https://files.slack.com/files-tmb/T033D70RR6H-F04TP6U24DA-6afbc2cc51/30-50g_aluminum_bag_64.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_80": "https://files.slack.com/files-tmb/T033D70RR6H-F04TP6U24DA-6afbc2cc51/30-50g_aluminum_bag_80.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360": "https://files.slack.com/files-tmb/T033D70RR6H-F04TP6U24DA-6afbc2cc51/30-50g_aluminum_bag_360.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_360_w": 205, "thumb_360_h": 360, "thumb_480": "https://files.slack.com/files-tmb/T033D70RR6H-F04TP6U24DA-6afbc2cc51/30-50g_aluminum_bag_480.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_480_w": 273, "thumb_480_h": 480, "thumb_160": "https://files.slack.com/files-tmb/T033D70RR6H-F04TP6U24DA-6afbc2cc51/30-50g_aluminum_bag_160.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720": "https://files.slack.com/files-tmb/T033D70RR6H-F04TP6U24DA-6afbc2cc51/30-50g_aluminum_bag_720.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_720_w": 410, "thumb_720_h": 720, "thumb_800": "https://files.slack.com/files-tmb/T033D70RR6H-F04TP6U24DA-6afbc2cc51/30-50g_aluminum_bag_800.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_800_w": 800, "thumb_800_h": 1406, "thumb_960": "https://files.slack.com/files-tmb/T033D70RR6H-F04TP6U24DA-6afbc2cc51/30-50g_aluminum_bag_960.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_960_w": 546, "thumb_960_h": 960, "thumb_1024": "https://files.slack.com/files-tmb/T033D70RR6H-F04TP6U24DA-6afbc2cc51/30-50g_aluminum_bag_1024.jpg?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_1024_w": 583, "thumb_1024_h": 1024, "original_w": 2219, "original_h": 3899, "thumb_tiny": "AwAwABuGK182MPvIz7VJ9g/6a/8AjtOtgfsy8gdetSAEnlwPzpAQizGOJP0qtmtLZwfnBrLpgX7X/j3XjPWpGB9OPpUdpJttlH1/nVgSAmkMjXd6cVm1rkA8iscnk0CLduMwD8amCkGq1vIoiALAfU1OJU4+cfnQMlXNZhHzH61oCeMfxr+dZxPzH60IGf/Z", "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F04TP6U24DA/30-50g_aluminum_bag.jpg", "permalink_public": "https://slack-files.com/T033D70RR6H-F04TP6U24DA-69d0edfcfc", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]
- [1678761424.072259] <@U0331FWGQRM>: デザインデータの雛形作成について
30g　（bag, can）ラベル用、印刷用
50g （bag, 缶） ラベル用、印刷用
100g　（bag） ラベル用、印刷用

## 2023-03-27

- [1679971347.683269] <@U041RJKV5JA>: <!channel>
お疲れ様です。
本日16時からの営業会議ですが、報告、確認事項等はございますか？
私からは、先日のtachu house様案件において発生した進め方の誤りについて
対策を報告しようと思っております。
よろしくお願いいたします。
- [1679985574.693629] <@U0331FZS7JT>: <!channel>
本日のURL よろしくお願いします。
<https://us02web.zoom.us/j/82462837422?pwd=UkQvNDZSNnZFLys0TW1ZL0F6K25NZz09>

## 2023-04-03

- [1680582930.495959] <@U041RJKV5JA>: <!channel>
本日16時からの営業会議ですが、報告、確認事項等はございますか？
スタンプ:man-gesturing-ok::man-gesturing-no:での返信で結構です。
よろしくお願いします。
- [1680588896.625329] <@U041RJKV5JA>: @channel
本日の営業会議は中止とします。
よろしくお願いします。

## 2023-04-10

- [1681140232.784239] <@U0331FWGQRM>: 4/11mtg
neels進め方擦り合わせ
名刺（和英）
缶の進捗（ラベルサイズ確認、フォーマット共有）
∟Neels, Dave

## 2023-04-12

- [1681367192.745399] <@U0331FWGQRM>: <@U03BLQ65GK0> <@U041RJKV5JA> <@U0331FZS7JT>
  - files: [{"id": "F0530PX4083", "created": 1681367189, "timestamp": 1681367189, "name": "底巻閉め機械資料.pdf", "title": "底巻閉め機械資料.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U0331FWGQRM", "user_team": "T033D70RR6H", "editable": false, "size": 205334, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F0530PX4083/________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F0530PX4083/download/________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F0530PX4083-2bb72ae9c9/_________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 888, "thumb_pdf_h": 1269, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F0530PX4083/________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F0530PX4083-daf4c6f143", "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}]

## 2023-05-01

- [1682996788.368599] <@U041RJKV5JA>: <!channel>
本日の営業会議ですが、海外チームからの報告事項はございません。
スキップでよろしいでしょうか？
- [1682997670.656949] <@U0331FWGQRM>: <@U041RJKV5JA> 
今回はスキップで大丈夫です。

メモ程度でいいので、海外営業mtgのスレッドに報告事項や情報共有すべきことは、
その都度メモとして残してください。
海外営業mtgのスレッドはメモとして使用して頂いて大丈夫です。
受注情報やサンプル出荷情報については、こちらからその都度連絡してますが、

船便の出荷ついてや、
台湾向けの注文、
ドイツ向けの注文
neels様の注文

など、海外輸出の事務における知見というのはその都度溜まっているはずです。

事務以外にも、製造における課題、
前回のmtgで出た課題の進捗（原料の準備に手が取られているなど）
も報告事項としてあると思います。

次回からはその辺も意識して頂けると有意義な会議ができるかと思います。

宜しくお願いします。

## 2023-05-02

- [1683050880.610369] <@U0331FWGQRM>: 5/9　海外営業mtgメモ
- [1683050886.522169] <@U0331FWGQRM>: 5/16　海外営業mtgメモ（社長・松井参加）
- [1683050946.054599] <@U0331FWGQRM>: ・同等性証明について（EUは電子申請？）
・Neels 窒素ガス充填の可否について（ガス充填量がバラバラ？）
・産地証明取得について（漏れあり）
・サウジ爆増とその中身、その対策について
・ミニシーマ進捗確認
・Neels 様　invoiceの書き方について
・SGS重金属レポートについて

## 2023-05-05

- [1683340752.354659] <@U0331FZS7JT>: 【ドイツ向け進捗】
船便（澁澤倉庫20ft Dry・Reefar）で提案中。
※reeferがオススメと伝えている。

【5/5現在、進捗】
見積提案済・サンプル発送済
先方と先方の客でサンプル到着後、品質確認
↓
問題なければ、正式オーダー
※１回目の注文数量及び納期は改めて連絡

見積時からオーダー変更
~①Gyokuro Loose Leaf Green tea - 500 kg~
②Japanese Matcha Green tea Ceremonial Grade - 1 ton
③Japanese Matcha Green tea Premium Grade - 20 tons
④Japanese Matcha Green tea Culinary Grade - 6 tons
~・Japanese Sencha Loose leaf green tea - 3 tons~
↓
②Ceremonial: we need to buy to you around 55 USD / kg product in Hamburg
③Premium: we need to buy to you around 28 USD / kg product in Hamburg
④Culinary: we need to buy to you around 20-22 USD / kg product in Hamburg
↓
④原料がないため断念（当初④で提案してたのを③にて提案）

【ドイツに限らず船便メモ】
・ドイツまでは出航後40日以内に製品が届く
・Dryコンテナのコンテナ内温度は40-50℃程度
・台湾までは船出航後4日程度で届く
・抹茶25kg/カートン(No.6)コンテナ入数（バラ積み※パレットに載せてない状態）
20ft Dry：336カートン（8,400kg）
20ft Reefer：246カートン（6,150kg）
40ft Dry：670カートン（16,750kg）
40ft Reefer：576カートン（14,400kg）
※Reeferが少ないのはコンテナ内に冷房があるため
・パレタイズして載せる際の基本パレットサイズは110cm×110cm（パレットに何カートン乗るか調べる必要あり）

【正式オーダー確定後のフロー】
・有機同等性証明の申請
　※EU・USDA
・入金確認後の原料発注
・ハンブルク港からの運搬の業者の確認→お客様に伝える

## 2023-05-16

- [1684220584.741309] <@U0331FZS7JT>: <!channel>
<https://us02web.zoom.us/j/85661564740?pwd=ZnZxV2hEUzhmbWtLUmNDbTJrdzhNQT09>

よろしくお願いします。
- [1684225613.249589] <@U0331FWGQRM>: メモ
30kg までEMS
30kg-500kg までクーリエ
500kg-6000kg まで船便20ft（max 約6t）
6000kg-12000kg まで船便40ft（max 約12t）

※コスト感として、クーリエの送料は+1000円/kg, 20ftコンテナの送料は+80円/kg
※コスト的には、20ft Rコンテナに10%の物量（約500kg程度）でもクーリエより安い。
※リーファーは常温の約1.2倍の価格。
※赤道を通過すると50度を超える。

## 2023-07-19

- [1689779418.326139] <@U0331FWGQRM>: メモ
・抹茶の写真の撮り直し→要スケジューリング
・国内商品のアップデート
・国内向けHPアップデート
・海外電子カタログ作成→どのような構成がいいか要検討
∟缶の写真、ダイラインなども準備すること。
∟
＊産地、品種（単一品種とは）、有機についてなど抹茶の枠組みを説明
Price listは個別にquotationを出す。
Organic, Non organic matcha (Top grade, Upper, Middle, Regular, Lower)
＊Blend Matcha
---抹茶以外は割愛もあり---要検討
＊Genmaicha
＊Sencha（Gyokuro）
＊ほうじ茶
＊その他
-------
・缶の種類
・有機認証（同等性について）
・バルクの出荷について
∟リーファーコンテナの詳細
・

## 2023-07-31

- [1690796789.459729] <@U05KGS6HN9H>: <@U05KGS6HN9H>さんがチャンネルに参加しました

## 2023-10-06

- [1696616195.077169] <@U0606SPN4BW>: <@U0606SPN4BW>さんがチャンネルに参加しました

## 2023-11-13

- [1699938184.257289] <@U0331FWGQRM>: メモ
・巻締機　中国産の缶が封しにくい件について

## 2023-11-21

- [1700559311.547029] <@U066P20UQH1>: <@U066P20UQH1>さんがチャンネルに参加しました

## 2024-01-11

- [1705025337.112689] <@U0331FZS7JT>: <@U0331FWGQRM> <@U041RJKV5JA>
<https://us02web.zoom.us/j/83715212691?pwd=OENTL2hKeElLTlMwaDdVeC9rMkh0UT09>

よろしくお願いします。

## 2024-04-19

- [1713592245.893079] <@U0331FWGQRM>: <@U05KGS6HN9H> cc <!channel>
下記スレッド（日本ーフィリピン）の船便に関する見積もりについて、
見方を教えていただけますか？

説明のための資料作成などの大掛かりな準備は
“現段階では”　必要ないので、
内容を口頭で教えて頂けたらと思います。

来週の月曜の都合のいい時間でお願いできますか？
~17時から~
13時から30分ー1時間とかはどうでしょう？~（16時でもOK）~
予定合う方はご参加ください。

<https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1713261064810859?thread_ts=1711560374.301829&cid=C03C62NBSDP|https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1713261064810859?thread_ts=1711560374.301829&cid=C03C62NBSDP>
  - attachments: [{"from_url": "https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1713261064810859?thread_ts=1711560374.301829&amp;cid=C03C62NBSDP", "ts": "1713261064.810859", "author_id": "U05KGS6HN9H", "channel_id": "C03C62NBSDP", "channel_team": "T033D70RR6H", "is_msg_unfurl": true, "is_reply_unfurl": true, "message_blocks": [{"team": "T033D70RR6H", "channel": "C03C62NBSDP", "ts": "1713261064.810859", "message": {"blocks": [{"type": "rich_text", "block_id": "sDi0v", "elements": [{"type": "rich_text_section", "elements": [{"type": "user", "user_id": "U0331FWGQRM"}, {"type": "text", "text": "\n"}, {"type": "user", "user_id": "U041RJKV5JA"}, {"type": "text", "text": " "}, {"type": "user", "user_id": "U033G4KN4TD"}, {"type": "text", "text": "\nリーファーコンテナでの見積試算を報告いたします。\n一部推定値も含まれますので、概算としてご理解のほどお願い致します。\n資料等は以下に保存致します。\n海外営業〉フィルピン〉Ralph Go〉リーファーコンテナ輸出試算"}]}]}]}}], "files": [{"id": "F06U2N42E4X", "created": 1713261044, "timestamp": 1713261044, "name": "フィリピン向けリーファーコンテナ輸出見積概要一覧.pdf", "title": "フィリピン向けリーファーコンテナ輸出見積概要一覧.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 414057, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06U2N42E4X/________________________________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06U2N42E4X/download/________________________________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F06U2N42E4X-dd14872272/_________________________________________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1383, "thumb_pdf_h": 978, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06U2N42E4X/________________________________________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F06U2N42E4X-0f8217a643", "comments_count": 0, "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}, {"id": "F06UKNV9YKE", "created": 1713261050, "timestamp": 1713261050, "name": "フィリピン向けリーファーコンテナ輸出見積内訳.pdf", "title": "フィリピン向けリーファーコンテナ輸出見積内訳.pdf", "mimetype": "application/pdf", "filetype": "pdf", "pretty_type": "PDF", "user": "U05KGS6HN9H", "user_team": "T033D70RR6H", "editable": false, "size": 541681, "mode": "hosted", "is_external": false, "external_type": "", "is_public": true, "public_url_shared": false, "display_as_bot": false, "username": "", "url_private": "https://files.slack.com/files-pri/T033D70RR6H-F06UKNV9YKE/__________________________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "url_private_download": "https://files.slack.com/files-pri/T033D70RR6H-F06UKNV9YKE/download/__________________________________________________________________.pdf?token=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "media_display_type": "unknown", "thumb_pdf": "https://files.slack.com/files-tmb/T033D70RR6H-F06UKNV9YKE-f11b5d098e/___________________________________________________________________thumb_pdf.png?t=xoxe-3115238875221-9710624591398-9697214945543-aa82359f925d11baadb4ddc07b089467", "thumb_pdf_w": 1513, "thumb_pdf_h": 1070, "permalink": "https://grp-ssm9297.slack.com/files/U0331FWGQRM/F06UKNV9YKE/__________________________________________________________________.pdf", "permalink_public": "https://slack-files.com/T033D70RR6H-F06UKNV9YKE-f85d29d9fe", "comments_count": 0, "is_starred": false, "skipped_shares": true, "has_rich_preview": false, "file_access": "visible"}], "id": 1, "original_url": "https://grp-ssm9297.slack.com/archives/C03C62NBSDP/p1713261064810859?thread_ts=1711560374.301829&amp;cid=C03C62NBSDP", "fallback": "[April 16th, 2024 2:51 AM] tousuien05: <@U0331FWGQRM>\n<@U041RJKV5JA> <@U033G4KN4TD>\nリーファーコンテナでの見積試算を報告いたします。\n一部推定値も含まれますので、概算としてご理解のほどお願い致します。\n資料等は以下に保存致します。\n海外営業〉フィルピン〉Ralph Go〉リーファーコンテナ輸出試算", "text": "<@U0331FWGQRM>\n<@U041RJKV5JA> <@U033G4KN4TD>\nリーファーコンテナでの見積試算を報告いたします。\n一部推定値も含まれますので、概算としてご理解のほどお願い致します。\n資料等は以下に保存致します。\n海外営業〉フィルピン〉Ralph Go〉リーファーコンテナ輸出試算", "author_name": "足立", "author_link": "https://grp-ssm9297.slack.com/team/U05KGS6HN9H", "author_icon": "https://secure.gravatar.com/avatar/c4e7258333f2958f831d063db85b4542.jpg?s=48&d=https%3A%2F%2Fa.slack-edge.com%2Fdf10d%2Fimg%2Favatars%2Fava_0005-48.png", "author_subname": "足立", "mrkdwn_in": ["text"], "footer": "Slack の会話内のスレッド"}]

## 2024-04-20

- [1713642337.157409] <@U0606SPN4BW>: <@U0331FWGQRM> <@U05KGS6HN9H>
&gt; 17時から30分ー1時間とかはどうでしょう？（16時でもOK）
&gt; 予定合う方はご参加ください。
16:00開始の場合は少し遅れての参加となるかもですが、参加させて頂きます。よろしくお願いします！＾＾
- [1713661838.897959] <@U0331FWGQRM>: <@U0606SPN4BW> 
その場合録画しておくので、またあとで渡しますね。

## 2024-04-21

- [1713684141.445229] <@U0331FWGQRM>: <@U05KGS6HN9H> 
すみません、13:00に変更でお願いできますか?
- [1713751479.328029] <@U0331FWGQRM>: <@U0331FZS7JT> <@U066P20UQH1>
時間変更になりました。
宜しくお願いします！
- [1713751579.509139] <@U0331FZS7JT>: <@U0331FWGQRM> <@U05KGS6HN9H> <@U033G4KN4TD>

参加 Zoom ミーティング
<https://us02web.zoom.us/j/6742855944?omn=88355822095>

ミーティング ID: <tel:6742855944|674 285 5944>
- [1713753247.338039] <@U0331FWGQRM>: <@U066P20UQH1>
今週のMTGですが、
明日の10:00に変更して頂けますか？:sweat_drops:
宜しくお願いします！
- [1713753858.835339] <@U0331FWGQRM>: <@U0331FZS7JT> <@U0606SPN4BW>
~6/3~  5/3のMTGですが、
祝日なので、~6/2~ 5/2に変更しますね。
宜しくお願いします。
- [1713761837.790399] <@U066P20UQH1>: <@U0331FZS7JT> <@U0331FWGQRM> <@U05KGS6HN9H> <@U041RJKV5JA> <@U033G4KN4TD> <@U0606SPN4BW>
<@U05KGS6HN9H> さん、先程は大変わかりやすい説明をありがとうございました！！
みなさま、
録画されているので不要かもですが、一応雑ですが議事録も取っておりましたので共有しておきます:bow:
<https://docs.google.com/spreadsheets/d/14q2n1Byihey0K115Lkh0zAtBk-0FLpyumYFmhaODKwE/edit#gid=519892887>

## 2024-04-22

- [1713774072.871199] <@U0331FZS7JT>: <@U0331FWGQRM> <@U05KGS6HN9H> <@U041RJKV5JA> <@U033G4KN4TD> <@U0606SPN4BW><@U066P20UQH1><@U0331FZTHEK>
<https://youtu.be/8i2H3fObH64>

本日のMTGの録画を送ります。
画質をHD・4Kなどでも処理しているため
完全にアップロードが終わるのはあと２時間かかりますが
標準画質では処理が終わっているので、確認できます！
<@U0606SPN4BW>
またお手隙の際にご確認、よろしくお願いします！
  - attachments: [{"from_url": "https://youtu.be/8i2H3fObH64", "service_icon": "https://a.slack-edge.com/80588/img/unfurl_icons/youtube.png", "thumb_url": "https://i.ytimg.com/vi/8i2H3fObH64/hqdefault.jpg", "thumb_width": 480, "thumb_height": 360, "video_html": "<iframe width=\"400\" height=\"300\" src=\"https://www.youtube.com/embed/8i2H3fObH64?feature=oembed&autoplay=1&iv_load_policy=3\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen title=\"海外営業・事務MTG（船便について）\"></iframe>", "video_html_width": 400, "video_html_height": 300, "id": 1, "original_url": "https://youtu.be/8i2H3fObH64", "fallback": "YouTube Video: 海外営業・事務MTG（船便について）", "title": "海外営業・事務MTG（船便について）", "title_link": "https://youtu.be/8i2H3fObH64", "author_name": "祐太", "author_link": "https://www.youtube.com/@user-to3ef4be4l", "service_name": "YouTube", "service_url": "https://www.youtube.com/"}]
- [1713834081.429169] <@U0331FWGQRM>: <@U066P20UQH1>
<https://meet.google.com/cae-vmwq-epy>
  - attachments: [{"from_url": "https://meet.google.com/cae-vmwq-epy", "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "id": 1, "original_url": "https://meet.google.com/cae-vmwq-epy", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/cae-vmwq-epy", "service_name": "meet.google.com"}]

## 2024-04-25

- [1714093211.296229] <@U0331FZS7JT>: <@U0331FWGQRM>
<https://meet.google.com/itx-hbkv-iif>
オネシャス！
  - attachments: [{"from_url": "https://meet.google.com/itx-hbkv-iif", "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "id": 1, "original_url": "https://meet.google.com/itx-hbkv-iif", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/itx-hbkv-iif", "service_name": "meet.google.com"}]

## 2024-04-30

- [1714525265.762919] <@U066P20UQH1>: <@U0331FWGQRM>
<https://meet.google.com/iru-hyhn-dhw>
こちらからお願いします！
  - attachments: [{"from_url": "https://meet.google.com/iru-hyhn-dhw", "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "id": 1, "original_url": "https://meet.google.com/iru-hyhn-dhw", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/iru-hyhn-dhw", "service_name": "meet.google.com"}]

## 2024-06-28

- [1719568406.842709] <@U0331FWGQRM>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
7/2（火）海外営業全体MTG
- [1719568488.130729] <@U0331FWGQRM>: メモ
・取扱商品一覧解説
∟見積り提案時に提案内容を迷わない為に情報共有・確認。

松井todo
・quotation整理
・specification、COA整理

## 2024-07-02

- [1719907147.080709] <@U0331FWGQRM>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
<https://meet.google.com/vbx-arvu-joe>
  - attachments: [{"from_url": "https://meet.google.com/vbx-arvu-joe", "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "id": 1, "original_url": "https://meet.google.com/vbx-arvu-joe", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/vbx-arvu-joe", "service_name": "meet.google.com"}]
- [1719910871.231489] <@U0331FWGQRM>: <https://meet.google.com/nrp-wcjt-ohf>
  - attachments: [{"from_url": "https://meet.google.com/nrp-wcjt-ohf", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "id": 1, "original_url": "https://meet.google.com/nrp-wcjt-ohf", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/nrp-wcjt-ohf", "service_name": "meet.google.com"}]
- [1719914541.087439] <@U0331FWGQRM>: <https://meet.google.com/yvv-abmv-prw>
  - attachments: [{"from_url": "https://meet.google.com/yvv-abmv-prw", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "id": 1, "original_url": "https://meet.google.com/yvv-abmv-prw", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/yvv-abmv-prw", "service_name": "meet.google.com"}]

## 2024-07-29

- [1722252072.950119] <@U0331FWGQRM>: *<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>* 
*8/6（火）海外営業全体MTG*
- [1722252243.072239] <@U0331FWGQRM>: ・現状ヒアリング（古川・林）
・JONAについて。SOAAとの違いについて確認したい。
・Decaf matchaについて。（現状確認の上、今後の方針）
・ブレンド抹茶について。（現状共有の上、今後の方針）
・有機認証@オランダについて。
・冷蔵庫購入について。
・缶の試験成績書について（タマヤ、奥村、中国、日東だけない。）
・サイクロデキストリン　シールドラボ

## 2024-09-03

- [1725350332.366919] <@U0331FZS7JT>: *<!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>*
*本日9/3（火）海外営業全体MTG*
<https://us02web.zoom.us/j/84465341116?pwd=RFxAvJbaFSf08Sw9SxZ1SzGv5n9AIP.1>
URL送ります。よろしくお願いします。

## 2024-10-01

- [1727769395.951809] <@U0331FZS7JT>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
*本日10/1（火）17:00-*
*海外営業全体MTG*
<https://us02web.zoom.us/j/82920003143?pwd=tPB2VBpo5ZZlmHKpg13QywAkmqDPWp.1>
URL送ります。よろしくお願いします。

## 2024-12-01

- [1733104651.213579] <@U082RF7UF1V>: <@U082RF7UF1V>さんがチャンネルに参加しました

## 2024-12-05

- [1733469344.374149] <@U0840UVFVA8>: <@U0840UVFVA8>さんがチャンネルに参加しました

## 2024-12-23

- [1734959893.835289] <@U0331FWGQRM>: <!subteam^S072Q871SF9|@oka-matsui-furukawa-hayashi-kimura-hasegawa-kawatani>
12/27MTG議題
- [1734959910.392639] <@U0331FWGQRM>: オランダ→EU各国について。
<https://grp-ssm9297.slack.com/archives/C033G42K9DG/p1734959860830039?thread_ts=1734959733.685449&amp;cid=C033G42K9DG>
  - attachments: [{"from_url": "https://grp-ssm9297.slack.com/archives/C033G42K9DG/p1734959860830039?thread_ts=1734959733.685449&amp;cid=C033G42K9DG", "ts": "1734959860.830039", "author_id": "U0331FWGQRM", "channel_id": "C033G42K9DG", "channel_team": "T033D70RR6H", "is_msg_unfurl": true, "is_reply_unfurl": true, "message_blocks": [{"team": "T033D70RR6H", "channel": "C033G42K9DG", "ts": "1734959860.830039", "message": {"blocks": [{"type": "rich_text", "block_id": "WuFJ9", "elements": [{"type": "rich_text_section", "elements": [{"type": "text", "text": "・アカウントは、古川さんのアカウントですか？\n・請求はどこにされますか？（JP free birds？)\n・桃翠園のアカウントは作成可能ですか？\n（屋号だけとかでも可能？お客様にはTOUSUIENから来たとわかる？）\n\nまたMTGで相談させてください。"}]}]}]}}], "id": 1, "original_url": "https://grp-ssm9297.slack.com/archives/C033G42K9DG/p1734959860830039?thread_ts=1734959733.685449&amp;cid=C033G42K9DG", "fallback": "[December 23rd, 2024 5:17 AM] tousuien.matsui: ・アカウントは、古川さんのアカウントですか？\n・請求はどこにされますか？（JP free birds？)\n・桃翠園のアカウントは作成可能ですか？\n（屋号だけとかでも可能？お客様にはTOUSUIENから来たとわかる？）\n\nまたMTGで相談させてください。", "text": "・アカウントは、古川さんのアカウントですか？\n・請求はどこにされますか？（JP free birds？)\n・桃翠園のアカウントは作成可能ですか？\n（屋号だけとかでも可能？お客様にはTOUSUIENから来たとわかる？）\n\nまたMTGで相談させてください。", "author_name": "matsui", "author_link": "https://grp-ssm9297.slack.com/team/U0331FWGQRM", "author_icon": "https://secure.gravatar.com/avatar/f9d05f2cae161f657bb1248fc85b5235.jpg?s=48&d=https%3A%2F%2Fa.slack-edge.com%2Fdf10d%2Fimg%2Favatars%2Fava_0008-48.png", "author_subname": "matsui", "mrkdwn_in": ["text"], "footer": "Slack の会話内のスレッド"}]

## 2024-12-26

- [1735261053.299989] <@U0331FWGQRM>: <@U066P20UQH1> <@U0331FZS7JT>
<https://meet.google.com/ruy-ybns-xuu>
  - attachments: [{"from_url": "https://meet.google.com/ruy-ybns-xuu", "service_icon": "http://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-24dp/logo_meet_2020q4_color_1x_web_24dp.png", "thumb_url": "https://fonts.gstatic.com/s/i/productlogos/meet_2020q4/v1/web-96dp/logo_meet_2020q4_color_2x_web_96dp.png", "thumb_width": 192, "thumb_height": 192, "id": 1, "original_url": "https://meet.google.com/ruy-ybns-xuu", "fallback": "Meet", "text": "Real-time meetings by Google. Using your browser, share your video, desktop, and presentations with teammates and customers.", "title": "Meet", "title_link": "https://meet.google.com/ruy-ybns-xuu", "service_name": "meet.google.com"}]
- [1735279813.126869] <@U0331FWGQRM>: <@U0606SPN4BW> <@U0331FZS7JT> 
すみません、発熱しちゃいまして、
今日のミーティング延期でお願いできますでしょうか？

すみませんが宜しくお願い致します


## 2025-03-03

- [1741050946.976599] <@U08FZUNPSQ3>: <@U08FZUNPSQ3>さんがチャンネルに参加しました

## 2025-03-31

- [1743469444.817199] <@U08L89G6JSG>: <@U08L89G6JSG>さんがチャンネルに参加しました

## 2025-04-13

- [1744592905.380999] <@U08N3SKSL75>: <@U08N3SKSL75>さんがチャンネルに参加しました

## 2025-04-20

- [1745195461.225819] <@U08NVD403GV>: <@U08NVD403GV>さんがチャンネルに参加しました

## 2025-05-06

- [1746589948.804609] <@U08RVRNBY00>: <@U08RVRNBY00>さんがチャンネルに参加しました

## 2025-05-28

- [1748485110.742959] <@U08U8MMTH43>: <@U08U8MMTH43>さんがチャンネルに参加しました

## 2025-06-02

- [1748914893.646389] <@U08V56G9U92>: <@U08V56G9U92>さんがチャンネルに参加しました

## 2025-07-13

- [1752475114.880409] <@U095LLEH09G>: <@U095LLEH09G>さんがチャンネルに参加しました

## 2025-09-01

- [1756788858.837819] <@U09DF1SDTQR>: <@U09DF1SDTQR>さんがチャンネルに参加しました

